<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/portal-view.php';
$account = portal_require_account();
$parts = portal_parts((int)$account['id']);
$title = setting('customer.catalog_title', 'قطعات آسانسور شما');
$brands = array_values(array_unique(array_filter(array_map(static fn($p) => trim($p['brand']), $parts), 'portal_has')));
natcasesort($brands);
portal_start($account, $title, 'parts');
portal_intro($title, 'جست‌وجوی تجهیزات ثبت‌شده، مشخصات نصب و اطلاعات ضمانت.', 'کاتالوگ قطعات');
?>
<?php if (!$parts): ?>
    <?php portal_empty('box', 'هنوز قطعه‌ای ثبت نشده است', 'قطعات پس از ثبت توسط مدیریت در کاتالوگ شما نمایش داده می‌شوند.'); ?>
<?php else: ?>
    <div class="pp-catalog" data-catalog>
        <div class="pp-card pp-catalog-tools">
            <div data-catalog-controls hidden>
                <label class="pp-search"><?=portal_icon('search', 18)?><span class="pp-sr">جست‌وجو در قطعات</span><input type="search" data-part-search placeholder="نام، سازنده، مدل یا سریال" autocomplete="off"></label>
                <div class="pp-filter-row">
                    <label><span>سازنده</span><select data-part-brand><option value="">همه</option><?php foreach ($brands as $brand): ?><option value="<?=e($brand)?>"><?=e($brand)?></option><?php endforeach ?></select></label>
                    <label><span>فیلتر</span><select data-part-filter><option value="">همه</option><option value="image">دارای تصویر</option><option value="warranty">دارای اطلاعات ضمانت</option></select></label>
                    <label><span>ترتیب</span><select data-part-sort><option value="new">جدیدترین</option><option value="name">نام قطعه</option><option value="brand">سازنده</option></select></label>
                </div>
            </div>
            <div class="pp-catalog-actions"><a class="pp-btn" href="catalog-print.php"><?=portal_icon('print', 17)?> چاپ کاتالوگ</a><button type="button" class="pp-btn" data-part-view aria-pressed="false" hidden>نمای فهرست</button></div>
        </div>
        <p class="pp-count pp-small pp-muted" role="status" data-part-count><?=fa_digits(count($parts))?> قطعه</p>
        <div class="pp-card-grid pp-parts-grid" data-part-list><?php foreach ($parts as $part) portal_part_card($part, true); ?></div>
        <div data-part-empty hidden><?php portal_empty('search', 'قطعه‌ای با این شرایط پیدا نشد', 'جست‌وجو یا فیلترها را تغییر دهید.'); ?></div>
    </div>
<?php endif ?>
<?php portal_end(); ?>

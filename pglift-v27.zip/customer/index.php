<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/portal-view.php';
require_once __DIR__ . '/../inc/customer-schema.php';
require_once __DIR__ . '/../inc/features.php';
if (!gf_is_configured()) redirect('../install.php');
portal_private_headers();

$error = '';
$account = null;
try {
    // v24 loaded these legacy schemas on first use. New portal tables are migrated only by the installer/admin.
    customer_schema();
    $magic = is_string($_GET['t'] ?? null) ? trim($_GET['t']) : '';
    if ($magic !== '') {
        $match = preg_match('/^[a-f0-9]{32,64}$/iD', $magic)
            ? q_one("SELECT id,password_hash FROM customer_accounts WHERE login_token=? AND login_token<>'' AND login_link_enabled=1", [$magic]) : null;
        if ($match) {
            session_regenerate_id(true);
            $_SESSION['customer_id'] = (int)$match['id'];
            $_SESSION['customer_password_hash'] = $match['password_hash'];
            redirect('index.php');
        }
        $error = 'لینک ورود غیرفعال یا نامعتبر است. از مدیریت لینک فعال بگیرید.';
    }
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        if (!csrf_check(is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : null)) {
            http_response_code(403);
            exit('توکن امنیتی نامعتبر است.');
        }
        $action = $_POST['action'] ?? 'login';
        if ($action === 'logout') {
            unset($_SESSION['customer_id'], $_SESSION['customer_password_hash']);
            session_regenerate_id(true);
            redirect('index.php');
        }
        if ($action === 'login') {
            $username = is_string($_POST['username'] ?? null) ? trim($_POST['username']) : '';
            $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';
            $key = hash('sha256', (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
            $attempt = q_one('SELECT attempts,last_attempt FROM customer_login_attempts WHERE attempt_key=?', [$key]);
            $recent = $attempt && (int)$attempt['last_attempt'] > time() - 300;
            if ($recent && (int)$attempt['attempts'] >= 6) {
                $error = 'تلاش‌های ورود بیش از حد است؛ پنج دقیقه بعد دوباره تلاش کنید.';
            } else {
                $match = q_one('SELECT id,password_hash FROM customer_accounts WHERE username=?', [$username]);
                if ($match && password_verify($password, $match['password_hash'])) {
                    q('DELETE FROM customer_login_attempts WHERE attempt_key=?', [$key]);
                    session_regenerate_id(true);
                    $_SESSION['customer_id'] = (int)$match['id'];
                    $_SESSION['customer_password_hash'] = $match['password_hash'];
                    redirect('index.php');
                }
                $attempts = $recent ? (int)$attempt['attempts'] + 1 : 1;
                if ($attempt) q('UPDATE customer_login_attempts SET attempts=?,last_attempt=? WHERE attempt_key=?', [$attempts,time(),$key]);
                else q('INSERT INTO customer_login_attempts (attempt_key,attempts,last_attempt) VALUES (?,?,?)', [$key,$attempts,time()]);
                $error = 'نام کاربری یا رمز عبور نادرست است.';
            }
        }
    }
    $account = portal_account();
    if ($account) {
        $customerId = (int)$account['id'];
        feature_schema();
        $contracts = portal_contracts($customerId);
        $maintenance = portal_maintenance_snapshot(portal_visits($customerId));
        $profile = portal_profile($customerId);
        $type = portal_type($account);
        $parts = portal_parts($customerId);
        $projects = portal_projects($customerId);
        $project = $projects[0] ?? null;
        $stageGroups = $project ? portal_stage_groups(portal_stages((int)$project['id'], $customerId)) : [];
        $maintenanceContracts = portal_maintenance_contracts($customerId);
        $stories = array_values(array_filter(active_stories(30, 'customer'), static fn($story) =>
            preg_match('#^uploads/stories/videos/[A-Za-z0-9_.-]+\.(?:mp4|webm|ogv)$#iD', $story['video_path'])));
    }
} catch (PDOException $exception) {
    error_log('Customer portal: '.$exception->getMessage());
    $error = 'دسترسی به پرونده در حال حاضر ممکن نیست. لطفاً دوباره تلاش کنید یا با پشتیبانی تماس بگیرید.';
    if ($account) {
        http_response_code(503);
        portal_start($account, 'پنل مشتریان', 'home');
        portal_intro('پنل مشتریان');
        portal_empty('lift', 'پرونده در دسترس نیست', $error);
        portal_end();
        return;
    }
}

portal_start($account, 'پنل مشتریان', $account ? 'home' : '');
if (!$account): ?>
<div class="pp-login">
    <section class="pp-login-intro">
        <span class="pp-eyebrow"><i></i>همراه شما در هر طبقه</span>
        <h1>پروندهٔ آسانسور شما، <em>در یک نگاه</em></h1>
        <p>مراحل نصب، گزارش‌های سرویس، قراردادها و مشخصات قطعات را در فضای اختصاصی پروژه پیگیری کنید.</p>
        <div class="pp-login-lift" aria-hidden="true"><img src="../assets/img/cabin-copper-sm.webp" alt=""></div>
    </section>
    <form class="pp-card pp-login-form" method="post" action="index.php">
        <span class="pp-tiny-icon"><?=portal_icon('lift', 21)?></span>
        <h2>ورود به پنل مشتری</h2>
        <p class="pp-muted">با نام کاربری و رمز عبور، یا لینک اختصاصی مدیریت وارد شوید.</p>
        <?php if ($error): ?><p class="pp-alert" role="alert"><?=e($error)?></p><?php endif ?>
        <?=csrf_field()?><input type="hidden" name="action" value="login">
        <label>نام کاربری<input name="username" required autocomplete="username" autocapitalize="off" spellcheck="false" dir="ltr"></label>
        <label>رمز عبور<span class="pp-password"><input type="password" name="password" required autocomplete="current-password" dir="ltr" data-password><button type="button" aria-pressed="false" data-password-toggle hidden>نمایش</button></span></label>
        <button type="submit" class="pp-btn pp-btn-primary">ورود به پنل <?=portal_icon('arrow', 17)?></button>
        <?php if ($phone = portal_phone()): ?><a class="pp-text-link" href="tel:<?=e($phone)?>"><?=portal_icon('phone', 17)?> راهنمای ورود</a><?php endif ?>
    </form>
</div>
<?php else:
$activeContract = null;
$activeMaintenance = null;
foreach ($contracts as $option) if ($option['status'] === 'active') { $activeContract = $option; break; }
foreach ($maintenanceContracts as $option) if ($option['status'] === 'active') { $activeMaintenance = $option; break; }
$representativeMaintenance = $activeMaintenance ?? $maintenanceContracts[0] ?? null;
$representativeContract = $representativeMaintenance ?? $activeContract ?? $contracts[0] ?? null;
?>
<div id="overview" class="pp-dashboard-title">
    <?php portal_intro('نمای کلی پروژه', 'سلام، '.$account['name'], 'پروندهٔ مشتری'); ?>
    <?php if (!empty(gf_config()['portal_demo'])): ?><span class="pp-demo-label">نسخه نمایشی · داده‌های نمونه</span><?php endif ?>
</div>
<?php if ($error): ?><p class="pp-alert" role="alert"><?=e($error)?></p><?php endif ?>
<div class="pp-hero-grid">
    <section class="pp-lift-card" id="type-dossier" aria-labelledby="lift-title">
        <div class="pp-lift-main">
            <div class="pp-lift-copy">
                <div class="pp-lift-status"><span class="pp-lift-label"><?=portal_icon('lift', 16)?> آسانسور شما</span>
                    <?=portal_badge($profile['operational_status'] ?? null, PORTAL_OPERATIONAL_STATUSES, 'وضعیت بهره‌برداری ثبت نشده')?></div>
                <h2 id="lift-title"><?=e($type['title'] ?? 'پروندهٔ آسانسور')?></h2>
                <?php if (portal_has($profile['installation_location'] ?? null)): ?><p class="pp-inline pp-lift-location"><?=portal_icon('pin', 16)?><?=e($profile['installation_location'])?></p><?php endif ?>
            </div>
            <figure class="pp-lift-art"><?php if (!empty($type['image'])): ?><img src="<?=e($type['image'])?>" alt="تصویر نمونهٔ <?=e($type['title'])?>" decoding="async"><?php else: ?><?=portal_icon('lift', 52)?><?php endif ?></figure>
        </div>
        <?php portal_facts(['سیستم محرکه' => $profile['drive_system'] ?? '', 'ظرفیت نامی' => $profile['rated_capacity'] ?? '', 'طبقات' => $profile['floors'] ?? '']); ?>
        <a class="pp-btn pp-btn-lift" href="elevator-details.php">مشاهده مشخصات کامل آسانسور <?=portal_icon('arrow', 17)?></a>
    </section>
    <section class="pp-card pp-install-card" aria-labelledby="install-title">
        <div class="pp-install-heading"><span class="pp-section-icon"><?=portal_icon('layers', 22)?></span><div><span class="pp-small pp-muted">نصب و راه‌اندازی</span><h2 id="install-title"><?=e($project['title'] ?? 'پیشرفت نصب')?></h2></div></div>
        <?php if ($project): ?>
            <?php if ($project['progress'] !== null): portal_progress($project['progress'], 'پیشرفت کلی پروژه'); else: ?><p class="pp-small pp-muted">درصد پیشرفت ثبت نشده است.</p><?php endif ?>
            <?php portal_facts(['مرحلهٔ جاری' => $stageGroups['current'][0]['title'] ?? 'ثبت نشده', 'پایان پیش‌بینی‌شده' => $project['expected_completion_date']]); ?>
        <?php else: ?><p class="pp-muted">مراحل نصب پس از ثبت پروژه در دسترس قرار می‌گیرند.</p><?php endif ?>
        <div class="pp-install-bottom">
            <a class="pp-text-link" href="installation.php<?= $project ? '?id='.(int)$project['id'] : '' ?>">مشاهده مراحل نصب <?=portal_icon('arrow', 16)?></a>
            <?php if (!empty($stageGroups['completed'])): ?><span class="pp-small pp-muted pp-inline"><?=portal_icon('check', 15)?> <?=fa_digits(count($stageGroups['completed']))?> مرحله تکمیل شده</span><?php endif ?>
        </div>
    </section>
</div>
<section class="pp-section" id="services">
    <?php portal_section_head(setting('customer.services_title', 'سرویس و نگهداری'), 'tool', 'maintenance.php', 'مرکز نگهداری'); ?>
    <div class="pp-metric-grid">
        <article class="pp-card pp-metric pp-metric-next"><span class="pp-section-icon"><?=portal_icon('calendar', 19)?></span><div><small>سرویس بعدی</small><b><bdi><?=e($maintenance['next']['date'] ?? 'ثبت نشده')?></bdi></b></div></article>
        <article class="pp-card pp-metric"><span class="pp-section-icon"><?=portal_icon('tool', 19)?></span><div><small>وضعیت نگهداری</small><?=portal_badge($profile['maintenance_status'] ?? null, PORTAL_MAINTENANCE_STATUSES)?></div></article>
        <article class="pp-card pp-metric"><span class="pp-section-icon"><?=portal_icon('check', 19)?></span><div><small>آخرین سرویس تکمیل‌شده</small><b><bdi><?=e($maintenance['last']['service_date'] ?? 'ثبت نشده')?></bdi></b></div></article>
        <article class="pp-card pp-metric"><span class="pp-section-icon"><?=portal_icon('file', 19)?></span><div><small><?= $representativeMaintenance ? 'قرارداد نگهداری' : 'وضعیت قرارداد' ?></small><?=portal_badge($representativeContract['status'] ?? null, PORTAL_CONTRACT_STATUSES)?></div></article>
    </div>
</section>
<section class="pp-section" id="contracts">
    <?php portal_section_head(setting('customer.contracts_title', 'قراردادهای من'), 'file', 'contracts.php', 'همه قراردادها'); ?>
    <?php if (!$contracts): ?>
        <?php portal_empty('file', 'قراردادی ثبت نشده است'); ?>
    <?php else: ?>
        <div class="pp-card-grid"><?php foreach (array_slice($contracts, 0, 3) as $contract) portal_contract_card($contract); ?></div>
    <?php endif ?>
</section>
<section class="pp-section" id="products">
    <?php portal_section_head(setting('customer.catalog_title', 'قطعات آسانسور شما'), 'box', 'parts.php', 'همه قطعات'); ?>
    <?php if (!$parts): ?>
        <?php portal_empty('box', 'هنوز قطعه‌ای ثبت نشده است'); ?>
    <?php else: ?>
        <div class="pp-card-grid pp-parts-grid"><?php foreach (array_slice($parts, 0, 3) as $part) portal_part_card($part); ?></div>
    <?php endif ?>
</section>
<?php if ($stories): ?>
<section class="pp-section" id="stories">
    <?php portal_section_head('داستان‌ها و پروژه‌های شرکت', 'play'); ?>
    <div class="pp-story-grid" data-stories>
        <?php foreach ($stories as $story):
            $poster = preg_match('#^uploads/stories/posters/[A-Za-z0-9_.-]+\.(?:jpg|jpeg|png|webp)$#iD', $story['poster_path']) ? '../'.$story['poster_path'] : ''; ?>
            <a class="pp-card pp-story" href="../<?=e($story['video_path'])?>" data-story data-title="<?=e($story['title'])?>" data-caption="<?=e(implode(' · ', array_filter([$story['company'], $story['subtitle']])))?>" data-poster="<?=e($poster)?>">
                <?php if ($poster): ?><img src="<?=e($poster)?>" alt="" loading="lazy"><?php endif ?>
                <span class="pp-tiny-icon"><?=portal_icon('play', 19)?></span><b><?=e($story['title'])?></b>
            </a>
        <?php endforeach ?>
    </div>
    <dialog class="pp-story-dialog" data-story-dialog aria-labelledby="pp-story-title">
        <div class="pp-card-top"><h3 id="pp-story-title"></h3><form method="dialog"><button type="submit" class="pp-btn">بستن</button></form></div>
        <video controls playsinline preload="none"></video><p data-story-caption></p>
        <div class="pp-actions"><button type="button" class="pp-btn" data-story-prev>قبلی</button><span class="pp-small pp-muted" data-story-position></span><button type="button" class="pp-btn" data-story-next>بعدی</button></div>
    </dialog>
</section>
<?php endif ?>
<?php endif; portal_end(); ?>

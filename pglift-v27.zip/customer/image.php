<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/portal.php';
portal_private_headers();
$id = portal_id($_GET['id'] ?? null);
$part = null;
if ($id && gf_is_configured()) {
    if (current_user()) {
        $part = q_one('SELECT image_ref FROM customer_parts WHERE id=?', [$id]);
    } elseif ($customer = portal_account()) {
        $part = q_one('SELECT image_ref FROM customer_parts WHERE id=? AND customer_id=?', [$id, (int)$customer['id']]);
    }
}
if (!$part) { http_response_code(404); exit; }
$ref = (string)$part['image_ref'];
if (preg_match('#^private/([a-f0-9]{32}\.(?:jpg|png|webp))$#D', $ref, $m)) {
    $file = dirname(__DIR__).'/data/customer-images/'.$m[1];
} elseif (preg_match('#^(assets/img/parts|uploads/parts)/[A-Za-z0-9_.-]+\.(?:webp|png|jpg|jpeg)$#iD', $ref)) {
    $file = dirname(__DIR__).'/'.$ref;
} else { http_response_code(404); exit; }
$info = @getimagesize($file);
$mime = [IMAGETYPE_JPEG => 'image/jpeg', IMAGETYPE_PNG => 'image/png', IMAGETYPE_WEBP => 'image/webp'];
if (!$info || !isset($mime[$info[2]]) || !is_file($file)) { http_response_code(404); exit; }
session_write_close();
header('Cross-Origin-Resource-Policy: same-origin');
header('Content-Type: '.$mime[$info[2]]);
header('Content-Length: '.filesize($file));
readfile($file);

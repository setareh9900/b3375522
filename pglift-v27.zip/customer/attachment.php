<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/portal-media.php';
$account = gf_is_configured() ? portal_account() : null;
portal_media_send(portal_id($_GET['id'] ?? null), $account ? (int)$account['id'] : null, ($_GET['download'] ?? '') === '1');

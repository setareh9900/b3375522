<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/portal-view.php';
$account = portal_require_account();
$customerId = (int)$account['id'];
$profile = portal_profile($customerId);
$type = portal_type($account);
$parts = portal_parts($customerId);
$rawAudio = trim($account['elevator_audio'] ?? '') ?: trim($type['audio'] ?? '');
$audioUrl = preg_match('#^uploads/audio/[A-Za-z0-9_.-]+\.(mp3|m4a|ogg|wav|webm)$#iD', $rawAudio) ? '../api/audio.php?f='.rawurlencode(basename($rawAudio)) : '';
$speech = trim($account['elevator_details'] ?? '') ?: trim($type['speech'] ?? $type['article'] ?? '');
$isGeneralAudio = !portal_has($account['elevator_audio'] ?? null) && ($audioUrl !== '' || !portal_has($account['elevator_details'] ?? null));
$profileFacts = static function (array $fields, bool $withType = false) use ($profile, $type): void {
    $facts = $withType ? ['نوع آسانسور' => $type['title'] ?? ''] : [];
    foreach ($fields as $field) $facts[PORTAL_PROFILE_FIELDS[$field]] = $profile[$field] ?? '';
    if (array_filter($facts, 'portal_has')) portal_facts($facts); else portal_note(null);
};
portal_start($account, 'مشخصات کامل آسانسور', 'home');
portal_intro('مشخصات کامل آسانسور', 'پروندهٔ فنی دستگاه، تجهیزات نصب‌شده و اطلاعات ضمانت.', 'پرونده فنی', 'index.php#type-dossier', 'نمای کلی');
?>
<section class="pp-card pp-profile-head">
    <figure class="pp-profile-image"><?php if (!empty($type['image'])): ?><img src="<?=e($type['image'])?>" alt="تصویر نمونهٔ <?=e($type['title'])?>"><?php else: ?><?=portal_icon('lift', 35)?><?php endif ?></figure>
    <div><h2><?=e($type['title'] ?? 'آسانسور شما')?></h2>
        <?=portal_badge($profile['operational_status'] ?? null, PORTAL_OPERATIONAL_STATUSES, 'وضعیت بهره‌برداری ثبت نشده') ?>
        <?php if (portal_has($profile['installation_location'] ?? null)): ?><p class="pp-inline pp-muted pp-small"><?=portal_icon('pin', 16)?><?=e($profile['installation_location'])?></p><?php endif ?>
    </div>
</section>
<div class="pp-disclosures pp-section">
    <?php
    portal_disclosure('مشخصات عمومی', static function () use ($profileFacts, $profile, $account, $audioUrl, $speech, $isGeneralAudio): void {
        $profileFacts(['drive_system', 'rated_capacity', 'passengers', 'floors', 'rated_speed', 'installation_location'], true);
        if (portal_has($profile['other_specs'] ?? null)) portal_note($profile['other_specs']);
        if (portal_has($account['elevator_details'] ?? null)) {
            echo '<h3 class="pp-subheading">توضیحات ثبت‌شدهٔ دستگاه</h3>';
            portal_note($account['elevator_details']);
        }
        if (!$isGeneralAudio) portal_audio_controls($audioUrl, $speech);
    }, true);
    portal_disclosure('تجهیزات مکانیکی', static fn() => $profileFacts(['motor_manufacturer', 'motor_model', 'door_type', 'mechanical_notes']));
    portal_disclosure('تجهیزات الکتریکی', static fn() => $profileFacts(['panel_manufacturer', 'panel_model', 'electrical_notes']));
    portal_disclosure('سامانه‌های ایمنی', static fn() => portal_note($profile['safety_systems'] ?? null));
    portal_disclosure('قطعات نصب‌شده', static function () use ($parts): void {
        if (!$parts) { portal_note(null); return; }
        ?><ul class="pp-flat-list"><?php foreach ($parts as $part): ?><li><div><b><?=e($part['name'])?></b><?php if (portal_has($part['model'])): ?><small><bdi><?=e($part['model'])?></bdi></small><?php endif ?></div><a class="pp-text-link" href="part.php?id=<?=(int)$part['id']?>">مشاهده قطعه <?=portal_icon('arrow', 15)?></a></li><?php endforeach ?></ul>
        <a class="pp-text-link" href="parts.php">رفتن به کاتالوگ <?=portal_icon('arrow', 15)?></a><?php
    });
    portal_disclosure('اطلاعات ضمانت', static fn() => portal_note($profile['warranty_info'] ?? null));
    if ($type) portal_disclosure('راهنمای عمومی نوع آسانسور', static function () use ($type, $audioUrl, $speech, $isGeneralAudio): void {
        ?><p class="pp-small pp-muted">این راهنما دربارهٔ نوع دستگاه است و مشخصات اختصاصی آسانسور شما محسوب نمی‌شود.</p><?php
        if (portal_has($type['article'] ?? null)) portal_note($type['article']);
        $genericFacts = [];
        foreach ($type['specs'] ?? [] as $row) if (is_array($row) && isset($row[0], $row[1])) $genericFacts[(string)$row[0]] = (string)$row[1];
        portal_facts($genericFacts);
        if (!empty($type['hotspots'])): ?><ul class="pp-flat-list"><?php foreach ($type['hotspots'] as $row): if (empty($row[0]) || empty($row[1])) continue; ?><li><div><b><?=e($row[0])?></b><?php portal_note($row[1]); ?></div></li><?php endforeach ?></ul><?php endif;
        if ($isGeneralAudio) portal_audio_controls($audioUrl, $speech);
    });
    ?>
</div>
<?php portal_end(); ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/portal-view.php';
$account = portal_require_account();
$customerId = (int)$account['id'];
$id = portal_id($_GET['id'] ?? null);
$contract = portal_owned('contract', $id, $customerId);
if (!$contract) portal_missing_record($account, 'contracts', 'contracts.php');
$details = portal_ready() ? (q_one('SELECT * FROM customer_contract_details WHERE contract_id=? AND is_published=1', [$id]) ?? []) : [];
$files = portal_media_list('contract', [$id], $customerId);
portal_start($account, $contract['title'], 'contracts');
portal_intro($contract['title'], 'جزئیات، پوشش و اسناد ثبت‌شدهٔ قرارداد شما', 'قرارداد', 'contracts.php', 'همه قراردادها');
?>
<div class="pp-detail-stack">
    <section class="pp-card pp-detail-lead" aria-labelledby="identification">
        <div class="pp-card-top"><h2 id="identification"><span class="pp-tiny-icon"><?=portal_icon('file', 20)?></span> شناسایی قرارداد</h2><?=portal_badge($contract['status'], PORTAL_CONTRACT_STATUSES)?></div>
        <?php portal_facts(['عنوان' => $contract['title'], 'شماره قرارداد' => $contract['contract_no'], 'تاریخ تنظیم' => $contract['contract_date'] ?? ''], true); ?>
        <?php if (!portal_has($contract['contract_date'] ?? null)) portal_note(null); ?>
        <div class="pp-quick-links"><a class="pp-text-link" href="#contract-coverage">پوشش و استثناها <?=portal_icon('chevron', 16)?></a>
            <?php if ($files): ?><a class="pp-text-link" href="#contract-attachments">پیوست‌های PDF <?=portal_icon('chevron', 16)?></a><?php endif ?>
        </div>
    </section>
    <div class="pp-disclosures" aria-label="بندهای قرارداد">
        <?php
        $textSection = static function (string $field, bool $open = false) use ($details): void {
            portal_disclosure(PORTAL_CONTRACT_FIELDS[$field], static fn() => portal_note($details[$field] ?? null), $open);
        };
        $textSection('parties');
        $textSection('subject_scope');
        $textSection('technical_specs');
        portal_disclosure('نشانی پروژه', static fn() => portal_note($contract['project_address']));
        portal_disclosure('تاریخ شروع و پایان', static function () use ($contract): void {
            portal_facts(['شروع قرارداد' => $contract['start_date'], 'انقضای قرارداد' => $contract['end_date']], true);
            if (!portal_has($contract['start_date']) || !portal_has($contract['end_date'])) portal_note(null);
        });
        portal_disclosure('تعهدات مالی', static function () use ($contract, $details): void {
            portal_facts(['مبلغ کل' => $contract['total_amount'] ?? ''], true);
            portal_note($details['financial_obligations'] ?? null);
            if (portal_has($details['financial_obligations'] ?? null) && !portal_has($contract['total_amount'] ?? null)) portal_note(null);
        });
        $textSection('payment_terms');
        portal_disclosure('خدمات مشمول و پوشش قرارداد', static function () use ($contract, $details): void {
            if (portal_has($details['included_services'] ?? null)) portal_note($details['included_services']);
            if (portal_has($contract['coverage'])) {
                echo '<h3 class="pp-subheading">شرح پوشش ثبت‌شده</h3>';
                portal_note($contract['coverage']);
            } elseif (!portal_has($details['included_services'] ?? null)) {
                portal_note(null);
            }
        }, true, 'contract-coverage');
        $textSection('excluded_services', true);
        portal_disclosure('تجهیزات و قطعات', static function () use ($contract, $details): void {
            if (portal_has($details['equipment'] ?? null)) portal_note($details['equipment']);
            if (portal_has($contract['contract_parts'] ?? null)) {
                echo '<h3 class="pp-subheading">فهرست قطعات و مبالغ ثبت‌شده</h3>';
                portal_note($contract['contract_parts']);
            } elseif (!portal_has($details['equipment'] ?? null)) {
                portal_note(null);
            }
        });
        foreach (['warranty_conditions', 'maintenance_obligations', 'company_responsibilities', 'customer_responsibilities', 'additional_conditions'] as $field) $textSection($field);
        portal_disclosure('پیوست‌های قرارداد', static fn() => portal_media_view($files, 'contract'), (bool)$files, 'contract-attachments');
        $textSection('approval_signature');
        if (portal_has($contract['contract_text'] ?? null)) portal_disclosure('متن کامل ثبت‌شده', static fn() => portal_note($contract['contract_text']));
        if (portal_has($details['legal_clarification'] ?? null)) $textSection('legal_clarification');
        ?>
    </div>
</div>
<?php portal_end(); ?>

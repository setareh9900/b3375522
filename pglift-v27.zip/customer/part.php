<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/portal-view.php';
$account = portal_require_account();
$customerId = (int)$account['id'];
$id = portal_id($_GET['id'] ?? null);
$part = portal_owned('part', $id, $customerId);
if (!$part) portal_missing_record($account, 'parts', 'parts.php');
$details = [];
$reports = [];
if (portal_ready()) {
    $details = q_one('SELECT * FROM customer_part_details WHERE part_id=?', [$id]) ?? [];
    $reports = q_all('SELECT v.id,v.service_date,v.status,c.relation_type,c.notes FROM customer_service_components c
        JOIN customer_service_visits v ON v.id=c.visit_id WHERE c.part_id=? AND v.customer_id=? ORDER BY c.id DESC', [$id, $customerId]);
    foreach ($reports as &$report) $report['date_key'] = portal_date_key($report['service_date']);
    unset($report);
    usort($reports, static fn($a, $b) => ($b['date_key'] ?? '') <=> ($a['date_key'] ?? '') ?: (int)$b['id'] <=> (int)$a['id']);
}
$warranty = portal_has($details['warranty_status'] ?? null) ? $details['warranty_status'] : ($part['warranty'] ?? '');
$previousPart = q_val('SELECT id FROM customer_parts WHERE customer_id=? AND id>? ORDER BY id LIMIT 1', [$customerId,$id]);
$nextPart = q_val('SELECT id FROM customer_parts WHERE customer_id=? AND id<? ORDER BY id DESC LIMIT 1', [$customerId,$id]);
$share = [$part['name']];
foreach (['brand' => 'سازنده', 'model' => 'مدل', 'serial_number' => 'سریال', 'installed_at' => 'تاریخ نصب'] as $field => $label) {
    if (portal_has($part[$field])) $share[] = $label.': '.$part[$field];
}
if (portal_has($warranty)) $share[] = 'ضمانت: '.$warranty;
portal_start($account, $part['name'], 'parts');
portal_intro($part['name'], 'مشخصات فنی، نصب و نگهداری این قطعه.', 'پرونده قطعه', 'parts.php#customer-part-'.$id, 'بازگشت به قطعات');
?>
<section class="pp-card pp-detail-lead">
    <div class="pp-profile-head">
        <figure class="pp-profile-image pp-part-profile"><?php if (portal_has($part['image_ref'])): ?><a href="image.php?id=<?=$id?>" target="_blank" rel="noopener"><img src="image.php?id=<?=$id?>" alt="تصویر <?=e($part['name'])?>"></a><?php else: ?><?=portal_icon('box', 35)?><?php endif ?></figure>
        <div><h2>معرفی قطعه</h2><?php portal_facts(['سازنده' => $part['brand'], 'مدل' => $part['model'], 'تعداد' => $part['quantity'], 'مبلغ ثبت‌شده' => $part['price']]); ?></div>
    </div>
    <div class="pp-actions">
        <button class="pp-btn" type="button" data-share-text="<?=e(implode("\n", $share))?>" hidden>ارسال مشخصات</button>
        <?php if (portal_has($part['serial_number'])): ?><button class="pp-btn" type="button" data-copy-text="<?=e($part['serial_number'])?>" hidden>کپی سریال</button><?php endif ?>
        <?php if ($phone = portal_phone()): ?><a class="pp-btn" href="tel:<?=e($phone)?>"><?=portal_icon('phone', 16)?> تماس دربارهٔ قطعه</a><?php endif ?>
    </div>
</section>
<div class="pp-section pp-disclosures">
    <?php
    portal_disclosure('مشخصات فنی', static fn() => portal_note($part['specifications']), true);
    portal_disclosure('اطلاعات نصب', static function () use ($part, $details): void {
        portal_facts(['شماره سریال' => $part['serial_number'], 'تاریخ نصب' => $part['installed_at']], true);
        if (portal_has($details['installation_notes'] ?? null)) portal_note($details['installation_notes']);
    });
    portal_disclosure('اطلاعات سازنده', static function () use ($part, $details): void {
        portal_facts(['سازنده' => $part['brand'], 'مدل' => $part['model']], true);
        if (portal_has($details['manufacturer_info'] ?? null)) portal_note($details['manufacturer_info']);
    });
    portal_disclosure('ضمانت', static function () use ($part, $details, $warranty): void {
        portal_facts(['وضعیت یا شرح ثبت‌شده' => $warranty]);
        if (portal_has($details['warranty_status'] ?? null) && portal_has($part['warranty'])) portal_note($part['warranty']);
        if (portal_has($details['warranty_details'] ?? null) || !portal_has($warranty)) portal_note($details['warranty_details'] ?? null);
    });
    if (portal_has($details['maintenance_notes'] ?? null)) portal_disclosure('سابقه نگهداری', static fn() => portal_note($details['maintenance_notes']));
    if ($reports) portal_disclosure('گزارش‌های سرویس مرتبط', static function () use ($reports): void {
        ?><ul class="pp-flat-list"><?php foreach ($reports as $report): ?><li><div><b><bdi><?=e($report['service_date'])?></bdi></b><small><?=e(PORTAL_COMPONENT_RELATIONS[$report['relation_type']] ?? '')?> · <?=e(PORTAL_VISIT_STATUSES[$report['status']] ?? $report['status'])?></small><?php if (portal_has($report['notes'])) portal_note($report['notes']); ?></div><a class="pp-text-link" href="service-report.php?id=<?=(int)$report['id']?>">گزارش <bdi><?=e(portal_report_number((int)$report['id']))?></bdi><?=portal_icon('arrow', 15)?></a></li><?php endforeach ?></ul><?php
    }, true);
    ?>
</div>
<?php if ($previousPart || $nextPart): ?>
    <nav class="pp-pager" aria-label="گردش کاتالوگ">
        <?php if ($previousPart): ?><a class="pp-btn" href="?id=<?=(int)$previousPart?>"><?=portal_icon('back', 15)?> قطعهٔ قبلی</a><?php endif ?>
        <?php if ($nextPart): ?><a class="pp-btn" href="?id=<?=(int)$nextPart?>">قطعهٔ بعدی <?=portal_icon('arrow', 15)?></a><?php endif ?>
    </nav>
<?php endif ?>
<?php portal_end(); ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/portal-view.php';
$account = portal_require_account();
$customerId = (int)$account['id'];
$visits = portal_visits($customerId);
$snapshot = portal_maintenance_snapshot($visits);
$profile = portal_profile($customerId);
$contracts = portal_maintenance_contracts($customerId);
$title = setting('customer.services_title', 'مرکز سرویس و نگهداری');
// Keep chronological ordering while limiting the number of cards on one screen.
$perPage = 20;
$pages = max(1, (int)ceil(count($visits) / $perPage));
$page = min($pages, max(1, portal_id($_GET['page'] ?? null)));
$history = array_slice($visits, ($page - 1) * $perPage, $perPage);
portal_start($account, $title, 'maintenance');
portal_intro($title, 'زمان‌بندی بازدیدها، سوابق فنی و گزارش‌های سرویس آسانسور.', 'نگهداری آسانسور');
?>
<div class="pp-metric-grid" aria-label="خلاصه نگهداری">
    <article class="pp-card pp-metric"><span class="pp-section-icon"><?=portal_icon('tool', 19)?></span><div><small>وضعیت فعلی نگهداری</small><?=portal_badge($profile['maintenance_status'] ?? null, PORTAL_MAINTENANCE_STATUSES)?></div></article>
    <article class="pp-card pp-metric"><span class="pp-section-icon"><?=portal_icon('check', 19)?></span><div><small>آخرین سرویس تکمیل‌شده</small><b><bdi><?=e($snapshot['last']['service_date'] ?? 'ثبت نشده')?></bdi></b></div></article>
    <article class="pp-card pp-metric"><span class="pp-section-icon"><?=portal_icon('calendar', 19)?></span><div><small>نزدیک‌ترین بازدید پیش‌رو</small><b><bdi><?=e($snapshot['next']['date'] ?? 'ثبت نشده')?></bdi></b></div></article>
    <article class="pp-card pp-metric"><span class="pp-section-icon"><?=portal_icon('clock', 19)?></span><div><small>تعداد بازدیدهای تکمیل‌شده</small><b><?=fa_digits($snapshot['completed'])?></b></div></article>
</div>
<div class="pp-section-pair">
    <section class="pp-section">
        <?php portal_section_head('یادآوری سرویس', 'calendar'); ?>
        <?php if (!$snapshot['reminders']): ?>
            <?php portal_empty('calendar', 'بازدید پیش‌رویی ثبت نشده است'); ?>
        <?php else: ?>
            <ul class="pp-flat-list"><?php foreach ($snapshot['reminders'] as $reminder): ?><li>
                <div><b><bdi><?=e($reminder['date'])?></bdi></b><small><?= $reminder['is_scheduled'] ? 'بازدید زمان‌بندی‌شده' : 'تاریخ درج‌شده در آخرین گزارش' ?></small></div>
                <a class="pp-text-link" href="service-report.php?id=<?=(int)$reminder['visit_id']?>">جزئیات <?=portal_icon('arrow', 15)?></a>
            </li><?php endforeach ?></ul>
        <?php endif ?>
    </section>
    <section class="pp-section">
        <?php portal_section_head('قراردادهای نگهداری', 'file'); ?>
        <?php if (!$contracts): ?>
            <?php portal_empty('file', 'قرارداد نگهداری مشخص نشده است'); ?>
        <?php else: ?>
            <ul class="pp-flat-list"><?php foreach ($contracts as $contract): ?><li>
                <div><a href="contract.php?id=<?=(int)$contract['id']?>"><b><?=e($contract['title'])?></b></a>
                <?php if ($contract['status'] === 'active' && $contract['included_visits'] !== null): ?><small>بازدید باقی‌مانده: <?=fa_digits(max(0, (int)$contract['included_visits'] - (int)$contract['linked_completed']))?> از <?=fa_digits($contract['included_visits'])?></small><?php endif ?></div>
                <?=portal_badge($contract['status'], PORTAL_CONTRACT_STATUSES)?>
            </li><?php endforeach ?></ul>
            <?php if (array_filter($contracts, static fn($c) => $c['status'] === 'active' && $c['included_visits'] !== null)): ?><p class="pp-small pp-muted">فقط بازدیدهای تکمیل‌شدهٔ مرتبط با همان قرارداد از سهمیه کسر می‌شوند.</p><?php endif ?>
        <?php endif ?>
    </section>
</div>
<section class="pp-section" id="history">
    <?php portal_section_head('خط زمانی سرویس‌ها', 'tool'); ?>
    <?php if (!$history): ?>
        <?php portal_empty('tool', 'هنوز گزارش سرویسی ثبت نشده است'); ?>
    <?php else: ?>
        <?php if (array_filter($history, static fn($v) => $v['date_key'] === null)): ?><p class="pp-small pp-muted">رکوردهای قدیمی با تاریخ غیرقابل مرتب‌سازی در انتهای فهرست هستند.</p><?php endif ?>
        <ol class="pp-timeline"><?php foreach ($history as $visit): ?><li data-status="<?=e($visit['status'])?>"><?php portal_visit_card($visit); ?></li><?php endforeach ?></ol>
        <?php if ($pages > 1): ?><nav class="pp-pager" aria-label="صفحات سابقه سرویس">
            <?php if ($page > 1): ?><a class="pp-btn" href="?page=<?=$page - 1?>#history"><?=portal_icon('back', 15)?> صفحه قبل</a><?php endif ?>
            <span>صفحه <?=fa_digits($page)?> از <?=fa_digits($pages)?></span>
            <?php if ($page < $pages): ?><a class="pp-btn" href="?page=<?=$page + 1?>#history">صفحه بعد <?=portal_icon('arrow', 15)?></a><?php endif ?>
        </nav><?php endif ?>
    <?php endif ?>
</section>
<?php portal_end(); ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/portal-view.php';
$account = portal_require_account();
$customerId = (int)$account['id'];
$projects = portal_projects($customerId);
$project = isset($_GET['id']) ? portal_owned('project', portal_id($_GET['id']), $customerId) : ($projects[0] ?? null);
if (isset($_GET['id']) && !$project) portal_missing_record($account, 'installation', 'installation.php');
portal_start($account, 'پیگیری نصب', 'installation');
portal_intro('پیگیری نصب', 'پیشرفت اجرا و مراحل ثبت‌شده از آغاز تا تحویل.', 'نصب و راه‌اندازی');
if (!$project) {
    portal_empty('layers', 'پروژهٔ نصبی ثبت نشده است', 'پس از ثبت پروژه توسط مدیریت، مراحل، زمان‌بندی و پیوست‌ها اینجا به‌روز می‌شوند.');
    portal_end();
    return;
}
$id = (int)$project['id'];
$stages = portal_stages($id, $customerId);
$groups = portal_stage_groups($stages);
$updates = q_all('SELECT u.message,u.created_at FROM customer_installation_updates u JOIN customer_installation_projects p ON p.id=u.project_id WHERE p.id=? AND p.customer_id=? ORDER BY u.created_at DESC,u.id DESC LIMIT 10', [$id, $customerId]);
$mediaByStage = [];
foreach (array_chunk(array_column($stages, 'id'), 250) as $stageIds) {
    foreach (portal_media_list('stage', $stageIds, $customerId) as $file) $mediaByStage[$file['owner_id']][] = $file;
}
?>
<?php if (count($projects) > 1): ?><nav class="pp-project-list" aria-label="پروژه‌های نصب"><?php foreach ($projects as $option): ?><a class="pp-btn" href="?id=<?=(int)$option['id']?>"<?= (int)$option['id'] === $id ? ' aria-current="page"' : '' ?>><?=e($option['title'])?></a><?php endforeach ?></nav><?php endif ?>
<section class="pp-card pp-detail-lead" aria-labelledby="project-title">
    <div class="pp-card-top"><h2 id="project-title"><span class="pp-tiny-icon"><?=portal_icon('layers', 20)?></span> <?=e($project['title'])?></h2></div>
    <?php if (portal_has($project['description'])) portal_note($project['description']); ?>
    <?php if ($project['progress'] !== null): ?><?php portal_progress($project['progress'], 'پیشرفت کلی پروژه'); ?><?php else: ?><p class="pp-muted">درصد پیشرفت کلی هنوز ثبت نشده است.</p><?php endif ?>
    <?php portal_facts([
        'مرحلهٔ جاری' => $groups['current'] ? implode('، ', array_column($groups['current'], 'title')) : 'ثبت نشده',
        'مراحل تکمیل‌شده' => $stages ? fa_digits(count($groups['completed'])) : '',
        'مراحل در انتظار شروع' => $stages ? fa_digits(count($groups['upcoming'])) : '',
        'تاریخ پیش‌بینی پایان' => $project['expected_completion_date'],
    ]); ?>
</section>
<section class="pp-section">
    <?php portal_section_head('خط زمانی نصب', 'layers'); ?>
    <?php if (!$stages): ?>
        <?php portal_empty('layers', 'مراحل این پروژه هنوز ثبت نشده‌اند'); ?>
    <?php else: ?>
        <ol class="pp-timeline pp-stages">
        <?php foreach ($stages as $n => $stage):
            $files = $mediaByStage[$stage['id']] ?? [];
            $isCurrent = in_array($stage['status'], ['in_progress', 'blocked'], true); ?>
            <li data-status="<?=e($stage['status'])?>" id="stage-<?=(int)$stage['id']?>">
                <details class="pp-card pp-disclosure pp-stage"<?=$isCurrent ? ' open' : ''?>>
                    <summary><div class="pp-stage-name"><small>مرحله <?=fa_digits($n + 1)?></small><b><?=e($stage['title'])?></b></div><?=portal_badge($stage['status'], PORTAL_STAGE_STATUSES)?><?=portal_icon('chevron', 18)?></summary>
                    <div class="pp-disclosure-body">
                        <?php if (portal_has($stage['description'])) portal_note($stage['description']); ?>
                        <?php portal_progress($stage['progress'], 'پیشرفت مرحله'); ?>
                        <?php portal_facts(['شروع' => $stage['start_date'], 'پایان پیش‌بینی‌شده' => $stage['expected_date'], 'پایان واقعی' => $stage['completion_date'], 'تکنسین یا تیم' => $stage['technician']]); ?>
                        <?php if (portal_has($stage['customer_notes'])): ?><h3 class="pp-subheading">یادداشت مرحله</h3><?php portal_note($stage['customer_notes']); endif ?>
                        <?php portal_media_view($files, 'stage', false); ?>
                        <?php if (!$files && $stage['progress'] === null && !array_filter([$stage['description'], $stage['customer_notes'], $stage['start_date'], $stage['expected_date'], $stage['completion_date'], $stage['technician']], 'portal_has')) portal_note(null); ?>
                    </div>
                </details>
            </li>
        <?php endforeach ?>
        </ol>
    <?php endif ?>
</section>
<section class="pp-section">
    <?php portal_section_head('آخرین به‌روزرسانی‌های پروژه', 'clock'); ?>
    <?php if (!$updates): ?>
        <?php portal_empty('clock', 'به‌روزرسانی‌ای منتشر نشده است'); ?>
    <?php else: ?>
        <ul class="pp-flat-list pp-updates"><?php foreach ($updates as $update): ?><li><div><small><?=e(jdate($update['created_at'], false))?></small><?php portal_note($update['message']); ?></div></li><?php endforeach ?></ul>
    <?php endif ?>
</section>
<?php portal_end(); ?>

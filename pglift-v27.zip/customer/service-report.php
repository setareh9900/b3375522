<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/portal-view.php';
$account = portal_require_account();
$customerId = (int)$account['id'];
$id = portal_id($_GET['id'] ?? null);
$visit = portal_owned('service', $id, $customerId);
if (!$visit) portal_missing_record($account, 'maintenance', 'maintenance.php');
$details = [];
$components = [];
if (portal_ready()) {
    $details = q_one('SELECT * FROM customer_service_report_details WHERE visit_id=?', [$id]) ?? [];
    $components = q_all('SELECT c.*, p.id AS visible_part_id FROM customer_service_components c
        LEFT JOIN customer_parts p ON p.id=c.part_id AND p.customer_id=? WHERE c.visit_id=? ORDER BY c.id', [$customerId, $id]);
}
$files = portal_media_list('service', [$id], $customerId);
$type = PORTAL_SERVICE_TYPES[$details['service_type'] ?? ''] ?? 'گزارش بازدید سرویس';
$reportNo = portal_report_number($id);
portal_start($account, $type, 'maintenance');
portal_intro($type, 'گزارش فنی و اقلام ثبت‌شده برای این بازدید', 'گزارش سرویس', 'maintenance.php#history', 'سابقه سرویس‌ها');
?>
<div class="pp-detail-stack">
    <section class="pp-card pp-detail-lead" aria-labelledby="visit-title">
        <div class="pp-card-top"><h2 id="visit-title"><span class="pp-tiny-icon"><?=portal_icon('tool', 20)?></span> اطلاعات بازدید</h2><?=portal_badge($visit['status'], PORTAL_VISIT_STATUSES)?></div>
        <?php portal_facts(['شماره گزارش' => $reportNo, 'تاریخ سرویس' => $visit['service_date'], 'ساعت شروع' => $details['start_time'] ?? '',
            'ساعت پایان' => $details['completion_time'] ?? '', 'تکنسین' => $visit['technician'],
            'نوع سرویس' => PORTAL_SERVICE_TYPES[$details['service_type'] ?? ''] ?? '', 'وضعیت آسانسور در بازدید' => PORTAL_OPERATIONAL_STATUSES[$details['operational_status'] ?? ''] ?? '',
            'تاریخ درج‌شده برای سرویس بعدی' => $visit['next_service_date']], true); ?>
        <?php if (portal_has($visit['summary'])): ?><div class="pp-summary-note"><strong>خلاصه بازدید</strong><?php portal_note($visit['summary']); ?></div><?php endif ?>
    </section>
    <div class="pp-disclosures" aria-label="جزئیات فنی بازدید">
        <?php
        foreach (['inspection_results', 'work_performed', 'detected_faults'] as $field) {
            portal_disclosure(PORTAL_REPORT_FIELDS[$field], static fn() => portal_note($details[$field] ?? null), $field === 'detected_faults' && portal_has($details[$field] ?? null));
        }
        portal_disclosure('مشکلات رفع‌شده', static fn() => portal_note($visit['resolved_problems'] ?? null), portal_has($visit['resolved_problems'] ?? null));
        portal_disclosure('قطعات تعویض‌شده و مرتبط', static function () use ($visit, $components): void {
            if (!$components || portal_has($visit['replaced_parts'] ?? null)) {
                if ($components) echo '<h3 class="pp-subheading">شرح ثبت‌شدهٔ تعویض قطعات</h3>';
                portal_note($visit['replaced_parts'] ?? null);
            }
            if (!$components) return;
            ?>
            <ul class="pp-flat-list"><?php foreach ($components as $component): ?><li>
                <div><b><?=e($component['name'])?></b><small><?=e(PORTAL_COMPONENT_RELATIONS[$component['relation_type']] ?? $component['relation_type'])?></small>
                    <?php portal_facts(['سازنده' => $component['manufacturer'], 'مدل' => $component['model']]); ?>
                    <?php if (portal_has($component['notes'])) portal_note($component['notes']); ?></div>
                <?php if ($component['visible_part_id']): ?><a class="pp-text-link" href="part.php?id=<?=(int)$component['visible_part_id']?>">پرونده قطعه <?=portal_icon('arrow', 15)?></a><?php endif ?>
            </li><?php endforeach ?></ul>
            <?php
        }, (bool)$components);
        foreach (['recommendations', 'follow_up', 'technician_notes'] as $field) {
            portal_disclosure(PORTAL_REPORT_FIELDS[$field], static fn() => portal_note($details[$field] ?? null), $field === 'recommendations' && portal_has($details[$field] ?? null));
        }
        portal_disclosure('تصاویر قبل و بعد و PDF گزارش', static fn() => portal_media_view($files, 'service'), (bool)$files);
        ?>
    </div>
</div>
<?php portal_end(); ?>

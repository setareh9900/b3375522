<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/portal-view.php';
$account = portal_require_account();
$contracts = portal_contracts((int)$account['id']);
$title = setting('customer.contracts_title', 'قراردادهای من');
portal_start($account, $title, 'contracts');
portal_intro($title, 'خلاصه قراردادهای پروژه و دسترسی به متن و پیوست‌های منتشرشده.', 'اسناد پروژه');
if (!$contracts) {
    portal_empty('file', 'قراردادی ثبت نشده است', 'قراردادهای ثبت‌شده برای حساب شما اینجا نمایش داده می‌شوند.');
} else {
    echo '<div class="pp-card-grid">';
    foreach ($contracts as $contract) portal_contract_card($contract);
    echo '</div>';
}
portal_end();

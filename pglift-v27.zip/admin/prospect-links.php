<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-admin-view.php';
require_once __DIR__.'/../inc/prospect-links.php';
$staff = prospect_staff();
prospect_admin_only($staff);
prospect_method(['GET','HEAD','POST']);
$ready = prospect_guidance_ready();
$error = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    prospect_csrf();
    try {
        $action = prospect_scalar($_POST,'action');
        if ($action === 'setup') {
            if (prospect_ready()) prospect_apply_guidance_schema(db());
            else prospect_apply_schema(db());
            prospect_flash('لینک و ویدیوهای راهنما فعال شدند. داده‌های قبلی تغییر نکردند.');
            prospect_redirect('prospect-links.php');
        }
        if (!$ready) throw new ProspectValidation('ابتدا لینک و ویدیوهای راهنما را فعال کنید.');
        if ($action === 'issue') {
            $id = prospect_issue_guide($staff,$_POST);
            prospect_flash('لینک راهنما صادر شد؛ می‌توانید آن را کپی و ارسال کنید.');
        } elseif (in_array($action,['enable','disable'],true)) {
            $id = prospect_id($_POST['id'] ?? null);
            prospect_set_guide_active($staff,$id,$action === 'enable');
            prospect_flash($action === 'enable' ? 'لینک دوباره فعال شد.' : 'لینک صادرشده متوقف شد؛ نشانی عمومی همچنان فعال است.');
        } else throw new ProspectValidation('عملیات نامعتبر است.');
        log_activity($staff['username'],'prospect.guide_link.'.$action,'لینک #'.$id);
        prospect_redirect('prospect-links.php?id='.$id);
    } catch (ProspectValidation | PDOException $ex) { $error = prospect_admin_error($ex,'guide link'); }
}
$id = prospect_id($_GET['id'] ?? null);
$link = $ready && $id ? q_one('SELECT id,token,label,is_active,created_at FROM prospect_guide_links WHERE id=?',[$id]) : null;
if ($ready && $id && !$link && $error === '') { http_response_code(404); $error = 'لینک پیدا نشد.'; }
prospect_admin_start($staff,'صدور لینک پرتال راهنما','links');
prospect_page_intro('ارسال دعوت پیش از خرید','صدور لینک پرتال راهنما','این لینک فقط مرکز عمومی معرفی و مشاوره را باز می‌کند. نام داخلی نمایش داده نمی‌شود و ارسال لینک، حساب یا دسترسی خریدار نمی‌سازد.');
prospect_show_flash($error);
?>
<div class="pc-columns">
<section class="ps-panel">
<?php if (!$ready): ?>
    <h2>فعال‌سازی روی سایت موجود</h2><p>جدول‌های لینک و ویدیو بدون تغییر پرونده‌های قبلی اضافه می‌شوند.</p>
    <form class="ps-actions" method="post" action="prospect-links.php"><?php prospect_admin_action('setup'); ?><button type="submit" class="ps-btn ps-primary">فعال‌سازی لینک و ویدیوهای راهنما</button></form>
<?php else: ?>
    <form class="ps-form" method="post" action="prospect-links.php">
        <h2>لینک جدید</h2><?php prospect_admin_action('issue'); ?>
        <?php prospect_input_field('label','عنوان داخلی (اختیاری)', $error ? prospect_scalar($_POST,'label') : '', 'maxlength="140" placeholder="مثلاً جلسهٔ مشاوره"'); ?>
        <button type="submit" class="ps-btn ps-primary ps-submit">صدور لینک راهنما</button>
    </form>
<?php endif ?>
</section>
<aside class="ps-panel ps-note-panel"><h2>نشانی عمومی هم همیشه در دسترس است</h2><p>مخاطب بدون لینک اختصاصی هم می‌تواند از «راهنمای خرید و مشاوره» در سایت اصلی وارد شود. غیرفعال‌کردن لینک، فقط همان نشانی صادرشده را متوقف می‌کند.</p><a class="ps-link" href="../prospects/index.php">باز کردن پرتال عمومی <?=prospect_arrow(14)?></a></aside>
</div>
<?php if ($link): $path = prospect_guide_share_path($link['token']); ?>
<section class="ps-panel pc-section" aria-label="لینک انتخاب‌شده">
    <div class="pc-head"><div><h2><?=e($link['label'] ?: 'لینک راهنما')?></h2><p class="pc-hint"><?=e(prospect_date($link['created_at'],true))?></p></div><span class="ps-chip"><?=(int)$link['is_active'] === 1 ? 'فعال' : 'غیرفعال'?></span></div>
    <?php if ((int)$link['is_active'] === 1): ?>
        <div class="ps-form pc-section" data-guide-share>
            <label class="ps-field"><span>نشانی قابل ارسال</span><input type="text" dir="ltr" readonly value="<?=e($path)?>" data-guide-address></label>
            <div class="ps-actions"><button type="button" class="ps-btn ps-primary" data-guide-copy hidden>کپی لینک راهنما</button><a class="ps-btn ps-secondary" data-guide-anchor href="<?=e($path)?>" target="_blank" rel="noopener noreferrer">باز کردن لینک</a></div>
            <p class="pc-hint" data-guide-status aria-live="polite"></p>
            <noscript><p class="pc-hint">از منوی مرورگر روی «باز کردن لینک»، گزینهٔ کپی نشانی پیوند را انتخاب کنید.</p></noscript>
        </div>
    <?php endif ?>
    <form method="post" class="ps-actions" action="prospect-links.php"><?php prospect_admin_action((int)$link['is_active'] === 1 ? 'disable' : 'enable',$id); ?><button type="submit" class="ps-btn ps-secondary"><?=(int)$link['is_active'] === 1 ? 'غیرفعال‌سازی این لینک' : 'فعال‌سازی دوباره'?></button></form>
</section>
<?php endif ?>
<?php if ($ready):
    [$page,$pages,$offset] = prospect_pagination((int)q_val('SELECT COUNT(*) FROM prospect_guide_links'),prospect_id($_GET['page'] ?? null),16);
    $rows = q_all("SELECT id,label,is_active,created_at FROM prospect_guide_links ORDER BY id DESC LIMIT 16 OFFSET $offset"); ?>
<section class="pc-section" aria-labelledby="guide-links-list">
    <h2 id="guide-links-list">لینک‌های صادرشده</h2>
    <?php if (!$rows): ?><p class="ps-empty">هنوز لینکی صادر نشده است.</p><?php endif ?>
    <div class="pc-list"><?php foreach ($rows as $row): ?>
        <article class="pc-row"><div><a href="?id=<?=(int)$row['id']?>" class="ps-link"><?=e($row['label'] ?: 'لینک راهنما')?></a><small><?=e(prospect_date($row['created_at'],true))?></small></div><span class="ps-chip"><?=(int)$row['is_active'] === 1 ? 'فعال' : 'غیرفعال'?></span></article>
    <?php endforeach ?></div>
    <?php prospect_admin_pager('prospect-links.php', [], $page, $pages); ?>
</section>
<?php endif ?>
<?php prospect_admin_end(); ?>

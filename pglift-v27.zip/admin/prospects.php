<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-admin-view.php';
$staff = prospect_staff();
prospect_method(['GET','HEAD','POST']);
$full = $staff['role'] === 'admin';
$ready = prospect_ready();
$isPost = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
$id = prospect_id(($isPost ? $_POST : $_GET)['id'] ?? null);
$tabs = ['inquiries'=>'درخواست‌ها','activity'=>'تماس‌ها و سابقه','followups'=>'پیگیری‌ها','quotes'=>'پیش‌فاکتورها'];
$tab = prospect_scalar($_GET, 'tab');
if (!isset($tabs[$tab])) $tab = 'inquiries';
$error = '';
if ($isPost) {
    prospect_csrf();
    $action = prospect_scalar($_POST, 'action');
    try {
        if ($action === 'setup') {
            prospect_admin_only($staff);
            prospect_apply_schema(db());
            prospect_flash('پرتال معرفی و CRM فعال است. داده‌های مشتریان موجود تغییر نکردند.');
            prospect_redirect('prospects.php');
        }
        if (!$ready) throw new ProspectValidation('ابتدا پرتال را فعال کنید.');
        if ($action === 'assign') prospect_admin_only($staff);
        $tab = prospect_crm_change($staff, $id, $action, $_POST);
        prospect_flash('تغییر در پرونده ثبت شد.');
        prospect_redirect('prospects.php?id='.$id.'&tab='.$tab);
    } catch (ProspectValidation | PDOException $ex) { $error = prospect_admin_error($ex,'CRM'); }
}
$lead = $ready && $id ? prospect_lead($id, $staff) : null;
if ($id && !$lead) http_response_code(404);
prospect_admin_start($staff, $lead ? 'پروندهٔ پیش از خرید' : 'مخاطبان و مشتریان بالقوه');
prospect_show_flash($error);
if (!$ready): ?>
    <?php prospect_page_intro('فعال‌سازی افزونه','پرتال معرفی هنوز فعال نشده است','فعال‌سازی فقط جدول‌های جدید را می‌سازد و هیچ پروندهٔ خریدار را تغییر نمی‌دهد.'); ?>
    <?php if ($full): ?><form method="post" class="ps-panel ps-form" action="prospects.php"><?php prospect_admin_action('setup'); ?><button type="submit" class="ps-btn ps-primary ps-submit">فعال‌سازی پرتال و CRM</button></form><?php endif ?>
<?php elseif ($id && !$lead): ?>
    <?php prospect_page_intro('پروندهٔ پیش از خرید','این پرونده در دسترس نیست.'); ?><a class="ps-btn ps-secondary" href="prospects.php">فهرست سرنخ‌ها</a>
<?php else:
    $statuses = prospect_statuses();
    $reps = $full ? prospect_rep_labels(prospect_reps()) : [];
    require __DIR__.'/../inc/prospect-admin-views/'.($lead ? 'detail' : 'list').'.php';
endif;
prospect_admin_end();

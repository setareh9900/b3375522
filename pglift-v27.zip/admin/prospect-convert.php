<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-admin-view.php';
require_once __DIR__.'/../inc/prospect-conversion.php';
$staff = prospect_staff();
prospect_admin_only($staff);
prospect_method(['GET','HEAD','POST']);
if (!prospect_ready()) redirect('prospects.php');
$isPost = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
if ($isPost) prospect_csrf();
$id = prospect_id(($isPost ? $_POST : $_GET)['id'] ?? null);
$lead = prospect_lead($id, $staff);
if (!$lead) { http_response_code(404); exit('پرونده در دسترس نیست.'); }
$existing = q_one('SELECT * FROM prospect_conversions WHERE prospect_id=?',[$id]);
$error = '';
try {
    customer_schema();
    feature_schema();
    if ($isPost) {
        if (!prospect_allow_attempt('convert-'.(int)$staff['id'],12,300)) throw new ProspectValidation('تعداد تلاش‌های تبدیل زیاد است. کمی بعد تلاش کنید.',403);
        $customerId = prospect_confirm_conversion($staff,$id,$_POST);
        log_activity($staff['username'],'prospect.convert','سرنخ #'.$id.' → حساب #'.$customerId);
        prospect_flash('خرید تأیید شد. حساب خریدار متصل است و سابقهٔ مشاوره باقی ماند.');
        prospect_redirect('prospect-convert.php?id='.$id);
    }
} catch (ProspectValidation | PDOException $ex) { $error = prospect_admin_error($ex,'conversion'); }
prospect_admin_start($staff,'بازبینی خرید و تبدیل','convert');
?>
<a class="ps-link" href="prospects.php?id=<?=$id?>">بازگشت به پروندهٔ پیش از خرید</a>
<?php prospect_page_intro('تبدیل کنترل‌شده','بازبینی خرید و اتصال حساب','این عملیات فقط پس از قرارداد امضاشده یا خرید قطعی انجام می‌شود. درخواست مشاوره و پیش‌فاکتور کافی نیستند.'); ?>
<?php prospect_show_flash($error); ?>
<?php if ($existing): ?>
    <section class="ps-panel"><h2>خرید تأییدشده</h2>
        <?php prospect_facts(['سرنخ'=>$lead['full_name'],'مدرک'=>$existing['evidence_type'] === 'contract' ? 'قرارداد خرید' : 'سند خرید قطعی',
            'شمارهٔ مدرک'=>$existing['evidence_reference'],'تاریخ خرید یا امضا'=>prospect_date($existing['purchase_date']),
            'مسئول ثبت'=>$existing['admin_username'],'زمان تبدیل'=>prospect_date($existing['created_at'],true)]); ?>
        <div class="ps-actions"><a class="ps-btn ps-primary" href="customers.php?id=<?=(int)$existing['customer_id']?>">حساب مشتری خریدکرده <?=prospect_arrow(14)?></a>
        <?php if ($existing['contract_id']): ?><a class="ps-btn ps-secondary" href="projects.php?customer=<?=(int)$existing['customer_id']?>&amp;contract=<?=(int)$existing['contract_id']?>">قرارداد مرتبط</a><?php endif ?></div>
    </section>
<?php else:
    $matches = prospect_customer_matches($lead['phone']);
    $username = mb_substr(trim(prospect_scalar($_GET,'account_username')),0,100);
    $named = $username !== '' ? q_one('SELECT id,name,username,phone FROM customer_accounts WHERE LOWER(username)=LOWER(?)',[$username]) : null;
    $accountId = prospect_id(($isPost ? $_POST['customer_id'] ?? null : $_GET['account'] ?? null));
    $account = $accountId ? q_one('SELECT id,name,username,phone FROM customer_accounts WHERE id=?',[$accountId]) : null;
    $mode = $account ? 'link' : (!$matches && (prospect_scalar($_GET,'mode') === 'create' || ($isPost && prospect_scalar($_POST,'mode') === 'create')) ? 'create' : '');
    ?>
    <div class="pc-columns">
    <section class="ps-panel"><h2>۱. حساب موجود را بررسی کنید</h2>
        <?php prospect_facts(['نام مخاطب'=>$lead['full_name'],'تماس ثبت‌شده'=>$lead['phone'],'تعداد درخواست‌ها'=>fa_digits(q_val('SELECT COUNT(*) FROM prospect_inquiries WHERE prospect_id=?',[$id]))]); ?>
        <p class="pc-hint">تطبیق شماره به‌تنهایی احراز هویت نیست. نام و سند خرید را بازبینی کنید. اگر شمارهٔ حساب قبلی فرق دارد، با نام کاربری دقیق جست‌وجو کنید.</p>
        <form method="get" action="prospect-convert.php" class="pc-short-form pc-section"><input type="hidden" name="id" value="<?=$id?>">
            <?php prospect_input_field('account_username','نام کاربری دقیق',$username,'maxlength="100" dir="ltr"'); ?><button type="submit" class="ps-btn ps-secondary">جست‌وجوی حساب</button>
        </form>
        <?php if ($username !== '' && !$named): ?><p class="ps-empty">حسابی با این نام کاربری پیدا نشد.</p><?php endif ?>
        <?php $choices = $named ? $matches+[(int)$named['id']=>$named] : $matches; ?>
        <?php if (!$choices): ?><p class="ps-empty">حساب هم‌شماره پیدا نشد.</p><?php endif ?>
        <?php foreach ($choices as $choice): ?><div class="pc-row"><div><b><?=e($choice['name'])?></b><small><bdi><?=e($choice['username'])?></bdi></small></div><a class="ps-link" href="?id=<?=$id?>&amp;account=<?=(int)$choice['id']?>">انتخاب حساب <?=prospect_arrow(14)?></a></div><?php endforeach ?>
        <?php if (!$matches && $mode !== 'create'): ?><a class="ps-link" href="?id=<?=$id?>&amp;mode=create">حسابی موجود نیست؛ ساخت حساب پس از تأیید <?=prospect_arrow(14)?></a><?php endif ?>
    </section>
    <?php if ($mode !== ''): ?>
    <form class="ps-panel ps-form" method="post" action="prospect-convert.php?id=<?=$id?>">
        <h2>۲. تأیید مدرک و ثبت تبدیل</h2><?php prospect_admin_action('convert',$id); ?><input type="hidden" name="mode" value="<?=e($mode)?>">
        <?php if ($mode === 'link'):
            $contracts = [];
            foreach (prospect_purchase_contracts($accountId) as $c) $contracts[(int)$c['id']] = $c['contract_no'].' · '.$c['title']; ?>
            <input type="hidden" name="customer_id" value="<?=$accountId?>">
            <p>حساب انتخاب‌شده: <b><?=e($account['name'])?></b> · <bdi><?=e($account['username'])?></bdi></p>
            <?php if (isset($matches[$accountId]) || !$matches): ?>
                <?php if ($contracts): prospect_select_field('evidence_type','نوع مدرک',['purchase'=>'سند خرید قطعی با شماره ثبت','contract'=>'قرارداد خرید امضاشدهٔ حساب'],prospect_scalar($_POST,'evidence_type','purchase'),true,'');
                    prospect_select_field('contract_id','قرارداد همان حساب (اگر مدرک قرارداد است)',$contracts,prospect_scalar($_POST,'contract_id'),false,'انتخاب نشده');
                else: ?><input type="hidden" name="evidence_type" value="purchase"><p class="pc-hint">برای این حساب سند خرید قطعیِ دارای شماره ثبت لازم است.</p><?php endif ?>
            <?php else: ?><p class="ps-notice ps-error">شماره به حساب دیگری می‌خورد. حساب صحیح را از فهرست هم‌شماره‌ها انتخاب کنید.</p><?php endif ?>
        <?php else: ?>
            <input type="hidden" name="evidence_type" value="purchase">
            <?php prospect_input_field('customer_name','نام خریدار',prospect_scalar($_POST,'customer_name',$lead['full_name']),'required maxlength="150"');
            prospect_input_field('username','نام کاربری جدید',prospect_scalar($_POST,'username'),'required minlength="3" maxlength="100" dir="ltr" autocomplete="off"');
            prospect_input_field('customer_password','رمز اولیهٔ مشتری','','required minlength="12" maxlength="72" autocomplete="new-password"','password'); ?>
            <p class="pc-hint">رمز را با روشی امن به خریدار تحویل دهید. لینک ورود خودکار صادر نمی‌شود و جزئیات فنی از سرنخ به حساب منتقل نمی‌شود.</p>
        <?php endif ?>
        <?php prospect_input_field('evidence_reference','شمارهٔ سند خرید (اگر مدرک قرارداد حساب نیست)',prospect_scalar($_POST,'evidence_reference'),'maxlength="140"');
        prospect_input_field('purchase_date','تاریخ خرید یا امضا *',prospect_scalar($_POST,'purchase_date'),'required placeholder="۱۴۰۵/۰۸/۲۵" maxlength="12"');
        prospect_checkbox('confirm_purchase','هویت خریدار و مدرک خرید قطعی یا قرارداد خرید امضاشده را بررسی کردم. این مورد پیش‌فاکتور یا درخواست مشاوره نیست.',false,true);
        prospect_input_field('admin_password','رمز حساب مدیر برای تأیید *','','required autocomplete="current-password"','password'); ?>
        <button type="submit" class="ps-btn ps-primary ps-submit"<?= $mode === 'link' && $matches && !isset($matches[$accountId]) ? ' disabled' : ''?>>تأیید خرید و ثبت تبدیل</button>
    </form>
    <?php else: ?><aside class="ps-panel ps-note-panel"><h2>تبدیل بدون حذف سوابق</h2><p>پس از انتخاب یا ساخت حساب در مرحلهٔ بعد، شمارهٔ مدرک خرید ثبت می‌شود. درخواست‌ها، تماس‌ها و یادداشت‌های فروش در همین پرونده می‌مانند.</p></aside><?php endif ?>
    </div>
<?php endif ?>
<?php prospect_admin_end(); ?>

<?php
/** آپلود فایل صوتی توضیحات هر نوع آسانسور → uploads/audio/ */
declare(strict_types=1);
require_once __DIR__ . '/../inc/fn.php';

$user = require_login_api();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'متد نامعتبر'], 405);
csrf_require($_POST['csrf'] ?? null);

if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    $code = $_FILES['file']['error'] ?? -1;
    $msg = in_array($code, [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)
        ? 'حجم فایل بیشتر از حد مجاز سرور است' : 'فایلی ارسال نشد یا آپلود ناموفق بود';
    json_out(['ok' => false, 'error' => $msg], 422);
}
$f = $_FILES['file'];
if ($f['size'] > 20 * 1024 * 1024) json_out(['ok' => false, 'error' => 'حجم فایل صوتی باید کمتر از ۲۰ مگابایت باشد'], 422);

$ext = strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION));
$allowedExt = ['mp3', 'm4a', 'ogg', 'wav', 'webm'];
if (!in_array($ext, $allowedExt, true)) json_out(['ok' => false, 'error' => 'فرمت مجاز: MP3، M4A، OGG، WAV'], 422);

$mime = (string) (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
$okMime = ['audio/mpeg', 'audio/mp3', 'audio/mp4', 'audio/x-m4a', 'audio/m4a', 'audio/aac', 'audio/ogg', 'application/ogg',
           'audio/wav', 'audio/x-wav', 'audio/wave', 'audio/webm', 'video/webm', 'video/mp4', 'application/octet-stream'];
if (!in_array($mime, $okMime, true)) json_out(['ok' => false, 'error' => 'فایل صوتی معتبر نیست'], 422);

$dir = dirname(__DIR__) . '/uploads/audio';
if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
    json_out(['ok' => false, 'error' => 'ساخت پوشه‌ی uploads/audio ممکن نیست؛ دسترسی نوشتن پوشه‌ی اصلی سایت را بررسی کنید'], 500);
}
// Access is through api/audio.php, not a direct upload URL.
if (!is_file($dir . '/.htaccess')) {
    file_put_contents($dir . '/.htaccess', "Options -Indexes\nRequire all denied\n");
}

$name = 'a_' . bin2hex(random_bytes(8)) . '.' . $ext;
if (!@move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
    json_out(['ok' => false, 'error' => 'ذخیره‌ی فایل ناموفق بود؛ دسترسی نوشتن پوشه را بررسی کنید'], 500);
}
log_activity($user['username'], 'types.audio', 'آپلود فایل صوتی ' . $name);
json_out(['ok' => true, 'path' => 'uploads/audio/' . $name]);

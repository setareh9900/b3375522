<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/portal-media.php';
if (!gf_is_configured()) redirect('../install.php');
require_login();
portal_media_send(portal_id($_GET['id'] ?? null), null, ($_GET['download'] ?? '') === '1', true);

<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/project-admin.php';
require_once __DIR__ . '/../inc/project-forms.php';
require_once __DIR__ . '/../inc/customer-schema.php';
require_once __DIR__ . '/../inc/features.php';
if (!gf_is_configured()) redirect('../install.php');
$user = require_login();
portal_private_headers();

$tabs = ['contracts' => 'قراردادها', 'services' => 'سرویس و گزارش فنی', 'installation' => 'نصب و راه‌اندازی', 'technical' => 'پرونده فنی و قطعات'];
$selection = $_GET['section'] ?? (isset($_GET['service']) ? 'services' : 'contracts');
$section = is_string($selection) && isset($tabs[$selection]) ? $selection : 'contracts';
$customerId = portal_id($_GET['customer'] ?? null);
$isPost = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
$action = $isPost ? project_post('action') : '';
if ($isPost) $customerId = portal_id($_POST['customer_id'] ?? null);
$error = '';
$ready = false;
$customers = [];
try {
    customer_schema();
    feature_schema();
    if (!portal_ready()) {
        portal_apply_schema(db());
        portal_ready(true);
    }
    $ready = true;
    $customers = q_all('SELECT id,name FROM customer_accounts ORDER BY name,id');
} catch (PDOException $exception) {
    error_log('Portal migration: '.$exception->getMessage());
    http_response_code(503);
    $error = 'جداول پروندهٔ مشتری آماده نشدند. دسترسی ساخت جدول یا وضعیت اتصال را بررسی کنید.';
}
$selectedCustomer = null;
foreach ($customers as $option) if ((int)$option['id'] === $customerId) { $selectedCustomer = $option; break; }
if (!$isPost && !$customerId && $customers) {
    $selectedCustomer = $customers[0];
    $customerId = (int)$selectedCustomer['id'];
}
if ($ready && $isPost) {
    if (!csrf_check(is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : null)) {
        http_response_code(403);
        exit('توکن امنیتی نامعتبر است.');
    }
    try {
        if (!$selectedCustomer) throw new RuntimeException('یک مشتری معتبر انتخاب کنید.');
        $result = project_atomic(static fn() => project_admin_action($action, $customerId));
        $section = $result['section'];
        unset($result['section']);
        $anchor = str_starts_with($action, 'media_') ? '#attachments' : (str_starts_with($action, 'component_') ? '#components' : '');
        log_activity($user['username'], 'project.'.$action, 'مشتری #'.$customerId);
        redirect(project_url($customerId, $section, $result + ['saved' => 1], $anchor));
    } catch (RuntimeException $exception) {
        if ($exception instanceof PDOException) {
            error_log('Project save: '.$exception->getMessage());
            $error = 'ذخیره انجام نشد. اتصال، حجم پیوست و اطلاعات واردشده را بررسی کنید.';
        } else {
            $error = $exception->getMessage();
        }
        http_response_code(422);
    }
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">
    <title>پرونده پروژه‌های مشتریان</title>
    <link rel="stylesheet" href="../assets/css/customer.css">
    <link rel="stylesheet" href="../assets/css/admin-themes.css"><link rel="stylesheet" href="../assets/css/project-admin.css?v=<?=filemtime(__DIR__.'/../assets/css/project-admin.css')?>">
    <script src="../assets/js/admin-themes.js" defer></script>
</head>
<body class="admin-customers pa">
<main class="wrap">
    <header>
        <div><h1>پروندهٔ پروژه‌های مشتریان</h1><p class="hint">ثبت اسناد قرارداد، گزارش‌های سرویس و پیشرفت هر پروژه در حساب موجود مشتری.</p></div>
        <nav aria-label="مدیریت"><a href="index.php">بازگشت به مدیریت</a><a href="customers.php<?=$selectedCustomer ? '?id='.$customerId : ''?>">مدیریت مشتریان</a></nav>
    </header>
    <?php if ($error): ?><p class="notice error" role="alert"><?=e($error)?></p><?php elseif (($_GET['saved'] ?? '') === '1'): ?><p class="notice" role="status">اطلاعات پروژه ذخیره شد.</p><?php endif ?>
    <?php if ($customers): ?>
        <form class="card pa-select-customer" method="get">
            <input type="hidden" name="section" value="<?=e($section)?>">
            <?php project_select('customer', 'انتخاب حساب مشتری', array_column($customers, 'name', 'id'), $customerId, '', true); ?>
            <button type="submit">نمایش پرونده</button>
        </form>
    <?php elseif ($ready): ?><p class="card">هنوز حساب مشتری ثبت نشده است. ابتدا از مدیریت مشتریان یک حساب بسازید.</p><?php endif ?>
    <?php if ($ready && $selectedCustomer): ?>
        <nav class="pa-tabs" aria-label="بخش‌های پرونده">
            <?php foreach ($tabs as $key => $label): ?><a href="<?=e(project_url($customerId, $key))?>"<?= $section === $key ? ' aria-current="page"' : '' ?>><?=e($label)?></a><?php endforeach ?>
        </nav>
        <?php require __DIR__.'/../inc/project-forms/'.$section.'.php'; ?>
    <?php endif ?>
</main>
</body></html>

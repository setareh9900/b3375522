<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-admin-view.php';
$staff = prospect_staff();
prospect_admin_only($staff);
prospect_method(['GET','HEAD','POST']);
if (!prospect_ready()) redirect('prospects.php');
$id = prospect_id($_GET['id'] ?? null);
$error = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    prospect_csrf();
    try {
        $action = prospect_scalar($_POST, 'action');
        if ($action === 'label') {
            $code = prospect_choice($_POST, 'code', 'وضعیت', prospect_default_statuses(), true);
            $title = prospect_text($_POST, 'title', 'عنوان وضعیت', 110, 2);
            $order = prospect_number($_POST, 'sort_order', 'ترتیب نمایش', 0, 999, true);
            q('UPDATE prospect_statuses SET title=?,sort_order=? WHERE code=?', [$title,$order,$code]);
            prospect_flash('نام و ترتیب وضعیت ذخیره شد.');
            prospect_redirect('prospect-team.php#statuses');
        }
        if ($action !== 'rep') throw new ProspectValidation('عملیات نامعتبر است.');
        $id = prospect_id($_POST['id'] ?? null);
        if (isset($_POST['id']) && !$id) throw new ProspectValidation('شناسهٔ نماینده معتبر نیست.');
        $name = prospect_text($_POST, 'full_name', 'نام نماینده', 150, 2);
        $password = prospect_staff_password($_POST,'password',!$id);
        $active = (int)(($_POST['is_active'] ?? '') === '1');
        if ($id) {
            if (!q_val("SELECT id FROM admin_users WHERE id=? AND role='sales'", [$id])) throw new ProspectValidation('نماینده پیدا نشد.',404);
            if ($password !== '') {
                q("UPDATE admin_users SET full_name=?,is_active=?,password_hash=? WHERE id=? AND role='sales'", [$name,$active,password_hash($password,PASSWORD_DEFAULT),$id]);
            } else {
                q("UPDATE admin_users SET full_name=?,is_active=? WHERE id=? AND role='sales'", [$name,$active,$id]);
            }
        } else {
            $username = prospect_text($_POST, 'username', 'نام کاربری', 80, 3);
            if (!preg_match('/^[A-Za-z0-9_.-]{3,80}$/D',$username)) throw new ProspectValidation('نام کاربری لاتین معتبر وارد کنید.');
            if (q_val('SELECT id FROM admin_users WHERE LOWER(username)=LOWER(?)', [$username])) throw new ProspectValidation('نام کاربری تکراری است.');
            q("INSERT INTO admin_users (username,password_hash,full_name,role,is_active,created_at) VALUES (?,?,?,'sales',?,?)",[$username,password_hash($password,PASSWORD_DEFAULT),$name,$active,prospect_now()]);
            $id = last_id();
        }
        log_activity($staff['username'],'prospect.sales_account','نماینده #'.$id);
        prospect_flash('حساب نماینده ذخیره شد.');
        prospect_redirect('prospect-team.php?id='.$id);
    } catch (ProspectValidation | PDOException $ex) { $error = prospect_admin_error($ex,'team'); }
}
$team = prospect_reps();
$rep = null;
foreach ($team as $item) if ((int)$item['id'] === $id) $rep = $item;
if ($id && !$rep && $error === '') { http_response_code(404); $error = 'نماینده پیدا نشد.'; }
prospect_admin_start($staff,'تیم فروش و وضعیت‌ها','team');
prospect_page_intro('تنظیمات CRM','تیم فروش و وضعیت‌ها','نماینده با فرم ورود مدیریت وارد می‌شود، اما فقط به سرنخ‌های تخصیص‌یافته دسترسی دارد.');
prospect_show_flash($error);
?>
<div class="pc-columns">
    <form class="ps-panel ps-form" method="post" action="prospect-team.php">
        <h2><?= $rep ? 'ویرایش نمایندهٔ فروش' : 'افزودن نمایندهٔ فروش'?></h2>
        <?php prospect_admin_action('rep', $rep ? $id : 0); ?>
        <?php prospect_input_field('full_name','نام نماینده',$rep['full_name'] ?? '','required maxlength="150"'); ?>
        <?php if ($rep): ?><p class="pc-hint">نام کاربری: <bdi dir="ltr"><?=e($rep['username'])?></bdi></p><?php else: prospect_input_field('username','نام کاربری لاتین','','required maxlength="80" minlength="3" dir="ltr" autocomplete="off"'); endif ?>
        <?php prospect_input_field('password',$rep ? 'رمز جدید (اختیاری)' : 'رمز ورود (حداقل ۱۲ نویسه)','','minlength="12" maxlength="72" autocomplete="new-password"'.($rep ? '' : ' required'),'password'); ?>
        <?php prospect_checkbox('is_active','حساب فعال باشد',!$rep || (int)$rep['is_active'] === 1); ?>
        <button class="ps-btn ps-primary ps-submit" type="submit">ذخیره نماینده</button>
    </form>
    <section class="ps-panel"><h2>نمایندگان فروش</h2><a href="prospect-team.php" class="ps-link">افزودن نماینده <?=prospect_arrow(14)?></a>
        <?php if (!$team): ?><p class="ps-empty">هنوز نماینده‌ای ثبت نشده است.</p><?php endif ?>
        <?php foreach ($team as $item): ?><div class="pc-row"><a class="ps-link" href="?id=<?=(int)$item['id']?>"><?=e($item['full_name'] ?: $item['username'])?></a><span class="ps-chip"><?=(int)$item['is_active'] ? 'فعال' : 'غیرفعال'?></span></div><?php endforeach ?>
    </section>
</div>
<section class="pc-section pc-settings-list" id="statuses">
    <h2>وضعیت‌های فروش</h2><p class="pc-hint">عنوان و ترتیب را تغییر دهید. معنای وضعیت «تبدیل» و آمار مراحل با کدهای ثابت حفظ می‌شوند.</p>
    <?php foreach (q_all('SELECT code,title,sort_order FROM prospect_statuses ORDER BY sort_order,code') as $row): ?>
        <form method="post" action="prospect-team.php" class="pc-list-item pc-short-form">
            <?php prospect_admin_action('label'); ?><input type="hidden" name="code" value="<?=e($row['code'])?>">
            <?php prospect_input_field('title','برچسب '.prospect_default_statuses()[$row['code']],$row['title'],'required maxlength="110"'); prospect_input_field('sort_order','ترتیب',$row['sort_order'],'required inputmode="numeric" maxlength="3"'); ?>
            <button type="submit" class="ps-btn ps-secondary">ذخیره وضعیت</button>
        </form>
    <?php endforeach ?>
</section>
<?php prospect_admin_end(); ?>

(() => {
    'use strict';
    const d = document;
    const legacyPart = location.hash.match(/^#part-([1-9]\d{0,9})$/);
    if (legacyPart && /\/(?:index\.php)?$/.test(location.pathname)) location.replace('part.php?id=' + legacyPart[1]);

    let toastTimer;
    function toast(message) {
        const box = d.querySelector('.pp-toast');
        if (!box) return;
        box.textContent = message;
        box.hidden = false;
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => { box.hidden = true; }, 3000);
    }

    const account = d.querySelector('.pp-account');
    if (account) {
        d.addEventListener('click', event => { if (account.open && !account.contains(event.target)) account.open = false; });
        account.addEventListener('keydown', event => {
            if (event.key === 'Escape' && account.open) {
                account.open = false;
                account.querySelector('summary').focus();
            }
        });
    }
    const password = d.querySelector('[data-password]');
    const toggle = d.querySelector('[data-password-toggle]');
    if (password && toggle) {
        toggle.hidden = false;
        toggle.addEventListener('click', () => {
            const show = password.type === 'password';
            password.type = show ? 'text' : 'password';
            toggle.setAttribute('aria-pressed', String(show));
            toggle.textContent = show ? 'پنهان' : 'نمایش';
        });
    }

    const catalog = d.querySelector('[data-catalog]');
    if (catalog) {
        const get = name => catalog.querySelector(`[data-part-${name}]`);
        const search = get('search'), brand = get('brand'), filter = get('filter'), sort = get('sort'), view = get('view');
        const list = get('list'), cards = Array.from(list.querySelectorAll('[data-part]'));
        const collator = new Intl.Collator('fa', { numeric: true, sensitivity: 'base' });
        const number = new Intl.NumberFormat('fa');
        const normalize = value => value.toLocaleLowerCase('fa').replace(/[يى]/g, 'ی').replace(/ك/g, 'ک')
            .replace(/[۰-۹]/g, digit => String(digit.charCodeAt(0) - 1776)).replace(/[٠-٩]/g, digit => String(digit.charCodeAt(0) - 1632))
            .replace(/\u200c/g, ' ').trim().replace(/\s+/g, ' ');
        const searchIndex = new Map(cards.map(card => [card, normalize(card.dataset.search)]));
        function apply(reorder = false) {
            const terms = normalize(search.value).split(' ').filter(Boolean);
            let visible = 0;
            if (reorder) cards.sort((a, b) => {
                const idOrder = Number(b.dataset.id) - Number(a.dataset.id);
                return sort.value === 'new' ? idOrder : collator.compare(a.dataset[sort.value], b.dataset[sort.value]) || idOrder;
            });
            for (const card of cards) {
                card.hidden = !terms.every(term => searchIndex.get(card).includes(term))
                    || (brand.value !== '' && brand.value !== card.dataset.brand.trim())
                    || (filter.value === 'image' && card.dataset.hasImage !== 'yes')
                    || (filter.value === 'warranty' && card.dataset.warranty !== 'yes');
                if (!card.hidden) visible++;
                if (reorder) list.appendChild(card);
            }
            get('count').textContent = number.format(visible) + ' قطعه';
            get('empty').hidden = visible !== 0;
        }
        catalog.querySelector('[data-catalog-controls]').hidden = false;
        view.hidden = false;
        search.addEventListener('input', () => apply());
        [brand, filter].forEach(field => field.addEventListener('change', () => apply()));
        sort.addEventListener('change', () => apply(true));
        view.addEventListener('click', () => {
            const isList = list.classList.toggle('is-list');
            view.setAttribute('aria-pressed', String(isList));
            view.textContent = isList ? 'نمای شبکه‌ای' : 'نمای فهرست';
        });
        d.addEventListener('keydown', event => {
            if (event.key === '/' && !event.target.closest('input, select, textarea, [contenteditable]')) {
                event.preventDefault();
                search.focus();
            }
        });
        apply();
    }

    async function copy(value) {
        if (navigator.clipboard && window.isSecureContext) {
            try { await navigator.clipboard.writeText(value); return true; } catch (_) { /* try legacy fallback */ }
        }
        const input = d.createElement('textarea');
        const previous = d.activeElement;
        input.value = value;
        Object.assign(input.style, { position: 'fixed', opacity: '0', inset: '0', pointerEvents: 'none' });
        input.readOnly = true;
        d.body.append(input);
        input.select();
        let ok = false;
        try { ok = d.execCommand('copy'); } catch (_) { /* unsupported */ }
        input.remove();
        previous?.focus();
        return ok;
    }
    d.querySelectorAll('[data-copy-text],[data-share-text]').forEach(button => {
        button.hidden = false;
        button.addEventListener('click', async () => {
            const share = button.dataset.shareText;
            const value = share || button.dataset.copyText;
            if (share && navigator.share) {
                try { await navigator.share({text: share}); return; }
                catch (error) { if (error.name === 'AbortError') return; }
            }
            toast(await copy(value) ? (share ? 'مشخصات کپی شد.' : 'شماره سریال کپی شد.') : 'کپی در این مرورگر در دسترس نیست.');
        });
    });
    const synth = window.speechSynthesis;
    if (synth && window.SpeechSynthesisUtterance) d.querySelectorAll('[data-speak]').forEach(button => {
        button.hidden = false;
        const label = button.querySelector('span');
        let active = false;
        const reset = () => { active = false; label.textContent = 'شنیدن مشخصات'; };
        button.addEventListener('click', () => {
            if (active) { synth.cancel(); reset(); return; }
            const voice = synth.getVoices().find(v => /^fa(?:-|$)/i.test(v.lang));
            let phrases = button.dataset.speak.match(/[^\n.!؟?]+[.!؟?]*/g) || [button.dataset.speak];
            phrases = phrases.map(value => value.trim()).filter(Boolean);
            if (!phrases.length) return;
            active = true;
            label.textContent = 'توقف پخش';
            phrases.forEach((value, i) => {
                const speech = new SpeechSynthesisUtterance(value);
                speech.lang = 'fa-IR';
                if (voice) speech.voice = voice;
                speech.onerror = () => { if (active) toast('خواندن متن در این دستگاه در دسترس نیست.'); reset(); };
                if (i === phrases.length - 1) speech.onend = reset;
                synth.speak(speech);
            });
        });
        window.addEventListener('pagehide', () => { if (active) synth.cancel(); });
    });

    const stories = Array.from(d.querySelectorAll('[data-story]'));
    const dialog = d.querySelector('[data-story-dialog]');
    if (stories.length && dialog && typeof dialog.showModal === 'function') {
        const video = dialog.querySelector('video');
        const number = new Intl.NumberFormat('fa');
        let index = 0, origin = null, touchX = null;
        function open(next) {
            index = (next + stories.length) % stories.length;
            const story = stories[index];
            video.src = story.href;
            if (story.dataset.poster) video.poster = story.dataset.poster;
            else video.removeAttribute('poster');
            dialog.querySelector('h3').textContent = story.dataset.title;
            dialog.querySelector('[data-story-caption]').textContent = story.dataset.caption;
            dialog.querySelector('[data-story-position]').textContent = number.format(index + 1) + ' از ' + number.format(stories.length);
            if (!dialog.open) dialog.showModal();
            video.play().catch(() => {});
        }
        stories.forEach((link, i) => link.addEventListener('click', event => {
            if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
            event.preventDefault(); origin = link; open(i);
        }));
        dialog.querySelector('[data-story-next]').addEventListener('click', () => open(index + 1));
        dialog.querySelector('[data-story-prev]').addEventListener('click', () => open(index - 1));
        video.addEventListener('ended', () => { if (stories.length > 1) open(index + 1); });
        dialog.addEventListener('keydown', event => {
            if (event.target === video) return;
            if (event.key === 'ArrowLeft') open(index + 1);
            if (event.key === 'ArrowRight') open(index - 1);
        });
        dialog.addEventListener('touchstart', event => { touchX = event.touches[0]?.clientX ?? null; }, {passive: true});
        dialog.addEventListener('touchend', event => {
            const dx = touchX === null ? 0 : event.changedTouches[0].clientX - touchX;
            if (Math.abs(dx) > 60) open(index + (dx < 0 ? 1 : -1));
            touchX = null;
        }, {passive: true});
        dialog.addEventListener('close', () => {
            video.pause(); video.removeAttribute('src'); video.load(); origin?.focus();
        });
    }
})();

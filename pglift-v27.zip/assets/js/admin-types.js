/* =========================================================================
   پنل مدیریت — ویرایشگر «انواع آسانسور»
   عکس + نقاط کلیک‌پذیر (با کلیک اضافه، با کشیدن جابه‌جا)، مقاله، مشخصات، صدا، قیمت
   ========================================================================= */
(function () {
  'use strict';
  var mount = document.getElementById('types-editor');
  if (!mount) return;

  var data = JSON.parse(document.getElementById('types-json').textContent);
  var csrf = document.getElementById('types-csrf').value;
  var toastEl = document.getElementById('toast'), toastT = 0;
  var clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };

  function toast(t, kind) {
    if (!toastEl) { alert(t); return; }
    clearTimeout(toastT); toastEl.textContent = t; toastEl.className = 'toast ' + (kind || ''); toastEl.hidden = false;
    requestAnimationFrame(function () { toastEl.classList.add('show'); });
    toastT = setTimeout(function () { toastEl.classList.remove('show'); setTimeout(function () { toastEl.hidden = true; }, 350); }, 3600);
  }
  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') n.textContent = attrs[k]; else if (k === 'class') n.className = attrs[k];
      else if (k === 'value') n.value = attrs[k]; else n.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  function field(label, input, hint) {
    return el('div', { class: 'field' }, [el('label', { text: label }), input, hint ? el('small', { class: 'muted', text: hint }) : null]);
  }
  function post(payload) {
    var fd = new FormData(); fd.append('csrf', csrf);
    Object.keys(payload).forEach(function (k) { fd.append(k, payload[k]); });
    return fetch('action.php', { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'پاسخ نامعتبر از سرور' }; }); });
  }
  function webPath(p) { return /^https?:/.test(p) ? p : '../' + p; }

  /* ---------- حذف پس‌زمینه‌ی تک‌رنگ (سمت مرورگر) ---------- */
  function removeBg(img, tol) {
    var MAX = 1700, sc = Math.min(1, MAX / Math.max(img.naturalWidth, img.naturalHeight));
    var w = Math.max(1, Math.round(img.naturalWidth * sc)), h = Math.max(1, Math.round(img.naturalHeight * sc));
    var cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    var cx = cv.getContext('2d', { willReadFrequently: true });
    cx.drawImage(img, 0, 0, w, h);
    var im = cx.getImageData(0, 0, w, h), d = im.data;
    var pts = [[0, 0], [w - 1, 0], [0, h - 1], [w - 1, h - 1]], bg = [0, 0, 0], cols = [];
    pts.forEach(function (p) { var i = (p[1] * w + p[0]) * 4; cols.push([d[i], d[i + 1], d[i + 2], d[i + 3]]); bg[0] += d[i]; bg[1] += d[i + 1]; bg[2] += d[i + 2]; });
    bg = bg.map(function (v) { return v / 4; });
    if (cols.every(function (c) { return c[3] < 10; })) return { canvas: cv, note: 'این تصویر از قبل شفاف است' };
    if (cols.some(function (c) { return Math.abs(c[0] - bg[0]) + Math.abs(c[1] - bg[1]) + Math.abs(c[2] - bg[2]) > tol * 2.2; }))
      return { canvas: cv, note: 'پس‌زمینه تک‌رنگ نیست؛ حذف انجام نشد' };
    var dist = function (i) { var a = d[i] - bg[0], b = d[i + 1] - bg[1], c = d[i + 2] - bg[2]; return Math.sqrt(a * a + b * b + c * c); };
    var seen = new Uint8Array(w * h), stack = [];
    function push(x, y) { var k = y * w + x; if (!seen[k] && dist(k * 4) <= tol) { seen[k] = 1; stack.push(k); } }
    for (var x = 0; x < w; x++) { push(x, 0); push(x, h - 1); }
    for (var y = 0; y < h; y++) { push(0, y); push(w - 1, y); }
    while (stack.length) {
      var k = stack.pop(), px = k % w, py = (k / w) | 0;
      if (px > 0) push(px - 1, py); if (px < w - 1) push(px + 1, py);
      if (py > 0) push(px, py - 1); if (py < h - 1) push(px, py + 1);
    }
    var minX = w, minY = h, maxX = -1, maxY = -1;
    for (var yy = 0; yy < h; yy++) for (var xx = 0; xx < w; xx++) {
      var kk = yy * w + xx, i4 = kk * 4;
      if (seen[kk]) { d[i4 + 3] = 0; continue; }
      var near = (xx > 0 && seen[kk - 1]) || (xx < w - 1 && seen[kk + 1]) || (yy > 0 && seen[kk - w]) || (yy < h - 1 && seen[kk + w]);
      if (near) { var f = clamp((dist(i4) - tol) / (tol * 0.8), 0, 1); d[i4 + 3] = Math.round(d[i4 + 3] * f); }
      if (d[i4 + 3] > 8) { if (xx < minX) minX = xx; if (xx > maxX) maxX = xx; if (yy < minY) minY = yy; if (yy > maxY) maxY = yy; }
    }
    cx.putImageData(im, 0, 0);
    if (maxX < 0) return { canvas: cv, note: 'چیزی باقی نماند؛ حساسیت را کمتر کنید' };
    var out = document.createElement('canvas'); out.width = maxX - minX + 1; out.height = maxY - minY + 1;
    out.getContext('2d').drawImage(cv, minX, minY, out.width, out.height, 0, 0, out.width, out.height);
    return { canvas: out, note: '' };
  }

  function newType() {
    return { id: '', active: 1, title: 'نوع جدید', tag: '', article: '', specs: [], speech: '', audio: '', image: '', hotspots: [], price: { base: 0, per_stop: 0 } };
  }

  var cards = [];
  function build() {
    mount.innerHTML = ''; cards = [];
    data.forEach(function (t, idx) { var c = buildCard(t, idx); cards.push(c); mount.appendChild(c.root); });
  }

  function buildCard(t, idx) {
    var st = { id: t.id || '', audio: t.audio || '', image: t.image || '', cabinImg: t.cabin_img || '', pano: t.pano || '',
               rect: (t.cabin_rect && t.cabin_rect.length === 4) ? t.cabin_rect.map(Number) : [],
               hot: (t.hotspots || []).map(function (h) { return { title: h[0], desc: h[1], x: +h[2], y: +h[3], z: +h[4] || 2.6, act: h[5] === 'pano' ? 'pano' : '' }; }) };
    var drawMode = false;

    var inTitle = el('input', { class: 'input', value: t.title || '' });
    var inActive = el('input', { type: 'checkbox' }); inActive.checked = !!t.active;
    var inTag = el('input', { class: 'input', value: t.tag || '' });
    var inArt = el('textarea', { class: 'input', rows: '8' }); inArt.value = t.article || '';
    var inSpecs = el('textarea', { class: 'input', rows: '8' }); inSpecs.value = (t.specs || []).map(function (s) { return s[0] + ': ' + s[1]; }).join('\n');
    var inSpeech = el('textarea', { class: 'input', rows: '6' }); inSpeech.value = t.speech || '';
    var inBase = el('input', { class: 'input ltr', type: 'number', min: '0', step: '100000', value: String((t.price && t.price.base) || 0), dir: 'ltr' });
    var inPer = el('input', { class: 'input ltr', type: 'number', min: '0', step: '100000', value: String((t.price && t.price.per_stop) || 0), dir: 'ltr' });

    /* ---------- صدا ---------- */
    var audioBox = el('div', { class: 'tx-adm-audio' });
    function renderAudio() {
      audioBox.innerHTML = '';
      if (st.audio) {
        var rm = el('button', { type: 'button', class: 'btn btn-danger btn-sm', text: 'حذف فایل صوتی' });
        rm.addEventListener('click', function () { st.audio = ''; renderAudio(); });
        audioBox.appendChild(el('audio', { controls: 'controls', preload: 'none', src: '../api/audio.php?f=' + encodeURIComponent(st.audio.split('/').pop()) })); audioBox.appendChild(rm);
      } else audioBox.appendChild(el('p', { class: 'muted small', text: 'فایلی انتخاب نشده؛ از «متن گفتار» با صدای مرورگر استفاده می‌شود.' }));
      var file = el('input', { type: 'file', accept: 'audio/mpeg,audio/mp4,audio/x-m4a,audio/ogg,audio/wav,.mp3,.m4a,.ogg,.wav' });
      var up = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: 'آپلود فایل صوتی' });
      up.addEventListener('click', function () {
        if (!file.files || !file.files[0]) { toast('ابتدا فایل را انتخاب کنید', 'err'); return; }
        var fd = new FormData(); fd.append('csrf', csrf); fd.append('file', file.files[0]);
        up.disabled = true; up.textContent = 'در حال آپلود...';
        fetch('upload-audio.php', { method: 'POST', body: fd, credentials: 'same-origin' })
          .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'پاسخ نامعتبر از سرور' }; }); })
          .then(function (j) { if (j.ok) { st.audio = j.path; toast('فایل صوتی آپلود و ذخیره شد', 'ok'); renderAudio(); var sv = document.getElementById('types-save'); if (sv) sv.click(); } else { toast(j.error || 'خطا در آپلود', 'err'); up.disabled = false; up.textContent = 'آپلود فایل صوتی'; } })
          .catch(function () { toast('خطا در ارتباط با سرور', 'err'); up.disabled = false; up.textContent = 'آپلود فایل صوتی'; });
      });
      audioBox.appendChild(el('div', { class: 'tx-adm-up' }, [file, up]));
    }
    renderAudio();

    /* ---------- عکس + نقاط ---------- */
    var imgBox = el('div', { class: 'tx-adm-img' });
    var rowsBox = el('div', { class: 'tx-adm-hots' });
    var sel = -1;

    function renderRows() {
      rowsBox.innerHTML = '';
      st.hot.forEach(function (h, i) {
        var ti = el('input', { class: 'input', value: h.title, placeholder: 'عنوان قطعه' });
        var de = el('textarea', { class: 'input', rows: '3', placeholder: 'توضیح قطعه' }); de.value = h.desc;
        var zr = el('input', { type: 'range', min: '1.2', max: '5', step: '0.1', value: String(h.z) });
        var zo = el('output', { text: 'زوم ×' + h.z });
        var xi = el('input', { class: 'input ltr', type: 'number', min: '0', max: '100', step: '0.1', value: String(h.x), dir: 'ltr' });
        var yi = el('input', { class: 'input ltr', type: 'number', min: '0', max: '100', step: '0.1', value: String(h.y), dir: 'ltr' });
        var del = el('button', { type: 'button', class: 'btn btn-danger btn-sm', text: 'حذف' });
        var sa = el('select', { class: 'input' }, [el('option', { value: '', text: 'زوم روی قطعه' }), el('option', { value: 'pano', text: 'نمایش ۳۶۰° (کابین)' })]);
        sa.value = h.act || '';
        sa.addEventListener('change', function () { h.act = sa.value; });
        ti.addEventListener('input', function () { h.title = ti.value; });
        de.addEventListener('input', function () { h.desc = de.value; });
        zr.addEventListener('input', function () { h.z = +zr.value; zo.textContent = 'زوم ×' + h.z; });
        xi.addEventListener('input', function () { h.x = clamp(+xi.value || 0, 0, 100); drawMarkers(); });
        yi.addEventListener('input', function () { h.y = clamp(+yi.value || 0, 0, 100); drawMarkers(); });
        del.addEventListener('click', function () { st.hot.splice(i, 1); sel = -1; renderRows(); drawMarkers(); });
        var row = el('div', { class: 'tx-adm-hot' + (i === sel ? ' on' : '') }, [
          el('b', { text: String(i + 1) }),
          el('div', { class: 'tx-adm-hot-f' }, [ti, de,
            el('div', { class: 'tx-adm-hot-n' }, [el('label', { text: 'X٪' }), xi, el('label', { text: 'Y٪' }), yi, zr, zo, sa, del])])
        ]);
        row.addEventListener('focusin', function () { sel = i; drawMarkers(); });
        rowsBox.appendChild(row);
      });
      if (!st.hot.length) rowsBox.appendChild(el('p', { class: 'muted small', text: 'هنوز نقطه‌ای ندارد. روی عکس کلیک کنید تا نقطه اضافه شود.' }));
    }

    var stage, zone;
    function drawMarkers() {
      if (!zone) return;
      zone.querySelectorAll('.tx-adm-dot,.tx-adm-rect').forEach(function (n) { n.remove(); });
      if (st.rect.length === 4) {
        var rc = el('div', { class: 'tx-adm-rect' });
        rc.style.left = st.rect[0] + '%'; rc.style.top = st.rect[1] + '%'; rc.style.width = st.rect[2] + '%'; rc.style.height = st.rect[3] + '%';
        if (st.cabinImg) rc.style.backgroundImage = 'url("' + webPath(st.cabinImg) + '")';
        zone.appendChild(rc);
      }
      st.hot.forEach(function (h, i) {
        var d = el('button', { type: 'button', class: 'tx-adm-dot' + (i === sel ? ' on' : ''), title: h.title, text: String(i + 1) });
        d.style.left = h.x + '%'; d.style.top = h.y + '%';
        d.addEventListener('pointerdown', function (e) {
          e.preventDefault(); e.stopPropagation();
          sel = i; d.setPointerCapture(e.pointerId);
          var r = zone.getBoundingClientRect();
          var move = function (ev) {
            h.x = Math.round(clamp((ev.clientX - r.left) / r.width * 100, 0, 100) * 10) / 10;
            h.y = Math.round(clamp((ev.clientY - r.top) / r.height * 100, 0, 100) * 10) / 10;
            d.style.left = h.x + '%'; d.style.top = h.y + '%';
          };
          var end = function () { d.removeEventListener('pointermove', move); d.removeEventListener('pointerup', end); renderRows(); drawMarkers(); };
          d.addEventListener('pointermove', move); d.addEventListener('pointerup', end);
        });
        zone.appendChild(d);
      });
    }

    function renderImage() {
      imgBox.innerHTML = '';
      var file = el('input', { type: 'file', accept: 'image/png,image/webp,image/jpeg' });
      var chk = el('input', { type: 'checkbox' });
      var tol = el('input', { type: 'range', min: '8', max: '90', value: '36' });
      var up = el('button', { type: 'button', class: 'btn btn-primary btn-sm', text: st.image ? 'جایگزینی عکس' : 'آپلود عکس' });
      var rm = el('button', { type: 'button', class: 'btn btn-danger btn-sm', text: 'حذف عکس' });
      rm.addEventListener('click', function () { st.image = ''; st.hot = []; st.rect = []; st.cabinImg = ''; renderImage(); renderRows(); renderCabin(); });

      up.addEventListener('click', function () {
        var f = file.files && file.files[0];
        if (!f) { toast('ابتدا عکس را انتخاب کنید', 'err'); return; }
        up.disabled = true; up.textContent = 'در حال آپلود...';
        var send = function (blob, name) {
          var fd = new FormData(); fd.append('csrf', csrf); fd.append('file', blob, name);
          fetch('upload-type-image.php', { method: 'POST', body: fd, credentials: 'same-origin' })
            .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'پاسخ نامعتبر از سرور' }; }); })
            .then(function (j) {
              if (j.ok) { st.image = j.path; toast('عکس آپلود شد؛ نقاط را روی آن بگذارید و «ذخیره‌ی همه» را بزنید', 'ok'); renderImage(); renderCabin(); }
              else { toast(j.error || 'خطا در آپلود', 'err'); up.disabled = false; up.textContent = 'آپلود عکس'; }
            })
            .catch(function () { toast('خطا در ارتباط با سرور', 'err'); up.disabled = false; up.textContent = 'آپلود عکس'; });
        };
        if (!chk.checked) { send(f, f.name); return; }
        var url = URL.createObjectURL(f), im = new Image();
        im.onload = function () {
          var r = removeBg(im, +tol.value); URL.revokeObjectURL(url);
          if (r.note) toast(r.note, 'err');
          r.canvas.toBlob(function (b) { send(b || f, 'photo.png'); }, 'image/png');
        };
        im.onerror = function () { toast('خواندن عکس ممکن نشد', 'err'); up.disabled = false; up.textContent = 'آپلود عکس'; };
        im.src = url;
      });

      if (st.image) {
        stage = el('div', { class: 'tx-adm-stage' });
        zone = el('div', { class: 'tx-adm-zone' });
        var im2 = el('img', { src: webPath(st.image), alt: '', draggable: 'false' });
        zone.appendChild(im2); stage.appendChild(zone);
        zone.addEventListener('pointerdown', function (e) {
          if (!drawMode || (e.target !== im2 && e.target !== zone && !(e.target.classList && e.target.classList.contains('tx-adm-rect')))) return;
          e.preventDefault();
          var r = zone.getBoundingClientRect();
          var x0 = clamp((e.clientX - r.left) / r.width * 100, 0, 100), y0 = clamp((e.clientY - r.top) / r.height * 100, 0, 100);
          zone.setPointerCapture(e.pointerId);
          var move = function (ev) {
            var x1 = clamp((ev.clientX - r.left) / r.width * 100, 0, 100), y1 = clamp((ev.clientY - r.top) / r.height * 100, 0, 100);
            st.rect = [Math.round(Math.min(x0, x1) * 10) / 10, Math.round(Math.min(y0, y1) * 10) / 10,
                       Math.max(1, Math.round(Math.abs(x1 - x0) * 10) / 10), Math.max(1, Math.round(Math.abs(y1 - y0) * 10) / 10)];
            drawMarkers();
          };
          var end = function () { zone.removeEventListener('pointermove', move); zone.removeEventListener('pointerup', end); drawMode = false; zone.classList.remove('drawing'); renderCabin(); };
          zone.addEventListener('pointermove', move); zone.addEventListener('pointerup', end);
        });
        zone.addEventListener('click', function (e) {
          if (drawMode) return;
          if (e.target !== im2 && e.target !== zone) return;
          var r = zone.getBoundingClientRect();
          st.hot.push({ title: 'قطعه‌ی جدید', desc: '', z: 2.6, act: '',
            x: Math.round(clamp((e.clientX - r.left) / r.width * 100, 0, 100) * 10) / 10,
            y: Math.round(clamp((e.clientY - r.top) / r.height * 100, 0, 100) * 10) / 10 });
          sel = st.hot.length - 1; renderRows(); drawMarkers();
          var last = rowsBox.lastChild; if (last && last.querySelector) { var inp = last.querySelector('input'); if (inp) { inp.focus(); inp.select(); } }
        });
        imgBox.appendChild(el('p', { class: 'muted small', text: 'روی عکس کلیک کنید تا نقطه اضافه شود؛ نقطه‌ها را با کشیدن جابه‌جا کنید.' }));
        imgBox.appendChild(stage);
        drawMarkers();
      } else {
        zone = null;
        imgBox.appendChild(el('p', { class: 'muted small', text: 'عکسی انتخاب نشده؛ این نوع بدون تصویر و فقط با مقاله نمایش داده می‌شود. بهترین نتیجه: PNG یا WebP شفاف (بدون پس‌زمینه).' }));
      }
      imgBox.appendChild(el('div', { class: 'tx-adm-up' }, [file, up, st.image ? rm : null]));
      imgBox.appendChild(el('label', { class: 'bg-opt' }, [chk, el('span', { text: 'حذف خودکار پس‌زمینه‌ی تک‌رنگ هنگام آپلود (برای عکس‌های دارای زمینه‌ی ساده)' })]));
      imgBox.appendChild(el('div', { class: 'bg-tol' }, [el('label', { text: 'حساسیت حذف' }), tol]));
    }
    renderImage(); renderRows();

    /* ---------- تصویر داخل کابین (جایگزین روی عکس) ---------- */
    var cabinBox = el('div', { class: 'tx-adm-cabin' });
    function uploadTo(kind, file, btn, label, done) {
      var fd = new FormData(); fd.append('csrf', csrf); fd.append('kind', kind); fd.append('file', file);
      btn.disabled = true; btn.textContent = 'در حال آپلود...';
      fetch('upload-type-image.php', { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'پاسخ نامعتبر از سرور' }; }); })
        .then(function (j) { if (j.ok) { done(j.path); toast('آپلود شد؛ «ذخیره‌ی همه» را بزنید', 'ok'); } else { toast(j.error || 'خطا در آپلود', 'err'); btn.disabled = false; btn.textContent = label; } })
        .catch(function () { toast('خطا در ارتباط با سرور', 'err'); btn.disabled = false; btn.textContent = label; });
    }
    function renderCabin() {
      cabinBox.innerHTML = '';
      if (!st.image) { cabinBox.appendChild(el('p', { class: 'muted small', text: 'ابتدا عکس آسانسور را آپلود کنید.' })); return; }
      cabinBox.appendChild(el('p', { class: 'muted small', text: '۱) ناحیه‌ی داخل کابین (محل دیده‌شدن داخل کابین در عکس) را با دکمه‌ی زیر روی عکس بکشید. ۲) تصویر داخل کابین را آپلود کنید؛ همان داخل ناحیه نمایش داده می‌شود.' }));
      var draw = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: st.rect.length === 4 ? 'رسم دوباره‌ی ناحیه' : 'رسم ناحیه‌ی داخل کابین روی عکس' });
      draw.addEventListener('click', function () { drawMode = true; if (zone) zone.classList.add('drawing'); toast('روی عکس بکشید تا مستطیل ناحیه رسم شود', 'ok'); });
      var clr = el('button', { type: 'button', class: 'btn btn-danger btn-sm', text: 'حذف ناحیه' });
      clr.addEventListener('click', function () { st.rect = []; drawMarkers(); renderCabin(); });
      var nums = el('div', { class: 'tx-adm-hot-n' });
      if (st.rect.length === 4) {
        ['X٪', 'Y٪', 'عرض٪', 'ارتفاع٪'].forEach(function (lb, i) {
          var inp = el('input', { class: 'input ltr', type: 'number', min: '0', max: '100', step: '0.1', value: String(st.rect[i]), dir: 'ltr' });
          inp.addEventListener('input', function () { st.rect[i] = clamp(+inp.value || 0, 0, 100); drawMarkers(); });
          nums.appendChild(el('label', { text: lb })); nums.appendChild(inp);
        });
      }
      var file = el('input', { type: 'file', accept: 'image/png,image/webp,image/jpeg' });
      var up = el('button', { type: 'button', class: 'btn btn-primary btn-sm', text: st.cabinImg ? 'جایگزینی تصویر داخل کابین' : 'آپلود تصویر داخل کابین' });
      up.addEventListener('click', function () {
        if (!file.files || !file.files[0]) { toast('ابتدا تصویر را انتخاب کنید', 'err'); return; }
        uploadTo('type', file.files[0], up, 'آپلود تصویر داخل کابین', function (path) { st.cabinImg = path; if (st.rect.length !== 4) toast('ناحیه‌ی داخل کابین را هم رسم کنید', 'err'); renderCabin(); drawMarkers(); });
      });
      var rm = el('button', { type: 'button', class: 'btn btn-danger btn-sm', text: 'برگشت به عکس اصلی' });
      rm.addEventListener('click', function () { st.cabinImg = ''; renderCabin(); drawMarkers(); });
      cabinBox.appendChild(el('div', { class: 'tx-adm-up' }, [draw, st.rect.length === 4 ? clr : null]));
      cabinBox.appendChild(nums);
      cabinBox.appendChild(el('div', { class: 'tx-adm-up' }, [file, up, st.cabinImg ? rm : null]));
    }
    renderCabin();

    /* ---------- تصویر ۳۶۰° ---------- */
    var panoBox = el('div', { class: 'tx-adm-pano' });
    function renderPano() {
      panoBox.innerHTML = '';
      panoBox.appendChild(el('p', { class: 'muted small', text: 'عکس پانورامای ۳۶۰° (equirectangular با نسبت ۲:۱، مثلاً ۴۰۹۶×۲۰۴۸؛ JPG/WebP تا ۱۲ مگابایت) داخل کابین. با زدن روی نقطه‌ی «کابین» (که عملکردش «نمایش ۳۶۰°» است) برای کاربر باز می‌شود.' }));
      if (st.pano) panoBox.appendChild(el('img', { src: webPath(st.pano), alt: '', class: 'tx-adm-pano-img' }));
      var file = el('input', { type: 'file', accept: 'image/jpeg,image/webp,image/png' });
      var up = el('button', { type: 'button', class: 'btn btn-primary btn-sm', text: st.pano ? 'جایگزینی تصویر ۳۶۰°' : 'آپلود تصویر ۳۶۰°' });
      up.addEventListener('click', function () {
        if (!file.files || !file.files[0]) { toast('ابتدا تصویر را انتخاب کنید', 'err'); return; }
        uploadTo('pano', file.files[0], up, 'آپلود تصویر ۳۶۰°', function (path) { st.pano = path; renderPano(); });
      });
      var rm = el('button', { type: 'button', class: 'btn btn-danger btn-sm', text: 'حذف تصویر ۳۶۰°' });
      rm.addEventListener('click', function () { st.pano = ''; renderPano(); });
      panoBox.appendChild(el('div', { class: 'tx-adm-up' }, [file, up, st.pano ? rm : null]));
    }
    renderPano();

    var up = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: '↑' });
    var down = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: '↓' });
    var del = el('button', { type: 'button', class: 'btn btn-danger btn-sm', text: 'حذف' });
    up.addEventListener('click', function () { move(idx, -1); });
    down.addEventListener('click', function () { move(idx, 1); });
    del.addEventListener('click', function () { if (confirm('این نوع آسانسور حذف شود؟')) { syncAll(); data.splice(idx, 1); build(); } });

    var head = el('div', { class: 'tx-adm-head' }, [el('b', { text: (idx + 1) + '.' }), inTitle,
      el('label', { class: 'bg-opt' }, [inActive, el('span', { text: 'نمایش در سایت' })]), up, down, del]);
    var body = el('div', { class: 'tx-adm-body' }, [
      field('شعار کوتاه زیر عنوان', inTag),
      el('div', { class: 'field' }, [el('label', { text: 'عکس آسانسور و نقاط کلیک‌پذیر' }), imgBox]),
      el('div', { class: 'field' }, [el('label', { text: 'توضیح قطعات (برای هر نقطه روی عکس)' }), rowsBox]),
      el('div', { class: 'field' }, [el('label', { text: 'تغییر تصویر داخل کابین' }), cabinBox]),
      el('div', { class: 'field' }, [el('label', { text: 'نمای ۳۶۰° داخل کابین' }), panoBox]),
      field('مقاله‌ی کوتاه', inArt, 'بین پاراگراف‌ها یک خط خالی بگذارید.'),
      field('مشخصات (هر خط: عنوان: مقدار) — مثل نوع ریل، سرعت، ظرفیت', inSpecs),
      field('متن گفتار (توضیح صوتی)', inSpeech, 'با «سلام، این آسانسور ...» شروع کنید. اگر خالی باشد، از متن مقاله استفاده می‌شود.'),
      el('div', { class: 'field' }, [el('label', { text: 'فایل صوتی (اختیاری، MP3 / M4A / OGG / WAV تا ۲۰ مگابایت؛ اگر خطای حجم داد، upload_max_filesize هاست را بالا ببرید)' }), audioBox]),
      el('div', { class: 'field-row two' }, [
        field('قیمت پایه برای ۲ توقف (تومان) — ۰ یعنی نمایش قیمت خاموش', inBase),
        field('افزایش قیمت به‌ازای هر توقف اضافه (تومان)', inPer)])
    ]);
    var root = el('section', { class: 'card tx-adm-card' }, [head, body]);

    function read() {
      var specs = inSpecs.value.split('\n').map(function (l) {
        var i = l.indexOf(':'); if (i < 0) i = l.indexOf('：');
        return i > 0 ? [l.slice(0, i).trim(), l.slice(i + 1).trim()] : null;
      }).filter(Boolean);
      return {
        id: st.id, active: inActive.checked ? 1 : 0, title: inTitle.value.trim(), tag: inTag.value.trim(),
        article: inArt.value.trim(), specs: specs, speech: inSpeech.value.trim(), audio: st.audio, image: st.image,
        cabin_img: st.cabinImg, cabin_rect: st.rect.length === 4 ? st.rect : [], pano: st.pano,
        hotspots: st.hot.map(function (h) { return [h.title, h.desc, h.x, h.y, h.z, h.act || '']; }),
        price: { base: parseInt(inBase.value, 10) || 0, per_stop: parseInt(inPer.value, 10) || 0 }
      };
    }
    return { root: root, read: read };
  }

  function syncAll() { data = cards.map(function (c) { return c.read(); }); }
  function move(i, d) {
    var j = i + d; if (j < 0 || j >= cards.length) return;
    syncAll(); var t = data[i]; data[i] = data[j]; data[j] = t; build();
  }

  document.getElementById('types-add').addEventListener('click', function () {
    if (cards.length >= 14) { toast('حداکثر ۱۴ نوع مجاز است', 'err'); return; }
    syncAll(); data.push(newType()); build();
    mount.lastChild.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  document.getElementById('types-save').addEventListener('click', function () {
    syncAll();
    if (!data.some(function (t) { return t.title; })) { toast('حداقل یک عنوان لازم است', 'err'); return; }
    post({ do: 'types.save', data: JSON.stringify(data) }).then(function (j) {
      if (j.ok) toast('ذخیره شد (' + j.count + ' نوع)', 'ok'); else toast(j.error || 'خطا در ذخیره', 'err');
    }).catch(function () { toast('خطا در ارتباط با سرور', 'err'); });
  });
  document.getElementById('types-reset').addEventListener('click', function () {
    if (!confirm('همه‌ی متن‌ها و تنظیمات این بخش به حالت پیش‌فرض برگردد؟')) return;
    post({ do: 'types.reset' }).then(function (j) { if (j.ok) location.reload(); else toast(j.error || 'خطا', 'err'); });
  });

  build();
})();

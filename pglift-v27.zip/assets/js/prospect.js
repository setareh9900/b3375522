(() => {
    const btn = document.querySelector('[data-prospect-copy]');
    if (!btn || !navigator.clipboard) return;
    btn.hidden = false;
    btn.addEventListener('click', async () => {
        const receipt = document.querySelector('[data-prospect-receipt]');
        const status = document.querySelector('[data-copy-status]');
        try {
            await navigator.clipboard.writeText(receipt.innerText);
            status.textContent = 'کد و کلید پیگیری کپی شد.';
        } catch (_) {
            status.textContent = 'کپی نشد؛ لطفاً کد و کلید را دستی ذخیره کنید.';
        }
    });
})();

// The share URL follows the real browser origin and installation directory, not a supplied Host header.
for (const share of document.querySelectorAll('[data-guide-share]')) {
    const anchor = share.querySelector('[data-guide-anchor]');
    const address = share.querySelector('[data-guide-address]');
    const copy = share.querySelector('[data-guide-copy]');
    const status = share.querySelector('[data-guide-status]');
    address.value = anchor.href;
    address.addEventListener('focus', () => address.select());
    copy.hidden = false;
    copy.addEventListener('click', async () => {
        try {
            await navigator.clipboard.writeText(address.value);
            status.textContent = 'لینک آمادهٔ ارسال کپی شد.';
        } catch (_) {
            address.focus();
            status.textContent = 'نشانی انتخاب شد؛ آن را دستی کپی کنید.';
        }
    });
}

const contentKind = document.querySelector('.pc-editor [name="kind"]');
if (contentKind) {
    const fields = document.querySelectorAll('[data-video-fields]');
    const updateVideoFields = () => { for (const field of fields) field.hidden = field.dataset.videoFields !== contentKind.value; };
    contentKind.addEventListener('change', updateVideoFields);
    updateVideoFields();
}

for (const section of document.querySelectorAll('.ps-context-video')) {
    section.addEventListener('toggle', () => { if (!section.open) section.querySelector('video')?.pause(); });
}

(() => {
    const dialog = document.querySelector('[data-story-dialog]');
    if (!dialog || typeof dialog.showModal !== 'function') return;
    const stories = [...document.querySelectorAll('[data-story-rail] [data-story]')];
    const player = dialog.querySelector('video');
    const title = dialog.querySelector('[data-story-dialog-title]');
    const previous = dialog.querySelector('[data-story-prev]');
    const next = dialog.querySelector('[data-story-next]');
    const count = dialog.querySelector('[data-story-count]');
    const original = dialog.querySelector('[data-story-original]');
    const numbers = new Intl.NumberFormat('fa');
    let current = 0;
    let opener = null;
    const show = index => {
        if (!stories[index]) return;
        current = index;
        const source = stories[index];
        title.textContent = source.dataset.storyTitle;
        player.pause();
        player.poster = source.dataset.storyPoster;
        player.src = source.dataset.storyMedia;
        original.href = source.href;
        previous.disabled = index === 0;
        next.disabled = index === stories.length - 1;
        count.textContent = `${numbers.format(index + 1)} از ${numbers.format(stories.length)}`;
    };
    stories.forEach((story, index) => story.addEventListener('click', event => {
        if (event.defaultPrevented || event.button !== 0 || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
        event.preventDefault();
        opener = story;
        show(index);
        dialog.showModal();
    }));
    previous.addEventListener('click', () => show(current - 1));
    next.addEventListener('click', () => show(current + 1));
    dialog.addEventListener('close', () => {
        if (dialog.open) return;
        player.pause();
        player.removeAttribute('src');
        player.removeAttribute('poster');
        player.load();
        if (opener) opener.focus({preventScroll: true});
    });
})();

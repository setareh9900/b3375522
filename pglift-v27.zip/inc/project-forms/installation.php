<?php
$projects = portal_projects($customerId);
$projectId = isset($_GET['project']) ? portal_id($_GET['project']) : (int)($projects[0]['id'] ?? 0);
$project = portal_owned('project', $projectId, $customerId) ?? [];
$values = project_form_values($project, 'project_save');
$stageId = portal_id($_GET['stage'] ?? null);
$stages = $project ? q_all('SELECT * FROM customer_installation_stages WHERE project_id=? ORDER BY sort_order,id', [$projectId]) : [];
$stage = [];
foreach ($stages as $row) if ((int)$row['id'] === $stageId) { $stage = $row; break; }
$stageValues = project_form_values($stage, 'stage_save');
?>
<div class="pa-layout">
    <section>
        <form method="post" class="card">
            <h2><?=$project ? 'ویرایش پروژه نصب' : 'ثبت پروژه نصب'?></h2>
            <?php project_hidden('project_save', $customerId, (int)($project['id'] ?? 0)); ?>
            <div class="pa-fields"><?php project_field('title', 'عنوان پروژه', $values['title'] ?? '', ['required' => true, 'maxlength' => 200]);
                project_field('expected_completion_date', 'تاریخ پیش‌بینی پایان', $values['expected_completion_date'] ?? '');
                project_field('progress', 'پیشرفت کلی از ۰ تا ۱۰۰ (اختیاری)', $values['progress'] ?? '', ['type' => 'number', 'min' => 0, 'max' => 100]); ?></div>
            <p class="hint">در صورت نامشخص بودن، درصد را خالی بگذارید. درصد از تعداد مراحل محاسبه نمی‌شود.</p>
            <?php project_textarea('description', 'توضیحات پروژه برای مشتری', $values['description'] ?? ''); ?>
            <button type="submit">ذخیره پروژه</button>
        </form>
        <?php if ($project): ?>
            <section class="card" id="stages">
                <h2>مراحل نصب</h2><p class="hint">مراحل بر اساس شمارهٔ ترتیب نمایش داده می‌شوند. وضعیت «در حال انجام» یا «متوقف» به عنوان مرحلهٔ جاری دیده می‌شود.</p>
                <?php if (!$stages): ?>
                    <form method="post" class="pa-template-form"><?php project_hidden('stage_template', $customerId, $projectId); ?>
                        <button type="submit" class="secondary">افزودن الگوی ۱۴ مرحله‌ای</button>
                        <p class="hint">فقط نام و ترتیب مراحل اضافه می‌شود. سپس می‌توانید مرحله‌ای را حذف، اضافه یا بازچینی کنید.</p>
                    </form>
                <?php else: ?>
                    <ul class="pa-records"><?php foreach ($stages as $entry): ?><li>
                        <div><b><?=e($entry['title'])?></b><small class="hint">ترتیب <?=fa_digits($entry['sort_order'])?> · <?=e(PORTAL_STAGE_STATUSES[$entry['status']] ?? 'وضعیت ثبت نشده')?></small></div>
                        <div class="pa-actions"><a href="<?=e(project_url($customerId, 'installation', ['project' => $projectId, 'stage' => $entry['id']], '#stage-form'))?>"<?= (int)$entry['id'] === $stageId ? ' aria-current="page"' : '' ?>>ویرایش</a><?php project_delete('stage_delete', $customerId, (int)$entry['id'], 'حذف'); ?></div>
                    </li><?php endforeach ?></ul>
                <?php endif ?>
                <form method="post" id="stage-form">
                    <?php project_hidden('stage_save', $customerId, (int)($stage['id'] ?? 0), ['project_id' => $projectId]); ?>
                    <h3><?=$stage ? 'ویرایش مرحله' : 'افزودن مرحله'?></h3>
                    <div class="pa-fields"><?php project_field('title', 'عنوان مرحله', $stageValues['title'] ?? '', ['required' => true, 'maxlength' => 200]);
                        project_field('sort_order', 'شماره ترتیب', $stageValues['sort_order'] ?? ($stages ? min(999999, (int)max(array_column($stages, 'sort_order')) + 10) : 10), ['type' => 'number', 'min' => 0, 'max' => 999999]);
                        project_select('status', 'وضعیت مرحله', PORTAL_STAGE_STATUSES, $stageValues['status'] ?? '');
                        project_field('progress', 'درصد پیشرفت (اختیاری)', $stageValues['progress'] ?? '', ['type' => 'number', 'min' => 0, 'max' => 100]);
                        project_field('start_date', 'تاریخ شروع', $stageValues['start_date'] ?? '');
                        project_field('expected_date', 'تاریخ پایان پیش‌بینی‌شده', $stageValues['expected_date'] ?? '');
                        project_field('completion_date', 'تاریخ پایان واقعی', $stageValues['completion_date'] ?? '');
                        project_field('technician', 'تکنسین یا تیم مسئول', $stageValues['technician'] ?? '', ['maxlength' => 160]); ?></div>
                    <?php project_textarea('description', 'شرح مرحله', $stageValues['description'] ?? '');
                    project_textarea('customer_notes', 'یادداشت قابل مشاهده برای مشتری', $stageValues['customer_notes'] ?? '');
                    project_textarea('admin_notes', 'یادداشت داخلی (فقط مدیریت)', $stageValues['admin_notes'] ?? ''); ?>
                    <div class="pa-actions"><button type="submit">ذخیره مرحله</button><?php if ($stage): ?><a href="<?=e(project_url($customerId, 'installation', ['project' => $projectId], '#stage-form'))?>">مرحله جدید</a><?php endif ?></div>
                </form>
            </section>
            <?php if ($stage) project_media_panel('stage', (int)$stage['id'], $customerId); ?>
        <?php endif ?>
    </section>
    <aside>
        <section class="card pa-record-panel">
            <h2>پروژه‌های همین حساب</h2>
            <a href="<?=e(project_url($customerId, 'installation', ['project' => 'new']))?>">ثبت پروژهٔ جدید</a>
            <?php if ($projects): ?><ul class="pa-records"><?php foreach ($projects as $entry): ?><li>
                <div><strong><?=e($entry['title'])?></strong><?php if ($entry['progress'] !== null): ?><small class="hint">پیشرفت ثبت‌شده: <?=fa_digits($entry['progress'])?>٪</small><?php endif ?></div>
                <div class="pa-actions"><a href="<?=e(project_url($customerId, 'installation', ['project' => $entry['id']]))?>"<?= (int)$entry['id'] === $projectId ? ' aria-current="page"' : '' ?>>مدیریت</a><?php project_delete('project_delete', $customerId, (int)$entry['id'], 'حذف'); ?></div>
            </li><?php endforeach ?></ul><?php endif ?>
        </section>
        <?php if ($project):
            $updates = q_all('SELECT * FROM customer_installation_updates WHERE project_id=? ORDER BY created_at DESC,id DESC', [$projectId]); ?>
            <section class="card">
                <h2>به‌روزرسانی پروژه</h2>
                <form method="post"><?php project_hidden('update_add', $customerId, $projectId); ?>
                    <?php project_textarea('message', 'متن قابل انتشار برای مشتری'); ?><button type="submit">انتشار به‌روزرسانی</button>
                </form>
                <?php if ($updates): ?><ul class="pa-records"><?php foreach ($updates as $update): ?><li><div><small class="hint"><?=e(jdate($update['created_at'], false))?></small><p><?=e($update['message'])?></p></div><?php project_delete('update_delete', $customerId, (int)$update['id'], 'حذف', ['project_id' => $projectId]); ?></li><?php endforeach ?></ul><?php endif ?>
            </section>
        <?php endif ?>
    </aside>
</div>

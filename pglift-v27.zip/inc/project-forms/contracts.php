<?php
$contracts = portal_contracts($customerId);
$contractId = portal_id($_GET['contract'] ?? null);
$contract = portal_owned('contract', $contractId, $customerId) ?? [];
$details = $contract ? (q_one('SELECT * FROM customer_contract_details WHERE contract_id=?', [$contractId]) ?? []) : [];
$values = project_form_values(array_merge($contract, $details), 'contract_save');
?>
<div class="pa-layout">
    <section>
        <form method="post" class="card">
            <h2><?=$contract ? 'ویرایش قرارداد' : 'افزودن قرارداد'?></h2>
            <?php project_hidden('contract_save', $customerId, (int)($contract['id'] ?? 0)); ?>
            <p class="hint">اطلاعات اصلی مانند نسخهٔ قبل پس از ذخیره برای مشتری قابل مشاهده‌اند. تاریخ‌ها را به قالب ۱۴۰۵/۰۸/۲۷ یا 2026-11-18 بنویسید.</p>
            <div class="pa-fields">
                <?php project_field('contract_no', 'شماره قرارداد', $values['contract_no'] ?? '', ['required' => true, 'maxlength' => 80]);
                project_field('title', 'عنوان قرارداد', $values['title'] ?? '', ['required' => true, 'maxlength' => 200]);
                project_select('status', 'وضعیت قرارداد', PORTAL_CONTRACT_STATUSES, $values['status'] ?? '', 'انتخاب کنید', true);
                project_field('contract_date', 'تاریخ تنظیم', $values['contract_date'] ?? '');
                project_field('start_date', 'تاریخ شروع', $values['start_date'] ?? '');
                project_field('end_date', 'تاریخ انقضا', $values['end_date'] ?? '');
                project_field('total_amount', 'مبلغ کل با واحد پول', $values['total_amount'] ?? '', ['maxlength' => 150]);
                project_field('project_address', 'نشانی پروژه', $values['project_address'] ?? '', ['maxlength' => 500]); ?>
            </div>
            <details class="pa-details"<?= !$contract || $action === 'contract_save' ? ' open' : '' ?>>
                <summary>متن قرارداد و شرح پوشش</summary>
                <?php project_textarea('coverage', 'شرح پوشش ثبت‌شده', $values['coverage'] ?? '');
                project_textarea('contract_text', 'متن کامل قرارداد', $values['contract_text'] ?? '', 6);
                project_textarea('contract_parts', 'قطعات و مبالغ ثبت‌شده', $values['contract_parts'] ?? ''); ?>
            </details>
            <details class="pa-details"<?= $action === 'contract_save' ? ' open' : '' ?>>
                <summary>بندهای تفکیک‌شده و تأیید</summary>
                <p class="hint">تنها بندهای واقعی و تأییدشده را وارد کنید. بدون تأیید انتشار، این بندها در پنل مشتری نمایش داده نمی‌شوند.</p>
                <div class="pa-fields"><?php foreach (PORTAL_CONTRACT_FIELDS as $field => $label) project_textarea($field, $label, $values[$field] ?? ''); ?></div>
            </details>
            <div class="pa-publish">
                <?php project_check('is_maintenance', 'این قرارداد برای نگهداری است', $values['is_maintenance'] ?? false);
                project_field('included_visits', 'تعداد کل بازدیدِ مشمول (اختیاری)', $values['included_visits'] ?? '', ['type' => 'number', 'min' => 0, 'max' => 100000]); ?>
                <p class="hint">برای نمایش بازدیدهای باقی‌مانده، سهمیهٔ واقعی را وارد کنید و گزارش‌های تکمیل‌شده را به همین قرارداد مرتبط کنید. در صورت نامشخص بودن، خالی بگذارید.</p>
                <?php project_check('is_published', 'بندهای تکمیلی و اطلاعات نگهداری بررسی و برای مشتری تأیید شده‌اند', $values['is_published'] ?? false); ?>
            </div>
            <div class="pa-actions"><button type="submit">ذخیره قرارداد</button><?php if ($contract): ?><a href="<?=e(project_url($customerId, 'contracts'))?>">قرارداد جدید</a><?php endif ?></div>
        </form>
        <?php if ($contract) project_media_panel('contract', $contractId, $customerId); ?>
    </section>
    <aside class="card pa-record-panel">
        <h2>قراردادهای ثبت‌شده</h2>
        <?php if (!$contracts): ?><p class="hint">قراردادی برای این مشتری ثبت نشده است.</p><?php endif ?>
        <ul class="pa-records"><?php foreach ($contracts as $entry): ?><li>
            <div><strong><?=e($entry['title'])?></strong><small class="hint"><bdi><?=e($entry['contract_no'])?></bdi> · <?=e(PORTAL_CONTRACT_STATUSES[$entry['status']] ?? $entry['status'])?></small></div>
            <div class="pa-actions"><a href="<?=e(project_url($customerId, 'contracts', ['contract' => $entry['id']]))?>"<?= (int)$entry['id'] === $contractId ? ' aria-current="page"' : '' ?>>ویرایش</a><?php project_delete('contract_delete', $customerId, (int)$entry['id'], 'حذف'); ?></div>
        </li><?php endforeach ?></ul>
    </aside>
</div>

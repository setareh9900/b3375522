<?php
$visits = portal_visits($customerId);
$visitId = portal_id($_GET['service'] ?? null);
$visit = portal_owned('service', $visitId, $customerId) ?? [];
$details = $visit ? (q_one('SELECT * FROM customer_service_report_details WHERE visit_id=?', [$visitId]) ?? []) : [];
$values = project_form_values(array_merge($visit, $details), 'service_save');
$contractOptions = array_column(q_all('SELECT c.id,c.title FROM customer_contracts c JOIN customer_contract_details d ON d.contract_id=c.id WHERE c.customer_id=? AND d.is_maintenance=1 ORDER BY c.id DESC', [$customerId]), 'title', 'id');
if (!empty($details['contract_id']) && !isset($contractOptions[$details['contract_id']])) {
    $oldContract = portal_owned('contract', (int)$details['contract_id'], $customerId);
    if ($oldContract) $contractOptions[$oldContract['id']] = $oldContract['title'];
}
?>
<div class="pa-layout">
    <section>
        <form method="post" class="card">
            <h2><?=$visit ? 'ویرایش گزارش '.e(portal_report_number($visitId)) : 'ثبت گزارش سرویس'?></h2>
            <?php project_hidden('service_save', $customerId, (int)($visit['id'] ?? 0)); ?>
            <p class="hint">این گزارش پس از ذخیره در پروندهٔ مشتری قابل مشاهده است. تاریخ را به‌صورت سال/ماه/روز وارد کنید.</p>
            <div class="pa-fields">
                <?php project_field('service_date', 'تاریخ سرویس', $values['service_date'] ?? '', ['required' => true]);
                project_field('next_service_date', 'تاریخ سرویس بعدی', $values['next_service_date'] ?? '');
                project_field('technician', 'نام تکنسین', $values['technician'] ?? '', ['maxlength' => 160]);
                project_select('status', 'وضعیت بازدید', PORTAL_VISIT_STATUSES, $values['status'] ?? '', 'انتخاب کنید', true);
                project_select('service_type', 'نوع سرویس', PORTAL_SERVICE_TYPES, $values['service_type'] ?? '');
                project_select('operational_status', 'وضعیت آسانسور در این بازدید', PORTAL_OPERATIONAL_STATUSES, $values['operational_status'] ?? '');
                project_field('start_time', 'ساعت شروع', $values['start_time'] ?? '', ['type' => 'time']);
                project_field('completion_time', 'ساعت پایان', $values['completion_time'] ?? '', ['type' => 'time']);
                project_select('contract_id', 'قرارداد نگهداری مرتبط', $contractOptions, $values['contract_id'] ?? '', 'بدون ارتباط'); ?>
            </div>
            <?php project_textarea('summary', 'خلاصهٔ بازدید', $values['summary'] ?? ''); ?>
            <details class="pa-details"<?= !$visit || $action === 'service_save' ? ' open' : '' ?>>
                <summary>جزئیات فنی، توصیه و پیگیری</summary>
                <div class="pa-fields"><?php foreach (PORTAL_REPORT_FIELDS as $field => $label) project_textarea($field, $label, $values[$field] ?? '');
                project_textarea('resolved_problems', 'مشکلات رفع‌شده', $values['resolved_problems'] ?? '');
                project_textarea('replaced_parts', 'شرح قطعات تعویض‌شده (فیلد متنی نسخهٔ قبل)', $values['replaced_parts'] ?? ''); ?></div>
            </details>
            <div class="pa-actions"><button type="submit">ذخیره گزارش</button><?php if ($visit): ?><a href="<?=e(project_url($customerId, 'services'))?>">گزارش جدید</a><?php endif ?></div>
        </form>
        <?php if ($visit):
            $components = q_all('SELECT * FROM customer_service_components WHERE visit_id=? ORDER BY id', [$visitId]);
            $componentId = portal_id($_GET['component'] ?? null);
            $component = $componentId ? (q_one('SELECT * FROM customer_service_components WHERE id=? AND visit_id=?', [$componentId,$visitId]) ?? []) : [];
            $component = project_form_values($component, 'component_save');
            $parts = array_column(portal_parts($customerId), 'name', 'id'); ?>
            <section class="card" id="components">
                <h2>قطعات مرتبط با گزارش</h2><p class="hint">ارتباط با قطعهٔ نصب‌شده، گزارش را در پروندهٔ همان قطعه هم قابل مشاهده می‌کند. برای قطعهٔ بدون پرونده، نام، مدل و سازنده را در صورت اطلاع وارد کنید.</p>
                <?php if ($components): ?><ul class="pa-records"><?php foreach ($components as $row): ?><li>
                    <div><b><?=e($row['name'])?></b><small class="hint"><?=e(PORTAL_COMPONENT_RELATIONS[$row['relation_type']] ?? $row['relation_type'])?></small></div>
                    <div class="pa-actions"><a href="<?=e(project_url($customerId, 'services', ['service' => $visitId,'component' => $row['id']], '#components'))?>">ویرایش</a><?php project_delete('component_delete', $customerId, (int)$row['id'], 'حذف', ['visit_id' => $visitId]); ?></div>
                </li><?php endforeach ?></ul><?php endif ?>
                <form method="post">
                    <?php project_hidden('component_save', $customerId, (int)($component['id'] ?? 0), ['visit_id' => $visitId]); ?>
                    <div class="pa-fields"><?php project_select('part_id', 'ارتباط با قطعهٔ نصب‌شده', $parts, $component['part_id'] ?? '', 'بدون ارتباط');
                    project_select('relation_type', 'نوع اقدام', PORTAL_COMPONENT_RELATIONS, $component['relation_type'] ?? '', 'انتخاب کنید', true);
                    project_field('name', 'نام قطعه', $component['name'] ?? '');
                    project_field('manufacturer', 'سازنده', $component['manufacturer'] ?? ''); project_field('model', 'مدل', $component['model'] ?? ''); ?></div>
                    <?php project_textarea('notes', 'یادداشت این قطعه', $component['notes'] ?? '', 2); ?>
                    <div class="pa-actions"><button type="submit"><?= !empty($component['id']) ? 'ذخیره تغییرات قطعه' : 'افزودن قطعه به گزارش' ?></button><?php if (!empty($component['id'])): ?><a href="<?=e(project_url($customerId, 'services', ['service' => $visitId], '#components'))?>">ردیف جدید</a><?php endif ?></div>
                </form>
            </section>
            <?php project_media_panel('service', $visitId, $customerId); ?>
        <?php endif ?>
    </section>
    <aside class="card pa-record-panel">
        <h2>بازدیدهای ثبت‌شده</h2>
        <?php if (!$visits): ?><p class="hint">بازدیدی برای این حساب ثبت نشده است.</p><?php endif ?>
        <ul class="pa-records"><?php foreach ($visits as $entry): ?><li>
            <div><strong><?=e($entry['service_date'])?></strong><small class="hint"><?=e(PORTAL_SERVICE_TYPES[$entry['service_type'] ?? ''] ?? 'بازدید سرویس')?> · <?=e(PORTAL_VISIT_STATUSES[$entry['status']] ?? $entry['status'])?></small></div>
            <div class="pa-actions"><a href="<?=e(project_url($customerId, 'services', ['service' => $entry['id']]))?>"<?= (int)$entry['id'] === $visitId ? ' aria-current="page"' : '' ?>>ویرایش</a><?php project_delete('service_delete', $customerId, (int)$entry['id'], 'حذف'); ?></div>
        </li><?php endforeach ?></ul>
    </aside>
</div>

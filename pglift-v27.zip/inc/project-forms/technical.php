<?php
$accountEdit = 'customers.php?id='.$customerId;
$profile = project_form_values(portal_profile($customerId), 'profile_save');
$parts = portal_parts($customerId);
$partId = portal_id($_GET['part'] ?? null);
$part = portal_owned('part', $partId, $customerId);
$partValues = $part ? project_form_values(q_one('SELECT * FROM customer_part_details WHERE part_id=?', [$partId]) ?? [], 'part_save') : [];
?>
<div class="pa-layout">
    <section>
        <form method="post" class="card">
            <h2>مشخصات ثبت‌شدهٔ آسانسور</h2>
            <p class="hint">این فیلدها اختصاصی همین مشتری هستند. نوع آسانسور، توضیحات و فایل صوتی از <a href="<?=e($accountEdit)?>">حساب مشتری</a> تنظیم می‌شوند.</p>
            <?php project_hidden('profile_save', $customerId); ?>
            <div class="pa-fields">
                <?php project_select('operational_status', 'وضعیت فعلی بهره‌برداری', PORTAL_OPERATIONAL_STATUSES, $profile['operational_status'] ?? '');
                project_select('maintenance_status', 'وضعیت فعلی نگهداری', PORTAL_MAINTENANCE_STATUSES, $profile['maintenance_status'] ?? '');
                foreach (array_slice(PORTAL_PROFILE_FIELDS, 0, 11, true) as $key => $label) project_field($key, $label, $profile[$key] ?? ''); ?>
            </div>
            <details class="pa-details"<?= $action === 'profile_save' ? ' open' : '' ?>>
                <summary>ایمنی، مشخصات تکمیلی و ضمانت</summary>
                <?php foreach (array_slice(PORTAL_PROFILE_FIELDS, 11, null, true) as $key => $label) project_textarea($key, $label, $profile[$key] ?? ''); ?>
            </details>
            <button type="submit">ذخیره پرونده فنی</button>
        </form>
        <?php if ($part): ?>
            <form method="post" class="card" id="part-technical">
                <h2>جزئیات قطعه: <?=e($part['name'])?></h2>
                <p class="hint">برای تغییر تصویر، شماره سریال و اطلاعات اصلی، <a href="<?=e($accountEdit.'&part='.$partId)?>">ویرایش قطعه در مدیریت مشتریان</a> را باز کنید.</p>
                <?php project_hidden('part_save', $customerId, $partId); ?>
                <?php foreach (PORTAL_PART_FIELDS as $key => $label) {
                    if ($key === 'warranty_status') project_field($key, $label, $partValues[$key] ?? '', ['maxlength' => 150]);
                    else project_textarea($key, $label, $partValues[$key] ?? '');
                } ?>
                <button type="submit">ذخیره جزئیات قطعه</button>
            </form>
        <?php endif ?>
    </section>
    <aside class="card pa-record-panel">
        <h2>قطعات این مشتری</h2>
        <p class="hint">از <a href="<?=e($accountEdit)?>">مدیریت مشتریان</a> می‌توانید قطعهٔ جدید ثبت کنید.</p>
        <?php if (!$parts): ?><p class="hint">قطعه‌ای ثبت نشده است.</p><?php endif ?>
        <ul class="pa-records"><?php foreach ($parts as $entry): ?><li>
            <div><strong><?=e($entry['name'])?></strong><small class="hint"><?=e($entry['brand'])?> <bdi><?=e($entry['model'])?></bdi></small></div>
            <a href="<?=e(project_url($customerId, 'technical', ['part' => $entry['id']], '#part-technical'))?>"<?= (int)$entry['id'] === $partId ? ' aria-current="page"' : '' ?>>ویرایش جزئیات</a>
        </li><?php endforeach ?></ul>
    </aside>
</div>

<?php
declare(strict_types=1);
require_once __DIR__.'/prospect-media.php';
require_once __DIR__.'/prospect-crm.php';

function prospect_content_lock(int $id): array
{
    if (gf_driver() === 'sqlite') q('UPDATE prospect_content SET id=id WHERE id=?',[$id]);
    $row = q_one('SELECT * FROM prospect_content WHERE id=?'.(gf_driver() === 'sqlite' ? '' : ' FOR UPDATE'),[$id]);
    if (!$row) throw new ProspectValidation('محتوا پیدا نشد.',404);
    return $row;
}

function prospect_optional_id(array $input, string $name, string $label): ?int
{
    $raw = $input[$name] ?? '';
    $id = prospect_id($raw);
    if ($raw !== '' && !$id) throw new ProspectValidation($label.' را از گزینه‌های فرم انتخاب کنید.');
    return $id ?: null;
}

function prospect_prepare_video_details(string $kind, array $input): array
{
    if ($kind !== 'guide_video' && $kind !== 'portfolio_video') return [];
    $guide = $kind === 'guide_video';
    return [
        'placement'=>$guide ? prospect_choice($input,'placement','محل نمایش',prospect_video_placements()) : '',
        'portfolio_group'=>$guide ? '' : prospect_choice($input,'portfolio_group','دستهٔ ویترین',prospect_portfolio_groups()),
        'company_name'=>$guide ? '' : prospect_text($input,'company_name','نام شرکت همکار',160),
        'equipment_brand'=>$guide ? '' : prospect_text($input,'equipment_brand','نام برند تجهیزات',160),
        'building_name'=>$guide ? '' : prospect_text($input,'building_name','نام ساختمان یا پروژه',160),
    ];
}

function prospect_replace_video_details(int $id, array $details): void
{
    if (!prospect_guidance_ready()) return;
    q('DELETE FROM prospect_video_details WHERE content_id=?',[$id]);
    if ($details) q('INSERT INTO prospect_video_details (content_id,placement,portfolio_group,company_name,equipment_brand,building_name) VALUES (?,?,?,?,?,?)',
        array_merge([$id],array_values($details)));
}

function prospect_content_assert_public(array $row, array $media, array $details = []): void
{
    if ($row['state'] !== 'published') return;
    if ($row['summary'] === '' || $row['body'] === '') throw new ProspectValidation('برای انتشار، خلاصه و متن یا شرح ویدیو را بنویسید.');
    if (in_array($row['kind'], prospect_evidence_types(), true) && (!(int)$row['is_verified'] || mb_strlen(trim($row['verification_note'])) < 3)) {
        throw new ProspectValidation('برای انتشار اطلاعات واقعی، مرجع داخلی و تأیید صحت و مجوز انتشار لازم است.');
    }
    if ($row['kind'] === 'project' && (!$media['cover'] || $row['image_alt'] === '' || $row['project_type'] === '' || $row['elevator_type'] === '' || $row['technical_info'] === '')) {
        throw new ProspectValidation('برای نمایش پروژه، عکس اصلی و متن جایگزین، نوع پروژه و آسانسور و اطلاعات فنی مستند لازم است.');
    }
    if ($row['kind'] === 'guide_video' && !isset(prospect_video_placements()[$details['placement'] ?? ''])) {
        throw new ProspectValidation('برای انتشار راهنمای ویدیویی، صفحهٔ مرتبط را انتخاب کنید.');
    }
    if ($row['kind'] === 'portfolio_video') {
        $field = prospect_portfolio_name_fields()[$details['portfolio_group'] ?? ''] ?? '';
        if ($field === '' || mb_strlen($details[$field] ?? '') < 2) {
            throw new ProspectValidation('دستهٔ ویترین و نام واقعی متناسب با آن (شرکت همکار، برند تجهیزات یا ساختمان تکمیل‌شده) را ثبت کنید.');
        }
    }
    if (prospect_is_video($row['kind']) && (!$media['video'] || !$media['cover'] || (int)$media['cover']['byte_size'] > 500*1024)) {
        throw new ProspectValidation('ویدیوی منتشرشده باید فایل ویدیویی واقعی و پوستر بهینه داشته باشد.');
    }
}

function prospect_content_save(int $id, int $actor, array $input, array $files): int
{
    $kind = prospect_choice($input,'kind','نوع محتوا',prospect_content_types(),true);
    if (isset(prospect_guidance_video_types()[$kind]) && !prospect_guidance_ready()) throw new ProspectValidation('ابتدا لینک و ویدیوهای راهنما را فعال کنید.');
    $details = prospect_prepare_video_details($kind,$input);
    $state = prospect_choice($input,'state','وضعیت انتشار',prospect_publish_states(),true);
    $publish = prospect_datetime(prospect_scalar($input,'publish_at'),'زمان انتشار');
    $isVideo = prospect_is_video($kind);
    $payload = [
        'kind'=>$kind,'category_id'=>prospect_optional_id($input,'category_id','دسته'), 'campaign_slot'=>prospect_optional_id($input,'campaign_slot','مرحلهٔ برنامه'),
        'title'=>prospect_text($input,'title','عنوان',180,2), 'summary'=>prospect_text($input,'summary','خلاصه',400),
        'body'=>prospect_text($input,'body','متن یا شرح',12000), 'state'=>$state, 'publish_at'=>$publish ?? ($state === 'published' ? prospect_now() : null),
        'is_featured'=>(int)(($input['is_featured'] ?? '') === '1'), 'is_verified'=>(int)(($input['is_verified'] ?? '') === '1'),
        'verification_note'=>prospect_text($input,'verification_note','مرجع داخلی تأیید',400), 'project_type'=>prospect_text($input,'project_type','نوع پروژه',140),
        'elevator_type'=>prospect_text($input,'elevator_type','نوع آسانسور',140), 'technical_info'=>prospect_text($input,'technical_info','اطلاعات فنی پروژه',5000),
        'image_alt'=>prospect_text($input,'image_alt','متن جایگزین تصویر',180), 'seo_title'=>prospect_text($input,'seo_title','عنوان سئو',160),
        'seo_description'=>prospect_text($input,'seo_description','توضیح سئو',240), 'updated_by'=>$actor, 'updated_at'=>prospect_now(),
    ];
    $uploads = [];
    foreach (['cover','video','gallery'] as $role) {
        $file = prospect_validate_upload($files[$role.'_file'] ?? null,$role,$role === 'cover' && $isVideo);
        if ($file === null) continue;
        if ($role === 'video' && !$isVideo) throw new ProspectValidation('فایل ویدیو را در نوع محتوای ویدیویی ثبت کنید.');
        $file['alt'] = $role === 'gallery' ? prospect_text($input,'gallery_alt','متن جایگزین عکس گالری',180,2) : '';
        $uploads[$role] = $file;
    }
    $created = []; $oldPaths = [];
    try {
        $id = prospect_atomic(static function () use ($id,$actor,$payload,$uploads,$isVideo,$details,&$created,&$oldPaths): int {
            if ($payload['category_id'] && !q_val('SELECT id FROM prospect_content_categories WHERE id=?',[$payload['category_id']])) throw new ProspectValidation('دسته وجود ندارد.');
            if ($payload['campaign_slot'] && !q_val('SELECT slot FROM prospect_campaigns WHERE slot=?',[$payload['campaign_slot']])) throw new ProspectValidation('مرحلهٔ انتشار وجود ندارد.');
            $fields = array_keys($payload);
            if ($id) {
                prospect_content_lock($id);
                $assign = implode(',',array_map(static fn($field)=>$field.'=?',$fields));
                q("UPDATE prospect_content SET $assign WHERE id=?", array_merge(array_values($payload),[$id]));
            } else {
                $fields = implode(',',$fields);
                $vars = implode(',',array_fill(0,count($payload)+2,'?'));
                q("INSERT INTO prospect_content ($fields,created_by,created_at) VALUES ($vars)",array_merge(array_values($payload),[$actor,prospect_now()]));
                $id = last_id();
            }
            if (!$isVideo || isset($uploads['video'])) {
                foreach (q_all("SELECT stored_name FROM prospect_content_media WHERE content_id=? AND kind='video'",[$id]) as $r) $oldPaths[] = prospect_media_path($r['stored_name']);
                q("DELETE FROM prospect_content_media WHERE content_id=? AND kind='video'",[$id]);
            }
            if (isset($uploads['cover'])) {
                foreach (q_all("SELECT stored_name FROM prospect_content_media WHERE content_id=? AND kind='cover'",[$id]) as $r) $oldPaths[] = prospect_media_path($r['stored_name']);
                q("DELETE FROM prospect_content_media WHERE content_id=? AND kind='cover'",[$id]);
            }
            if (isset($uploads['gallery']) && (int)q_val("SELECT COUNT(*) FROM prospect_content_media WHERE content_id=? AND kind='gallery'",[$id]) >= 12) {
                throw new ProspectValidation('حداکثر ۱۲ عکس گالری برای هر مطلب مجاز است.');
            }
            foreach ($uploads as $role=>$file) {
                $created[] = prospect_store_upload($file);
                q('INSERT INTO prospect_content_media (content_id,kind,stored_name,mime,byte_size,alt_text,created_at) VALUES (?,?,?,?,?,?,?)',
                    [$id,$role,$file['name'],$file['mime'],$file['size'],$file['alt'],prospect_now()]);
            }
            prospect_content_assert_public($payload,prospect_content_media($id),$details);
            prospect_replace_video_details($id,$details);
            return $id;
        });
    } catch (Throwable $ex) {
        foreach ($created as $path) @unlink($path);
        throw $ex;
    }
    foreach ($oldPaths as $path) if ($path) @unlink($path);
    return $id;
}

function prospect_content_delete_media(int $id, int $mediaId, int $actor): void
{
    $name = prospect_atomic(static function () use ($id,$mediaId,$actor): string {
        $row = prospect_content_lock($id);
        $media = q_one('SELECT stored_name FROM prospect_content_media WHERE content_id=? AND id=?',[$id,$mediaId]);
        if (!$media) throw new ProspectValidation('رسانه به این محتوا تعلق ندارد.',404);
        q('DELETE FROM prospect_content_media WHERE content_id=? AND id=?',[$id,$mediaId]);
        prospect_content_assert_public($row,prospect_content_media($id),prospect_video_details($id));
        q('UPDATE prospect_content SET updated_by=?,updated_at=? WHERE id=?',[$actor,prospect_now(),$id]);
        return $media['stored_name'];
    });
    if ($path = prospect_media_path($name)) @unlink($path);
}

function prospect_content_pause(int $id, int $actor): void
{
    prospect_atomic(static function () use ($id,$actor): void {
        prospect_content_lock($id);
        q("UPDATE prospect_content SET state='paused',updated_by=?,updated_at=? WHERE id=?",[$actor,prospect_now(),$id]);
    });
}

function prospect_save_campaign(array $input): void
{
    $slot = prospect_number($input,'slot','مرحله',1,6,true);
    $title = prospect_text($input,'title','عنوان مرحله',160,2);
    $objective = prospect_text($input,'objective','هدف مرحله',320,2);
    $order = prospect_number($input,'sort_order','ترتیب',0,999,true);
    $date = prospect_datetime(prospect_scalar($input,'starts_at'),'زمان آغاز مرحله');
    q('UPDATE prospect_campaigns SET title=?,objective=?,sort_order=?,is_active=?,starts_at=? WHERE slot=?',[$title,$objective,$order,(int)(($input['is_active'] ?? '') === '1'),$date,$slot]);
}

function prospect_save_category(array $input): int
{
    $id = prospect_optional_id($input,'id','دسته');
    $title = prospect_text($input,'title','نام دسته',120,2);
    if (q_val('SELECT id FROM prospect_content_categories WHERE LOWER(title)=LOWER(?) AND id<>?',[$title,$id ?? 0])) throw new ProspectValidation('نام دسته تکراری است.');
    if ($id) {
        if (!q_val('SELECT id FROM prospect_content_categories WHERE id=?',[$id])) throw new ProspectValidation('دسته وجود ندارد.',404);
        q('UPDATE prospect_content_categories SET title=? WHERE id=?',[$title,$id]);
        return $id;
    }
    q('INSERT INTO prospect_content_categories (title) VALUES (?)',[$title]);
    return last_id();
}

function prospect_save_portal_settings(array $input): void
{
    $title = prospect_text($input,'seo_title','عنوان سئوی پرتال',160);
    $description = prospect_text($input,'seo_description','توضیح سئوی پرتال',240);
    $reviewed = ($input['contact_reviewed'] ?? '') === '1' ? prospect_contact_digest(prospect_contact_settings()) : '';
    prospect_atomic(static function () use ($title,$description,$reviewed): void {
        set_setting('prospect.seo_title',$title,'prospect','عنوان سئو پرتال معرفی');
        set_setting('prospect.seo_description',$description,'prospect','توضیح سئو پرتال معرفی');
        set_setting('prospect.contact_reviewed',$reviewed,'prospect','بازبینی کانال‌های پرتال معرفی');
    });
}

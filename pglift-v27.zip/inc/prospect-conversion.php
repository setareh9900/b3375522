<?php
declare(strict_types=1);
require_once __DIR__.'/prospect-crm.php';
require_once __DIR__.'/customer-schema.php';
require_once __DIR__.'/features.php';
require_once __DIR__.'/portal.php';

function prospect_customer_matches(string $phone, bool $lock = false): array
{
    $sql = "SELECT id,name,username,phone FROM customer_accounts WHERE phone<>'' ORDER BY id";
    if ($lock && gf_driver() !== 'sqlite') $sql .= ' FOR UPDATE';
    $matches = [];
    $cursor = q($sql);
    while ($customer = $cursor->fetch()) {
        if (prospect_phone($customer['phone']) === $phone) $matches[(int)$customer['id']] = $customer;
    }
    return $matches;
}

function prospect_purchase_contracts(int $customerId, int $contractId = 0): array
{
    if (!$customerId) return [];
    // Check known maintenance-only records; the signed purchase still needs an administrator's review.
    $join = portal_ready() ? ' LEFT JOIN customer_contract_details d ON d.contract_id=c.id' : '';
    $arg = [$customerId];
    $where = " AND c.status IN ('active','expired','suspended') AND c.contract_no<>''";
    if ($join !== '') $where .= ' AND (d.is_maintenance IS NULL OR d.is_maintenance=0)';
    if ($contractId) { $where .= ' AND c.id=?'; $arg[] = $contractId; }
    return q_all("SELECT c.id,c.contract_no,c.title,c.contract_date,c.status FROM customer_contracts c$join
        WHERE c.customer_id=?$where ORDER BY c.id DESC",$arg);
}

function prospect_normalized_evidence(string $reference): string
{
    return preg_replace('/\s+/u','',mb_strtolower(en_digits($reference),'UTF-8')) ?? '';
}

function prospect_confirm_conversion(array $staff, int $leadId, array $input): int
{
    if ($staff['role'] !== 'admin') throw new ProspectValidation('تبدیل باید توسط مدیر تأیید شود.',403);
    if (($input['confirm_purchase'] ?? '') !== '1') throw new ProspectValidation('خرید قطعی یا قرارداد امضاشده را تأیید کنید.');
    $pw = prospect_scalar($input,'admin_password');
    if (strlen($pw) > 4096 || !password_verify($pw,$staff['password_hash'])) throw new ProspectValidation('رمز حساب مدیر برای تأیید تبدیل درست نیست.',403);
    $mode = prospect_choice($input,'mode','روش ساخت یا اتصال حساب',['link'=>'اتصال','create'=>'ساخت'],true);
    $evidence = prospect_choice($input,'evidence_type','مدرک خرید',['contract'=>'قرارداد','purchase'=>'خرید'],true);
    if ($mode === 'create' && $evidence !== 'purchase') throw new ProspectValidation('برای حساب جدید، شمارهٔ مدرک خرید قطعی را ثبت کنید.');
    $day = portal_date_key(prospect_text($input,'purchase_date','تاریخ خرید یا امضا',12,8));
    $today = (new DateTimeImmutable('now',new DateTimeZone('Asia/Tehran')))->format('Y-m-d');
    if (!$day || $day > $today) throw new ProspectValidation('تاریخ معتبر و غیرآیندهٔ خرید یا امضا را وارد کنید.');
    return prospect_atomic(static function () use ($staff,$leadId,$input,$mode,$evidence,$day): int {
        $lead = prospect_lead($leadId,$staff,true);
        if (!$lead) throw new ProspectValidation('سرنخ پیدا نشد.',404);
        if ($lead['status'] === 'converted' || q_val('SELECT prospect_id FROM prospect_conversions WHERE prospect_id=?',[$leadId])) {
            throw new ProspectValidation('برای این سرنخ قبلاً تبدیل ثبت شده است.',409);
        }
        $matches = prospect_customer_matches($lead['phone'],true);
        $customerId = $mode === 'link' ? prospect_id($input['customer_id'] ?? null) : 0;
        if ($mode === 'link' && (!$customerId || !q_val('SELECT id FROM customer_accounts WHERE id=?',[$customerId]))) {
            throw new ProspectValidation('حساب خریدکردهٔ معتبر انتخاب کنید.');
        }
        if ($matches && !isset($matches[$customerId])) throw new ProspectValidation('حسابی با این شماره وجود دارد. ابتدا حساب‌های هم‌شماره را بررسی و حساب درست را انتخاب کنید.',409);
        $contractId = null;
        if ($evidence === 'contract') {
            $contractId = prospect_id($input['contract_id'] ?? null);
            $contract = $contractId ? (prospect_purchase_contracts($customerId,$contractId)[0] ?? null) : null;
            if (!$contract) throw new ProspectValidation('قرارداد معتبر مربوط به همین حساب نیست یا فقط قرارداد نگهداری است.');
            $reference = $contract['contract_no'];
            $key = hash('sha256','contract:'.$contractId);
        } else {
            $reference = prospect_text($input,'evidence_reference','شمارهٔ سند خرید قطعی',140,3);
            $normalized = prospect_normalized_evidence($reference);
            foreach (q_all('SELECT reference FROM prospect_quotations WHERE prospect_id=?',[$leadId]) as $quote) {
                if (prospect_normalized_evidence($quote['reference']) === $normalized) throw new ProspectValidation('شمارهٔ پیش‌فاکتور به‌تنهایی مدرک خرید نیست. سند خرید قطعی را وارد کنید.');
            }
            $key = hash('sha256','purchase:'.$normalized);
        }
        if (q_val('SELECT prospect_id FROM prospect_conversions WHERE evidence_key=?',[$key])) {
            throw new ProspectValidation('این سند قبلاً برای تبدیل ثبت شده است.',409);
        }
        if ($mode === 'create') {
            if (gf_driver() !== 'sqlite' && strtolower((string)q_val("SELECT ENGINE FROM information_schema.TABLES
                WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='customer_accounts'")) !== 'innodb') {
                throw new ProspectValidation('برای ایجاد حساب در این تراکنش، جدول حساب‌ها باید InnoDB باشد. ابتدا موتور جدول را با پشتیبان و بررسی مدیر فنی ارتقا دهید یا حساب موجود انتخاب کنید.');
            }
            $username = prospect_text($input,'username','نام کاربری خریدار',100,3);
            if (!preg_match('/^[A-Za-z0-9_.-]{3,100}$/D',$username)) throw new ProspectValidation('نام کاربری لاتین معتبر وارد کنید.');
            if (q_val('SELECT id FROM customer_accounts WHERE LOWER(username)=LOWER(?)',[$username])) {
                throw new ProspectValidation('نام کاربری موجود است؛ حساب را بررسی و در صورت تطابق، متصل کنید.',409);
            }
            $name = prospect_text($input,'customer_name','نام خریدار',150,2);
            $password = prospect_staff_password($input,'customer_password',true);
            $mobile = str_starts_with($lead['phone'],'09') ? $lead['phone'] : '';
            q('INSERT INTO customer_accounts (name,username,password_hash,phone,elevator_details,login_link_enabled) VALUES (?,?,?,?,?,0)',
                [$name,$username,password_hash($password,PASSWORD_DEFAULT),$mobile,'']);
            $customerId = last_id();
        }
        $at = prospect_now();
        q('INSERT INTO prospect_conversions (prospect_id,customer_id,contract_id,evidence_type,evidence_reference,evidence_key,purchase_date,admin_id,admin_username,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
            [$leadId,$customerId,$contractId,$evidence,$reference,$key,$day,(int)$staff['id'],$staff['username'],$at]);
        q("UPDATE prospects SET status='converted',updated_at=? WHERE id=?",[$at,$leadId]);
        prospect_log($leadId,(int)$staff['id'],'conversion','خرید قطعی و تبدیل پرونده توسط مدیر ثبت شد. سابقهٔ مشاوره حفظ شد.');
        return $customerId;
    });
}

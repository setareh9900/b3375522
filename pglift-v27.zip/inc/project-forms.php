<?php
declare(strict_types=1);

function project_url(int $customerId, string $section, array $params = [], string $anchor = ''): string
{
    return 'projects.php?'.http_build_query(['customer' => $customerId, 'section' => $section] + $params, '', '&', PHP_QUERY_RFC3986).$anchor;
}

function project_hidden(string $action, int $customerId, int $id = 0, array $extra = []): void
{
    echo csrf_field();
    foreach ((['action' => $action, 'customer_id' => $customerId, 'id' => $id] + $extra) as $key => $value) {
        echo '<input type="hidden" name="'.e($key).'" value="'.e((string)$value).'">';
    }
}

function project_field(string $name, string $label, $value = '', array $attrs = []): void
{
    $attributes = '';
    foreach ($attrs as $key => $v) {
        if ($v === false) continue;
        $attributes .= ' '.e($key).($v === true ? '' : '="'.e((string)$v).'"');
    }
    ?><label><?=e($label)?><input name="<?=e($name)?>" value="<?=e((string)$value)?>"<?=$attributes?>></label><?php
}

function project_textarea(string $name, string $label, ?string $value = '', int $rows = 3): void
{
    ?><label><?=e($label)?><textarea name="<?=e($name)?>" rows="<?=$rows?>"><?=e($value)?></textarea></label><?php
}

function project_select(string $name, string $label, array $options, $value = '', string $placeholder = 'ثبت نشده', bool $required = false): void
{
    $value = (string)$value;
    ?><label><?=e($label)?><select name="<?=e($name)?>"<?=$required ? ' required' : ''?>>
    <?php if ($placeholder !== ''): ?><option value=""><?=e($placeholder)?></option><?php endif ?>
    <?php foreach ($options as $key => $text): ?><option value="<?=e((string)$key)?>"<?= (string)$key === $value ? ' selected' : '' ?>><?=e($text)?></option><?php endforeach ?>
    </select></label><?php
}

function project_check(string $name, string $label, $value): void
{
    ?><label class="pa-checkbox"><input type="checkbox" name="<?=e($name)?>" value="1"<?=$value ? ' checked' : ''?>> <?=e($label)?></label><?php
}

function project_delete(string $action, int $customerId, int $id, string $label, array $extra = []): void
{
    ?><form method="post" class="pa-inline-form" onsubmit="return confirm('این رکورد و پیوست‌های مرتبط حذف شوند؟')">
    <?php project_hidden($action, $customerId, $id, $extra); ?><button type="submit" class="secondary"><?=e($label)?></button></form><?php
}

/** Retain submitted input after a validation error, but do not override another form. */
function project_form_values(array $values, string $action): array
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST' || project_post('action') !== $action) return $values;
    if (isset($values['id']) && (int)$values['id'] !== portal_id($_POST['id'] ?? null)) return $values;
    $posted = array_filter($_POST, 'is_string');
    if ($action === 'contract_save') $posted += ['is_published' => '', 'is_maintenance' => ''];
    return array_replace($values, $posted);
}

function project_media_panel(string $type, int $ownerId, int $customerId): void
{
    $files = portal_media_list($type, [$ownerId], $customerId, true);
    $owner = ['owner_type' => $type, 'owner_id' => $ownerId];
    ?>
<section class="card pa-media-panel" id="attachments">
    <h2>پیوست‌ها</h2>
    <p class="hint">فقط فایل‌های منتشرشده برای مشتری نمایش داده می‌شوند. سقف تصویر ۴ و PDF هشت مگابایت است.</p>
    <?php if ($files): ?><ul class="pa-records">
        <?php foreach ($files as $file): ?><li>
            <div><a href="project-file.php?id=<?=(int)$file['id']?>" target="_blank" rel="noopener"><?=e($file['caption'] ?: $file['original_name'])?></a>
                <small class="hint"><?=e(PORTAL_MEDIA_KINDS[$type][$file['kind']] ?? $file['kind'])?> · <?=$file['is_published'] ? 'منتشرشده' : 'خصوصی'?></small></div>
            <div class="pa-actions">
                <form method="post" class="pa-inline-form"><?php project_hidden('media_publish', $customerId, (int)$file['id'], $owner + ['is_published' => $file['is_published'] ? '0' : '1']); ?>
                    <button type="submit" class="secondary"><?=$file['is_published'] ? 'خصوصی کردن' : 'انتشار'?></button></form>
                <?php project_delete('media_delete', $customerId, (int)$file['id'], 'حذف', $owner); ?>
            </div>
        </li><?php endforeach ?>
    </ul><?php endif ?>
    <form method="post" enctype="multipart/form-data">
        <?php project_hidden('media_upload', $customerId, 0, $owner); ?>
        <div class="pa-fields"><?php project_select('kind', 'نوع پیوست', PORTAL_MEDIA_KINDS[$type], array_key_first(PORTAL_MEDIA_KINDS[$type]), '', true);
        project_field('caption', 'عنوان یا توضیح کوتاه', '', ['maxlength' => 240]); ?></div>
        <label>فایل پیوست<input name="attachment" type="file" required accept="<?=$type === 'contract' ? 'application/pdf' : 'image/jpeg,image/png,image/webp,application/pdf'?>"></label>
        <?php project_check('is_published', 'برای مشتری منتشر شود', false); ?>
        <button type="submit">افزودن پیوست</button>
    </form>
</section>
    <?php
}

<?php
declare(strict_types=1);
require_once __DIR__ . '/portal-media.php';

function project_post(string $key): string
{
    return is_string($_POST[$key] ?? null) ? trim($_POST[$key]) : '';
}

function project_post_id(string $key): int
{
    if (isset($_POST[$key]) && !is_string($_POST[$key])) throw new RuntimeException('شناسهٔ انتخاب‌شده معتبر نیست.');
    $value = project_post($key);
    $id = portal_id($value);
    if (!$id && !in_array($value, ['', '0'], true)) throw new RuntimeException('شناسهٔ انتخاب‌شده معتبر نیست.');
    return $id;
}

function project_text(string $key, int $length = 200): string
{
    return clean(project_post($key), $length);
}

function project_body(string $key, int $length = 12000): string
{
    // TEXT on the legacy database holds 65,535 bytes; reject changes that cannot fit.
    $text = trim(strip_tags(project_post($key)));
    if (strlen($text) > 65000 || mb_strlen($text, 'UTF-8') > $length) {
        throw new RuntimeException('متن یکی از فیلدها طولانی‌تر از حد مجاز است.');
    }
    return $text;
}

function project_enum(string $key, array $values, bool $optional = false): string
{
    $value = project_post($key);
    if (($optional && $value === '') || isset($values[$value])) return $value;
    throw new RuntimeException('نوع یا وضعیت انتخاب‌شده معتبر نیست.');
}

function project_date(string $key, ?string $previous = null, bool $required = false): string
{
    $value = project_text($key, 40);
    if ($value === '' && !$required) return '';
    if ($value !== '' && ($value === $previous || portal_date_key($value) !== null)) return $value;
    throw new RuntimeException('تاریخ را به‌صورت سال/ماه/روز (شمسی یا میلادی) وارد کنید.');
}

function project_time(string $key): string
{
    $time = en_digits(project_post($key));
    if ($time !== '' && !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $time)) {
        throw new RuntimeException('زمان واردشده معتبر نیست.');
    }
    return $time;
}

function project_int(string $key, int $max): ?int
{
    $value = en_digits(project_post($key));
    if ($value === '') return null;
    if (!preg_match('/^\d{1,6}$/D', $value) || (int)$value > $max) throw new RuntimeException('مقدار عددی خارج از محدودهٔ مجاز است.');
    return (int)$value;
}

function project_required(string $value, string $message): string
{
    if ($value === '') throw new RuntimeException($message);
    return $value;
}

function project_owned(string $kind, int $id, int $customerId): array
{
    $record = portal_owned($kind, $id, $customerId);
    if (!$record) throw new RuntimeException('رکوردی برای مشتری انتخاب‌شده پیدا نشد.');
    return $record;
}

function project_atomic(callable $callback)
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $value = $callback();
        $pdo->commit();
        return $value;
    } catch (Throwable $error) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $error;
    }
}

/** Table and column names are supplied by the handlers below, never the request. */
function project_save_base(string $table, string $scope, int $owner, int $id, array $data, bool $withCreatedAt = true): int
{
    $columns = array_keys($data);
    if ($id) {
        $sets = implode(',', array_map(static fn($field) => "$field=?", $columns));
        q("UPDATE $table SET $sets WHERE id=? AND $scope=?", [...array_values($data), $id, $owner]);
        return $id;
    }
    $data[$scope] = $owner;
    if ($withCreatedAt) $data['created_at'] = now();
    $fields = implode(',', array_keys($data));
    $values = implode(',', array_fill(0, count($data), '?'));
    q("INSERT INTO $table ($fields) VALUES ($values)", array_values($data));
    return last_id();
}

function project_save_details(string $table, string $key, int $id, array $data): void
{
    $columns = array_keys($data);
    $values = implode(',', array_fill(0, count($data) + 1, '?'));
    $fields = implode(',', $columns);
    if (gf_driver() === 'sqlite') {
        $update = 'ON CONFLICT ('.$key.') DO UPDATE SET '.implode(',', array_map(static fn($c) => "$c=excluded.$c", $columns));
    } else {
        $update = 'ON DUPLICATE KEY UPDATE '.implode(',', array_map(static fn($c) => "$c=VALUES($c)", $columns));
    }
    q("INSERT INTO $table ($key,$fields) VALUES ($values) $update", [$id, ...array_values($data)]);
}

function project_save_contract(int $customerId, int $id): int
{
    $old = $id ? project_owned('contract', $id, $customerId) : [];
    $base = [
        'contract_no' => project_required(project_text('contract_no', 80), 'شماره قرارداد الزامی است.'),
        'title' => project_required(project_text('title'), 'عنوان قرارداد الزامی است.'),
        'project_address' => project_text('project_address', 500),
        'start_date' => project_date('start_date', $old['start_date'] ?? null),
        'end_date' => project_date('end_date', $old['end_date'] ?? null),
        'status' => project_enum('status', PORTAL_CONTRACT_STATUSES),
        'coverage' => project_body('coverage', 20000),
        'contract_date' => project_date('contract_date', $old['contract_date'] ?? null),
        'contract_text' => project_body('contract_text', 30000),
        'total_amount' => project_text('total_amount', 150),
        'contract_parts' => project_body('contract_parts', 20000),
    ];
    // A legacy integration may omit fields. Only an explicitly submitted blank clears them.
    foreach ($base as $key => $value) if (!array_key_exists($key, $_POST) && array_key_exists($key, $old)) $base[$key] = $old[$key];
    $details = [];
    foreach (PORTAL_CONTRACT_FIELDS as $key => $_) $details[$key] = project_body($key);
    $details['is_published'] = (int)(project_post('is_published') === '1');
    $details['is_maintenance'] = (int)(project_post('is_maintenance') === '1');
    $details['included_visits'] = $details['is_maintenance'] ? project_int('included_visits', 100000) : null;
    $id = project_save_base('customer_contracts', 'customer_id', $customerId, $id, $base);
    project_save_details('customer_contract_details', 'contract_id', $id, $details);
    return $id;
}

function project_save_service(int $customerId, int $id): int
{
    $old = $id ? project_owned('service', $id, $customerId) : [];
    $base = [
        'service_date' => project_date('service_date', $old['service_date'] ?? null, true),
        'next_service_date' => project_date('next_service_date', $old['next_service_date'] ?? null),
        'technician' => project_text('technician', 160), 'summary' => project_body('summary'),
        'status' => project_enum('status', PORTAL_VISIT_STATUSES),
        'replaced_parts' => project_body('replaced_parts', 20000), 'resolved_problems' => project_body('resolved_problems', 20000),
    ];
    foreach ($base as $key => $value) if (!array_key_exists($key, $_POST) && array_key_exists($key, $old)) $base[$key] = $old[$key];
    $contractId = project_post_id('contract_id');
    if ($contractId) {
        project_owned('contract', $contractId, $customerId);
        // Keep an existing association editable even if the contract was reclassified.
        if (!q_one('SELECT contract_id FROM customer_contract_details WHERE contract_id=? AND is_maintenance=1', [$contractId])
            && (!$id || (int)q_val('SELECT contract_id FROM customer_service_report_details WHERE visit_id=?', [$id]) !== $contractId)) {
            throw new RuntimeException('برای این بازدید یک قرارداد نگهداری انتخاب کنید.');
        }
    }
    $details = [
        'contract_id' => $contractId ?: null,
        'service_type' => project_enum('service_type', PORTAL_SERVICE_TYPES, true),
        'operational_status' => project_enum('operational_status', PORTAL_OPERATIONAL_STATUSES, true),
        'start_time' => project_time('start_time'), 'completion_time' => project_time('completion_time'),
    ];
    foreach (PORTAL_REPORT_FIELDS as $key => $_) $details[$key] = project_body($key);
    $id = project_save_base('customer_service_visits', 'customer_id', $customerId, $id, $base);
    project_save_details('customer_service_report_details', 'visit_id', $id, $details);
    return $id;
}

function project_save_component(int $customerId, int $visitId, int $id): void
{
    project_owned('service', $visitId, $customerId);
    if ($id && !q_one('SELECT id FROM customer_service_components WHERE id=? AND visit_id=?', [$id, $visitId])) {
        throw new RuntimeException('ردیف قطعه در این گزارش پیدا نشد.');
    }
    $partId = project_post_id('part_id');
    $part = $partId ? project_owned('part', $partId, $customerId) : [];
    $name = project_text('name');
    $brand = project_text('manufacturer');
    $model = project_text('model');
    project_save_base('customer_service_components', 'visit_id', $visitId, $id, [
        'part_id' => $partId ?: null, 'name' => project_required($name !== '' ? $name : ($part['name'] ?? ''), 'نام قطعه یا قطعهٔ مرتبط الزامی است.'),
        'manufacturer' => $brand !== '' ? $brand : ($part['brand'] ?? ''), 'model' => $model !== '' ? $model : ($part['model'] ?? ''),
        'relation_type' => project_enum('relation_type', PORTAL_COMPONENT_RELATIONS), 'notes' => project_body('notes'),
    ], false);
}

function project_admin_action(string $action, int $customerId): array
{
    $id = project_post_id('id');
    switch ($action) {
        case 'contract_save':
            return ['section' => 'contracts', 'contract' => project_save_contract($customerId, $id)];
        case 'contract_delete':
            project_owned('contract', $id, $customerId);
            q("DELETE FROM customer_portal_media WHERE owner_type='contract' AND owner_id=?", [$id]);
            q('UPDATE customer_service_report_details SET contract_id=NULL WHERE contract_id=? AND visit_id IN (SELECT id FROM customer_service_visits WHERE customer_id=?)', [$id, $customerId]);
            q('DELETE FROM customer_contract_details WHERE contract_id=?', [$id]);
            q('DELETE FROM customer_contracts WHERE id=? AND customer_id=?', [$id, $customerId]);
            return ['section' => 'contracts'];
        case 'service_save':
            return ['section' => 'services', 'service' => project_save_service($customerId, $id)];
        case 'service_delete':
            project_owned('service', $id, $customerId);
            q("DELETE FROM customer_portal_media WHERE owner_type='service' AND owner_id=?", [$id]);
            q('DELETE FROM customer_service_components WHERE visit_id=?', [$id]);
            q('DELETE FROM customer_service_report_details WHERE visit_id=?', [$id]);
            q('DELETE FROM customer_service_visits WHERE id=? AND customer_id=?', [$id, $customerId]);
            return ['section' => 'services'];
        case 'component_save':
        case 'component_delete':
            $visit = project_post_id('visit_id');
            if ($action === 'component_save') project_save_component($customerId, $visit, $id);
            else {
                project_owned('service', $visit, $customerId);
                if (q('DELETE FROM customer_service_components WHERE id=? AND visit_id=?', [$id, $visit])->rowCount() !== 1) {
                    throw new RuntimeException('ردیف قطعه در این گزارش پیدا نشد.');
                }
            }
            return ['section' => 'services', 'service' => $visit];
        case 'project_save':
            $old = $id ? project_owned('project', $id, $customerId) : [];
            $id = project_save_base('customer_installation_projects', 'customer_id', $customerId, $id, [
                'title' => project_required(project_text('title'), 'عنوان پروژه الزامی است.'),
                'description' => project_body('description'), 'progress' => project_int('progress', 100),
                'expected_completion_date' => project_date('expected_completion_date', $old['expected_completion_date'] ?? null),
            ]);
            return ['section' => 'installation', 'project' => $id];
        case 'project_delete':
            project_owned('project', $id, $customerId);
            q("DELETE FROM customer_portal_media WHERE owner_type='stage' AND owner_id IN (SELECT id FROM customer_installation_stages WHERE project_id=?)", [$id]);
            q('DELETE FROM customer_installation_projects WHERE id=? AND customer_id=?', [$id, $customerId]);
            return ['section' => 'installation'];
        case 'stage_save':
            $projectId = project_post_id('project_id');
            project_owned('project', $projectId, $customerId);
            $old = $id ? project_owned('stage', $id, $customerId) : [];
            if ($id && (int)$old['project_id'] !== $projectId) throw new RuntimeException('مرحله به پروژهٔ انتخاب‌شده تعلق ندارد.');
            $id = project_save_base('customer_installation_stages', 'project_id', $projectId, $id, [
                'title' => project_required(project_text('title'), 'عنوان مرحله الزامی است.'),
                'description' => project_body('description'), 'progress' => project_int('progress', 100),
                'sort_order' => project_int('sort_order', 999999) ?? 0, 'status' => project_enum('status', PORTAL_STAGE_STATUSES, true),
                'start_date' => project_date('start_date', $old['start_date'] ?? null),
                'expected_date' => project_date('expected_date', $old['expected_date'] ?? null),
                'completion_date' => project_date('completion_date', $old['completion_date'] ?? null),
                'technician' => project_text('technician', 160), 'admin_notes' => project_body('admin_notes'), 'customer_notes' => project_body('customer_notes'),
            ], false);
            return ['section' => 'installation', 'project' => $projectId, 'stage' => $id];
        case 'stage_delete':
            $stage = project_owned('stage', $id, $customerId);
            q("DELETE FROM customer_portal_media WHERE owner_type='stage' AND owner_id=?", [$id]);
            q('DELETE FROM customer_installation_stages WHERE id=? AND project_id=?', [$id, $stage['project_id']]);
            return ['section' => 'installation', 'project' => $stage['project_id']];
        case 'stage_template':
            project_owned('project', $id, $customerId);
            if (q_one('SELECT id FROM customer_installation_stages WHERE project_id=? LIMIT 1', [$id])) throw new RuntimeException('الگو فقط برای پروژهٔ بدون مرحله قابل افزودن است.');
            foreach (PORTAL_STAGE_TEMPLATE as $position => $title) {
                q('INSERT INTO customer_installation_stages (project_id,title,sort_order) VALUES (?,?,?)', [$id, $title, ($position + 1) * 10]);
            }
            return ['section' => 'installation', 'project' => $id];
        case 'update_add':
            project_owned('project', $id, $customerId);
            q('INSERT INTO customer_installation_updates (project_id,message,created_at) VALUES (?,?,?)', [$id, project_required(project_body('message', 3000), 'متن به‌روزرسانی را وارد کنید.'), now()]);
            return ['section' => 'installation', 'project' => $id];
        case 'update_delete':
            $projectId = project_post_id('project_id');
            project_owned('project', $projectId, $customerId);
            if (q('DELETE FROM customer_installation_updates WHERE id=? AND project_id=?', [$id, $projectId])->rowCount() !== 1) throw new RuntimeException('این به‌روزرسانی پیدا نشد.');
            return ['section' => 'installation', 'project' => $projectId];
        case 'profile_save':
            $data = ['operational_status' => project_enum('operational_status', PORTAL_OPERATIONAL_STATUSES, true),
                'maintenance_status' => project_enum('maintenance_status', PORTAL_MAINTENANCE_STATUSES, true)];
            $lengths = ['drive_system' => 150, 'rated_capacity' => 100, 'passengers' => 80, 'floors' => 80, 'rated_speed' => 100,
                'installation_location' => 500, 'motor_manufacturer' => 160, 'motor_model' => 160, 'door_type' => 160, 'panel_manufacturer' => 160, 'panel_model' => 160];
            foreach (PORTAL_PROFILE_FIELDS as $key => $_) $data[$key] = isset($lengths[$key]) ? project_text($key, $lengths[$key]) : project_body($key);
            project_save_details('customer_elevator_profiles', 'customer_id', $customerId, $data);
            return ['section' => 'technical'];
        case 'part_save':
            project_owned('part', $id, $customerId);
            $data = [];
            foreach (PORTAL_PART_FIELDS as $key => $_) $data[$key] = $key === 'warranty_status' ? project_text($key, 150) : project_body($key);
            project_save_details('customer_part_details', 'part_id', $id, $data);
            return ['section' => 'technical', 'part' => $id];
        case 'media_upload':
        case 'media_publish':
        case 'media_delete':
            $kind = project_post('owner_type');
            if (!isset(PORTAL_MEDIA_KINDS[$kind])) throw new RuntimeException('گروه پیوست معتبر نیست.');
            $owner = project_owned($kind, project_post_id('owner_id'), $customerId);
            $published = project_post('is_published') === '1';
            if ($action === 'media_upload') {
                portal_media_upload($kind, (int)$owner['id'], project_post('kind'), $_FILES['attachment'] ?? [], project_text('caption', 240), $published);
            } else {
                $scope = [$id, $kind, $owner['id']];
                if (!q_one('SELECT id FROM customer_portal_media WHERE id=? AND owner_type=? AND owner_id=?', $scope)) throw new RuntimeException('پیوست پیدا نشد.');
                if ($action === 'media_delete') q('DELETE FROM customer_portal_media WHERE id=? AND owner_type=? AND owner_id=?', $scope);
                else q('UPDATE customer_portal_media SET is_published=? WHERE id=? AND owner_type=? AND owner_id=?', [(int)$published, ...$scope]);
            }
            return match ($kind) {
                'contract' => ['section' => 'contracts', 'contract' => $owner['id']],
                'service' => ['section' => 'services', 'service' => $owner['id']],
                'stage' => ['section' => 'installation', 'project' => $owner['project_id'], 'stage' => $owner['id']],
            };
        default:
            throw new RuntimeException('عملیات نامعتبر است.');
    }
}

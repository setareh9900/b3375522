<?php
declare(strict_types=1);
require_once __DIR__.'/prospect-forms.php';
require_once __DIR__.'/prospect-content.php';

function prospect_card_list(array $items): void
{
    if (!$items) return;
    ?><div class="ps-post-grid">
    <?php foreach ($items as $item): $link = 'content.php?id='.(int)$item['id']; $video = prospect_is_video($item['kind']); ?>
        <article class="ps-panel ps-post">
            <?php if ($item['cover_id']): ?><a href="<?=e($link)?>" class="ps-post-img" aria-label="<?=e($item['title'])?>">
                <img src="media.php?id=<?=(int)$item['cover_id']?>" loading="lazy" decoding="async" alt="<?=e($item['image_alt'])?>">
                <?php if ($video): ?><span class="ps-post-play" aria-hidden="true">▶ ویدیو</span><?php endif ?>
            </a><?php endif ?>
            <div class="ps-post-text"><span class="ps-chip"><?=e($item['category_title'] ?: (prospect_content_types()[$item['kind']] ?? 'مطلب'))?></span>
                <h3><a href="<?=e($link)?>"><?=e($item['title'])?></a></h3><p><?=e($item['summary'])?></p>
                <?php if ($item['kind'] === 'project'): ?><span class="ps-caption"><?=e($item['project_type'])?> · <?=e($item['elevator_type'])?></span><?php endif ?>
                <time class="ps-post-date" datetime="<?=e(str_replace(' ', 'T', $item['publish_at']).'Z')?>"><?=e(prospect_date($item['publish_at']))?></time>
            </div>
        </article>
    <?php endforeach ?>
    </div><?php
}

function prospect_media_url(array $media): string { return 'media.php?id='.(int)$media['id']; }

<?php
[$rows,$filters,$total,$page,$pages] = prospect_lead_list($staff, $_GET, $statuses);
$stats = prospect_stats($staff);
prospect_page_intro('صندوق درخواست‌های پیش از خرید','مخاطبان و مشتریان بالقوه', $full ? 'مدیریت مشاوره، فروش و پیگیری. حساب‌های خریدکرده در بخش جداگانه‌اند.' : 'فقط پرونده‌های تخصیص‌یافته به شما در این فهرست دیده می‌شوند.');
?>
<div class="pc-overview">
    <?php foreach ($stats as $label=>$value): ?>
        <?php if ($label === 'درخواست بررسی‌نشده'): ?><a href="prospects.php?only=unread"><small><?=e($label)?></small><b><?=e($value)?></b></a>
        <?php else: ?><div><small><?=e($label)?></small><b><?=e($value)?></b></div><?php endif ?>
    <?php endforeach ?>
</div>
<form class="ps-panel ps-form" method="get" action="prospects.php" aria-label="جست‌وجو و فیلتر مخاطبان">
    <div class="ps-fields">
        <?php prospect_input_field('q','نام، شماره تماس یا کد پیگیری',$filters['q'] ?? '','maxlength="90"','search'); ?>
        <?php prospect_select_field('status','وضعیت',$statuses,$filters['status'] ?? '',false,'همهٔ وضعیت‌ها'); ?>
        <?php if ($full) prospect_select_field('rep','مسئول', ['unassigned'=>'بدون مسئول']+$reps,$filters['rep'] ?? '',false,'همه'); ?>
        <?php prospect_select_field('only','صندوق و زمان پیگیری',['unread'=>'درخواست بررسی‌نشده','due'=>'پیگیری سررسیدشده'], $filters['only'] ?? '',false,'همه'); ?>
    </div>
    <div class="ps-actions"><button type="submit" class="ps-btn ps-primary">جست‌وجو</button><?php if ($filters): ?><a class="ps-btn ps-secondary" href="prospects.php">پاک کردن فیلتر</a><?php endif ?></div>
</form>
<section class="pc-section" aria-label="فهرست مخاطبان">
    <p class="pc-hint"><?=fa_digits($total)?> پرونده</p>
    <?php if (!$rows): ?><p class="ps-empty">پرونده‌ای با این فیلترها پیدا نشد.</p><?php endif ?>
    <div class="pc-list">
        <?php foreach ($rows as $p): ?>
            <article class="pc-row"><div><a class="ps-link" href="prospects.php?id=<?=(int)$p['id']?>"><b><?=e($p['full_name'])?></b> <?=prospect_arrow(14)?></a>
                <div class="pc-meta"><bdi dir="ltr"><?=e($p['phone'])?></bdi><span><?=e(prospect_services()[$p['last_service']] ?? '')?></span><?php if ($full): ?><span><?=e($reps[$p['assigned_to']] ?? 'بدون مسئول')?></span><?php endif ?></div>
                <?php if ($p['next_followup']): ?><small>پیگیری بعدی: <?=e(prospect_date($p['next_followup'], true))?></small><?php endif ?></div>
                <div><span class="ps-chip"><?=e($statuses[$p['status']] ?? $p['status'])?></span><?php if ((int)$p['unread']): ?><small><span class="ps-chip pc-unread"><?=fa_digits($p['unread'])?> بررسی‌نشده</span></small><?php endif ?></div>
            </article>
        <?php endforeach ?>
    </div>
    <?php prospect_admin_pager('prospects.php', $filters, $page, $pages); ?>
</section>

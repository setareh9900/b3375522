<?php
$initialKind = prospect_scalar($_GET,'kind');
$values = ($item ?? ['kind'=>isset($kinds[$initialKind]) ? $initialKind : 'article','state'=>'draft']) + prospect_video_details($id);
if ($error !== '' && ($_POST['action'] ?? '') === 'content') $values = array_filter($_POST,'is_string') + $values;
$media = $id ? prospect_content_media($id) : ['cover'=>null,'gallery'=>[],'video'=>null];
$stageOptions = array_column($campaign,'title','slot');
$editUrl = 'prospect-content.php?edit='.($id ?: 'new');
$public = $id ? prospect_public_post($id) : null;
?>
<div class="pc-head pc-section"><h2><?=$item ? 'ویرایش محتوا' : 'محتوای جدید'?></h2><div class="pc-actions"><a class="ps-btn ps-secondary" href="prospect-content.php">فهرست محتوا</a>
    <?php if ($public): ?><a class="ps-btn ps-secondary" href="../prospects/content.php?id=<?=$id?>">نمای عمومی <?=prospect_arrow(14)?></a><?php endif ?>
    <?php if ($item && $item['state'] === 'published'): ?><form method="post" action="<?=e($editUrl)?>"><?php prospect_admin_action('pause',$id); ?><button type="submit" class="ps-btn ps-secondary">توقف انتشار</button></form><?php endif ?>
</div></div>
<div class="pc-columns pc-section pc-editor">
<form class="ps-panel ps-form" method="post" enctype="multipart/form-data" action="<?=e($editUrl)?>">
    <?php prospect_admin_action('content',$id); ?>
    <div class="ps-fields">
        <?php prospect_select_field('kind','نوع محتوا',$kinds,$values['kind'],true,''); prospect_select_field('category_id','دسته',$categories,$values['category_id'] ?? '',false,'بدون دسته'); ?>
        <?php prospect_select_field('campaign_slot','وابسته به مرحله',$stageOptions,$values['campaign_slot'] ?? '',false,'انتشار مستقل'); prospect_select_field('state','وضعیت',prospect_publish_states(),$values['state'],true,''); ?>
        <?php prospect_input_field('publish_at','انتشار به وقت تهران (خالی: اکنون)',($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $error ? prospect_scalar($_POST,'publish_at') : prospect_local_time($values['publish_at'] ?? null),'','datetime-local'); ?>
        <?php prospect_checkbox('is_featured','نمایش به‌عنوان محتوای منتخب',(int)($values['is_featured'] ?? 0) === 1); ?>
    </div>
    <?php prospect_input_field('title','عنوان *',$values['title'] ?? '','required maxlength="180"'); ?>
    <?php prospect_textarea('summary','خلاصهٔ کارت',$values['summary'] ?? '',400,2); prospect_textarea('body','متن، شرح محتوا یا متن همراه ویدیو',$values['body'] ?? '',12000,6); ?>
    <hr class="ps-rule">
    <h3>تصاویر و ویدیو</h3><p class="pc-hint">پوستر ویدیو: ضلع حداکثر ۱۲۸۰ پیکسل و حجم ۵۰۰ کیبی‌بایت. عکس‌های دیگر تا ۲ مگابایت. ویدیو: MP4 یا WebM تا ۲۴ مگابایت. برای سازگاری موبایل، MP4 (H.264) با عرض مناسب پیشنهاد می‌شود.</p>
    <?php prospect_input_field('cover_file','تصویر اصلی یا پوستر','','accept="image/jpeg,image/png,image/webp"','file'); prospect_input_field('image_alt','متن جایگزین عکس اصلی',$values['image_alt'] ?? '','maxlength="180"'); ?>
    <?php prospect_input_field('video_file','ویدیو (فقط برای محتوای ویدیویی)','','accept="video/mp4,video/webm"','file'); ?>
    <p class="pc-hint">مدت پیشنهادی: ویدیوی کوتاه ۱۵ تا ۲۰ ثانیه؛ ویدیوی هفته ۲۰ تا ۳۰ ثانیه. برای دسترس‌پذیری، نکتهٔ گفته‌شده در ویدیو را در متن همراه بنویسید.</p>
    <?php prospect_input_field('gallery_file','افزودن یک عکس به گالری','','accept="image/jpeg,image/png,image/webp"','file'); prospect_input_field('gallery_alt','متن جایگزین عکس گالری','','maxlength="180"'); ?>
    <hr class="ps-rule">
    <?php if ($guidanceReady): ?>
    <fieldset class="pc-media-fields" data-video-fields="guide_video">
        <legend>محل نمایش راهنمای ویدیویی</legend>
        <p class="pc-hint">برای نوع «راهنمای ویدیویی یک بخش»، صفحه‌ای را انتخاب کنید که کاربر همان‌جا به توضیح نیاز دارد.</p>
        <?php prospect_select_field('placement','صفحهٔ مرتبط',prospect_video_placements(),$values['placement'] ?? '',false,'انتخاب نشده'); ?>
    </fieldset>
    <fieldset class="pc-media-fields" data-video-fields="portfolio_video">
        <legend>ویترین ویدیویی همکاری و پروژه</legend>
        <p class="pc-hint">دسته را مشخص کنید و نام واقعی متناظر را وارد کنید. برای دستهٔ ساختمان‌ها، فقط پروژهٔ تکمیل و تحویل‌شده را ثبت کنید.</p>
        <?php prospect_select_field('portfolio_group','دستهٔ ویترین',prospect_portfolio_groups(),$values['portfolio_group'] ?? '',false,'انتخاب نشده'); ?>
        <div class="ps-fields">
            <?php prospect_input_field('company_name','نام شرکت همکار',$values['company_name'] ?? '','maxlength="160"');
            prospect_input_field('equipment_brand','نام برند تجهیزات',$values['equipment_brand'] ?? '','maxlength="160"');
            prospect_input_field('building_name','نام ساختمان یا پروژهٔ تکمیل‌شده',$values['building_name'] ?? '','maxlength="160"'); ?>
        </div>
    </fieldset>
    <p class="pc-hint" data-video-fields="brand_story">استوری برند در خانهٔ راهنما و آرشیو استوری‌ها دیده می‌شود. ویدیوی متعلق به برند یا دارای اجازهٔ انتشار، همراه پوستر و متن معرفی بارگذاری کنید.</p>
    <?php endif ?>
    <h3>پروژه و تأیید اصالت</h3><p class="pc-hint">برای پروژهٔ واقعی سه فیلد زیر و عکس ثبت‌شده الزامی‌اند. برای استوری برند، ویدیوی همکاری، معرفی، نمونه‌کار، تیم، بازخورد و گواهی نیز باید مرجع و اجازهٔ انتشار را بررسی کنید. مرجع داخلی نمایش عمومی ندارد.</p>
    <div class="ps-fields"><?php prospect_input_field('project_type','نوع پروژه',$values['project_type'] ?? '','maxlength="140"'); prospect_input_field('elevator_type','نوع آسانسور پروژه',$values['elevator_type'] ?? '','maxlength="140"'); ?></div>
    <?php prospect_textarea('technical_info','اطلاعات فنی مستند پروژه',$values['technical_info'] ?? '',5000); ?>
    <?php prospect_textarea('verification_note','شناسه یا مرجع داخلی تأیید',$values['verification_note'] ?? '',400,2); ?>
    <?php prospect_checkbox('is_verified','صحت اطلاعات و مجوز انتشار متن، تصاویر و ویدیو را بررسی کردم.'); ?>
    <hr class="ps-rule">
    <h3>سئوی مطلب</h3>
    <?php prospect_input_field('seo_title','عنوان سئو',$values['seo_title'] ?? '','maxlength="160"'); prospect_textarea('seo_description','توضیح سئو',$values['seo_description'] ?? '',240,2); ?>
    <button class="ps-btn ps-primary ps-submit" type="submit">ذخیره محتوا</button>
</form>
<aside class="ps-panel">
    <h2>رسانه‌های موجود</h2><p class="pc-hint">این پیش‌نمایش خصوصی است. برای حذف فایل الزامیِ مطلب منتشرشده، ابتدا انتشار را متوقف کنید.</p>
    <?php $all = array_merge(array_filter([$media['cover'],$media['video']]),$media['gallery']); if (!$all): ?><p class="ps-empty">رسانه‌ای بارگذاری نشده است.</p><?php endif ?>
    <div class="pc-list">
    <?php foreach ($all as $file): $previewUrl = '../prospects/media.php?id='.(int)$file['id'].'&preview=1'; ?>
        <div class="pc-list-item">
            <?php if ($file['kind'] === 'video'): ?><video class="ps-video" preload="none" controls playsinline src="<?=e($previewUrl)?>"></video>
            <?php else: ?><img src="<?=e($previewUrl)?>" loading="lazy" alt="<?=e($file['alt_text'] ?: ($item['image_alt'] ?? ''))?>"><?php endif ?>
            <small><?=e(['cover'=>'تصویر اصلی','gallery'=>'گالری','video'=>'ویدیو'][$file['kind']])?> · <?=fa_digits(round((int)$file['byte_size']/1024))?> KiB</small>
            <form method="post" action="<?=e($editUrl)?>" class="ps-form"><?php prospect_admin_action('media_delete',$id); ?><input type="hidden" name="media_id" value="<?=(int)$file['id']?>"><button class="ps-btn ps-secondary ps-submit">حذف فایل</button></form>
        </div>
    <?php endforeach ?>
    </div>
</aside>
</div>

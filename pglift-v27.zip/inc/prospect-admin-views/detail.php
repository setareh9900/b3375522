<?php
$id = (int)$lead['id'];
[$history,$page,$pages] = prospect_history($id, $tab, prospect_id($_GET['page'] ?? null));
$leadUrl = 'prospects.php?id='.$id.'&tab='.$tab;
?>
<a class="ps-link" href="prospects.php">همهٔ سرنخ‌ها</a>
<div class="pc-head">
    <div><?php prospect_page_intro('پروندهٔ پیش از خرید · '.fa_digits($id),$lead['full_name']); ?></div>
    <span class="ps-chip"><?=e($statuses[$lead['status']] ?? $lead['status'])?></span>
</div>
<div class="pc-columns">
<section class="ps-panel" aria-label="مشخصات مخاطب">
    <h2>مشخصات و مسئول پیگیری</h2>
    <?php prospect_facts(['شماره تماس'=>$lead['phone'],'تاریخ اولین ثبت'=>prospect_date($lead['created_at'],true),'آخرین فعالیت'=>prospect_date($lead['updated_at'],true)] + ($full ? ['نمایندهٔ فروش'=>$reps[$lead['assigned_to']] ?? 'بدون مسئول'] : [])); ?>
    <?php if ($full && $lead['status'] !== 'converted'): ?><a href="prospect-convert.php?id=<?=$id?>" class="ps-link">بازبینی تبدیل پس از خرید قطعی <?=prospect_arrow(14)?></a><?php endif ?>
    <?php if ($full && $lead['status'] === 'converted'): $conversion = q_one('SELECT customer_id,created_at FROM prospect_conversions WHERE prospect_id=?',[$id]); ?>
        <?php if ($conversion): ?><div class="pc-meta">تبدیل تأییدشده در <?=e(prospect_date($conversion['created_at'],true))?> · <a class="ps-link" href="customers.php?id=<?=(int)$conversion['customer_id']?>">حساب خریدکرده</a> · <a class="ps-link" href="prospect-convert.php?id=<?=$id?>">سند تبدیل</a></div><?php endif ?>
    <?php endif ?>
</section>
<section class="ps-panel ps-form" aria-label="مدیریت سرنخ">
    <?php if ($lead['status'] !== 'converted'): ?>
    <form method="post" action="<?=e($leadUrl)?>" class="pc-short-form">
        <?php prospect_admin_action('status',$id); ?>
        <?php prospect_select_field('status','وضعیت سرنخ',array_diff_key($statuses,['converted'=>true]),$lead['status'],true,''); ?>
        <button class="ps-btn ps-secondary" type="submit">ذخیره وضعیت</button>
    </form>
    <?php else: ?><p class="pc-hint">پرونده تبدیل شده است؛ سوابق فروش اینجا باقی می‌مانند.</p><?php endif ?>
    <?php if ($full): ?>
    <form method="post" action="<?=e($leadUrl)?>" class="pc-short-form">
        <?php prospect_admin_action('assign',$id); ?>
        <?php $repOptions = prospect_rep_labels(prospect_reps(true)); if ($lead['assigned_to'] && !isset($repOptions[$lead['assigned_to']])) $repOptions[$lead['assigned_to']] = $reps[$lead['assigned_to']] ?? 'غیرفعال'; ?>
        <?php prospect_select_field('rep','تخصیص نماینده',$repOptions,$lead['assigned_to'],false,'بدون مسئول'); ?>
        <button class="ps-btn ps-secondary" type="submit">ثبت مسئول</button>
    </form>
    <?php endif ?>
</section>
</div>
<nav class="pc-tabs" aria-label="بخش‌های پرونده"><?php foreach ($tabs as $key=>$label): ?><a href="prospects.php?id=<?=$id?>&amp;tab=<?=e($key)?>"<?=$key === $tab ? ' aria-current="page"' : ''?>><?=e($label)?></a><?php endforeach ?></nav>
<section class="pc-section" aria-label="<?=e($tabs[$tab])?>">
<?php if ($tab === 'inquiries'): ?>
    <?php if (!$history): ?><p class="ps-empty">هنوز درخواستی برای این پرونده ثبت نشده است.</p><?php endif ?>
    <div class="pc-list">
        <?php foreach ($history as $item): ?>
        <article class="pc-list-item">
            <div class="pc-head"><h3><?=e(prospect_services()[$item['service']] ?? $item['service'])?></h3>
                <span class="ps-chip<?=$item['reviewed_at'] ? '' : ' pc-unread'?>"><?=$item['reviewed_at'] ? 'بررسی‌شده' : 'بررسی‌نشده'?></span></div>
            <div class="pc-meta"><bdi dir="ltr"><?=e($item['reference'])?></bdi><span><?=e(prospect_date($item['created_at'], true))?></span><span>ثبت‌کننده: <?=e($item['sender_name'])?></span><span><?=e(['contact'=>'فرم تماس','selection'=>'راهنمای انتخاب','request'=>'فرم مشاوره'][$item['source']] ?? '')?></span></div>
            <?php $facts = prospect_project_facts($item); if ($facts) prospect_facts($facts); ?>
            <?php if ($item['requirements']): ?><p class="pc-body"><b>نیازها:</b> <?=e($item['requirements'])?></p><?php endif ?>
            <?php if ($item['description']): ?><p class="pc-body"><?=e($item['description'])?></p><?php endif ?>
            <form method="post" action="<?=e($leadUrl)?>" class="pc-short-form">
                <?php prospect_admin_action('review',$id); ?><input type="hidden" name="inquiry_id" value="<?=(int)$item['id']?>">
                <?php prospect_select_field('public_state','وضعیت قابل پیگیری',prospect_public_states(),$item['public_state'],true,''); ?>
                <button class="ps-btn ps-secondary" type="submit">ثبت بازبینی</button>
            </form>
        </article>
        <?php endforeach ?>
    </div>
<?php elseif ($tab === 'activity'): ?>
    <form class="ps-panel ps-form" method="post" action="<?=e($leadUrl)?>">
        <h2>ثبت تماس یا یادداشت خصوصی</h2><?php prospect_admin_action('interaction',$id); ?>
        <?php prospect_select_field('kind','نوع تعامل',prospect_interaction_choices(),'call',true,''); prospect_textarea('body','متن یا خلاصهٔ گفت‌وگو','',3000,3,true); ?>
        <button class="ps-btn ps-primary ps-submit" type="submit">ثبت در تاریخچه</button>
    </form>
    <?php $kinds = prospect_interaction_choices()+['inquiry'=>'دریافت درخواست','status'=>'تغییر وضعیت','assignment'=>'تخصیص','review'=>'بازبینی','followup'=>'پیگیری','quote'=>'پیش‌فاکتور','conversion'=>'تبدیل خرید']; ?>
    <div class="pc-list pc-timeline">
        <?php foreach ($history as $item): ?>
        <article class="pc-list-item"><h3><?=e($kinds[$item['kind']] ?? 'فعالیت')?></h3>
            <div class="pc-meta"><span><?=e($item['full_name'] ?: ($item['username'] ?: 'ثبت سامانه'))?></span><span><?=e(prospect_date($item['created_at'],true))?></span></div><p class="pc-body"><?=e($item['body'])?></p>
        </article>
        <?php endforeach ?>
    </div>
<?php elseif ($tab === 'followups'): ?>
    <form class="ps-panel ps-form" method="post" action="<?=e($leadUrl)?>">
        <h2>برنامه‌ریزی پیگیری</h2><?php prospect_admin_action('followup',$id); ?>
        <div class="ps-fields"><?php prospect_input_field('due_at','تاریخ و ساعت پیگیری (به وقت تهران)','','required','datetime-local'); prospect_input_field('body','موضوع پیگیری','','required maxlength="300"'); ?></div>
        <button class="ps-btn ps-primary ps-submit" type="submit">زمان‌بندی</button>
    </form>
    <div class="pc-list">
        <?php foreach ($history as $item): $late = $item['state'] === 'pending' && $item['due_at'] <= prospect_now(); ?>
        <article class="pc-list-item"><div class="pc-head"><h3><?=e($item['body'])?></h3><span class="ps-chip<?=$late ? ' pc-due' : ''?>"><?=e($late ? 'سررسیدشده' : ['pending'=>'باز','done'=>'انجام شد','canceled'=>'لغو شد'][$item['state']])?></span></div>
            <div class="pc-meta"><span><?=e(prospect_date($item['due_at'],true))?></span><?php if ($item['closed_at']): ?><span>بسته‌شدن: <?=e(prospect_date($item['closed_at'],true))?></span><?php endif ?></div>
            <?php if ($item['state'] === 'pending'): ?><form method="post" action="<?=e($leadUrl)?>" class="pc-actions ps-form">
                <?php prospect_admin_action('close_followup',$id); ?><input type="hidden" name="followup_id" value="<?=(int)$item['id']?>">
                <button class="ps-btn ps-secondary" name="state" value="done">انجام شد</button><button class="ps-btn ps-secondary" name="state" value="canceled">لغو پیگیری</button>
            </form><?php endif ?>
        </article>
        <?php endforeach ?>
    </div>
<?php elseif ($tab === 'quotes'): ?>
    <form class="ps-panel ps-form" method="post" action="<?=e($leadUrl)?>">
        <h2>ثبت پیش‌فاکتور</h2><p class="pc-hint">این ثبت داخلی است؛ پیش‌فاکتور ارسال نمی‌شود و خرید قطعی محسوب نمی‌شود.</p>
        <?php prospect_admin_action('quote',$id); ?>
        <div class="ps-fields"><?php prospect_input_field('reference','شمارهٔ پیش‌فاکتور','','required maxlength="120"'); prospect_input_field('amount','مبلغ و واحد (در صورت ثبت)','','maxlength="120"'); ?></div>
        <?php prospect_textarea('body','یادداشت داخلی','',2500); ?>
        <button class="ps-btn ps-primary ps-submit" type="submit">ثبت اطلاعات پیش‌فاکتور</button>
    </form>
    <div class="pc-list">
        <?php foreach ($history as $item): ?>
        <article class="pc-list-item"><div class="pc-head"><h3><bdi><?=e($item['reference'])?></bdi><?= $item['amount'] !== '' ? ' · '.e($item['amount']) : ''?></h3><span class="ps-chip"><?=$item['sent_at'] ? 'ارسال شده' : 'آماده'?></span></div>
            <div class="pc-meta"><span>ثبت: <?=e(prospect_date($item['created_at'],true))?></span><?php if ($item['sent_at']): ?><span>ارسال: <?=e(prospect_date($item['sent_at'],true))?></span><?php endif ?></div>
            <?php if ($item['notes']): ?><p class="pc-body"><?=e($item['notes'])?></p><?php endif ?>
            <?php if (!$item['sent_at']): ?><form method="post" action="<?=e($leadUrl)?>" class="ps-form"><?php prospect_admin_action('quote_sent',$id); ?><input type="hidden" name="quote_id" value="<?=(int)$item['id']?>"><button class="ps-btn ps-secondary ps-submit" type="submit">ثبت شد که پیش‌فاکتور ارسال شده</button></form><?php endif ?>
        </article>
        <?php endforeach ?>
    </div>
<?php endif ?>
<?php prospect_admin_pager('prospects.php',['id'=>$id,'tab'=>$tab],$page,$pages); ?>
</section>

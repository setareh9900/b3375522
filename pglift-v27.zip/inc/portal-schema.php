<?php
declare(strict_types=1);

/** Additive only. Existing accounts, parts, contracts and visits are not rewritten. */
function portal_schema_sql(string $driver): array
{
    $my = $driver !== 'sqlite';
    $id = $my ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $dt = $my ? 'DATETIME' : 'TEXT';
    $blob = $my ? 'MEDIUMBLOB' : 'BLOB';
    $engine = $my ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';
    $index = static fn(string $name, string $fields): string => $my ? ", INDEX $name ($fields)" : '';

    $tables = [
        // No foreign keys into legacy tables: some v24 installations use older table engines.
        "CREATE TABLE IF NOT EXISTS customer_contract_details (
            contract_id INT PRIMARY KEY NOT NULL,
            parties TEXT NULL, subject_scope TEXT NULL, technical_specs TEXT NULL,
            financial_obligations TEXT NULL, payment_terms TEXT NULL, included_services TEXT NULL,
            excluded_services TEXT NULL, equipment TEXT NULL, warranty_conditions TEXT NULL,
            maintenance_obligations TEXT NULL, company_responsibilities TEXT NULL,
            customer_responsibilities TEXT NULL, additional_conditions TEXT NULL,
            approval_signature TEXT NULL, legal_clarification TEXT NULL,
            is_published INT NOT NULL DEFAULT 0, is_maintenance INT NOT NULL DEFAULT 0,
            included_visits INT NULL
        )$engine",
        "CREATE TABLE IF NOT EXISTS customer_service_report_details (
            visit_id INT PRIMARY KEY NOT NULL, contract_id INT NULL,
            service_type VARCHAR(30) NOT NULL DEFAULT '', operational_status VARCHAR(30) NOT NULL DEFAULT '',
            start_time VARCHAR(5) NOT NULL DEFAULT '', completion_time VARCHAR(5) NOT NULL DEFAULT '',
            inspection_results TEXT NULL, work_performed TEXT NULL, detected_faults TEXT NULL,
            recommendations TEXT NULL, follow_up TEXT NULL, technician_notes TEXT NULL
            {$index('portal_visit_contract', 'contract_id')}
        )$engine",
        "CREATE TABLE IF NOT EXISTS customer_service_components (
            id $id, visit_id INT NOT NULL, part_id INT NULL,
            relation_type VARCHAR(20) NOT NULL, name VARCHAR(200) NOT NULL,
            manufacturer VARCHAR(200) NOT NULL DEFAULT '', model VARCHAR(200) NOT NULL DEFAULT '', notes TEXT NULL
            {$index('portal_component_visit', 'visit_id')}
            {$index('portal_component_part', 'part_id')}
        )$engine",
        "CREATE TABLE IF NOT EXISTS customer_installation_projects (
            id $id, customer_id INT NOT NULL, title VARCHAR(200) NOT NULL,
            description TEXT NULL, progress INT NULL, expected_completion_date VARCHAR(40) NOT NULL DEFAULT '',
            created_at $dt NOT NULL
            {$index('portal_project_customer', 'customer_id')}
        )$engine",
        "CREATE TABLE IF NOT EXISTS customer_installation_stages (
            id $id, project_id INT NOT NULL, title VARCHAR(200) NOT NULL, description TEXT NULL,
            sort_order INT NOT NULL DEFAULT 0, progress INT NULL, status VARCHAR(30) NOT NULL DEFAULT '',
            start_date VARCHAR(40) NOT NULL DEFAULT '', expected_date VARCHAR(40) NOT NULL DEFAULT '',
            completion_date VARCHAR(40) NOT NULL DEFAULT '', technician VARCHAR(160) NOT NULL DEFAULT '',
            admin_notes TEXT NULL, customer_notes TEXT NULL,
            FOREIGN KEY (project_id) REFERENCES customer_installation_projects(id) ON DELETE CASCADE
            {$index('portal_stage_project', 'project_id, sort_order')}
        )$engine",
        "CREATE TABLE IF NOT EXISTS customer_installation_updates (
            id $id, project_id INT NOT NULL, message TEXT NOT NULL, created_at $dt NOT NULL,
            FOREIGN KEY (project_id) REFERENCES customer_installation_projects(id) ON DELETE CASCADE
            {$index('portal_update_project', 'project_id, created_at')}
        )$engine",
        // One binary store for contract, service and installation media; never in a public upload path.
        "CREATE TABLE IF NOT EXISTS customer_portal_media (
            id $id, owner_type VARCHAR(16) NOT NULL, owner_id INT NOT NULL,
            kind VARCHAR(16) NOT NULL, caption VARCHAR(240) NOT NULL DEFAULT '',
            original_name VARCHAR(240) NOT NULL, mime VARCHAR(40) NOT NULL,
            byte_size INT NOT NULL, payload $blob NOT NULL,
            is_published INT NOT NULL DEFAULT 0, created_at $dt NOT NULL
            {$index('portal_media_owner', 'owner_type, owner_id, is_published')}
        )$engine",
        "CREATE TABLE IF NOT EXISTS customer_part_details (
            part_id INT PRIMARY KEY NOT NULL,
            manufacturer_info TEXT NULL, installation_notes TEXT NULL,
            warranty_status VARCHAR(150) NOT NULL DEFAULT '', warranty_details TEXT NULL, maintenance_notes TEXT NULL
        )$engine",
    ];
    if (!$my) {
        foreach ([
            'portal_visit_contract ON customer_service_report_details(contract_id)',
            'portal_component_visit ON customer_service_components(visit_id)',
            'portal_component_part ON customer_service_components(part_id)',
            'portal_project_customer ON customer_installation_projects(customer_id)',
            'portal_stage_project ON customer_installation_stages(project_id, sort_order)',
            'portal_update_project ON customer_installation_updates(project_id, created_at)',
            'portal_media_owner ON customer_portal_media(owner_type, owner_id, is_published)',
        ] as $definition) {
            $tables[] = 'CREATE INDEX IF NOT EXISTS '.$definition;
        }
    }
    // Create last: customer reads use this table as the migration readiness check.
    $tables[] = "CREATE TABLE IF NOT EXISTS customer_elevator_profiles (
        customer_id INT PRIMARY KEY NOT NULL,
        drive_system VARCHAR(150) NOT NULL DEFAULT '', rated_capacity VARCHAR(100) NOT NULL DEFAULT '',
        passengers VARCHAR(80) NOT NULL DEFAULT '', floors VARCHAR(80) NOT NULL DEFAULT '', rated_speed VARCHAR(100) NOT NULL DEFAULT '',
        motor_manufacturer VARCHAR(160) NOT NULL DEFAULT '', motor_model VARCHAR(160) NOT NULL DEFAULT '',
        panel_manufacturer VARCHAR(160) NOT NULL DEFAULT '', panel_model VARCHAR(160) NOT NULL DEFAULT '',
        door_type VARCHAR(160) NOT NULL DEFAULT '', installation_location VARCHAR(500) NOT NULL DEFAULT '',
        operational_status VARCHAR(30) NOT NULL DEFAULT '', maintenance_status VARCHAR(30) NOT NULL DEFAULT '',
        mechanical_notes TEXT NULL, electrical_notes TEXT NULL, safety_systems TEXT NULL,
        other_specs TEXT NULL, warranty_info TEXT NULL
    )$engine";
    return $tables;
}

function portal_apply_schema(PDO $pdo): void
{
    foreach (portal_schema_sql($pdo->getAttribute(PDO::ATTR_DRIVER_NAME)) as $sql) {
        $pdo->exec($sql);
    }
}

function portal_ready(bool $refresh = false): bool
{
    static $ready = null;
    if ($refresh || $ready === null) {
        try {
            q('SELECT customer_id FROM customer_elevator_profiles WHERE 1=0');
            $ready = true;
        } catch (PDOException $error) {
            $missingTable = $error->getCode() === '42S02' ||
                (gf_driver() === 'sqlite' && str_contains($error->getMessage(), 'no such table: customer_elevator_profiles'));
            if (!$missingTable) throw $error;
            $ready = false;
        }
    }
    return $ready;
}

<?php
declare(strict_types=1);
require_once __DIR__.'/db.php';

/** Share links point only to public material and never grant a login or access to an inquiry. */
function prospect_issue_guide(array $staff, array $input): int
{
    if ($staff['role'] !== 'admin') throw new ProspectValidation('صدور لینک فقط با مجوز مدیر ممکن است.',403);
    $label = prospect_text($input,'label','عنوان داخلی لینک',140);
    $at = prospect_now();
    // Separate namespace from the 48-hex-digit buyer login token.
    $token = 'g-'.bin2hex(random_bytes(20));
    q('INSERT INTO prospect_guide_links (token,label,is_active,created_by,created_at,updated_at) VALUES (?,?,1,?,?,?)',
        [$token,$label,(int)$staff['id'],$at,$at]);
    return last_id();
}

function prospect_set_guide_active(array $staff, int $id, bool $active): void
{
    if ($staff['role'] !== 'admin') throw new ProspectValidation('مدیریت لینک فقط با مجوز مدیر ممکن است.',403);
    if (!$id || !q_val('SELECT id FROM prospect_guide_links WHERE id=?',[$id])) throw new ProspectValidation('لینک پیدا نشد.',404);
    q('UPDATE prospect_guide_links SET is_active=?,updated_at=? WHERE id=?',[(int)$active,prospect_now(),$id]);
}

function prospect_guide_link_active(string $token): bool
{
    if (!gf_is_configured() || preg_match('/^g-[a-f0-9]{40}$/D',$token) !== 1) return false;
    try {
        return (bool)q_val('SELECT id FROM prospect_guide_links WHERE token=? AND is_active=1',[$token]);
    } catch (PDOException $ex) {
        // A site that has not applied the extension still serves its normal public guide.
        return false;
    }
}

function prospect_guide_share_path(string $token): string
{
    return '../prospects/guide-link.php?t='.rawurlencode($token);
}

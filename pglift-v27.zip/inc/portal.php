<?php
declare(strict_types=1);

require_once __DIR__ . '/fn.php';
require_once __DIR__ . '/portal-schema.php';
require_once __DIR__ . '/portal-fields.php';

function portal_private_headers(): void
{
    header('Cache-Control: private, no-store');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('X-Robots-Tag: noindex, nofollow');
}

function portal_id($value): int
{
    if ((!is_int($value) && !is_string($value)) || !preg_match('/^[0-9]{1,10}$/D', (string)$value)) return 0;
    return (int)$value > 0 && (float)$value <= 2147483647 ? (int)$value : 0;
}

function portal_account(): ?array
{
    $id = portal_id($_SESSION['customer_id'] ?? null);
    if (!$id) return null;
    $account = q_one('SELECT * FROM customer_accounts WHERE id=?', [$id]);
    if (!$account || !hash_equals($account['password_hash'], (string)($_SESSION['customer_password_hash'] ?? ''))) {
        unset($_SESSION['customer_id'], $_SESSION['customer_password_hash']);
        return null;
    }
    unset($account['password_hash'], $account['login_token']);
    return $account;
}

function portal_require_account(): array
{
    portal_private_headers();
    if (!gf_is_configured()) redirect('../install.php');
    if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true)) {
        header('Allow: GET, HEAD');
        http_response_code(405);
        exit;
    }
    $account = portal_account();
    if (!$account) redirect('index.php');
    return $account;
}

/** Stages inherit ownership only through their installation project. */
function portal_owned(string $type, int $id, int $customerId): ?array
{
    if (!$id) return null;
    if (in_array($type, ['project', 'stage'], true) && !portal_ready()) return null;
    if ($type === 'stage') {
        return q_one('SELECT s.* FROM customer_installation_stages s JOIN customer_installation_projects p ON p.id=s.project_id WHERE s.id=? AND p.customer_id=?', [$id, $customerId]);
    }
    $table = ['contract' => 'customer_contracts', 'service' => 'customer_service_visits',
        'part' => 'customer_parts', 'project' => 'customer_installation_projects'][$type] ?? null;
    if ($table === null) throw new InvalidArgumentException('Unknown portal record type');
    return q_one("SELECT * FROM $table WHERE id=? AND customer_id=?", [$id, $customerId]);
}

function portal_contracts(int $customerId): array
{
    return q_all('SELECT id, title, contract_no, status, start_date, end_date, total_amount FROM customer_contracts WHERE customer_id=? ORDER BY id DESC', [$customerId]);
}

function portal_report_number(int $id): string
{
    return 'SR-' . str_pad((string)$id, 6, '0', STR_PAD_LEFT);
}

/** Return a sortable Gregorian day key, without changing the legacy display value.
 * v24 accepts Jalali and Gregorian strings; unknown formats must not become a date guess.
 */
function portal_date_key(string $input): ?string
{
    $date = en_digits(trim($input));
    if (!preg_match('/^(\d{4})[\/.\-](\d{1,2})[\/.\-](\d{1,2})$/D', $date, $match)) return null;
    [, $year, $month, $day] = array_map('intval', $match);
    if ($year >= 1700) return checkdate($month, $day, $year) ? sprintf('%04d-%02d-%02d', $year, $month, $day) : null;
    if ($year < 1200 || $year > 1600 || $month < 1 || $month > 12 || $day < 1 || $day > 31) return null;

    // Inverse of the calendar conversion in fn.php, with a round trip to reject invalid days.
    $jy = $year + 1595;
    $days = -355668 + 365 * $jy + intdiv($jy, 33) * 8 + intdiv($jy % 33 + 3, 4) + $day
        + ($month < 7 ? ($month - 1) * 31 : ($month - 7) * 30 + 186);
    $gy = 400 * intdiv($days, 146097);
    $days %= 146097;
    if ($days > 36524) {
        $gy += 100 * intdiv(--$days, 36524);
        $days %= 36524;
        if ($days >= 365) ++$days;
    }
    $gy += 4 * intdiv($days, 1461);
    $days %= 1461;
    if ($days > 365) {
        $gy += intdiv($days - 1, 365);
        $days = ($days - 1) % 365;
    }
    $gd = $days + 1;
    $gm = 1;
    $lengths = [31, checkdate(2, 29, $gy) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    while ($gm <= 12 && $gd > $lengths[$gm - 1]) $gd -= $lengths[$gm++ - 1];
    if (!checkdate($gm, $gd, $gy) || gregorian_to_jalali($gy, $gm, $gd) !== [$year, $month, $day]) return null;
    return sprintf('%04d-%02d-%02d', $gy, $gm, $gd);
}

function portal_visits(int $customerId): array
{
    $extension = portal_ready() ? 'LEFT JOIN customer_service_report_details d ON d.visit_id=v.id' : '';
    $type = $extension ? 'd.service_type' : "'' AS service_type";
    $rows = q_all("SELECT v.id, v.service_date, v.next_service_date, v.status, v.technician, v.summary, $type
        FROM customer_service_visits v $extension WHERE v.customer_id=?", [$customerId]);
    foreach ($rows as &$row) $row['date_key'] = portal_date_key($row['service_date']);
    unset($row);
    usort($rows, static fn($a, $b) => ($b['date_key'] ?? '') <=> ($a['date_key'] ?? '') ?: (int)$b['id'] <=> (int)$a['id']);
    return $rows;
}

function portal_maintenance_snapshot(array $visits, ?string $today = null): array
{
    $today ??= (new DateTimeImmutable('now', new DateTimeZone('Asia/Tehran')))->format('Y-m-d');
    $last = null;
    $completed = 0;
    $reminders = [];
    $cancellations = [];
    foreach ($visits as $visit) {
        $day = $visit['date_key'];
        if ($visit['status'] === 'done') {
            ++$completed;
            $last ??= $visit;
        } elseif ($day !== null && $day >= $today) {
            if ($visit['status'] === 'scheduled') {
                // Keep each scheduled visit even when more than one is on the same day.
                $reminders[] = ['day' => $day, 'date' => $visit['service_date'], 'visit_id' => $visit['id'], 'is_scheduled' => true];
            } elseif ($visit['status'] === 'canceled') {
                $cancellations[$day] = true;
            }
        }
    }
    $next = $last ? portal_date_key($last['next_service_date']) : null;
    if ($next !== null && $next >= $today && !isset($cancellations[$next]) && !in_array($next, array_column($reminders, 'day'), true)) {
        $reminders[] = ['day' => $next, 'date' => $last['next_service_date'], 'visit_id' => $last['id'], 'is_scheduled' => false];
    }
    usort($reminders, static fn($a, $b) => $a['day'] <=> $b['day']);
    return ['last' => $last, 'completed' => $completed, 'reminders' => $reminders, 'next' => $reminders[0] ?? null];
}

function portal_maintenance_contracts(int $customerId): array
{
    if (!portal_ready()) return [];
    return q_all("SELECT c.id, c.title, c.status, d.included_visits, COUNT(v.id) AS linked_completed
        FROM customer_contracts c JOIN customer_contract_details d ON d.contract_id=c.id
        LEFT JOIN customer_service_report_details r ON r.contract_id=c.id
        LEFT JOIN customer_service_visits v ON v.id=r.visit_id AND v.customer_id=c.customer_id AND v.status='done'
        WHERE c.customer_id=? AND d.is_published=1 AND d.is_maintenance=1
        GROUP BY c.id, c.title, c.status, d.included_visits ORDER BY c.id DESC", [$customerId]);
}

function portal_profile(int $customerId): array
{
    return portal_ready() ? (q_one('SELECT * FROM customer_elevator_profiles WHERE customer_id=?', [$customerId]) ?? []) : [];
}

function portal_type(array $account): array
{
    $type = (string)($account['elevator_type'] ?? '');
    if ($type === '') return [];
    require_once __DIR__ . '/types.php';
    foreach (types_load() as $entry) {
        if ($entry['id'] !== $type) continue;
        $image = (string)($entry['image'] ?? '');
        $entry['image'] = preg_match(TYPES_IMG_RE, $image) ? '../'.$image : '';
        return $entry;
    }
    return [];
}

function portal_parts(int $customerId): array
{
    if (!portal_ready()) return q_all('SELECT * FROM customer_parts WHERE customer_id=? ORDER BY id DESC', [$customerId]);
    return q_all('SELECT p.*, d.warranty_status FROM customer_parts p LEFT JOIN customer_part_details d ON d.part_id=p.id WHERE p.customer_id=? ORDER BY p.id DESC', [$customerId]);
}

function portal_projects(int $customerId): array
{
    return portal_ready() ? q_all('SELECT * FROM customer_installation_projects WHERE customer_id=? ORDER BY id DESC', [$customerId]) : [];
}

function portal_stages(int $projectId, int $customerId): array
{
    return q_all('SELECT s.id,s.title,s.description,s.progress,s.status,s.start_date,s.expected_date,s.completion_date,s.technician,s.customer_notes
        FROM customer_installation_stages s JOIN customer_installation_projects p ON p.id=s.project_id
        WHERE p.id=? AND p.customer_id=? ORDER BY s.sort_order, s.id', [$projectId, $customerId]);
}

function portal_stage_groups(array $stages): array
{
    $group = ['completed' => [], 'current' => [], 'upcoming' => []];
    foreach ($stages as $stage) {
        switch ($stage['status']) {
            case 'completed': $group['completed'][] = $stage; break;
            case 'in_progress':
            case 'blocked': $group['current'][] = $stage; break;
            case 'pending': $group['upcoming'][] = $stage; break;
        }
    }
    return $group;
}

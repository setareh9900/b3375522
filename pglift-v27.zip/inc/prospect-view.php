<?php
declare(strict_types=1);
require_once __DIR__.'/prospect.php';
require_once __DIR__.'/prospect-catalog.php';

function prospect_arrow(int $size = 16): string
{
    return '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 12H4m6-6-6 6 6 6"/></svg>';
}

function prospect_brand(): string
{
    return gf_is_configured() ? (trim(setting('brand.name')) ?: 'مرکز انتخاب آسانسور') : 'مرکز انتخاب آسانسور';
}

function prospect_logo(): string
{
    $logo = gf_is_configured() ? active_logo() : null;
    return $logo && preg_match('#^data:image/(?:png|jpeg|webp|gif|svg\+xml);base64,#i', $logo)
        ? '<img src="'.e($logo).'" alt="" width="42" height="42" decoding="async">' : icon('elevator', 22);
}

function prospect_start(string $title, string $page = '', string $description = '', bool $private = false): void
{
    $brand = prospect_brand();
    $nav = ['home' => ['index.php','معرفی'], 'types' => ['elevator-types.php','انواع آسانسور'],
        'guide' => ['elevator-selection.php','راهنمای انتخاب'], 'learn' => ['knowledge.php','دانش‌نامه']];
    if ($private) prospect_private_headers();
    ?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#f8f7f3">
    <?php if ($private): ?><meta name="robots" content="noindex,nofollow"><?php endif ?>
    <?php if ($description !== ''): ?><meta name="description" content="<?=e($description)?>"><?php endif ?>
    <title><?=e($title)?> | <?=e($brand)?></title>
    <link rel="stylesheet" href="../assets/css/prospect.css?v=<?=filemtime(__DIR__.'/../assets/css/prospect.css')?>">
    <script defer src="../assets/js/prospect.js?v=<?=filemtime(__DIR__.'/../assets/js/prospect.js')?>"></script>
</head>
<body class="ps-site">
<a class="ps-skip" href="#main">رفتن به محتوا</a>
<header class="ps-header"><div class="ps-wrap ps-top">
    <a href="index.php" class="ps-brand"><span class="ps-mark"><?=prospect_logo()?></span><span><b><?=e($brand)?></b><small>مرکز معرفی، مشاوره و انتخاب آسانسور</small></span></a>
    <nav class="ps-nav" aria-label="ناوبری مرکز انتخاب">
        <?php foreach ($nav as $key => [$url,$label]): ?><a href="<?=e($url)?>"<?=$page === $key ? ' aria-current="page"' : ''?>><?=e($label)?></a><?php endforeach ?>
    </nav>
    <a class="ps-header-buyer" href="../customer/index.php">پنل خریداران <?=icon('elevator', 15)?></a>
</div></header>
<?php if (!empty(gf_config()['prospect_demo'])): ?><div class="ps-demo">پیش‌نمایش با داده‌های نمونه؛ لطفاً اطلاعات واقعی وارد نکنید.</div><?php endif ?>
<main id="main" class="ps-wrap ps-main">
    <?php
}

function prospect_end(): void
{
    ?>
</main>
<footer class="ps-footer"><div class="ps-wrap ps-foot-inner">
    <div class="ps-brand"><span class="ps-mark"><?=prospect_logo()?></span><span><b><?=e(prospect_brand())?></b><small>مرکز معرفی، مشاوره و انتخاب آسانسور</small></span></div>
    <nav aria-label="پیوندهای پایانی"><a href="index.php#contact">تماس</a><a href="track.php">پیگیری درخواست</a><a href="../customer/index.php">ورود خریداران</a><a href="../index.php">سایت اصلی</a></nav>
</div></footer>
</body></html>
    <?php
}

function prospect_page_intro(string $category, string $title, string $description = ''): void
{
    ?>
    <header class="ps-page-intro"><span class="ps-kicker"><?=e($category)?></span><h1><?=e($title)?></h1><?php if ($description !== ''): ?><p><?=e($description)?></p><?php endif ?></header>
    <?php
}

function prospect_section(string $id, string $kicker, string $title, string $link = '', string $label = ''): void
{
    ?>
    <header class="ps-section-head"><div><span class="ps-kicker"><?=e($kicker)?></span><h2 id="<?=e($id)?>"><?=e($title)?></h2></div>
        <?php if ($link !== ''): ?><a class="ps-link" href="<?=e($link)?>"><?=e($label)?> <?=prospect_arrow(16)?></a><?php endif ?></header>
    <?php
}

function prospect_type_cards(): void
{
    ?><div class="ps-type-grid"><?php foreach (prospect_elevator_types() as $key => [$title,$tag,$image,$description]): ?>
        <a class="ps-type-card" href="elevator-type.php?type=<?=e($key)?>">
            <div class="ps-type-art"><img src="../assets/img/types/<?=e($image)?>" alt="" loading="lazy" decoding="async"><span lang="en" dir="ltr"><?=e($tag)?></span></div>
            <div class="ps-type-text"><h3><?=e($title)?></h3><p><?=e($description)?></p><span class="ps-link">معرفی و مقایسه <?=prospect_arrow(15)?></span></div>
        </a>
    <?php endforeach ?></div><?php
}

function prospect_faq_view(): void
{
    ?><div class="ps-faq"><?php foreach (prospect_faq() as $question => $answer): ?><details><summary><?=e($question)?><span aria-hidden="true">+</span></summary><p><?=e($answer)?></p></details><?php endforeach ?></div><?php
}

function prospect_select_field(string $name, string $label, array $options, $value, bool $required = false, string $empty = 'انتخاب کنید'): void
{
    ?><label class="ps-field"><span><?=e($label)?><?=$required ? ' *' : ''?></span><select name="<?=e($name)?>"<?=$required ? ' required' : ''?>>
    <?php if ($empty !== ''): ?><option value=""><?=e($empty)?></option><?php endif ?>
    <?php foreach ($options as $key => $option): ?><option value="<?=e((string)$key)?>"<?= (string)$key === (string)$value ? ' selected' : ''?>><?=e($option)?></option><?php endforeach ?>
    </select></label><?php
}

function prospect_notice(string $message, bool $error = false): void
{
    ?><p class="ps-notice<?=$error ? ' ps-error' : ''?>" role="<?=$error ? 'alert' : 'status'?>"><?=e($message)?></p><?php
}

function prospect_not_found(): void
{
    http_response_code(404);
    prospect_start('صفحه پیدا نشد', '', '', true);
    prospect_page_intro('مرکز انتخاب آسانسور', 'این صفحه در دسترس نیست.');
    echo '<a class="ps-btn ps-primary" href="index.php">بازگشت به مرکز انتخاب</a>';
    prospect_end();
    exit;
}

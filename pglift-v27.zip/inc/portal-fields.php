<?php
declare(strict_types=1);

const PORTAL_MISSING = 'این اطلاعات هنوز توسط مدیریت ثبت نشده است.';
const PORTAL_CONTRACT_STATUSES = ['active' => 'فعال', 'expired' => 'پایان‌یافته', 'suspended' => 'متوقف'];
const PORTAL_VISIT_STATUSES = ['done' => 'انجام‌شده', 'scheduled' => 'زمان‌بندی‌شده', 'canceled' => 'لغوشده'];
const PORTAL_SERVICE_TYPES = [
    'preventive' => 'نگهداری پیشگیرانه', 'emergency' => 'سرویس اضطراری', 'corrective' => 'نگهداری اصلاحی',
    'inspection' => 'بازرسی فنی', 'replacement' => 'تعویض قطعه', 'safety' => 'بازرسی ایمنی',
];
const PORTAL_OPERATIONAL_STATUSES = ['operational' => 'در حال بهره‌برداری', 'limited' => 'بهره‌برداری محدود', 'out_of_service' => 'خارج از سرویس', 'under_installation' => 'در حال نصب'];
const PORTAL_MAINTENANCE_STATUSES = ['on_track' => 'طبق برنامه', 'needs_followup' => 'نیازمند پیگیری', 'paused' => 'متوقف'];
const PORTAL_STAGE_STATUSES = ['pending' => 'در انتظار شروع', 'in_progress' => 'در حال انجام', 'completed' => 'تکمیل‌شده', 'blocked' => 'متوقف'];
const PORTAL_COMPONENT_RELATIONS = ['replaced' => 'تعویض', 'inspected' => 'بازرسی', 'repaired' => 'تعمیر', 'serviced' => 'سرویس'];
const PORTAL_CONTRACT_FIELDS = [
    'parties' => 'طرفین قرارداد', 'subject_scope' => 'موضوع و دامنهٔ قرارداد', 'technical_specs' => 'مشخصات فنی قرارداد',
    'financial_obligations' => 'تعهدات مالی', 'payment_terms' => 'شرایط پرداخت', 'included_services' => 'خدمات مشمول',
    'excluded_services' => 'خدمات خارج از پوشش', 'equipment' => 'تجهیزات و قطعات', 'warranty_conditions' => 'شرایط ضمانت',
    'maintenance_obligations' => 'تعهدات نگهداری', 'company_responsibilities' => 'مسئولیت‌های شرکت',
    'customer_responsibilities' => 'مسئولیت‌های مشتری', 'additional_conditions' => 'شرایط تکمیلی',
    'approval_signature' => 'تأیید و امضای قرارداد', 'legal_clarification' => 'توضیحات حقوقی مدیریت',
];
const PORTAL_REPORT_FIELDS = [
    'inspection_results' => 'نتایج بازرسی', 'work_performed' => 'کارهای انجام‌شده', 'detected_faults' => 'ایرادهای شناسایی‌شده',
    'recommendations' => 'توصیه‌های فنی', 'follow_up' => 'اقدام‌های پیگیری', 'technician_notes' => 'یادداشت تکنسین',
];
const PORTAL_PROFILE_FIELDS = [
    'drive_system' => 'سیستم محرکه', 'rated_capacity' => 'ظرفیت نامی', 'passengers' => 'تعداد نفرات',
    'floors' => 'تعداد طبقات', 'rated_speed' => 'سرعت نامی', 'installation_location' => 'محل نصب',
    'motor_manufacturer' => 'سازندهٔ موتور', 'motor_model' => 'مدل موتور', 'door_type' => 'نوع درب',
    'panel_manufacturer' => 'سازندهٔ تابلو فرمان', 'panel_model' => 'مدل تابلو فرمان',
    'mechanical_notes' => 'سایر تجهیزات مکانیکی', 'electrical_notes' => 'سایر تجهیزات برقی',
    'safety_systems' => 'سامانه‌های ایمنی', 'other_specs' => 'سایر مشخصات ثبت‌شده', 'warranty_info' => 'اطلاعات ضمانت آسانسور',
];
const PORTAL_PART_FIELDS = [
    'manufacturer_info' => 'اطلاعات تکمیلی سازنده', 'installation_notes' => 'یادداشت نصب', 'warranty_status' => 'وضعیت ضمانت',
    'warranty_details' => 'جزئیات ضمانت', 'maintenance_notes' => 'سوابق و نکات نگهداری',
];
const PORTAL_STAGE_TEMPLATE = [
    'ثبت و تأیید سفارش', 'بازدید فنی محل', 'مهندسی و طراحی آسانسور', 'آماده‌سازی تجهیزات', 'تأمین قطعات',
    'نصب ریل و براکت', 'نصب موتور و تجهیزات محرکه', 'مونتاژ کابین', 'نصب تابلو فرمان', 'سیم‌کشی برق',
    'راه‌اندازی سامانه', 'آزمون‌های فنی', 'بازرسی نهایی', 'تحویل پروژه',
];
const PORTAL_MEDIA_KINDS = [
    'contract' => ['pdf' => 'PDF قرارداد یا پیوست'],
    'service' => ['before' => 'عکس قبل از سرویس', 'after' => 'عکس بعد از سرویس', 'pdf' => 'PDF گزارش'],
    'stage' => ['photo' => 'عکس مرحله', 'pdf' => 'سند PDF مرحله'],
];

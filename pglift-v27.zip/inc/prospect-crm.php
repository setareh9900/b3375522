<?php
declare(strict_types=1);
require_once __DIR__.'/prospect.php';

function prospect_staff(): array
{
    prospect_private_headers();
    if (!gf_is_configured()) redirect('../install.php');
    $staff = current_staff();
    if (!$staff) redirect('login.php');
    return $staff;
}

function prospect_admin_only(array $staff): void
{
    if ($staff['role'] !== 'admin') {
        http_response_code(403);
        exit('این عملیات فقط با حساب مدیر سامانه ممکن است.');
    }
}

function prospect_scope(array $staff, string $alias = 'p'): array
{
    return $staff['role'] === 'admin' ? ['1=1',[]] : ["$alias.assigned_to=?", [(int)$staff['id']]];
}

function prospect_lead(int $id, array $staff, bool $lock = false): ?array
{
    if (!$id) return null;
    [$scope,$params] = prospect_scope($staff);
    if ($lock && gf_driver() === 'sqlite') {
        // Acquire the write lock before validating ownership, not after a stale read.
        [$updateScope] = prospect_scope($staff, 'prospects');
        q("UPDATE prospects SET id=id WHERE id=? AND $updateScope", array_merge([$id], $params));
    }
    $suffix = $lock && gf_driver() !== 'sqlite' ? ' FOR UPDATE' : '';
    return q_one("SELECT p.* FROM prospects p WHERE p.id=? AND $scope".$suffix, array_merge([$id], $params));
}

function prospect_statuses(): array
{
    return array_column(q_all('SELECT code,title FROM prospect_statuses ORDER BY sort_order,code'), 'title', 'code');
}

function prospect_reps(bool $activeOnly = false): array
{
    return q_all("SELECT id,username,full_name,is_active FROM admin_users WHERE role='sales'".($activeOnly ? ' AND is_active=1' : '').' ORDER BY full_name,username');
}

function prospect_rep_labels(array $rows): array
{
    $labels = [];
    foreach ($rows as $row) $labels[$row['id']] = ($row['full_name'] ?: $row['username']).((int)$row['is_active'] === 1 ? '' : ' (غیرفعال)');
    return $labels;
}

function prospect_staff_password(array $input, string $key, bool $required): string
{
    $password = $input[$key] ?? '';
    if (!is_string($password) || (($required || $password !== '') && (strlen($password) < 12 || strlen($password) > 72 || str_contains($password, "\0")))) {
        throw new ProspectValidation('رمز باید دست‌کم ۱۲ و حداکثر ۷۲ بایت باشد.');
    }
    return $password;
}

function prospect_new_unread(): int
{
    return prospect_ready() ? (int)q_val('SELECT COUNT(*) FROM prospect_inquiries WHERE reviewed_at IS NULL') : 0;
}

function prospect_stats(array $staff): array
{
    [$where,$params] = prospect_scope($staff);
    $total = (int)q_val("SELECT COUNT(*) FROM prospects p WHERE $where", $params);
    $converted = (int)q_val("SELECT COUNT(*) FROM prospect_conversions c JOIN prospects p ON p.id=c.prospect_id WHERE $where", $params);
    return [
        'کل مخاطبان'=>fa_digits($total),
        'درخواست بررسی‌نشده'=>fa_digits(q_val("SELECT COUNT(*) FROM prospect_inquiries i JOIN prospects p ON p.id=i.prospect_id WHERE $where AND i.reviewed_at IS NULL", $params)),
        'پیگیری باز'=>fa_digits(q_val("SELECT COUNT(*) FROM prospect_followups f JOIN prospects p ON p.id=f.prospect_id WHERE $where AND f.state='pending'", $params)),
        'در مذاکره'=>fa_digits(q_val("SELECT COUNT(*) FROM prospects p WHERE $where AND p.status='negotiation'", $params)),
        'پیش‌فاکتور ارسال‌شده'=>fa_digits(q_val("SELECT COUNT(*) FROM prospect_quotations o JOIN prospects p ON p.id=o.prospect_id WHERE $where AND o.sent_at IS NOT NULL", $params)),
        'نرخ تبدیل'=> $total ? fa_digits((string)round(100*$converted/$total, 1)).'٪' : '—',
    ];
}

function prospect_lead_list(array $staff, array $search, array $statuses): array
{
    [$scope,$params] = prospect_scope($staff);
    $where = [$scope];
    $filters = [];
    $text = mb_substr(trim(prospect_scalar($search, 'q')), 0, 90, 'UTF-8');
    if ($text !== '') {
        $pattern = static fn(string $v) => '%'.strtr($v, ['!'=>'!!','%'=>'!%','_'=>'!_']).'%';
        $where[] = "(p.full_name LIKE ? ESCAPE '!' OR p.phone LIKE ? ESCAPE '!' OR EXISTS (SELECT 1 FROM prospect_inquiries s WHERE s.prospect_id=p.id AND (s.reference LIKE ? ESCAPE '!' OR s.sender_name LIKE ? ESCAPE '!')))";
        array_push($params, $pattern($text), $pattern(prospect_phone($text) ?: en_digits($text)), $pattern($text), $pattern($text));
        $filters['q'] = $text;
    }
    $status = prospect_scalar($search, 'status');
    if (isset($statuses[$status])) { $where[] = 'p.status=?'; $params[] = $status; $filters['status'] = $status; }
    $rep = prospect_scalar($search, 'rep');
    if ($staff['role'] === 'admin' && $rep !== '') {
        if ($rep === 'unassigned') $where[] = 'p.assigned_to IS NULL';
        elseif (prospect_id($rep)) { $where[] = 'p.assigned_to=?'; $params[] = (int)$rep; }
        $filters['rep'] = $rep;
    }
    $only = prospect_scalar($search, 'only');
    if ($only === 'unread') $where[] = 'EXISTS (SELECT 1 FROM prospect_inquiries i WHERE i.prospect_id=p.id AND i.reviewed_at IS NULL)';
    if ($only === 'due') {
        $where[] = "EXISTS (SELECT 1 FROM prospect_followups f WHERE f.prospect_id=p.id AND f.state='pending' AND f.due_at<=?)";
        $params[] = prospect_now();
    }
    if (in_array($only, ['unread','due'], true)) $filters['only'] = $only;
    $where = implode(' AND ', $where);
    $total = (int)q_val("SELECT COUNT(*) FROM prospects p WHERE $where", $params);
    [$page,$pages,$offset] = prospect_pagination($total, prospect_id($search['page'] ?? null), 24);
    $rows = q_all("SELECT p.id,p.full_name,p.phone,p.status,p.updated_at,p.assigned_to,
        (SELECT COUNT(*) FROM prospect_inquiries i WHERE i.prospect_id=p.id AND i.reviewed_at IS NULL) AS unread,
        (SELECT MIN(f.due_at) FROM prospect_followups f WHERE f.prospect_id=p.id AND f.state='pending') AS next_followup,
        (SELECT s.service FROM prospect_inquiries s WHERE s.prospect_id=p.id ORDER BY s.id DESC LIMIT 1) AS last_service
        FROM prospects p WHERE $where ORDER BY p.updated_at DESC,p.id DESC LIMIT 24 OFFSET $offset", $params);
    return [$rows,$filters,$total,$page,$pages];
}

function prospect_pagination(int $total, int $requested, int $perPage): array
{
    $pages = max(1,(int)ceil($total/$perPage));
    $page = max(1,min($pages,$requested));
    return [$page,$pages,($page-1)*$perPage];
}

function prospect_history(int $leadId, string $tab, int $requested): array
{
    $queries = [
        'inquiries'=>['prospect_inquiries', 'i', 'i.id,i.reference,i.sender_name,i.service,i.source,i.building_type,i.location,i.floors,i.passengers,i.capacity_kg,i.installation_space,i.installation_kind,i.preferred_system,i.requirements,i.description,i.public_state,i.reviewed_at,i.created_at', '', 'i.id DESC'],
        'activity'=>['prospect_interactions', 'i', 'i.*,a.username,a.full_name', ' LEFT JOIN admin_users a ON a.id=i.actor_id', 'i.id DESC'],
        'followups'=>['prospect_followups', 'f', 'f.*', '', "CASE WHEN f.state='pending' THEN 0 ELSE 1 END,f.due_at ASC,f.id DESC"],
        'quotes'=>['prospect_quotations', 'o', 'o.*', '', 'o.id DESC'],
    ];
    [$table,$alias,$fields,$join,$order] = $queries[$tab];
    [$page,$pages,$offset] = prospect_pagination((int)q_val("SELECT COUNT(*) FROM $table WHERE prospect_id=?", [$leadId]), $requested, 20);
    $rows = q_all("SELECT $fields FROM $table $alias$join WHERE $alias.prospect_id=? ORDER BY $order LIMIT 20 OFFSET $offset", [$leadId]);
    return [$rows,$page,$pages];
}

function prospect_crm_change(array $staff, int $id, string $action, array $in): string
{
    return prospect_atomic(static function () use ($staff,$id,$action,$in): string {
        $row = prospect_lead($id, $staff, true);
        if (!$row) throw new ProspectValidation('پرونده در دسترس نیست.', 404);
        $actor = (int)$staff['id'];
        $at = prospect_now();
        $tab = 'inquiries';
        switch ($action) {
            case 'status':
                $statuses = prospect_statuses(); unset($statuses['converted']);
                $status = prospect_choice($in, 'status', 'وضعیت سرنخ', $statuses, true);
                if ($row['status'] === 'converted') throw new ProspectValidation('وضعیت تبدیل‌شده از این فرم قابل تغییر نیست.');
                if ($row['status'] !== $status) {
                    q('UPDATE prospects SET status=? WHERE id=?', [$status,$id]);
                    prospect_log($id,$actor,'status','وضعیت: '.($statuses[$row['status']] ?? $row['status']).' ← '.$statuses[$status]);
                }
                break;
            case 'assign':
                if ($staff['role'] !== 'admin') throw new ProspectValidation('تخصیص پرونده فقط در اختیار مدیر است.', 403);
                $rep = $in['rep'] ?? '';
                $repId = prospect_id($rep);
                $selected = $repId ? q_one("SELECT id,username FROM admin_users WHERE id=? AND role='sales' AND is_active=1", [$repId]) : null;
                if ($rep !== '' && !$selected) throw new ProspectValidation('مسئول فروش فعال انتخاب کنید.');
                if ((int)$row['assigned_to'] !== $repId) {
                    $old = $row['assigned_to'] ? q_val('SELECT username FROM admin_users WHERE id=?', [$row['assigned_to']]) : 'بدون مسئول';
                    q('UPDATE prospects SET assigned_to=? WHERE id=?', [$selected ? $repId : null,$id]);
                    prospect_log($id,$actor,'assignment','مسئول: '.$old.' ← '.($selected['username'] ?? 'بدون مسئول'));
                }
                break;
            case 'review':
                $item = q_one('SELECT id,reference FROM prospect_inquiries WHERE id=? AND prospect_id=?', [prospect_id($in['inquiry_id'] ?? null),$id]);
                if (!$item) throw new ProspectValidation('درخواست متعلق به این پرونده نیست.', 404);
                $states = prospect_public_states();
                $state = prospect_choice($in, 'public_state', 'وضعیت درخواست', $states, true);
                q('UPDATE prospect_inquiries SET public_state=?, reviewed_at=COALESCE(reviewed_at,?), reviewed_by=COALESCE(reviewed_by,?) WHERE id=? AND prospect_id=?',
                    [$state,$at,$actor,$item['id'],$id]);
                prospect_log($id,$actor,'review',$item['reference'].' — '.$states[$state]);
                break;
            case 'interaction':
                $kind = prospect_choice($in, 'kind', 'نوع ارتباط', prospect_interaction_choices(), true);
                prospect_log($id,$actor,$kind,prospect_text($in, 'body', 'متن ارتباط', 3000, 2));
                $tab = 'activity';
                break;
            case 'followup':
                $due = prospect_datetime(prospect_scalar($in, 'due_at'), 'زمان پیگیری');
                if (!$due || $due <= $at) throw new ProspectValidation('برای پیگیری، زمان آینده را به وقت تهران وارد کنید.');
                $task = prospect_text($in,'body','موضوع پیگیری',300,2);
                q('INSERT INTO prospect_followups (prospect_id,due_at,body,created_by,created_at) VALUES (?,?,?,?,?)', [$id,$due,$task,$actor,$at]);
                prospect_log($id,$actor,'followup','پیگیری برای '.prospect_date($due,true).' ثبت شد.');
                $tab = 'followups';
                break;
            case 'close_followup':
                $state = prospect_choice($in, 'state', 'نتیجه', ['done'=>'انجام شد','canceled'=>'لغو شد'], true);
                $followup = prospect_id($in['followup_id'] ?? null);
                if (q("UPDATE prospect_followups SET state=?,closed_at=?,closed_by=? WHERE id=? AND prospect_id=? AND state='pending'", [$state,$at,$actor,$followup,$id])->rowCount() !== 1) {
                    throw new ProspectValidation('پیگیری باز متعلق به این پرونده پیدا نشد.', 404);
                }
                prospect_log($id,$actor,'followup','پیگیری #'.$followup.($state === 'done' ? ' انجام شد.' : ' لغو شد.'));
                $tab = 'followups';
                break;
            case 'quote':
                $ref = prospect_text($in,'reference','شمارهٔ پیش‌فاکتور',120,2);
                if (q_val('SELECT id FROM prospect_quotations WHERE prospect_id=? AND LOWER(reference)=LOWER(?)', [$id,$ref])) throw new ProspectValidation('این شماره قبلاً ثبت شده است.');
                $amount = prospect_text($in,'amount','مبلغ و واحد',120);
                $notes = prospect_text($in,'body','یادداشت پیش‌فاکتور',2500);
                q('INSERT INTO prospect_quotations (prospect_id,reference,amount,notes,created_by,created_at) VALUES (?,?,?,?,?,?)', [$id,$ref,$amount,$notes,$actor,$at]);
                prospect_log($id,$actor,'quote','پیش‌فاکتور '.$ref.' ثبت شد.');
                $tab = 'quotes';
                break;
            case 'quote_sent':
                $quote = q_one('SELECT id,reference FROM prospect_quotations WHERE id=? AND prospect_id=? AND sent_at IS NULL', [prospect_id($in['quote_id'] ?? null),$id]);
                if (!$quote) throw new ProspectValidation('پیش‌فاکتور آماده متعلق به این پرونده پیدا نشد.', 404);
                q('UPDATE prospect_quotations SET sent_at=? WHERE id=? AND prospect_id=?', [$at,$quote['id'],$id]);
                prospect_log($id,$actor,'quote','ارسال پیش‌فاکتور '.$quote['reference'].' تأیید شد.');
                $tab = 'quotes';
                break;
            default:
                throw new ProspectValidation('عملیات نامعتبر است.');
        }
        q('UPDATE prospects SET updated_at=? WHERE id=?', [$at,$id]);
        return $tab;
    });
}

function prospect_interaction_choices(): array
{
    return ['call'=>'تماس تلفنی','note'=>'یادداشت داخلی','email'=>'ایمیل','message'=>'پیام','meeting'=>'جلسه یا بازدید'];
}

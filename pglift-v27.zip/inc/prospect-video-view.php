<?php
declare(strict_types=1);
require_once __DIR__.'/prospect-editorial-view.php';
require_once __DIR__.'/prospect-video.php';

function prospect_story_rail(array $items): void
{
    $items = array_filter($items,static fn($item) => $item['cover_id'] && $item['video_id']);
    if (!$items) { echo '<p class="ps-empty">هنوز استوری برند برای نمایش منتشر نشده است.</p>'; return; }
    ?>
<div class="ps-storyrail" role="list" aria-label="استوری‌های برند" data-story-rail>
    <?php foreach ($items as $item): ?>
        <div role="listitem"><a class="ps-story" href="content.php?id=<?=(int)$item['id']?>" data-story
              data-story-title="<?=e($item['title'])?>" data-story-poster="media.php?id=<?=(int)$item['cover_id']?>" data-story-media="media.php?id=<?=(int)$item['video_id']?>">
            <span class="ps-story-ring"><img src="media.php?id=<?=(int)$item['cover_id']?>" alt="" width="81" height="81" loading="lazy" decoding="async"><span aria-hidden="true" class="ps-story-play">▶</span></span>
            <span class="ps-story-name"><?=e($item['title'])?></span>
        </a></div>
    <?php endforeach ?>
</div>
<dialog class="ps-story-dialog" aria-labelledby="ps-story-title" data-story-dialog>
    <div class="ps-story-head"><div><span>استوری برند</span><h2 id="ps-story-title" data-story-dialog-title></h2></div>
        <form method="dialog"><button class="ps-btn ps-secondary" aria-label="بستن استوری" value="close"><?=icon('close',18)?></button></form></div>
    <video class="ps-video" controls playsinline preload="none" aria-labelledby="ps-story-title"></video>
    <div class="ps-story-actions">
        <button type="button" class="ps-btn ps-secondary" data-story-prev>قبلی</button><span class="ps-caption" data-story-count aria-live="polite"></span><button type="button" class="ps-btn ps-secondary" data-story-next>بعدی</button>
    </div>
    <a class="ps-link" href="brand-stories.php" data-story-original>جزئیات ویدیو <?=prospect_arrow(14)?></a>
</dialog>
    <?php
}

/** One playback surface per context; more clips for the same page are listed below it. */
function prospect_context_video(string $placement): void
{
    $items = prospect_video_items('guide_video',4,$placement);
    $item = $items[0] ?? null;
    if (!$item || !$item['video_id']) return;
    ?>
<details class="ps-context-video">
    <summary><span class="ps-context-play" aria-hidden="true">▶</span><span><strong>راهنمای ویدیویی این بخش</strong><small><?=e($item['title'])?></small></span><span class="ps-context-toggle" aria-hidden="true">+</span></summary>
    <div class="ps-context-body">
        <video class="ps-video" controls playsinline preload="none" aria-label="<?=e($item['title'])?>" src="media.php?id=<?=(int)$item['video_id']?>" poster="media.php?id=<?=(int)$item['cover_id']?>">
            <a href="media.php?id=<?=(int)$item['video_id']?>">باز کردن ویدیو</a>
        </video>
        <p><?=e($item['summary'])?></p>
        <a class="ps-link" href="content.php?id=<?=(int)$item['id']?>">توضیحات ویدیو <?=prospect_arrow(14)?></a>
        <?php if (count($items)>1): ?><ul><?php foreach (array_slice($items,1) as $clip): ?><li><a class="ps-link" href="content.php?id=<?=(int)$clip['id']?>"><?=e($clip['title'])?> <?=prospect_arrow(14)?></a></li><?php endforeach ?></ul><?php endif ?>
    </div>
</details>
    <?php
}

function prospect_portfolio_cards(array $items): void
{
    if (!$items) { echo '<p class="ps-empty">هنوز ویدیوی تأییدشده‌ای برای این بخش منتشر نشده است.</p>'; return; }
    ?>
<div class="ps-post-grid">
    <?php foreach ($items as $item): $url = 'content.php?id='.(int)$item['id']; ?>
    <article class="ps-panel ps-post">
        <?php if ($item['cover_id']): ?><a class="ps-post-img" href="<?=e($url)?>" aria-label="<?=e($item['title'])?>"><img src="media.php?id=<?=(int)$item['cover_id']?>" loading="lazy" decoding="async" alt="<?=e($item['image_alt'])?>"><span class="ps-post-play" aria-hidden="true">▶ ویدیو</span></a><?php endif ?>
        <div class="ps-post-text">
            <span class="ps-chip"><?=e(prospect_portfolio_groups()[$item['portfolio_group']] ?? 'ویترین ویدیویی')?></span>
            <h3><a href="<?=e($url)?>"><?=e($item['title'])?></a></h3>
            <p><?=e($item['summary'])?></p>
            <?php $facts = prospect_video_facts($item); if ($facts): ?><p class="ps-caption"><?=e(implode(' · ',array_values($facts)))?></p><?php endif ?>
        </div>
    </article>
    <?php endforeach ?>
</div>
    <?php
}

function prospect_video_pager(int $page,int $pages,string $group = ''): void
{
    if ($pages <= 1) return;
    $url = static fn(int $n): string => '?'.http_build_query($group !== '' ? ['group'=>$group,'page'=>$n] : ['page'=>$n]);
    ?>
<nav class="ps-pager" aria-label="صفحه‌بندی ویدیوها">
    <?php if ($page > 1): ?><a class="ps-btn ps-secondary" href="<?=e($url($page-1))?>">قبلی</a><?php endif ?>
    <span><?=fa_digits($page)?> از <?=fa_digits($pages)?></span>
    <?php if ($page < $pages): ?><a class="ps-btn ps-secondary" href="<?=e($url($page+1))?>">بعدی</a><?php endif ?>
</nav>
    <?php
}

function prospect_video_placement_url(string $placement): string
{
    return ['intro'=>'index.php#introduction','types'=>'elevator-types.php','type_traction'=>'elevator-type.php?type=traction',
        'type_geared'=>'elevator-type.php?type=geared','type_gearless'=>'elevator-type.php?type=gearless','type_hydraulic'=>'elevator-type.php?type=hydraulic',
        'selection'=>'elevator-selection.php','consultation'=>'request-consultation.php','contact'=>'request-consultation.php?source=contact',
        'tracking'=>'track.php','showcase'=>'showcase.php'][$placement] ?? 'knowledge.php?kind=guide_video';
}

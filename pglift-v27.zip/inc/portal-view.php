<?php
declare(strict_types=1);

require_once __DIR__ . '/portal-media.php';

function portal_icon(string $name, int $size = 20): string
{
    $paths = [
        'lift' => '<rect x="4" y="2.5" width="16" height="19" rx="2"/><path d="M12 7v14.5M4 7h16M10 4.7h4"/>',
        'home' => '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M9 21v-7h6v7"/>',
        'layers' => '<path d="m12 3 9 5-9 5-9-5 9-5ZM3 12l9 5 9-5M3 16l9 5 9-5"/>',
        'tool' => '<path d="M14.5 6.5a4.5 4.5 0 0 0-5.8 5.8l-5 5a2.1 2.1 0 0 0 3 3l5-5a4.5 4.5 0 0 0 5.8-5.8l-2.8 2.8-3-3z"/>',
        'file' => '<path d="M14 2.5H6a2 2 0 0 0-2 2v15a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8.5zM14 2.5v6h6M8 13h8M8 17h6"/>',
        'box' => '<path d="m12 3 9 5v8l-9 5-9-5V8l9-5ZM3 8l9 5 9-5M12 13v8M7.5 5.5l9 5"/>',
        'back' => '<path d="M4 12h16m-6-6 6 6-6 6"/>',
        'arrow' => '<path d="M20 12H4m6-6-6 6 6 6"/>',
        'chevron' => '<path d="m6 9 6 6 6-6"/>',
        'phone' => '<path d="M20.7 16.4v2.7a2 2 0 0 1-2.2 2 17.9 17.9 0 0 1-15.6-15.6 2 2 0 0 1 2-2.2h2.7l1.8 4.6-2.6 1.7a14 14 0 0 0 7.6 7.6l1.7-2.6z"/>',
        'logout' => '<path d="M9 4H4v16h5m5-12 4 4-4 4m-6-4h10"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18m-13 5h2m4 0h2"/>',
        'check' => '<path d="m5 12 4 4L19 6"/>',
        'pin' => '<path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.2"/>',
        'image' => '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m3 17 5-5 4 4 4-5 5 6"/><circle cx="8" cy="8" r="1"/>',
        'download' => '<path d="M12 3v12m-4-4 4 4 4-4M4 15v5h16v-5"/>',
        'play' => '<path d="m9 5 11 7-11 7z"/>',
        'audio' => '<path d="M4 10v4m4-7v10m4-14v18m4-14v10m4-7v4"/>',
        'search' => '<circle cx="10.5" cy="10.5" r="5.5"/><path d="m15 15 5 5"/>',
        'print' => '<path d="M6 8V3h12v5M6 17H4a1 1 0 0 1-1-1v-5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5a1 1 0 0 1-1 1h-2M6 14h12v7H6z"/>',
    ];
    return '<svg aria-hidden="true" width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'.($paths[$name] ?? $paths['lift']).'</svg>';
}

function portal_brand(): string
{
    return setting('customer.brand_name') ?: setting('brand.name', 'خلیج فارس');
}

function portal_phone(): string
{
    $raw = trim(setting('brand.phone'));
    return preg_replace('/[^+\d]/', '', en_digits($raw)) ?? '';
}

function portal_start(?array $account, string $title, string $nav = ''): void
{
    $brand = portal_brand();
    $theme = setting('customer.ui_kit', 'gradient');
    if (!in_array($theme, ['gradient', 'porcelain', 'azure', 'sage', 'sand', 'midnight'], true)) $theme = 'gradient';
    $layout = setting('customer.layout', 'sidebar') === 'compact' ? 'compact' : 'sidebar';
    $logo = active_logo();
    $phone = portal_phone();
    $items = [
        'home' => ['index.php', 'نمای کلی', 'home'], 'installation' => ['installation.php', 'نصب', 'layers'],
        'maintenance' => ['maintenance.php', 'سرویس', 'tool'], 'contracts' => ['contracts.php', 'قراردادها', 'file'],
        'parts' => ['parts.php', 'قطعات', 'box'],
    ];
    ?>
<!doctype html>
<html lang="fa" dir="rtl" data-customer-theme="<?=e($theme)?>" data-customer-layout="<?=e($layout)?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
    <meta name="robots" content="noindex,nofollow">
    <meta name="theme-color" content="<?=$theme === 'midnight' ? '#131826' : '#f4f6fb'?>">
    <title><?=e($title)?> | <?=e($brand)?></title>
    <link rel="stylesheet" href="../assets/css/customer-portal.css?v=<?=filemtime(__DIR__.'/../assets/css/customer-portal.css')?>">
    <script defer src="../assets/js/customer-portal.js?v=<?=filemtime(__DIR__.'/../assets/js/customer-portal.js')?>"></script>
</head>
<body class="portal<?=$account ? '' : ' portal-guest'?>">
<a class="pp-skip" href="#main">رفتن به محتوای اصلی</a>
<header class="pp-header">
    <div class="pp-header-inner">
        <a class="pp-brand" href="index.php">
            <span class="pp-brand-mark"><?php if ($logo): ?><img src="<?=e($logo)?>" alt=""><?php else: ?><?=portal_icon('lift', 23)?><?php endif ?></span>
            <span><strong><?=e($brand)?></strong><small><?=e(setting('customer.subtitle', 'پنل اختصاصی مشتریان'))?></small></span>
        </a>
        <?php if ($account): ?>
        <div class="pp-header-actions">
            <?php if ($phone !== ''): ?><a class="pp-header-help" href="tel:<?=e($phone)?>" aria-label="تماس با پشتیبانی"><?=portal_icon('phone', 17)?> <span>پشتیبانی</span></a><?php endif ?>
            <details class="pp-account">
                <summary><span class="pp-avatar" aria-hidden="true"><?=e(mb_substr(trim($account['name']), 0, 1, 'UTF-8'))?></span><span class="pp-account-label"><?=e($account['name'])?></span><span class="pp-account-chevron"><?=portal_icon('chevron', 14)?></span><span class="pp-sr">حساب مشتری</span></summary>
                <div class="pp-account-popover"><b><?=e($account['name'])?></b><form method="post" action="index.php"><?=csrf_field()?><input type="hidden" name="action" value="logout"><button type="submit"><?=portal_icon('logout', 17)?> خروج از حساب</button></form></div>
            </details>
        </div>
        <?php endif ?>
    </div>
</header>
<div class="pp-shell">
<?php if ($account): ?>
    <aside class="pp-sidebar">
        <nav aria-label="ناوبری پنل مشتری">
            <span class="pp-nav-label">میز کار پروژه</span>
            <?php foreach ($items as $key => [$url, $label, $icon]): ?>
                <a href="<?=$url?>"<?= $nav === $key ? ' aria-current="page"' : '' ?>><?=portal_icon($icon, 20)?><span><?=e($label)?></span></a>
            <?php endforeach ?>
        </nav>
        <div class="pp-sidebar-foot"><a href="../index.php">سایت اصلی <?=portal_icon('arrow', 15)?></a></div>
    </aside>
<?php endif ?>
<main id="main" class="pp-main">
    <?php
}

function portal_end(): void
{
    ?>
    <footer class="pp-footer"><span><?=e(portal_brand())?> · پنل مشتریان</span><a href="../index.php">سایت اصلی <?=portal_icon('arrow', 14)?></a></footer>
</main></div>
<div class="pp-toast" role="status" aria-live="polite" hidden></div>
</body></html>
    <?php
}

function portal_intro(string $title, string $subtitle = '', string $eyebrow = '', string $backUrl = '', string $backLabel = 'بازگشت'): void
{
    ?>
    <header class="pp-intro">
        <?php if ($backUrl !== ''): ?><a class="pp-back" href="<?=e($backUrl)?>"><?=portal_icon('back', 16)?> <?=e($backLabel)?></a><?php endif ?>
        <?php if ($eyebrow !== ''): ?><span class="pp-eyebrow"><i></i><?=e($eyebrow)?></span><?php endif ?>
        <h1><?=e($title)?></h1>
        <?php if ($subtitle !== ''): ?><p><?=e($subtitle)?></p><?php endif ?>
    </header>
    <?php
}

function portal_missing_record(array $account, string $nav, string $back): void
{
    http_response_code(404);
    portal_start($account, 'موردی پیدا نشد', $nav);
    portal_intro('موردی پیدا نشد', 'این پرونده در حساب شما در دسترس نیست.', '', $back, 'بازگشت به فهرست');
    portal_end();
    exit;
}

function portal_badge(?string $key, array $labels, string $missing = 'ثبت نشده'): string
{
    $key = trim($key ?? '');
    $tone = [
        'active' => 'good', 'done' => 'good', 'completed' => 'good', 'operational' => 'good', 'on_track' => 'good',
        'scheduled' => 'info', 'in_progress' => 'info', 'under_installation' => 'info',
        'limited' => 'warn', 'suspended' => 'warn', 'blocked' => 'warn', 'needs_followup' => 'warn', 'paused' => 'warn',
        'canceled' => 'bad', 'out_of_service' => 'bad',
    ][$key] ?? 'neutral';
    return '<span class="pp-badge tone-'.$tone.'"><i aria-hidden="true"></i>'.e($labels[$key] ?? ($key !== '' ? $key : $missing)).'</span>';
}

function portal_section_head(string $title, string $icon = '', string $url = '', string $linkLabel = ''): void
{
    ?>
    <div class="pp-section-head"><h2><?php if ($icon): ?><span class="pp-section-icon"><?=portal_icon($icon, 19)?></span><?php endif ?><?=e($title)?></h2>
        <?php if ($url): ?><a class="pp-text-link" href="<?=e($url)?>"><?=e($linkLabel)?> <?=portal_icon('arrow', 16)?></a><?php endif ?>
    </div>
    <?php
}

function portal_empty(string $icon, string $title, string $description = ''): void
{
    ?>
    <div class="pp-empty"><span class="pp-section-icon"><?=portal_icon($icon, 19)?></span><div><strong><?=e($title)?></strong><?php if ($description): ?><p><?=e($description)?></p><?php endif ?></div></div>
    <?php
}

function portal_has($value): bool
{
    return trim((string)($value ?? '')) !== '';
}

/** Label/value display. Do not treat string zero as missing. */
function portal_facts(array $facts, bool $showMissing = false): void
{
    if (!$showMissing) $facts = array_filter($facts, 'portal_has');
    if (!$facts) return;
    ?><dl class="pp-facts"><?php foreach ($facts as $label => $value): ?>
        <div><dt><?=e($label)?></dt><dd><bdi<?=portal_has($value) ? '' : ' class="pp-muted"'?>><?=e(portal_has($value) ? (string)$value : 'ثبت نشده')?></bdi></dd></div>
    <?php endforeach ?></dl><?php
}

function portal_note(?string $text, string $missing = PORTAL_MISSING): void
{
    ?><p class="pp-note<?=portal_has($text) ? '' : ' pp-muted'?>"><?=e(portal_has($text) ? $text : $missing)?></p><?php
}

function portal_disclosure(string $title, callable $body, bool $open = false, string $id = ''): void
{
    ?><details class="pp-disclosure"<?=$id !== '' ? ' id="'.e($id).'"' : ''?><?=$open ? ' open' : ''?>><summary><span><?=e($title)?></span><?=portal_icon('chevron', 19)?></summary><div class="pp-disclosure-body"><?php $body(); ?></div></details><?php
}

function portal_contract_card(array $contract): void
{
    ?>
    <article class="pp-card pp-contract">
        <div class="pp-card-top"><span class="pp-tiny-icon"><?=portal_icon('file', 18)?></span><?=portal_badge($contract['status'], PORTAL_CONTRACT_STATUSES)?></div>
        <h3><?=e($contract['title'])?></h3>
        <span class="pp-muted pp-small">شماره قرارداد: <bdi><?=e($contract['contract_no'])?></bdi></span>
        <?php portal_facts(['شروع' => $contract['start_date'], 'انقضا' => $contract['end_date'], 'مبلغ کل' => $contract['total_amount']], true); ?>
        <a class="pp-btn" href="contract.php?id=<?=(int)$contract['id']?>">مشاهده کامل قرارداد <?=portal_icon('arrow', 16)?></a>
    </article>
    <?php
}

function portal_media_view(array $files, string $type, bool $showMissing = true): void
{
    if (!$files) {
        if ($showMissing) portal_note(null);
        return;
    }
    ?>
    <div class="pp-media">
    <?php foreach ($files as $file):
        $url = 'attachment.php?id='.(int)$file['id'];
        $label = PORTAL_MEDIA_KINDS[$type][$file['kind']] ?? 'پیوست';
        $name = $file['caption'] ?: $file['original_name']; ?>
        <?php if ($file['mime'] === 'application/pdf'): ?>
            <div class="pp-media-file"><span class="pp-tiny-icon"><?=portal_icon('file', 19)?></span><div class="pp-media-meta"><b><?=e($name)?></b><small><?=e($label)?></small></div><div class="pp-actions">
                <a class="pp-btn" href="<?=$url?>" target="_blank" rel="noopener">مشاهده PDF</a>
                <a class="pp-btn" href="<?=$url?>&amp;download=1" download><?=portal_icon('download', 16)?> دانلود</a>
            </div></div>
        <?php else: ?>
            <figure class="pp-media-photo"><a href="<?=$url?>" target="_blank" rel="noopener" aria-label="نمایش <?=e($label)?>: <?=e($name)?>"><img src="<?=$url?>" alt="<?=e($name)?>" loading="lazy" decoding="async"></a><figcaption><small><?=e($label)?></small><b><?=e($name)?></b></figcaption></figure>
        <?php endif ?>
    <?php endforeach ?>
    </div>
    <?php
}

function portal_progress($value, string $label): void
{
    if ($value === null || $value === '' || !is_numeric($value) || $value < 0 || $value > 100) return;
    ?>
    <div class="pp-progress"><div><span><?=e($label)?></span><b><?=fa_digits((int)$value)?>٪</b></div><progress max="100" value="<?=(int)$value?>" aria-label="<?=e($label)?>"><?=(int)$value?>%</progress></div>
    <?php
}

function portal_part_card(array $part, bool $filterable = false): void
{
    $id = (int)$part['id'];
    $warranty = portal_has($part['warranty_status'] ?? null) ? $part['warranty_status'] : ($part['warranty'] ?? '');
    ?>
    <article class="pp-card pp-part" id="customer-part-<?=$id?>"<?php if ($filterable): ?> data-part data-id="<?=$id?>" data-name="<?=e($part['name'])?>" data-brand="<?=e($part['brand'])?>"
        data-has-image="<?=portal_has($part['image_ref']) ? 'yes' : 'no'?>" data-warranty="<?=portal_has($warranty) ? 'yes' : 'no'?>"
        data-search="<?=e(implode(' ', [$part['name'], $part['brand'], $part['model'], $part['serial_number'], $part['specifications'], $warranty]))?>"<?php endif ?>>
        <div class="pp-part-top">
            <a class="pp-part-thumb" href="part.php?id=<?=$id?>" aria-label="مشاهده <?=e($part['name'])?>"><?php if (portal_has($part['image_ref'])): ?><img src="image.php?id=<?=$id?>" alt="" loading="lazy" decoding="async"><?php else: ?><?=portal_icon('box', 28)?><?php endif ?></a>
            <div><h3><a href="part.php?id=<?=$id?>"><?=e($part['name'])?></a></h3>
                <small class="pp-muted"><?php if (portal_has($part['brand'])): ?><bdi><?=e($part['brand'])?></bdi><?php endif ?><?php if (portal_has($part['model'])): ?><?=portal_has($part['brand']) ? ' · ' : ''?><bdi><?=e($part['model'])?></bdi><?php endif ?></small>
                <?php if (portal_has($part['quantity'])): ?><span class="pp-part-qty">تعداد: <bdi><?=e($part['quantity'])?></bdi></span><?php endif ?>
            </div>
        </div>
        <?php portal_facts(['سریال' => $part['serial_number'], 'نصب' => $part['installed_at'], 'ضمانت' => $warranty]); ?>
        <a class="pp-text-link" href="part.php?id=<?=$id?>">جزئیات قطعه <?=portal_icon('arrow', 15)?></a>
    </article>
    <?php
}

function portal_visit_card(array $visit): void
{
    $summary = preg_replace('/\s+/u', ' ', trim($visit['summary'])) ?? '';
    if (mb_strlen($summary, 'UTF-8') > 180) $summary = mb_substr($summary, 0, 179, 'UTF-8').'…';
    ?>
    <article class="pp-card pp-visit">
        <div class="pp-card-top"><span class="pp-small pp-muted pp-inline"><?=portal_icon('calendar', 16)?> <bdi><?=e($visit['service_date'])?></bdi></span><?=portal_badge($visit['status'], PORTAL_VISIT_STATUSES)?></div>
        <h3><?=e(PORTAL_SERVICE_TYPES[$visit['service_type'] ?? ''] ?? 'بازدید سرویس')?></h3>
        <p class="pp-small pp-muted">تکنسین: <?=e(portal_has($visit['technician']) ? $visit['technician'] : 'ثبت نشده')?></p>
        <?php if ($summary !== ''): ?><p class="pp-visit-summary"><?=e($summary)?></p><?php endif ?>
        <a class="pp-text-link" href="service-report.php?id=<?=(int)$visit['id']?>">مشاهده گزارش <?=portal_icon('arrow', 16)?></a>
    </article>
    <?php
}

function portal_audio_controls(string $audioUrl, string $speech): void
{
    if ($audioUrl !== '') {
        ?><div class="pp-audio"><span class="pp-small pp-muted">صوت مشخصات</span><audio controls preload="none" src="<?=e($audioUrl)?>"></audio></div><?php
    } elseif ($speech !== '') {
        ?><button class="pp-btn" type="button" data-speak="<?=e($speech)?>" hidden><?=portal_icon('audio', 17)?> <span>شنیدن مشخصات</span></button><?php
    }
}

<?php
declare(strict_types=1);
require_once __DIR__.'/prospect-view.php';

function prospect_input_field(string $name, string $label, $value = '', string $attributes = '', string $kind = 'text'): void
{
    ?><label class="ps-field"><span><?=e($label)?></span><input name="<?=e($name)?>" type="<?=e($kind)?>" value="<?=e((string)$value)?>" <?=$attributes?>></label><?php
}

function prospect_textarea(string $name, string $label, $value, int $max, int $rows = 3, bool $required = false): void
{
    ?><label class="ps-field"><span><?=e($label)?></span><textarea name="<?=e($name)?>" maxlength="<?=$max?>" rows="<?=$rows?>"<?=$required ? ' required' : ''?>><?=e((string)$value)?></textarea></label><?php
}

function prospect_checkbox(string $name, string $label, bool $checked = false, bool $required = false): void
{
    ?><label class="ps-check"><input type="checkbox" name="<?=e($name)?>" value="1"<?=$checked ? ' checked' : ''?><?=$required ? ' required' : ''?>><span><?=e($label)?></span></label><?php
}

function prospect_facts(array $facts): void
{
    ?><dl class="ps-facts"><?php foreach ($facts as $label=>$value): ?><div><dt><?=e($label)?></dt><dd><bdi><?=e((string)$value)?></bdi></dd></div><?php endforeach ?></dl><?php
}

function prospect_project_fields(array $in, bool $needContext, bool $compact = false): void
{
    ?><div class="ps-fields">
        <?php prospect_select_field('building_type', 'کاربری ساختمان', prospect_buildings(), $in['building_type'] ?? '', $needContext, $needContext ? 'انتخاب کنید' : 'نامشخص'); ?>
        <?php prospect_input_field('location', 'شهر و محدودهٔ ساختمان'.($needContext ? ' *' : ''), $in['location'] ?? '', 'maxlength="180" placeholder="نیازی به نشانی دقیق نیست"'.($needContext ? ' required' : '')); ?>
        <?php prospect_input_field('floors', 'تعداد طبقات', $in['floors'] ?? '', 'inputmode="numeric" maxlength="3" placeholder="اگر مشخص است"'); ?>
    </div>
    <?php if ($compact): ?><details class="ps-form-more"<?=array_filter(array_intersect_key($in,array_flip(['passengers','capacity_kg','installation_space','installation_kind','preferred_system']))) ? ' open' : ''?>><summary>جزئیات اختیاری محل و ظرفیت</summary><?php endif ?>
    <div class="ps-fields">
        <?php prospect_input_field('passengers', 'تعداد تقریبی مسافر', $in['passengers'] ?? '', 'inputmode="numeric" maxlength="3"'); ?>
        <?php prospect_input_field('capacity_kg', 'ظرفیت مدنظر (کیلوگرم)', $in['capacity_kg'] ?? '', 'inputmode="numeric" maxlength="5"'); ?>
        <?php prospect_select_field('installation_space', 'محل پیش‌بینی‌شده برای نصب', prospect_spaces(), $in['installation_space'] ?? '', false, 'نامشخص'); ?>
        <?php prospect_select_field('installation_kind', 'نصب یا جایگزینی', prospect_installation_kinds(), $in['installation_kind'] ?? '', false, 'نامشخص'); ?>
        <?php prospect_select_field('preferred_system', 'سامانهٔ مدنظر', prospect_systems(), $in['preferred_system'] ?? '', false, 'بدون ترجیح'); ?>
    </div>
    <?php if ($compact): ?></details><?php endif ?>
    <?php prospect_textarea('requirements','نیازهای آسانسور یا ملاحظات ساختمان', $in['requirements'] ?? '', 1400); ?>
    <?php
}

function prospect_contact_fields(array $in = []): void
{
    ?><div class="ps-fields">
        <?php prospect_input_field('name', 'نام و نام خانوادگی *', $in['name'] ?? '', 'required maxlength="150" autocomplete="name"'); ?>
        <?php prospect_input_field('phone', 'شمارهٔ تماس *', $in['phone'] ?? '', 'required maxlength="40" autocomplete="tel" inputmode="tel" dir="ltr"', 'tel'); ?>
    </div><?php
}

function prospect_consent(array $in = []): void
{
    ?><div hidden><label>Website<input name="website" value="" tabindex="-1" autocomplete="off"></label></div>
    <?php prospect_checkbox('consent','موافقم برای رسیدگی به همین درخواست، اطلاعات واردشده ثبت و از شمارهٔ تماس استفاده شود.', ($in['consent'] ?? '') === '1', true); ?>
    <?php
}

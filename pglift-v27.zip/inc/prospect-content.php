<?php
declare(strict_types=1);
require_once __DIR__.'/prospect.php';

function prospect_guidance_video_types(): array
{
    return ['brand_story'=>'استوری تبلیغاتی برند','guide_video'=>'راهنمای ویدیویی یک بخش','portfolio_video'=>'ویدیوی همکاری و پروژه'];
}

function prospect_content_types(): array
{
    return ['company'=>'معرفی شرکت','tip'=>'نکتهٔ فنی','article'=>'مقاله و راهنمای تخصصی','short_video'=>'ویدیوی کوتاه',
        'weekly_video'=>'ویدیوی آموزشی هفته','project'=>'پروژهٔ اجراشده','trust'=>'تیم و توانمندی‌ها','feedback'=>'تجربهٔ مستند مشتری',
        'certificate'=>'گواهی و مدرک','appreciation'=>'قدردانی و ارتباط'] + prospect_guidance_video_types();
}

function prospect_evidence_types(): array { return ['company','project','trust','feedback','certificate','brand_story','portfolio_video']; }
function prospect_is_video(string $kind): bool { return in_array($kind, ['short_video','weekly_video'],true) || isset(prospect_guidance_video_types()[$kind]); }

function prospect_video_placements(): array
{
    return ['intro'=>'خانهٔ راهنما: معرفی','types'=>'فهرست انواع آسانسور','type_traction'=>'صفحهٔ آسانسور کششی',
        'type_gearless'=>'صفحهٔ آسانسور گیرلس','type_geared'=>'صفحهٔ آسانسور گیربکس‌دار','type_hydraulic'=>'صفحهٔ آسانسور هیدرولیک',
        'selection'=>'ابزار راهنمای انتخاب','consultation'=>'فرم مشاوره','contact'=>'فرم تماس','tracking'=>'پیگیری درخواست','showcase'=>'صفحهٔ نمونه‌کارها'];
}

function prospect_portfolio_groups(): array
{
    return ['company'=>'شرکت‌های همکار','equipment'=>'برندها و تجهیزات','delivery'=>'ساختمان‌های تکمیل‌شده'];
}

function prospect_portfolio_name_fields(): array
{
    return ['company'=>'company_name','equipment'=>'equipment_brand','delivery'=>'building_name'];
}

function prospect_video_details(int $id): array
{
    if (!$id || !prospect_guidance_ready()) return [];
    return q_one('SELECT placement,portfolio_group,company_name,equipment_brand,building_name FROM prospect_video_details WHERE content_id=?',[$id]) ?? [];
}

function prospect_publish_states(): array { return ['draft'=>'پیش‌نویس','published'=>'انتشار یا زمان‌بندی','paused'=>'متوقف']; }

function prospect_campaigns(): array
{
    return q_all('SELECT * FROM prospect_campaigns ORDER BY sort_order,slot');
}

/** Use this same gate for cards, article routes and every public byte of uploaded media. */
function prospect_public_gate(): string
{
    $verified = "'".implode("','", prospect_evidence_types())."'";
    $gate = "c.state='published' AND c.publish_at<=?
        AND (c.kind NOT IN ($verified) OR c.is_verified=1)
        AND (c.campaign_slot IS NULL OR (s.is_active=1 AND (s.starts_at IS NULL OR s.starts_at<=?)))";
    $newKinds = "'brand_story','guide_video','portfolio_video'";
    if (!prospect_guidance_ready()) return "$gate AND c.kind NOT IN ($newKinds)";

    // Incomplete video metadata must not make either a page or its media public.
    $placements = "'".implode("','",array_keys(prospect_video_placements()))."'";
    $length = gf_driver() === 'sqlite' ? 'LENGTH' : 'CHAR_LENGTH';
    $portfolio = [];
    foreach (prospect_portfolio_name_fields() as $group=>$field) {
        $portfolio[] = "(vd.portfolio_group='$group' AND $length(TRIM(vd.$field))>=2)";
    }
    $portfolio = implode(' OR ',$portfolio);
    return "$gate
        AND (c.kind NOT IN ($newKinds) OR (
            EXISTS (SELECT 1 FROM prospect_content_media vm WHERE vm.content_id=c.id AND vm.kind='video' AND vm.mime IN ('video/mp4','video/webm') AND vm.byte_size BETWEEN 16 AND 25165824)
            AND EXISTS (SELECT 1 FROM prospect_content_media pm WHERE pm.content_id=c.id AND pm.kind='cover' AND pm.mime IN ('image/jpeg','image/png','image/webp') AND pm.byte_size BETWEEN 16 AND 512000)
            AND (c.kind='guide_video' OR $length(TRIM(c.verification_note))>=3)
            AND (c.kind='brand_story' OR EXISTS (SELECT 1 FROM prospect_video_details vd WHERE vd.content_id=c.id
                AND ((c.kind='guide_video' AND vd.placement IN ($placements)) OR (c.kind='portfolio_video' AND ($portfolio)))))))";
}

function prospect_feed_filter(array $kinds, int $category, int $slot = 0): array
{
    $at = prospect_now();
    $gate = prospect_public_gate();
    $params = [$at,$at];
    if ($kinds) {
        $gate .= ' AND c.kind IN ('.implode(',',array_fill(0,count($kinds),'?')).')';
        $params = array_merge($params,$kinds);
    }
    if ($category) { $gate .= ' AND c.category_id=?'; $params[] = $category; }
    if ($slot) { $gate .= ' AND c.campaign_slot=?'; $params[] = $slot; }
    return [$gate,$params];
}

function prospect_public_items(array $kinds, int $limit, int $offset = 0, int $category = 0, int $slot = 0): array
{
    if (!prospect_ready()) return [];
    [$gate,$args] = prospect_feed_filter($kinds,$category,$slot);
    $limit = max(1,min(36,$limit));
    $offset = max(0,$offset);
    return q_all("SELECT c.id,c.kind,c.title,c.summary,c.project_type,c.elevator_type,c.image_alt,c.publish_at,c.is_featured,
        d.title AS category_title, s.title AS stage_title,
        (SELECT m.id FROM prospect_content_media m WHERE m.content_id=c.id AND m.kind='cover' ORDER BY m.id DESC LIMIT 1) AS cover_id
        FROM prospect_content c LEFT JOIN prospect_campaigns s ON s.slot=c.campaign_slot
        LEFT JOIN prospect_content_categories d ON d.id=c.category_id WHERE $gate
        ORDER BY c.is_featured DESC,c.publish_at DESC,c.id DESC LIMIT $limit OFFSET $offset",$args);
}

function prospect_public_count(array $kinds, int $category): int
{
    if (!prospect_ready()) return 0;
    [$gate,$args] = prospect_feed_filter($kinds,$category);
    return (int)q_val("SELECT COUNT(*) FROM prospect_content c LEFT JOIN prospect_campaigns s ON s.slot=c.campaign_slot WHERE $gate",$args);
}

function prospect_public_categories(array $kinds): array
{
    if (!prospect_ready()) return [];
    [$gate,$args] = prospect_feed_filter($kinds,0);
    return array_column(q_all("SELECT DISTINCT d.id,d.title FROM prospect_content_categories d JOIN prospect_content c ON c.category_id=d.id
        LEFT JOIN prospect_campaigns s ON s.slot=c.campaign_slot WHERE $gate ORDER BY d.title,d.id",$args), 'title','id');
}

function prospect_public_post(int $id): ?array
{
    if (!$id || !prospect_ready()) return null;
    [$gate,$args] = prospect_feed_filter([],0);
    return q_one("SELECT c.id,c.kind,c.title,c.summary,c.body,c.project_type,c.elevator_type,c.technical_info,c.image_alt,c.seo_title,c.seo_description,
        c.publish_at,d.title AS category_title,s.title AS stage_title FROM prospect_content c
        LEFT JOIN prospect_campaigns s ON s.slot=c.campaign_slot LEFT JOIN prospect_content_categories d ON d.id=c.category_id
        WHERE c.id=? AND $gate",array_merge([$id],$args));
}

function prospect_content_media(int $contentId): array
{
    $result = ['cover'=>null,'video'=>null,'gallery'=>[]];
    foreach (q_all('SELECT id,kind,mime,alt_text,byte_size FROM prospect_content_media WHERE content_id=? ORDER BY id',[$contentId]) as $m) {
        if ($m['kind'] === 'gallery') $result['gallery'][] = $m;
        elseif (array_key_exists($m['kind'],$result)) $result[$m['kind']] = $m;
    }
    return $result;
}

/** Confirmation binds to the exact contact settings the administrator reviewed. */
function prospect_contact_settings(): array
{
    if (!gf_is_configured()) return [];
    $values = [];
    foreach (['phone','mobile','email','address','hours','whatsapp','instagram'] as $key) $values[$key] = trim(setting('brand.'.$key));
    return $values;
}

function prospect_contact_digest(array $settings): string { return hash('sha256', implode("\0", $settings)); }

function prospect_contact_channels(): array
{
    $values = prospect_contact_settings();
    if (!$values || !hash_equals(setting('prospect.contact_reviewed'), prospect_contact_digest($values))) return [[],[]];
    $links = [];
    foreach (['phone'=>'تلفن دفتر','mobile'=>'شمارهٔ همراه'] as $key=>$label) {
        $normalized = prospect_phone($values[$key]);
        if ($normalized !== '') $links[] = [$label, $values[$key], 'tel:'.$normalized, 'phone'];
    }
    if (valid_email($values['email'])) $links[] = ['ایمیل', $values['email'], 'mailto:'.$values['email'], 'mail'];
    if (($whatsapp = prospect_phone($values['whatsapp'])) !== '') $links[] = ['واتس‌اپ','پیام در واتس‌اپ','https://wa.me/98'.substr($whatsapp,1),'whatsapp'];
    if (preg_match('#^https://(www\.)?instagram\.com/[A-Za-z0-9_.]{1,60}/?$#D', $values['instagram'])) $links[] = ['اینستاگرام','صفحهٔ اینستاگرام',$values['instagram'],'instagram'];
    return [$links,array_filter(['نشانی دفتر'=>$values['address'],'ساعات کاری'=>$values['hours']],static fn($v) => $v !== '')];
}

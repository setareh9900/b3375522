<?php
declare(strict_types=1);
require_once __DIR__.'/prospect-content.php';

function prospect_media_path(string $name): ?string
{
    return preg_match('/^[a-f0-9]{32}\.(?:jpg|png|webp|mp4|webm)$/D',$name)
        ? dirname(__DIR__).'/data/prospect-media/'.$name : null;
}

function prospect_validate_upload($file, string $kind, bool $poster): ?array
{
    if ($file === null || ($file['error'] ?? null) === UPLOAD_ERR_NO_FILE) return null;
    $tmp = is_array($file) && is_string($file['tmp_name'] ?? null) ? $file['tmp_name'] : '';
    $limit = $kind === 'video' ? 24*1024*1024 : ($poster ? 500*1024 : 2*1024*1024);
    if (($file['error'] ?? null) !== UPLOAD_ERR_OK || !is_uploaded_file($tmp) || ($size = filesize($tmp)) === false || $size < 16 || $size > $limit) {
        throw new ProspectValidation($kind === 'video' ? 'فایل ویدیو معتبر و حداکثر ۲۴ مگابایت باشد.' : ($poster ? 'پوستر بهینهٔ حداکثر ۵۰۰ کیبی‌بایت بارگذاری کنید.' : 'تصویر معتبر و حداکثر ۲ مگابایت باشد.'));
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
    if ($kind === 'video') {
        $head = file_get_contents($tmp, false, null, 0, 256);
        $extension = match ($mime) {
            'video/mp4' => is_string($head) && substr($head,4,4) === 'ftyp' ? 'mp4' : '',
            'video/webm' => is_string($head) && substr($head,0,4) === "\x1a\x45\xdf\xa3" && strpos($head,'webm') !== false ? 'webm' : '',
            default => '',
        };
        if ($extension === '') throw new ProspectValidation('ویدیو باید فایل واقعی MP4 یا WebM قابل پخش در مرورگر باشد.');
    } else {
        $dimensions = @getimagesize($tmp);
        $allowed = [IMAGETYPE_JPEG=>['jpg','image/jpeg'],IMAGETYPE_PNG=>['png','image/png'],IMAGETYPE_WEBP=>['webp','image/webp']];
        $type = $dimensions ? ($allowed[$dimensions[2]] ?? []) : [];
        $max = $poster ? 1280 : 2200;
        if (!$type || $type[1] !== $mime || $dimensions[0] < 1 || $dimensions[1] < 1 || max($dimensions[0],$dimensions[1]) > $max) {
            throw new ProspectValidation('تصویر واقعی JPG، PNG یا WebP با ضلع حداکثر '.fa_digits($max).' پیکسل بارگذاری کنید.');
        }
        $extension = $type[0];
    }
    return ['tmp'=>$tmp,'name'=>bin2hex(random_bytes(16)).'.'.$extension,'mime'=>$mime,'size'=>$size];
}

function prospect_store_upload(array $upload): string
{
    $path = prospect_media_path($upload['name']);
    $dir = dirname($path);
    if (!is_dir($dir) && !@mkdir($dir,0750,true) && !is_dir($dir)) throw new ProspectValidation('پوشهٔ خصوصی رسانه قابل ساخت نیست.');
    if (is_link($dir) || file_exists($path) || !move_uploaded_file($upload['tmp'],$path)) throw new ProspectValidation('ذخیرهٔ فایل در پوشهٔ خصوصی انجام نشد.');
    @chmod($path,0640);
    return $path;
}

function prospect_media_row(int $id, bool $preview): ?array
{
    if (!$id || !prospect_ready()) return null;
    if ($preview) return current_user() ? q_one('SELECT id,stored_name,mime,byte_size FROM prospect_content_media WHERE id=?',[$id]) : null;
    [$gate,$args] = prospect_feed_filter([],0);
    return q_one("SELECT m.id,m.stored_name,m.mime,m.byte_size FROM prospect_content_media m JOIN prospect_content c ON c.id=m.content_id
        LEFT JOIN prospect_campaigns s ON s.slot=c.campaign_slot WHERE m.id=? AND $gate", array_merge([$id],$args));
}

function prospect_stream_media(array $row, string $method, string $range): void
{
    $path = prospect_media_path($row['stored_name']);
    $mimes = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','video/mp4'=>'mp4','video/webm'=>'webm'];
    $extension = $mimes[$row['mime']] ?? '';
    if (!$path || $extension === '' || !str_ends_with($path,'.'.$extension) || is_link($path) || !is_file($path) || !($stream = @fopen($path,'rb'))) {
        http_response_code(404); return;
    }
    $size = fstat($stream)['size'] ?? 0;
    if ($size < 1 || $size !== (int)$row['byte_size']) { fclose($stream); http_response_code(404); return; }
    $start = 0; $end = $size-1;
    header('Accept-Ranges: bytes');
    if ($range !== '') {
        $valid = preg_match('/^bytes=(\d{0,18})-(\d{0,18})$/D',$range,$parts) && ($parts[1] !== '' || $parts[2] !== '');
        if ($valid) {
            if ($parts[1] === '') {
                $valid = (float)$parts[2] > 0;
                $start = $size - (int)min((float)$parts[2],$size);
            } else {
                $valid = (float)$parts[1] < $size;
                if ($valid) $start = (int)$parts[1];
                if ($parts[2] !== '') $end = (int)min((float)$parts[2],$end);
                $valid = $valid && $end >= $start;
            }
        }
        if (!$valid) { fclose($stream); header('Content-Range: bytes */'.$size); http_response_code(416); return; }
        http_response_code(206);
        header('Content-Range: bytes '.$start.'-'.$end.'/'.$size);
    }
    header('Content-Type: '.$row['mime']);
    header('Content-Disposition: inline; filename="media.'.$extension.'"');
    header('Content-Security-Policy: sandbox; default-src \'none\'');
    $remaining = $end-$start+1;
    header('Content-Length: '.$remaining);
    if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
    if ($method !== 'HEAD' && fseek($stream,$start) === 0) {
        while ($remaining > 0 && !feof($stream) && !connection_aborted()) {
            $chunk = fread($stream,min(65536,$remaining));
            if ($chunk === false || $chunk === '') break;
            echo $chunk;
            $remaining -= strlen($chunk);
        }
    }
    fclose($stream);
}

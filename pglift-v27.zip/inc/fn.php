<?php
/**
 * توابع کمکی مشترک — آسانسور خلیج فارس صادقی
 */
declare(strict_types=1);

require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    $secureSession = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (int)($_SERVER['SERVER_PORT'] ?? 0) === 443;
    session_set_cookie_params(['httponly' => true, 'secure' => $secureSession, 'samesite' => 'Lax', 'path' => '/']);
    session_start();
}

/* ------------------------------------------------------------------ */
/* خروجی امن                                                           */
/* ------------------------------------------------------------------ */

function e(?string $s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function json_out($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/** بدنه JSON درخواست ورودی */
function json_in(): array
{
    $raw = file_get_contents('php://input') ?: '';
    $d = json_decode($raw, true);
    return is_array($d) ? $d : [];
}

/* ------------------------------------------------------------------ */
/* CSRF                                                               */
/* ------------------------------------------------------------------ */

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(?string $token): bool
{
    return is_string($token) && !empty($_SESSION['csrf'])
        && hash_equals($_SESSION['csrf'], $token);
}

function csrf_require(?string $token): void
{
    if (!csrf_check($token)) {
        json_out(['ok' => false, 'error' => 'توکن امنیتی نامعتبر است. صفحه را تازه کنید.'], 419);
    }
}

/* ------------------------------------------------------------------ */
/* تاریخ و اعداد فارسی                                                 */
/* ------------------------------------------------------------------ */

function fa_digits($v): string
{
    $en = ['0','1','2','3','4','5','6','7','8','9'];
    $fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    return str_replace($en, $fa, (string) $v);
}

function en_digits(string $v): string
{
    $fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    $ar = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
    $en = ['0','1','2','3','4','5','6','7','8','9'];
    return str_replace(array_merge($fa, $ar), array_merge($en, $en), $v);
}

/** میلادی → شمسی (الگوریتم بدون وابستگی) */
function gregorian_to_jalali(int $gy, int $gm, int $gd): array
{
    $g_d_m = [0,31,59,90,120,151,181,212,243,273,304,334];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100))
          + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * ((int)($days / 12053)));
    $days %= 12053;
    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }
    return [$jy, $jm, $jd];
}

function jdate(?string $datetime, bool $withTime = true): string
{
    if (!$datetime) return '—';
    $ts = strtotime($datetime);
    if ($ts === false) return '—';
    [$jy, $jm, $jd] = gregorian_to_jalali(
        (int) date('Y', $ts), (int) date('n', $ts), (int) date('j', $ts)
    );
    $months = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور',
               'مهر','آبان','آذر','دی','بهمن','اسفند'];
    $out = fa_digits($jd) . ' ' . $months[$jm - 1] . ' ' . fa_digits($jy);
    if ($withTime) {
        $out .= ' — ' . fa_digits(date('H:i', $ts));
    }
    return $out;
}

function now(): string
{
    return date('Y-m-d H:i:s');
}

/* ------------------------------------------------------------------ */
/* اعتبارسنجی                                                          */
/* ------------------------------------------------------------------ */

function valid_phone(string $p): bool
{
    $d = preg_replace('/\D+/', '', en_digits($p));
    return (bool) preg_match('/^(98|0)?9\d{9}$/', $d)
        || (bool) preg_match('/^0\d{10}$/', $d);
}

function valid_email(string $m): bool
{
    return (bool) filter_var($m, FILTER_VALIDATE_EMAIL);
}

function clean(string $v, int $max = 255): string
{
    $v = trim(preg_replace('/\s+/u', ' ', strip_tags($v)) ?? '');
    return mb_substr($v, 0, $max, 'UTF-8');
}

function clean_multiline(string $v, int $max = 4000): string
{
    $v = trim(strip_tags($v));
    return mb_substr($v, 0, $max, 'UTF-8');
}

function ticket_code(string $prefix, int $id): string
{
    return $prefix . '-' . strtoupper(base_convert((string) time(), 10, 36)) . '-' . str_pad((string) $id, 4, '0', STR_PAD_LEFT);
}

/* ------------------------------------------------------------------ */
/* احراز هویت مدیر                                                    */
/* ------------------------------------------------------------------ */

/** Staff session shared by the full administrator and the restricted CRM sales role. */
function current_staff(): ?array
{
    if (empty($_SESSION['uid'])) return null;
    static $staff = false;
    if ($staff === false) {
        $staff = q_one("SELECT * FROM admin_users WHERE id=? AND is_active=1 AND role IN ('admin','sales')", [$_SESSION['uid']]);
        // An account reset invalidates new staff sessions. Old admin sessions from v25 still work.
        if ($staff && ($staff['role'] === 'sales' || isset($_SESSION['staff_password_hash'])) &&
            !hash_equals($staff['password_hash'], (string)($_SESSION['staff_password_hash'] ?? ''))) $staff = null;
    }
    return $staff ?: null;
}

/** Legacy management and privileged customer media are full-admin only. */
function current_user(): ?array
{
    $user = current_staff();
    return ($user['role'] ?? '') === 'admin' ? $user : null;
}

function require_login(): array
{
    $user = current_staff();
    if (!$user) redirect('login.php');
    if ($user['role'] !== 'admin') {
        header('Cache-Control: private, no-store');
        http_response_code(403);
        exit('این بخش فقط برای مدیر سامانه در دسترس است.');
    }
    return $user;
}

function require_login_api(): array
{
    $user = current_staff();
    if (!$user) json_out(['ok' => false, 'error' => 'دسترسی غیرمجاز'], 401);
    if ($user['role'] !== 'admin') json_out(['ok' => false, 'error' => 'مجوز مدیریت لازم است.'], 403);
    return $user;
}

function login_user(array $user): void
{
    session_regenerate_id(true);
    unset($_SESSION['csrf']);
    $_SESSION['uid'] = (int)$user['id'];
    $_SESSION['staff_password_hash'] = $user['password_hash'];
    q('UPDATE admin_users SET last_login_at = ? WHERE id = ?', [now(), $user['id']]);
}

function logout_user(): void
{
    $_SESSION = [];
    session_destroy();
}

/* ------------------------------------------------------------------ */
/* لاگ فعالیت                                                          */
/* ------------------------------------------------------------------ */

function log_activity(string $actor, string $action, string $detail = ''): void
{
    try {
        q('INSERT INTO activity_log (actor, action, detail, created_at) VALUES (?,?,?,?)',
          [mb_substr($actor, 0, 100), mb_substr($action, 0, 80), mb_substr($detail, 0, 400), now()]);
    } catch (Throwable $e) { /* بی‌صدا */ }
}

/* ------------------------------------------------------------------ */
/* تنظیمات و محتوا                                                     */
/* ------------------------------------------------------------------ */

function settings(bool $reload = false): array
{
    static $s = null;
    if ($reload || $s === null) {
        $s = [];
        foreach (q_all('SELECT skey, svalue FROM site_settings') as $r) {
            $s[$r['skey']] = $r['svalue'];
        }
    }
    return $s;
}

function setting(string $key, string $default = ''): string
{
    $s = settings();
    return $s[$key] ?? $default;
}

function set_setting(string $key, string $value, string $group = 'general', string $label = ''): void
{
    $exists = q_val('SELECT id FROM site_settings WHERE skey = ?', [$key]);
    if ($exists) {
        q('UPDATE site_settings SET svalue = ?, updated_at = ? WHERE skey = ?', [$value, now(), $key]);
    } else {
        q('INSERT INTO site_settings (skey, svalue, sgroup, slabel, updated_at) VALUES (?,?,?,?,?)',
          [$key, $value, $group !== '' ? $group : 'general', $label !== '' ? $label : $key, now()]);
    }
    settings(true);
}


/** .htaccess امن و سازگار برای پوشه‌های آپلود (بدون دستورهایی که روی بعضی هاست‌ها خطای ۵۰۰ می‌دهند) */
function gf_upload_htaccess(string $dir): void
{
    $rules = "Options -Indexes\n"
        . "<IfModule mod_authz_core.c>\n  <FilesMatch \"\\.(php|phtml|php5|phar|cgi|pl)$\">\n    Require all denied\n  </FilesMatch>\n</IfModule>\n"
        . "<IfModule !mod_authz_core.c>\n  <FilesMatch \"\\.(php|phtml|php5|phar|cgi|pl)$\">\n    Order allow,deny\n    Deny from all\n  </FilesMatch>\n</IfModule>\n"
        . "<IfModule mod_headers.c>\n  Header set X-Content-Type-Options \"nosniff\"\n</IfModule>\n"
        . "<IfModule mod_mime.c>\n  AddType audio/mpeg .mp3\n  AddType audio/mp4 .m4a\n  AddType audio/ogg .ogg\n  AddType audio/wav .wav\n</IfModule>\n";
    @file_put_contents($dir . '/.htaccess', $rules);
    if (!is_file($dir . '/index.html')) @file_put_contents($dir . '/index.html', '');
}

/** مسیر مجاز تصویر بک‌گراند سایت (assets یا آپلود ادمین) */
function is_bg_image_path(string $p): bool
{
    return (bool) preg_match('#^(assets/img|uploads/bg)/[A-Za-z0-9_./-]+\.(webp|png|jpg|jpeg)$#i', $p);
}

function contents(): array
{
    static $c = null;
    if ($c === null) {
        $c = [];
        foreach (q_all('SELECT * FROM site_content ORDER BY sort_order ASC') as $r) {
            $r['extra'] = json_decode((string) $r['extra'], true) ?: [];
            $c[$r['section']] = $r;
        }
    }
    return $c;
}

function section(string $name): array
{
    $c = contents();
    return $c[$name] ?? ['title' => '', 'subtitle' => '', 'body' => '', 'extra' => [], 'is_visible' => 1];
}

function active_logo(): ?string
{
    static $l = false;
    if ($l === false) {
        $l = q_val("SELECT data_url FROM brand_assets WHERE kind = 'logo' AND is_active = 1 ORDER BY id DESC", [], null);
    }
    return $l ?: null;
}

/* ------------------------------------------------------------------ */
/* آیکون‌های SVG                                                       */
/* ------------------------------------------------------------------ */

function icon(string $name, int $size = 22, string $class = ''): string
{
    static $p = null;
    if ($p === null) {
        $p = [
            'shield'  => 'M12 2.5 4 5.6v5.9c0 4.7 3.2 9.1 8 10.4 4.8-1.3 8-5.7 8-10.4V5.6L12 2.5Zm0 4.1a2.6 2.6 0 1 1 0 5.2 2.6 2.6 0 0 1 0-5.2Zm-4 9.1c.9-1.6 2.3-2.6 4-2.6s3.1 1 4 2.6c-1 1-2.4 1.8-4 2.4-1.6-.6-3-1.4-4-2.4Z',
            'clock'   => 'M12 2a10 10 0 1 1 0 20 10 10 0 0 1 0-20Zm1 4.8h-2v5.6l4.2 2.5 1-1.7-3.2-1.9V6.8Z',
            'gear'    => 'M12 8.4a3.6 3.6 0 1 0 0 7.2 3.6 3.6 0 0 0 0-7.2Zm9 3.6a8.9 8.9 0 0 0-.14-1.5l2-1.55-2-3.46-2.37.95a9 9 0 0 0-2.6-1.5L15.5 2.5h-4l-.39 2.44a9 9 0 0 0-2.6 1.5L6.14 5.49l-2 3.46 2 1.55a9.2 9.2 0 0 0 0 3l-2 1.55 2 3.46 2.37-.95a9 9 0 0 0 2.6 1.5l.39 2.44h4l.39-2.44a9 9 0 0 0 2.6-1.5l2.37.95 2-3.46-2-1.55c.09-.49.14-1 .14-1.5Z',
            'wallet'  => 'M3 6.5A2.5 2.5 0 0 1 5.5 4H18a1 1 0 0 1 1 1v1.5H6a1 1 0 0 0 0 2h13v9A2.5 2.5 0 0 1 16.5 20h-11A2.5 2.5 0 0 1 3 17.5v-11Zm13 5.5h2v2h-2a1 1 0 0 1 0-2Z',
            'chip'    => 'M9 3h2v2.2h2V3h2v2.2h1.5A2.5 2.5 0 0 1 19 7.7V9h2.2v2H19v2h2.2v2H19v1.3a2.5 2.5 0 0 1-2.5 2.5H15V21h-2v-2.2h-2V21H9v-2.2H7.5A2.5 2.5 0 0 1 5 16.3V15H2.8v-2H5v-2H2.8v-2H5V9h2.2V7.7A2.5 2.5 0 0 1 9.7 5.2H9V3Zm.7 4.7v8.6h4.6V7.7H9.7Z',
            'wrench'  => 'M20.3 4.3a5.5 5.5 0 0 1-7.2 6.9L6 18.3a2.2 2.2 0 0 1-3.1-3.1l7.1-7.1a5.5 5.5 0 0 1 6.9-7.2l-3 3 2.6 2.6 3-3a5.5 5.5 0 0 1-.2 1.1Z',
            'install' => 'M12 2 3 7v10l9 5 9-5V7l-9-5Zm0 2.3 6.5 3.6-6.5 3.6L5.5 7.9 12 4.3ZM5 9.6l6 3.3v6.6l-6-3.3V9.6Zm8 9.9v-6.6l6-3.3v6.6l-6 3.3Z',
            'repair'  => 'M17.8 3.4a4.2 4.2 0 0 0-5.6 5.6L6 15.2 8.8 18l6.2-6.2a4.2 4.2 0 0 0 5.6-5.6l-2.7 2.7-2.3-.6-.6-2.3 2.8-2.6Z',
            'board'   => 'M3 5.5A1.5 1.5 0 0 1 4.5 4h15A1.5 1.5 0 0 1 21 5.5v9a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 14.5v-9Zm2 2v5h5v-5H5Zm7 0v5h7v-5h-7Zm-7 7v1h5v-1H5Zm7 0v1h7v-1h-7Z',
            'part'    => 'M12 2a4 4 0 0 1 4 4v1.1a3 3 0 0 1 2 2.8V17a3 3 0 0 1-3 3h-6a3 3 0 0 1-3-3V9.9a3 3 0 0 1 2-2.8V6a4 4 0 0 1 4-4Zm0 2a2 2 0 0 0-2 2v2h4V6a2 2 0 0 0-2-2Z',
            'inspect' => 'M14.7 2.3a1.5 1.5 0 0 1 2.1 0l4.9 4.9a1.5 1.5 0 0 1 0 2.1l-1.6 1.6-7-7 1.6-1.6ZM11.4 5.6l7 7L11 20H4v-7l7.4-7.4Z',
            'phone'   => 'M6.6 3h3.1l1.6 4-2 1.4a11 11 0 0 0 5.3 5.3l1.4-2 4 1.6v3.1A2.6 2.6 0 0 1 17.4 19 13.4 13.4 0 0 1 4.9 6.6 2.6 2.6 0 0 1 6.6 3Z',
            'mail'    => 'M3 5.5h18A1.5 1.5 0 0 1 22.5 7v10a1.5 1.5 0 0 1-1.5 1.5H3A1.5 1.5 0 0 1 1.5 17V7A1.5 1.5 0 0 1 3 5.5Zm9 7.3L19.2 7H4.8L12 12.8ZM4 9.4V17h16V9.4l-8 5.6-8-5.6Z',
            'pin'     => 'M12 2a7.5 7.5 0 0 1 7.5 7.5c0 5.2-6.3 11.9-6.6 12.2a1.3 1.3 0 0 1-1.8 0C10.8 21.4 4.5 14.7 4.5 9.5A7.5 7.5 0 0 1 12 2Zm0 5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Z',
            'arrow'   => 'M13.2 5.4 20.6 12l-7.4 6.6-1.4-1.5 4.4-4.1H3.5v-2h12.7l-4.4-4.1 1.4-1.5Z',
            'check'   => 'M9.6 16.2 5.4 12l-1.5 1.5 5.7 5.7L20.1 8.7 18.6 7.2 9.6 16.2Z',
            'sparkle' => 'M12 2l1.9 5.6L19.5 9l-4.4 3.3 1.4 5.7L12 15l-4.5 3 1.4-5.7L4.5 9l5.6-1.4L12 2Z',
            'life'    => 'M12 21s-8.5-4.7-8.5-10A4.9 4.9 0 0 1 12 7.6 4.9 4.9 0 0 1 20.5 11c0 5.3-8.5 10-8.5 10Z',
            'send'    => 'M2.5 21 22 12 2.5 3l.1 7L16 12 2.6 14l-.1 7Z',
            'chevron' => 'M9.3 5.3 8 6.6l5.4 5.4L8 17.4l1.3 1.3 6.7-6.7L9.3 5.3Z',
            'menu'    => 'M3 6h18v2H3V6Zm0 5h18v2H3v-2Zm0 5h18v2H3v-2Z',
            'close'   => 'M18.3 5.7 12 12l6.3 6.3-1.4 1.4L10.6 13.4 5.7 18.3 4.3 16.9 10.6 12 4.3 6.4 5.7 5l4.9 4.9 6.3-6.3 1.4 1.3Z',
            'whatsapp'=> 'M12 2a9.9 9.9 0 0 0-8.5 15.1L2 22l5-1.5A9.9 9.9 0 1 0 12 2Zm5.8 14.1c-.3.7-1.4 1.3-2 1.4-.5.1-1.2.1-1.9-.1-.4-.1-1-.3-1.7-.6-3-1.3-4.9-4.3-5-4.5-.2-.2-1.2-1.6-1.2-3s.7-2.1 1-2.4c.2-.3.5-.4.7-.4h.5c.2 0 .4 0 .6.5l.8 2c.1.2.2.4 0 .6l-.4.6c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.1 1 2.1 1.3 2.4 1.5.2.1.4 0 .6-.2l.7-.9c.2-.2.4-.2.6-.1l2 1c.2.1.4.2.4.3.1.2.1.7-.1 1.4Z',
            'telegram'=> 'M21.9 4.3 2.9 11.6c-.9.3-.9 1.5 0 1.8l4.6 1.5 1.8 5.3c.3.8 1.3 1 1.9.3l2.6-3.1 4.6 3.4c.7.5 1.7.1 1.9-.7l3.2-14.6c.2-.9-.7-1.6-1.6-1.2Zm-3.3 4.6-8 7.4-.4 3.2-.9-3.7 8.3-6.6c.3-.3 0-.5-.4-.3Z',
            'instagram'=> 'M12 2.2c3.2 0 3.6 0 4.9.1 1.2.1 1.8.2 2.2.4.6.2 1 .5 1.4.9.4.4.7.8.9 1.4.2.4.4 1 .4 2.2.1 1.3.1 1.7.1 4.9s0 3.6-.1 4.9c-.1 1.2-.2 1.8-.4 2.2-.2.6-.5 1-.9 1.4-.4.4-.8.7-1.4.9-.4.2-1 .4-2.2.4-1.3.1-1.7.1-4.9.1s-3.6 0-4.9-.1c-1.2-.1-1.8-.2-2.2-.4-.6-.2-1-.5-1.4-.9-.4-.4-.7-.8-.9-1.4-.2-.4-.4-1-.4-2.2C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.9c.1-1.2.2-1.8.4-2.2.2-.6.5-1 .9-1.4.4-.4.8-.7 1.4-.9.4-.2 1-.4 2.2-.4C8.4 2.2 8.8 2.2 12 2.2Zm0 1.8c-3.1 0-3.5 0-4.8.1-1.1 0-1.7.2-2.1.3-.5.2-.9.4-1.2.7-.3.3-.6.7-.7 1.2-.1.4-.3 1-.3 2.1-.1 1.3-.1 1.7-.1 4.8s0 3.5.1 4.8c0 1.1.2 1.7.3 2.1.2.5.4.9.7 1.2.3.3.7.6 1.2.7.4.1 1 .3 2.1.3 1.3.1 1.7.1 4.8.1s3.5 0 4.8-.1c1.1 0 1.7-.2 2.1-.3.5-.2.9-.4 1.2-.7.3-.3.6-.7.7-1.2.1-.4.3-1 .3-2.1.1-1.3.1-1.7.1-4.8s0-3.5-.1-4.8c0-1.1-.2-1.7-.3-2.1a3.2 3.2 0 0 0-.7-1.2 3.2 3.2 0 0 0-1.2-.7c-.4-.1-1-.3-2.1-.3-1.3-.1-1.7-.1-4.8-.1Zm0 3.1a5 5 0 1 1 0 10 5 5 0 0 1 0-10Zm0 1.8a3.2 3.2 0 1 0 0 6.4 3.2 3.2 0 0 0 0-6.4Zm5.3-3.3a1.2 1.2 0 1 1 0 2.4 1.2 1.2 0 0 1 0-2.4Z',
            'elevator'=> 'M4 2h16a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1Zm3 2.5v15l5-7.5-5-7.5Zm10 0-5 7.5 5 7.5v-15Z',
            'gauge'   => 'M12 3a9 9 0 0 0-9 9h2a7 7 0 1 1 14 0h2a9 9 0 0 0-9-9Zm0 4a5 5 0 0 0-5 5h2a3 3 0 1 1 6 0h2a5 5 0 0 0-5-5Zm-1 8h2v5h-2v-5Z',
            'layers'  => 'M12 2 2 7.5 12 13l10-5.5L12 2Zm0 12.8L5.2 10.9 2 13l10 5.5L22 13l-3.2-2.1L12 14.8Z',
            'star'    => 'm12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5 6.1 20.6l1.2-6.5L2.5 9.5l6.6-.9 2.9-6Z',
            'users'   => 'M8.5 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm7.5.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM2 19.5c0-3 2.9-5 6.5-5s6.5 2 6.5 5V21H2v-1.5Zm13 1.5V19c0-1.6-.7-3-1.9-4 4 .2 7.4 2 7.4 4.5V21H15Z',
            'trash'   => 'M9 3h6l1 2h4v2H4V5h4l1-2ZM6 9h12l-1 12H7L6 9Z',
        ];
    }
    $d = $p[$name] ?? $p['sparkle'];
    return '<svg class="' . e($class) . '" width="' . $size . '" height="' . $size
         . '" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="' . $d . '"/></svg>';
}

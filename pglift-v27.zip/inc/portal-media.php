<?php
declare(strict_types=1);

require_once __DIR__ . '/portal.php';

const PORTAL_MEDIA_MIMES = ['application/pdf' => 'pdf', 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];

/** The joins are fixed, never identifiers supplied by the request. */
function portal_media_owner_join(): string
{
    return "LEFT JOIN customer_contracts c ON m.owner_type='contract' AND c.id=m.owner_id
        LEFT JOIN customer_service_visits v ON m.owner_type='service' AND v.id=m.owner_id
        LEFT JOIN customer_installation_stages s ON m.owner_type='stage' AND s.id=m.owner_id
        LEFT JOIN customer_installation_projects p ON p.id=s.project_id";
}

function portal_media_list(string $type, array $ids, int $customerId, bool $admin = false): array
{
    if (!$ids || !portal_ready() || !isset(PORTAL_MEDIA_KINDS[$type])) return [];
    $params = implode(',', array_fill(0, count($ids), '?'));
    $visibility = $admin ? '' : ' AND m.is_published=1';
    return q_all("SELECT m.id, m.owner_id, m.kind, m.caption, m.original_name, m.mime, m.byte_size, m.is_published
        FROM customer_portal_media m ".portal_media_owner_join()."
        WHERE m.owner_type=? AND m.owner_id IN ($params) AND (c.customer_id=? OR v.customer_id=? OR p.customer_id=?)$visibility ORDER BY m.id",
        [$type, ...$ids, $customerId, $customerId, $customerId]);
}

function portal_media_send(int $id, ?int $customerId, bool $download = false, bool $admin = false): void
{
    portal_private_headers();
    if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true)) {
        header('Allow: GET, HEAD');
        http_response_code(405);
        exit;
    }
    $file = null;
    if ($id && ($admin || $customerId !== null) && portal_ready()) {
        $rule = $admin ? 'COALESCE(c.customer_id,v.customer_id,p.customer_id) IS NOT NULL'
            : 'm.is_published=1 AND (c.customer_id=? OR v.customer_id=? OR p.customer_id=?)';
        $file = q_one('SELECT m.original_name, m.mime, m.payload FROM customer_portal_media m '.portal_media_owner_join().
            " WHERE m.id=? AND $rule", $admin ? [$id] : [$id, $customerId, $customerId, $customerId]);
    }
    if (!$file || !isset(PORTAL_MEDIA_MIMES[$file['mime']])) {
        http_response_code(404);
        exit;
    }
    session_write_close();
    $extension = PORTAL_MEDIA_MIMES[$file['mime']];
    $name = pathinfo($file['original_name'], PATHINFO_FILENAME) ?: 'attachment';
    header('Cross-Origin-Resource-Policy: same-origin');
    header('Content-Type: '.$file['mime']);
    header('Content-Disposition: '.($download ? 'attachment' : 'inline').'; filename="attachment.'.$extension.'"; filename*=UTF-8\'\''.rawurlencode($name.'.'.$extension));
    header('Content-Length: '.strlen($file['payload']));
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'HEAD') echo $file['payload'];
    exit;
}

function portal_media_upload(string $type, int $id, string $kind, array $file, string $caption, bool $published): void
{
    if (!isset(PORTAL_MEDIA_KINDS[$type][$kind])) throw new RuntimeException('نوع پیوست نامعتبر است.');
    $pdf = $kind === 'pdf';
    $limit = $pdf ? 8 : 4;
    $path = $file['tmp_name'] ?? null;
    if (($file['error'] ?? null) !== UPLOAD_ERR_OK || !is_string($path) || !is_uploaded_file($path)) {
        throw new RuntimeException('فایل نرسیده یا بارگذاری ناموفق بوده است. محدودیت حجم سرور را بررسی کنید.');
    }
    $size = filesize($path);
    if (!$size || $size > $limit * 1024 * 1024) throw new RuntimeException('حداکثر حجم این پیوست '.fa_digits($limit).' مگابایت است.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($path);
    if ($pdf) {
        $signature = file_get_contents($path, false, null, 0, 10);
        $end = file_get_contents($path, false, null, max(0, $size - 4096));
        if ($mime !== 'application/pdf' || $signature === false || !preg_match('/^%PDF-[12]\.[0-9][\r\n]/', $signature)
            || $end === false || !str_contains($end, '%%EOF')) {
            throw new RuntimeException('فایل PDF معتبر انتخاب کنید.');
        }
    } else {
        $info = @getimagesize($path);
        if (!$info || $mime === 'application/pdf' || !isset(PORTAL_MEDIA_MIMES[$mime])
            || $info['mime'] !== $mime || max($info[0], $info[1]) > 5000) {
            throw new RuntimeException('تصویر JPG، PNG یا WebP با حداکثر عرض و ارتفاع ۵۰۰۰ پیکسل انتخاب کنید.');
        }
    }
    $data = file_get_contents($path);
    if ($data === false || strlen($data) !== $size) throw new RuntimeException('خواندن پیوست ناموفق بود.');
    $name = clean(basename(str_replace('\\', '/', (string)($file['name'] ?? ''))), 220) ?: 'attachment.'.PORTAL_MEDIA_MIMES[$mime];
    $st = db()->prepare('INSERT INTO customer_portal_media (owner_type, owner_id, kind, caption, original_name, mime, byte_size, payload, is_published, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)');
    foreach ([$type, $id, $kind, $caption, $name, $mime, $size, $data, $published ? 1 : 0, now()] as $k => $value) {
        $st->bindValue($k + 1, $value, $k === 7 ? PDO::PARAM_LOB : (is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR));
    }
    $st->execute();
}

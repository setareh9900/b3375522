<?php
declare(strict_types=1);
require_once __DIR__.'/prospect-content.php';

function prospect_video_query(string $kind, string $filter): array
{
    [$gate,$params] = prospect_feed_filter([$kind],0);
    $from = ' FROM prospect_content c LEFT JOIN prospect_campaigns s ON s.slot=c.campaign_slot
        LEFT JOIN prospect_video_details d ON d.content_id=c.id';
    if ($filter !== '' && in_array($kind,['guide_video','portfolio_video'],true)) {
        $gate .= $kind === 'guide_video' ? ' AND d.placement=?' : ' AND d.portfolio_group=?';
        $params[] = $filter;
    }
    return [$from.' WHERE '.$gate,$params];
}

/** Media IDs only. Public playback is always checked separately by the media route. */
function prospect_video_items(string $kind, int $limit, string $filter = '', int $offset = 0): array
{
    if (!isset(prospect_guidance_video_types()[$kind]) || !prospect_guidance_ready()) return [];
    [$where,$params] = prospect_video_query($kind,$filter);
    $limit = max(1,min(24,$limit));
    $offset = max(0,$offset);
    return q_all("SELECT c.id,c.title,c.kind,c.summary,c.image_alt,c.publish_at,d.placement,d.portfolio_group,d.company_name,d.equipment_brand,d.building_name,
        (SELECT id FROM prospect_content_media WHERE content_id=c.id AND kind='cover' ORDER BY id DESC LIMIT 1) AS cover_id,
        (SELECT id FROM prospect_content_media WHERE content_id=c.id AND kind='video' ORDER BY id DESC LIMIT 1) AS video_id
        $where ORDER BY c.is_featured DESC,c.publish_at DESC,c.id DESC LIMIT $limit OFFSET $offset",$params);
}

function prospect_video_count(string $kind, string $filter = ''): int
{
    if (!isset(prospect_guidance_video_types()[$kind]) || !prospect_guidance_ready()) return 0;
    [$where,$params] = prospect_video_query($kind,$filter);
    return (int)q_val('SELECT COUNT(*)'.$where,$params);
}

function prospect_video_facts(array $item): array
{
    return array_filter(['شرکت همکار'=>$item['company_name'] ?? '', 'برند تجهیزات'=>$item['equipment_brand'] ?? '',
        'ساختمان یا پروژه'=>$item['building_name'] ?? ''], static fn($value)=>$value !== '');
}

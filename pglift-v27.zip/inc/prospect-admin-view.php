<?php
declare(strict_types=1);
require_once __DIR__.'/prospect-forms.php';
require_once __DIR__.'/prospect-crm.php';

function prospect_admin_start(array $staff, string $title, string $area = 'leads'): void
{
    $full = $staff['role'] === 'admin';
    ?>
<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">
<title><?=e($title)?> | <?=e(prospect_brand())?></title>
<link rel="stylesheet" href="../assets/css/prospect.css?v=<?=filemtime(__DIR__.'/../assets/css/prospect.css')?>">
<link rel="stylesheet" href="../assets/css/prospect-admin.css?v=<?=filemtime(__DIR__.'/../assets/css/prospect-admin.css')?>">
<?php if ($area === 'links' || $area === 'content'): ?><script defer src="../assets/js/prospect.js?v=<?=filemtime(__DIR__.'/../assets/js/prospect.js')?>"></script><?php endif ?>
</head><body class="ps-admin"><a href="#main" class="ps-skip">رفتن به محتوا</a>
<header class="pc-top"><div class="ps-wrap pc-top-inner">
    <a href="prospects.php" class="ps-brand"><span class="ps-mark"><?=prospect_logo()?></span><span><b><?=e(prospect_brand())?></b><small>میز کار ارتباط پیش از خرید</small></span></a>
    <div class="pc-user"><small><?=e($staff['full_name'] ?: $staff['username'])?> · <?=$full ? 'مدیر' : 'نمایندهٔ فروش'?></small><a class="ps-btn ps-secondary" href="logout.php">خروج</a></div>
</div></header>
<div class="ps-wrap">
<?php if ($full): ?>
<nav class="pc-segments" aria-label="گروه‌های مستقل مدیریت">
    <div class="pc-segment current"><small>پیش از خرید</small><a href="prospects.php"<?=$area === 'leads' ? ' aria-current="page"' : ''?>>مخاطبان و مشتریان بالقوه</a></div>
    <div class="pc-segment"><small>پس از خرید</small><a href="customers.php">مشتریان خریدکرده <?=prospect_arrow(14)?></a></div>
</nav>
<?php endif ?>
<nav class="pc-nav" aria-label="مدیریت پرتال معرفی">
    <a href="prospects.php"<?=$area === 'leads' ? ' aria-current="page"' : ''?>>صندوق و سرنخ‌ها</a>
    <?php if ($full): ?>
        <a href="prospect-links.php"<?=$area === 'links' ? ' aria-current="page"' : ''?>>لینک راهنما</a>
        <a href="prospect-content.php"<?=$area === 'content' ? ' aria-current="page"' : ''?>>محتوا و انتشار</a>
        <a href="prospect-team.php"<?=$area === 'team' ? ' aria-current="page"' : ''?>>تیم و وضعیت‌ها</a>
        <a href="index.php">مدیریت اصلی</a>
    <?php endif ?>
    <a href="../prospects/index.php">مشاهده پرتال <?=prospect_arrow(14)?></a>
</nav>
<main class="pc-main" id="main">
    <?php
}

function prospect_admin_end(): void { echo '</main></div></body></html>'; }

function prospect_admin_error(Throwable $ex, string $context): string
{
    if ($ex instanceof ProspectValidation) {
        $code = $ex->getCode();
        http_response_code(in_array($code, [403,404,409], true) ? $code : 422);
        return $ex->getMessage();
    }
    error_log('Prospect '.$context.' failed ('.$ex->getCode().')');
    http_response_code(503);
    return 'عملیات انجام نشد. اتصال، دسترسی‌ها و اطلاعات ورودی را بررسی کنید.';
}

function prospect_flash(string $message): void { $_SESSION['prospect_admin_flash'] = $message; }

function prospect_show_flash(string $error): void
{
    $saved = $_SESSION['prospect_admin_flash'] ?? '';
    unset($_SESSION['prospect_admin_flash']);
    if ($error !== '') prospect_notice($error, true);
    elseif ($saved !== '') prospect_notice($saved);
}

function prospect_admin_pager(string $url, array $params, int $page, int $pages): void
{
    if ($pages <= 1) return;
    ?><nav class="ps-pager" aria-label="صفحه‌بندی">
        <?php if ($page > 1): ?><a class="ps-btn ps-secondary" href="<?=e($url.'?'.http_build_query($params+['page'=>$page-1]))?>">قبلی</a><?php endif ?>
        <span class="pc-page-num"><?=fa_digits($page)?> از <?=fa_digits($pages)?></span>
        <?php if ($page < $pages): ?><a class="ps-btn ps-secondary" href="<?=e($url.'?'.http_build_query($params+['page'=>$page+1]))?>">بعدی</a><?php endif ?>
    </nav><?php
}

function prospect_admin_action(string $action, int $id = 0): void
{
    echo csrf_field(), '<input type="hidden" name="action" value="', e($action), '">';
    if ($id) echo '<input type="hidden" name="id" value="', $id, '">';
}

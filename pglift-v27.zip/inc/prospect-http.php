<?php
declare(strict_types=1);

function prospect_private_headers(): void
{
    header('Cache-Control: private, no-store, max-age=0');
    header('X-Robots-Tag: noindex, nofollow');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
}

function prospect_method(array $allowed): void
{
    if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', $allowed, true)) {
        header('Allow: '.implode(', ', $allowed));
        http_response_code(405);
        exit;
    }
}

function prospect_scalar(array $from, string $key, string $default = ''): string
{
    return is_string($from[$key] ?? null) ? $from[$key] : $default;
}

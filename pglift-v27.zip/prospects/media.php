<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-media.php';
prospect_method(['GET','HEAD']);
// Never cache media across a pause, a future schedule, or an admin-only preview.
prospect_private_headers();
$id = prospect_id($_GET['id'] ?? null);
$preview = prospect_scalar($_GET,'preview') === '1';
$row = prospect_media_row($id,$preview);
if (!$row) { http_response_code(404); exit; }
prospect_stream_media($row,$_SERVER['REQUEST_METHOD'] ?? 'GET',$_SERVER['HTTP_RANGE'] ?? '');

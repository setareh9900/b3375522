<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-video-view.php';
prospect_method(['GET','HEAD','POST']);
prospect_private_headers();
$ready = prospect_ready();
$demo = !empty(gf_config()['prospect_demo']);
$error = '';
$result = null;
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    prospect_csrf();
    if (!$ready || $demo) http_response_code(503);
    else {
        try {
            if (!prospect_allow_attempt('track', 16)) {
                http_response_code(429);
                $error = 'تعداد تلاش‌ها زیاد است. کمی بعد دوباره تلاش کنید.';
            } else {
                $result = prospect_track(prospect_scalar($_POST, 'reference'), prospect_scalar($_POST, 'access'));
                if (!$result) {
                    http_response_code(422);
                    $error = 'ترکیب کد و کلید پیگیری معتبر نیست.';
                }
            }
        } catch (PDOException $ex) {
            error_log('Prospect tracking database error ('.$ex->getCode().')');
            http_response_code(503);
            $error = 'پیگیری در حال حاضر ممکن نیست.';
        }
    }
}
prospect_start('پیگیری خصوصی درخواست', '', '', true);
prospect_page_intro('رسید درخواست', 'وضعیت درخواست را ببینید', 'کد و کلید خصوصی همان رسید را وارد کنید. کلید در نشانی صفحه قرار نمی‌گیرد.');
?>
<?php prospect_context_video('tracking'); ?>
<div class="ps-form-layout">
<?php if ($result): ?>
    <section class="ps-panel" role="status"><h2><?=e(prospect_public_states()[$result['public_state']] ?? 'دریافت شد')?></h2>
        <?php prospect_facts(['کد پیگیری'=>$result['reference'], 'موضوع'=>prospect_services()[$result['service']] ?? 'مشاوره', 'تاریخ ثبت'=>prospect_date($result['created_at'])]); ?>
        <a class="ps-link" href="track.php">پیگیری درخواست دیگر <?=prospect_arrow(14)?></a>
    </section>
<?php elseif ($ready): ?>
    <form method="post" class="ps-panel ps-form" action="track.php">
        <?=csrf_field()?><?php if ($error) prospect_notice($error, true); ?>
        <?php if ($demo) prospect_notice('پیگیری خصوصی در پیش‌نمایش غیرفعال است.'); ?>
        <?php prospect_input_field('reference', 'کد پیگیری *', '', 'required maxlength="30" placeholder="P-…" dir="ltr" autocomplete="off"'); ?>
        <?php prospect_input_field('access', 'کلید خصوصی *', '', 'required maxlength="32" dir="ltr" autocomplete="off"', 'password'); ?>
        <button class="ps-btn ps-primary ps-submit" type="submit"<?=$demo ? ' disabled' : ''?>>نمایش وضعیت <?=prospect_arrow()?></button>
    </form>
<?php else: ?><p class="ps-panel">پیگیری آنلاین هنوز فعال نیست.</p><?php endif ?>
<aside class="ps-panel ps-note-panel"><h2>پیگیری جدا از پنل خریداران</h2><p>این صفحه فقط وضعیت درخواست مشاوره را نمایش می‌دهد و دسترسی به پروندهٔ مشتریان خریدکرده نمی‌دهد.</p><a class="ps-link" href="index.php#contact">راه‌های تماس <?=prospect_arrow(14)?></a></aside>
</div>
<?php prospect_end(); ?>

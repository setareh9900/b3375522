<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-video-view.php';
prospect_method(['GET','HEAD']);
$pages = max(1,(int)ceil(prospect_video_count('brand_story')/12));
$page = max(1,min($pages,prospect_id($_GET['page'] ?? null)));
$items = prospect_video_items('brand_story',12,'',($page-1)*12);
prospect_start('استوری‌های برند','', 'ویدیوهای کوتاه و منتشرشده برای آشنایی با برند و فعالیت‌ها.');
prospect_page_intro('ویدیوهای کوتاه معرفی','استوری‌های برند','برای آشنایی با '.prospect_brand().'، استوری را انتخاب کنید و ویدیو را پخش کنید.');
prospect_story_rail($items);
prospect_video_pager($page,$pages);
?>
<div class="ps-actions"><a class="ps-btn ps-secondary" href="portfolio-videos.php">ویدیوهای همکاری و پروژه <?=prospect_arrow(14)?></a></div>
<?php prospect_end(); ?>

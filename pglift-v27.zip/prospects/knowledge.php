<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-editorial-view.php';
prospect_method(['GET','HEAD']);
$libraryKinds = ['tip','article','short_video','weekly_video'];
if (prospect_guidance_ready()) $libraryKinds[] = 'guide_video';
$types = array_intersect_key(prospect_content_types(),array_fill_keys($libraryKinds,true));
$which = prospect_scalar($_GET,'kind');
$kinds = isset($types[$which]) ? [$which] : array_keys($types);
$categories = prospect_public_categories($kinds);
$category = prospect_id($_GET['category'] ?? null);
if (!isset($categories[$category])) $category = 0;
$total = prospect_public_count($kinds,$category);
$pages = max(1,(int)ceil($total/12));
$page = max(1,min($pages,prospect_id($_GET['page'] ?? null)));
$rows = prospect_public_items($kinds,12,($page-1)*12,$category);
$url = static fn(int $n): string => 'knowledge.php?'.http_build_query(array_filter(['kind'=>$which, 'category'=>$category,'page'=>$n]));
prospect_start('دانش‌نامه آسانسور','learn','پاسخ به پرسش‌های خرید، یادداشت‌های فنی، ویدیوهای کوتاه و آموزش هفتگی آسانسور.');
prospect_page_intro('آموزش کاربردی','دانش‌نامهٔ پیش از خرید','نکته‌ها، مقایسه‌ها و ویدیوهایی برای اینکه پیش از بازدید و قرارداد بدانید چه بپرسید.');
?>
<form action="knowledge.php" method="get" class="ps-panel ps-form ps-filter" aria-label="فیلتر دانش‌نامه"><div class="ps-fields">
    <?php prospect_select_field('kind','نوع محتوا',$types,$which,false,'همه'); prospect_select_field('category','دسته',$categories,$category,false,'همه'); ?>
</div><div class="ps-actions"><button class="ps-btn ps-primary" type="submit">نمایش مطالب</button><a class="ps-btn ps-secondary" href="#faq">پرسش‌های رایج</a></div></form>
<section class="ps-learning-posts" aria-label="مطالب آموزشی">
<?php if ($rows) prospect_card_list($rows); else echo '<p class="ps-empty">هنوز مطلب منتشرشده‌ای برای این فیلتر ثبت نشده است. پرسش‌های رایج را در ادامه بخوانید.</p>'; ?>
<?php if ($pages > 1): ?><nav class="ps-pager" aria-label="صفحه‌بندی مطالب"><?php if ($page > 1): ?><a class="ps-btn ps-secondary" href="<?=e($url($page-1))?>">صفحهٔ قبل</a><?php endif ?><span><?=fa_digits($page)?> از <?=fa_digits($pages)?></span><?php if ($page < $pages): ?><a class="ps-btn ps-secondary" href="<?=e($url($page+1))?>">صفحهٔ بعد</a><?php endif ?></nav><?php endif ?>
</section>
<section id="faq" class="ps-section" aria-labelledby="faq-heading"><?php prospect_section('faq-heading','پاسخ پیش از تصمیم','پرسش‌های رایج خرید'); prospect_faq_view(); ?></section>
<section class="ps-section ps-callout"><div><h2>پرسش مخصوص ساختمان خود دارید؟</h2><p>برای بررسی شرایط نصب، درخواست مشاوره ثبت کنید.</p></div><a class="ps-btn ps-primary" href="request-consultation.php">درخواست مشاوره <?=prospect_arrow()?></a></section>
<?php prospect_end(); ?>

<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-video-view.php';
prospect_method(['GET','HEAD']);
$groups = [''=>'همهٔ ویدیوها'] + prospect_portfolio_groups();
$filter = prospect_scalar($_GET,'group');
if (!isset($groups[$filter])) $filter = '';
$pages = max(1,(int)ceil(prospect_video_count('portfolio_video',$filter)/12));
$page = max(1,min($pages,prospect_id($_GET['page'] ?? null)));
$items = prospect_video_items('portfolio_video',12,$filter,($page-1)*12);
prospect_start('ویدیوهای همکاری و پروژه','','ویدیوهای مستند شرکت‌های همکار، برند تجهیزات و ساختمان‌های تکمیل‌شده.');
prospect_page_intro('ویترین ویدیویی','همکاری‌ها و پروژه‌ها','ویدیوهای تأییدشده دربارهٔ شرکت‌های همکار، برندهای استفاده‌شده در پروژه و ساختمان‌های تکمیل‌شده.');
?>
<nav class="ps-video-tabs" aria-label="دسته‌بندی ویدیوها">
    <?php foreach ($groups as $key=>$label): ?><a href="portfolio-videos.php<?= $key === '' ? '' : '?group='.e($key) ?>"<?= $key === $filter ? ' aria-current="page"' : ''?>><?=e($label)?></a><?php endforeach ?>
</nav>
<?php prospect_portfolio_cards($items); prospect_video_pager($page,$pages,$filter); ?>
<div class="ps-actions"><a class="ps-btn ps-secondary" href="showcase.php">دیدن پروندهٔ نمونه‌کارها <?=prospect_arrow(14)?></a><a class="ps-btn ps-primary" href="request-consultation.php">مشاوره دربارهٔ ساختمان شما <?=prospect_arrow(14)?></a></div>
<?php prospect_end(); ?>

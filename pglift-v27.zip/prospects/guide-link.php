<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-http.php';
require_once __DIR__.'/../inc/prospect-links.php';
prospect_method(['GET','HEAD']);
prospect_private_headers();
if (prospect_guide_link_active(prospect_scalar($_GET,'t'))) {
    // This path neither creates a PHP session nor passes the token to the guide.
    header('Location: index.php', true, 302);
    exit;
}
require_once __DIR__.'/../inc/prospect-view.php';
http_response_code(404);
prospect_start('لینک راهنما فعال نیست','', '', true);
prospect_page_intro('مرکز معرفی و مشاوره','این لینک راهنمایی فعال نیست.','می‌توانید از مسیر عمومی سایت وارد مرکز راهنما شوید.');
?>
<a class="ps-btn ps-primary" href="index.php">باز کردن پرتال عمومی راهنما <?=prospect_arrow()?></a>
<?php prospect_end(); ?>

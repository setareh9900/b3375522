<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-video-view.php';
prospect_method(['GET','HEAD']);
$ready = prospect_ready();
$guidance = prospect_guidance_ready();
$stories = prospect_video_items('brand_story',8);
$portfolio = prospect_video_items('portfolio_video',3);
$demo = !empty(gf_config()['prospect_demo']);
$company = prospect_public_items(['company'], 1)[0] ?? null;
$learning = prospect_public_items(['tip','article','short_video'], 3);
$weekly = prospect_public_items(['weekly_video'], 2);
$projects = prospect_public_items(['project'], 3);
$trust = prospect_public_items(['trust','feedback','certificate'], 3);
$appreciation = prospect_public_items(['appreciation'], 1)[0] ?? null;
$stageHighlights = [];
if ($ready) foreach (prospect_campaigns() as $stage) {
    $item = prospect_public_items([], 1, 0, 0, (int)$stage['slot'])[0] ?? null;
    if ($item) $stageHighlights[] = $item;
}
[$contacts,$office] = prospect_contact_channels();
$title = gf_is_configured() ? trim(setting('prospect.seo_title')) : '';
$seo = gf_is_configured() ? trim(setting('prospect.seo_description')) : '';
prospect_start($title ?: 'مرکز معرفی، مشاوره و انتخاب آسانسور', 'home', $seo ?: 'انواع آسانسور، پرسش‌های پیش از خرید و راهنمای انتخاب را بررسی کنید و درخواست مشاورهٔ فنی بفرستید.');
?>
<section class="ps-hero" aria-labelledby="hero-title">
    <div class="ps-hero-text">
        <span class="ps-kicker">راهنمای خرید و مشاورهٔ فنی</span>
        <h1 id="hero-title">آسانسور مناسب،<br><em>برای ساختمان شما</em></h1>
        <p>از شناخت سیستم‌ها تا بررسی شرایط نصب. گزینه‌ها و پرسش‌های فنی را قبل از خرید مرور کنید و برای بررسی ساختمان خود مشاوره بگیرید.</p>
        <div class="ps-actions"><a class="ps-btn ps-primary" href="request-consultation.php">درخواست مشاوره <?=prospect_arrow()?></a><a class="ps-btn ps-secondary" href="elevator-types.php">دیدن انواع آسانسور</a></div>
    </div>
    <figure class="ps-hero-art">
        <img src="../assets/img/prospects/elevator-1200.webp" srcset="../assets/img/prospects/elevator-640.webp 640w, ../assets/img/prospects/elevator-1200.webp 1200w" sizes="(min-width:760px) 570px, 92vw" width="1200" height="805" alt="طرح مفهومی ورودی آسانسور با پوشش برنزی" fetchpriority="high" decoding="async">
        <figcaption>تصویر مفهومی · نمونهٔ پروژه نیست</figcaption>
    </figure>
</section>
<nav class="ps-path" aria-label="مسیر پیشنهادی"><a href="#elevator-types"><span>۰۱</span> شناخت سیستم‌ها</a><a href="elevator-selection.php"><span>۰۲</span> راهنمای انتخاب</a><a href="request-consultation.php"><span>۰۳</span> مشاورهٔ فنی</a></nav>

<?php if ($guidance): ?>
<section class="ps-section ps-stories" aria-labelledby="stories-heading">
    <?php prospect_section('stories-heading','آشنایی با برند','استوری‌های برند','brand-stories.php','همهٔ استوری‌ها'); prospect_story_rail($stories); ?>
</section>
<?php endif ?>
<section class="ps-section" id="introduction" aria-labelledby="introduction-heading">
    <?php prospect_section('introduction-heading', 'معرفی مرکز', $company ? $company['title'] : 'معرفی و بررسی پیش از خرید'); ?>
    <div class="ps-intro-grid">
        <article class="ps-panel"><h3><?=e(prospect_brand())?></h3>
            <p><?=e($company ? $company['summary'] : 'اینجا می‌توانید دربارهٔ انواع سامانه‌ها، آماده‌سازی محل، نصب و نگهداری پیش از خرید مطالعه کنید. برای بررسی شرایط پروژهٔ خود، درخواست بازدید یا مشاوره ثبت کنید.')?></p>
            <?php if ($company): ?><a class="ps-link" href="content.php?id=<?=(int)$company['id']?>">معرفی و خدمات <?=prospect_arrow(14)?></a><?php endif ?>
        </article>
        <article class="ps-panel ps-note-panel"><h3 class="ps-panel-title"><?=icon('inspect',20)?> بررسی فنی از کجا شروع می‌شود؟</h3><p>کاربری و مسیر حرکت، فضای نصب و زیرساخت برق را مشخص کنید. انتخاب نهایی تجهیزات و ظرفیت به بازدید و بررسی حرفه‌ای نیاز دارد.</p><a href="elevator-selection.php" class="ps-link">شروع راهنمای انتخاب <?=prospect_arrow(14)?></a></article>
    </div>
    <?php prospect_context_video('intro'); ?>
</section>
<section class="ps-section" id="elevator-types" aria-labelledby="types-heading">
    <?php prospect_section('types-heading','مقایسهٔ سامانه‌ها','انواع آسانسور','elevator-types.php','همهٔ انواع'); prospect_type_cards(); ?>
    <p class="ps-caption">تصاویر کارت‌ها مرجع آموزشی‌اند؛ نوع، ظرفیت و تجهیزات نهایی هر پروژه پس از بررسی تعیین می‌شود.</p>
</section>
<section class="ps-section" aria-labelledby="education-heading">
    <?php prospect_section('education-heading','دانش‌نامه پیش از خرید','یادداشت‌های فنی و ویدیو','knowledge.php','ورود به دانش‌نامه'); ?>
    <?php if (prospect_video_count('guide_video')): ?><a href="knowledge.php?kind=guide_video" class="ps-link ps-context-library">راهنماهای ویدیویی بخش‌ها <?=prospect_arrow(14)?></a><?php endif ?>
    <?php if ($weekly): ?><h3 class="ps-subhead">ویدیوی هفته</h3><?php prospect_card_list($weekly); ?><?php endif ?>
    <?php if ($learning): ?><div class="ps-learning-posts"><?php prospect_card_list($learning); ?></div>
    <?php else: ?><div class="ps-panel"><h3>نکتهٔ فنی: فقط تعداد طبقات را مقایسه نکنید</h3><p>تعداد توقف و ارتفاع واقعی حرکت یکسان نیستند. برای مقایسهٔ پیشنهادها، نقشهٔ ساختمان و الگوی رفت‌وآمد را هم آماده کنید.</p><a class="ps-link" href="knowledge.php#faq">پرسش‌های رایج پیش از خرید <?=prospect_arrow(14)?></a></div><?php endif ?>
    <?php if ($stageHighlights): ?>
    <div class="ps-editorial-path"><h3>از برنامهٔ آموزشی</h3><div class="ps-stage-links"><?php foreach ($stageHighlights as $item): ?><a href="content.php?id=<?=(int)$item['id']?>"><small><?=e($item['stage_title'])?></small><strong><?=e($item['title'])?></strong><?=prospect_arrow(15)?></a><?php endforeach ?></div></div>
    <?php endif ?>
</section>
<section class="ps-section" aria-labelledby="projects-heading">
    <?php prospect_section('projects-heading','نمونه‌های اجرا','پروژه‌های مستند','showcase.php','همهٔ نمونه‌کارها'); ?>
    <?php if ($projects): prospect_card_list($projects); else: ?><p class="ps-empty">هنوز پروژه‌ای برای نمایش عمومی تأیید و منتشر نشده است.</p><?php endif ?>
</section>
<?php if ($guidance): ?>
<section class="ps-section" aria-labelledby="portfolio-heading">
    <?php prospect_section('portfolio-heading','ویترین ویدیویی','همکاری‌ها و پروژه‌ها','portfolio-videos.php','همهٔ ویدیوها'); prospect_portfolio_cards($portfolio); ?>
</section>
<?php endif ?>
<section class="ps-section" aria-labelledby="trust-heading">
    <?php prospect_section('trust-heading','پیش از تصمیم‌گیری','مدارک، توانمندی‌ها و تجربه‌های مستند'); ?>
    <?php if ($trust): prospect_card_list($trust); else: ?>
    <div class="ps-panel"><h3>در بررسی پیشنهاد، چه شواهدی بخواهید؟</h3><p>دامنهٔ اجرا، مسئولیت‌های هر طرف، مشخصات اقلام، روند بازرسی و تعهدات خدمات را در پیشنهاد مکتوب مرور کنید. مدرک یا بازخورد فقط پس از تأیید و اجازهٔ انتشار در این بخش قرار می‌گیرد.</p></div>
    <?php endif ?>
</section>
<section class="ps-section ps-callout dark" aria-labelledby="consult-heading">
    <div><h2 id="consult-heading">دربارهٔ ساختمان خود مشاوره بگیرید</h2><p>نوع ساختمان، محدوده و نیازتان را ثبت کنید تا درخواست برای بررسی ارسال شود.</p></div>
    <a class="ps-btn ps-primary" href="request-consultation.php">درخواست مشاوره تخصصی <?=prospect_arrow()?></a>
</section>
<section class="ps-section" id="contact" aria-labelledby="contact-heading">
    <?php prospect_section('contact-heading','راه‌های ارتباط','تماس و پیگیری','track.php','پیگیری درخواست'); prospect_context_video('contact'); ?>
    <div class="ps-split">
        <article class="ps-panel"><h3>ارتباط با <?=e(prospect_brand())?></h3>
        <?php if ($office) prospect_facts($office); ?>
        <?php if ($contacts): ?><div class="ps-contact-list"><?php foreach ($contacts as [$label,$text,$url,$icon]): ?><a href="<?=e($url)?>" aria-label="<?=e($label.' '.$text)?>"><?=icon($icon,16)?><bdi><?=e($text)?></bdi></a><?php endforeach ?></div><?php endif ?>
        <?php if (!$office && !$contacts): ?><p>اطلاعات تماس دفتر پس از بازبینی مدیریت نمایش داده می‌شود.</p><?php endif ?>
        <?php if ($appreciation): ?><p><?=e($appreciation['summary'])?></p><a href="content.php?id=<?=(int)$appreciation['id']?>" class="ps-link"><?=e($appreciation['title'])?></a><?php endif ?>
        <a class="ps-link" href="track.php">رسید درخواست دارید؟ وضعیت را ببینید <?=prospect_arrow(14)?></a></article>
        <?php if ($ready && !$demo): ?>
        <form action="request-consultation.php?source=contact" method="post" class="ps-panel ps-form"><h3>فرم تماس</h3><?=csrf_field()?>
            <?php prospect_contact_fields(); prospect_textarea('description','پیام شما *','',2000,2,true); prospect_consent(); ?>
            <button type="submit" class="ps-btn ps-primary ps-submit">ارسال پیام <?=prospect_arrow(14)?></button>
        </form>
        <?php elseif ($demo): ?><div class="ps-panel"><h3>فرم تماس</h3><p>در پیش‌نمایش ارسال پیام فعال نیست.</p><a class="ps-link" href="request-consultation.php?source=contact">دیدن فرم تماس <?=prospect_arrow(14)?></a></div>
        <?php elseif (!$ready): ?><div class="ps-panel"><h3>فرم تماس</h3><p>ثبت آنلاین بعد از فعال‌سازی مدیریت در دسترس خواهد بود.</p></div><?php endif ?>
    </div>
</section>
<?php prospect_end(); ?>

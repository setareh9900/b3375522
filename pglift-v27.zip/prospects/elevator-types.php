<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-video-view.php';
prospect_method(['GET','HEAD']);
prospect_start('انواع آسانسور', 'types', 'تفاوت آسانسور کششی، گیرلس، گیربکس‌دار و هیدرولیک و نکات بررسی پیش از انتخاب.');
prospect_page_intro('آشنایی با سامانه‌ها', 'انواع آسانسور را بشناسید', 'هر سامانه ویژگی‌های متفاوتی دارد. این راهنما به شما کمک می‌کند گزینه‌ها را با پرسش‌های درست مقایسه کنید.');
prospect_context_video('types');
prospect_type_cards();
?>
<section class="ps-section ps-callout"><div><h2>از مشخصات ساختمان شروع کنید.</h2><p>شرایط نصب را وارد کنید و چک‌لیست بررسی فنی بگیرید.</p></div><a class="ps-btn ps-primary" href="elevator-selection.php">شروع راهنمای انتخاب <?=prospect_arrow()?></a></section>
<?php prospect_end(); ?>

<?php
/** Authenticated customer recordings and published type audio; supports seeking. */
declare(strict_types=1);
require_once __DIR__ . '/../inc/portal.php';

portal_private_headers();
$f = $_GET['f'] ?? null;
if (!gf_is_configured() || !is_string($f) || !preg_match('/^[a-zA-Z0-9_.-]+\.(mp3|m4a|ogg|wav|webm)$/iD', $f)) {
    http_response_code(404); exit;
}
if (!in_array($_SERVER['REQUEST_METHOD'], ['GET','HEAD'], true)) {
    header('Allow: GET, HEAD'); http_response_code(405); exit;
}
$ref = 'uploads/audio/'.$f;
$path = dirname(__DIR__).'/'.$ref;
if (!is_file($path)) { http_response_code(404); exit; }

$allowed = (bool)current_user();
if (!$allowed) {
    $account = portal_account();
    $allowed = $account && ($account['elevator_audio'] ?? '') === $ref;
    if (!$allowed) {
        require_once __DIR__ . '/../inc/types.php';
        foreach (types_load() as $type) {
            if (($type['audio'] ?? '') === $ref && (!empty($type['active']) || ($account['elevator_type'] ?? '') === $type['id'])) {
                $allowed = true; break;
            }
        }
    }
}
if (!$allowed) { http_response_code(404); exit; }
session_write_close();

$ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
$mime = ['mp3'=>'audio/mpeg','m4a'=>'audio/mp4','ogg'=>'audio/ogg','wav'=>'audio/wav','webm'=>'audio/webm'][$ext];
$stream = @fopen($path, 'rb');
if ($stream === false) { http_response_code(404); exit; }
$size = (int)fstat($stream)['size'];
$start = 0;
$end = $size - 1;
header('Accept-Ranges: bytes');
header('Cross-Origin-Resource-Policy: same-origin');
if (isset($_SERVER['HTTP_RANGE']) && preg_match('/^bytes=(\d*)-(\d*)$/D', $_SERVER['HTTP_RANGE'], $matches)) {
    if ($matches[1] !== '') $start = (int)$matches[1];
    if ($matches[2] !== '') $end = min($end, (int)$matches[2]);
    if ($matches[1] === '' && $matches[2] !== '') { $start = max(0, $size - (int)$matches[2]); $end = $size - 1; }
    if ($start > $end) { fclose($stream); http_response_code(416); header("Content-Range: bytes */$size"); exit; }
    http_response_code(206);
    header("Content-Range: bytes $start-$end/$size");
}
header('Content-Type: '.$mime);
header('Content-Length: '.($end - $start + 1));
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    fseek($stream, $start);
    $left = $end - $start + 1;
    while ($left > 0 && !feof($stream)) {
        $bytes = fread($stream, min(8192, $left));
        if ($bytes === false || $bytes === '') break;
        echo $bytes;
        $left -= strlen($bytes);
    }
}
fclose($stream);

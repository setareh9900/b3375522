<?php
/**
 * تعریف جداول و داده‌های پیش‌فرض — آسانسور خلیج فارس صادقی
 * DDL برای MySQL و SQLite تولید می‌شود.
 */
declare(strict_types=1);

require_once __DIR__ . '/portal-schema.php';

/** تولید دستورات ساخت جدول متناسب با درایور */
function gf_schema_sql(string $driver): array
{
    $my = ($driver !== 'sqlite');

    // تفاوت‌های نوع داده بین MySQL و SQLite
    $PK   = $my ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $BOOL = $my ? 'TINYINT(1)' : 'INTEGER';
    $TXT  = 'TEXT';
    $DT   = $my ? 'DATETIME' : 'TEXT';
    $ENG  = $my ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';

    $t = [];

    $t[] = "CREATE TABLE IF NOT EXISTS site_settings (
        id $PK,
        skey VARCHAR(100) NOT NULL UNIQUE,
        svalue $TXT NOT NULL,
        sgroup VARCHAR(50) NOT NULL DEFAULT 'general',
        slabel VARCHAR(190) NOT NULL DEFAULT '',
        updated_at $DT NULL
    )$ENG";

    $t[] = "CREATE TABLE IF NOT EXISTS site_content (
        id $PK,
        section VARCHAR(50) NOT NULL,
        title VARCHAR(255) NOT NULL DEFAULT '',
        subtitle VARCHAR(255) NOT NULL DEFAULT '',
        body $TXT NULL,
        extra $TXT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        is_visible $BOOL NOT NULL DEFAULT 1,
        updated_at $DT NULL
    )$ENG";

    $t[] = "CREATE TABLE IF NOT EXISTS brand_assets (
        id $PK,
        kind VARCHAR(30) NOT NULL,
        label VARCHAR(190) NOT NULL DEFAULT '',
        data_url LONGTEXT NOT NULL,
        is_active $BOOL NOT NULL DEFAULT 1,
        created_at $DT NULL
    )$ENG";

    $t[] = "CREATE TABLE IF NOT EXISTS service_requests (
        id $PK,
        ticket VARCHAR(40) NOT NULL UNIQUE,
        request_type VARCHAR(30) NOT NULL DEFAULT 'service',
        subject VARCHAR(255) NOT NULL,
        customer_name VARCHAR(150) NOT NULL,
        phone VARCHAR(40) NOT NULL,
        email VARCHAR(190) NOT NULL DEFAULT '',
        address VARCHAR(400) NOT NULL DEFAULT '',
        city VARCHAR(100) NOT NULL DEFAULT '',
        elevator_type VARCHAR(100) NOT NULL DEFAULT '',
        floors INT NOT NULL DEFAULT 1,
        passengers INT NOT NULL DEFAULT 6,
        brand VARCHAR(100) NOT NULL DEFAULT '',
        preferred_date VARCHAR(40) NOT NULL DEFAULT '',
        message $TXT NULL,
        urgency VARCHAR(20) NOT NULL DEFAULT 'normal',
        status VARCHAR(20) NOT NULL DEFAULT 'new',
        admin_note $TXT NULL,
        technician VARCHAR(150) NOT NULL DEFAULT '',
        estimated_cost BIGINT NOT NULL DEFAULT 0,
        created_at $DT NULL,
        updated_at $DT NULL
    )$ENG";

    $t[] = "CREATE TABLE IF NOT EXISTS request_events (
        id $PK,
        request_id INT NOT NULL,
        message $TXT NOT NULL,
        actor VARCHAR(100) NOT NULL DEFAULT 'system',
        created_at $DT NULL
    )$ENG";

    $t[] = "CREATE TABLE IF NOT EXISTS support_tickets (
        id $PK,
        ticket VARCHAR(40) NOT NULL UNIQUE,
        subject VARCHAR(255) NOT NULL,
        body $TXT NOT NULL,
        sender_name VARCHAR(150) NOT NULL DEFAULT '',
        sender_email VARCHAR(190) NOT NULL DEFAULT '',
        priority VARCHAR(20) NOT NULL DEFAULT 'normal',
        status VARCHAR(20) NOT NULL DEFAULT 'open',
        reply $TXT NULL,
        created_at $DT NULL,
        updated_at $DT NULL
    )$ENG";

    $t[] = "CREATE TABLE IF NOT EXISTS admin_users (
        id $PK,
        username VARCHAR(80) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        full_name VARCHAR(150) NOT NULL DEFAULT '',
        role VARCHAR(30) NOT NULL DEFAULT 'admin',
        is_active $BOOL NOT NULL DEFAULT 1,
        last_login_at $DT NULL,
        created_at $DT NULL
    )$ENG";

    $t[] = "CREATE TABLE IF NOT EXISTS activity_log (
        id $PK,
        actor VARCHAR(100) NOT NULL DEFAULT 'system',
        action VARCHAR(80) NOT NULL,
        detail VARCHAR(400) NOT NULL DEFAULT '',
        created_at $DT NULL
    )$ENG";

    $t[] = "CREATE TABLE IF NOT EXISTS installer_state (
        id $PK,
        step VARCHAR(40) NOT NULL DEFAULT 'pending',
        message VARCHAR(255) NOT NULL DEFAULT '',
        is_complete $BOOL NOT NULL DEFAULT 0,
        installed_at $DT NULL
    )$ENG";

    // ایندکس‌ها
    $t[] = "CREATE INDEX idx_sr_status ON service_requests (status)";
    $t[] = "CREATE INDEX idx_sr_created ON service_requests (created_at)";
    $t[] = "CREATE INDEX idx_st_status ON support_tickets (status)";
    $t[] = "CREATE INDEX idx_sc_section ON site_content (section)";
    $t[] = "CREATE INDEX idx_log_created ON activity_log (created_at)";
    $t[] = "CREATE INDEX idx_re_request ON request_events (request_id)";

    return array_merge($t, portal_schema_sql($driver));
}

/** تنظیمات پیش‌فرض سایت */
function gf_default_settings(): array
{
    return [
        ['brand.name',    'آسانسور خلیج فارس صادقی', 'brand',   'نام برند'],
        ['brand.short',   'خلیج فارس',               'brand',   'نام کوتاه'],
        ['brand.tagline', 'تخصص در نصب، سرویس و نگهداری آسانسور', 'brand', 'شعار'],
        ['brand.phone',   '۰۲۱-۱۲۳۴۵۶۷۸',           'contact', 'تلفن ثابت'],
        ['brand.mobile',  '۰۹۱۲۱۲۳۴۵۶۷',            'contact', 'تلفن همراه'],
        ['brand.email',   'info@gulfpars-elevator.ir', 'contact', 'ایمیل'],
        ['brand.address', 'تهران، خیابان صادقی، پلاک ۱۲۳، برج خلیج فارس', 'contact', 'نشانی'],
        ['brand.hours',   'شنبه تا چهارشنبه ۸:۰۰ تا ۱۸:۰۰ — پنجشنبه ۸:۰۰ تا ۱۳:۰۰', 'contact', 'ساعات کاری'],
        ['brand.whatsapp','989121234567',            'contact', 'شماره واتس‌اپ'],
        ['brand.instagram','https://instagram.com',  'contact', 'اینستاگرام'],
        ['seo.title',     'آسانسور خلیج فارس صادقی | نصب، سرویس و نگهداری آسانسور', 'seo', 'عنوان سئو'],
        ['seo.description','نصب، سرویس، تعمیر و نگهداری آسانسور با بیش از ۱۵ سال تجربه در تهران.', 'seo', 'توضیحات سئو'],
        ['seo.keywords',  'آسانسور, تعمیر آسانسور, سرویس آسانسور, نصب آسانسور, خلیج فارس, صادقی', 'seo', 'کلیدواژه‌ها'],
        /* ظاهر سایت */
        ['site.theme',    'copper',     'appearance', 'تم رنگ سایت (copper / amber / darkmatter / slate)'],
        ['site.bg_fx',    'sparkles',   'appearance', 'افکت بک‌گراند (sparkles / particles / aurora / mouse / none)'],
        ['site.cabin_bg', 'assets/img/cabin-copper.webp', 'appearance', 'تصویر اصلی بک‌گراند کابین'],
        ['site.cabin_bg2', 'assets/img/cabin-red.webp', 'appearance', 'تصویر کابین دوم (اسکرول)'],
        ['site.cabin_bg3', 'assets/img/cabin-black.webp', 'appearance', 'تصویر کابین سوم (اسکرول)'],
        ['site.hq_images','assets/img/cabin-copper.webp|assets/img/types/hydraulic.webp|assets/img/cabin-red.webp|assets/img/types/gearless.webp|assets/img/cabin-black.webp|assets/img/types/mrl-traction.webp|assets/img/types/home-f7.webp|assets/img/customer-background.webp', 'appearance', 'گالری تصاویر بک‌گراند (با | جدا کنید)'],
    ];
}

/** محتوای پیش‌فرض بخش‌های سایت */
function gf_default_content(): array
{
    return [
        [
            'hero',
            'آسانسور خلیج فارس صادقی',
            'ارتقای آسانسور شما با تکنولوژی هوشمند',
            'بیش از ۱۵ سال تجربه در نصب، سرویس و نگهداری آسانسور در سراسر تهران. تیم متخصص ما با بهره‌گیری از جدیدترین فناوری‌های کنترلی، ایمنی و آسایش شما را تضمین می‌کند.',
            [
                'ctaPrimary'   => 'درخواست سرویس فوری',
                'ctaSecondary' => 'مشاوره رایگان',
                'stats' => [
                    ['value' => '+۱۵',   'label' => 'سال تجربه'],
                    ['value' => '+۳۲۰۰', 'label' => 'آسانسور تحت سرویس'],
                    ['value' => '۲۴',    'label' => 'پاسخ اضطراری'],
                ],
            ],
            0,
        ],
        [
            'features',
            'چرا خلیج فارس؟',
            'مزایایی که ما را متمایز می‌کند',
            'از طراحی تا پشتیبانی، همه چیز برای یک تجربه بی‌دغدغه طراحی شده است.',
            ['items' => [
                ['icon' => 'shield', 'title' => 'ایمنی صددرصد',  'text' => 'بازرسی دوره‌ای قطعات و سیستم‌های ایمنی مطابق استاندارد ملی.'],
                ['icon' => 'clock',  'title' => 'پاسخ سریع',     'text' => 'تیم آنلاین ۲۴ ساعته و اعزام سریع تکنسین در کمترین زمان.'],
                ['icon' => 'gear',   'title' => 'تعمیر تخصصی',   'text' => 'تعمیر برندهای معتبر جهانی با قطعات اصل و ضمانت بازگشت وجه.'],
                ['icon' => 'wallet', 'title' => 'قیمت منصفانه',  'text' => 'ارائه فاکتور رسمی و شفاف با تخفیف ویژه قراردادهای سالانه.'],
                ['icon' => 'chip',   'title' => 'سیستم هوشمند',  'text' => 'کنترل هوشمند سفر، آسیب‌شناسی پیش‌بین و پایش از راه دور.'],
                ['icon' => 'wrench', 'title' => 'پشتیبانی مستمر','text' => 'قرارداد نگهداری با بازدید دوره‌ای و گزارش عملکرد ماهانه.'],
            ]],
            1,
        ],
        [
            'services',
            'خدمات ما',
            'هر آنچه برای آسانسور خود نیاز دارید',
            'از نصب صفر تا سرویس دوره‌ای؛ همه در یک جا.',
            ['items' => [
                ['icon' => 'install', 'title' => 'نصب آسانسور',    'text' => 'نصب انواع آسانسور مسکونی، تجاری و صنعتی با پروانه رسمی.'],
                ['icon' => 'wrench',  'title' => 'سرویس و نگهداری','text' => 'برنامه سرویس ماهانه و فصلی مطابق چک‌لیست استاندارد.'],
                ['icon' => 'repair',  'title' => 'تعمیر آسانسور',  'text' => 'رفع خطا، تعویض سیستم کنترل و بازسازی کامل کابین.'],
                ['icon' => 'board',   'title' => 'سرویس سازمانی',  'text' => 'پشتیبانی ویژه مجتمع‌های مسکونی، برج‌ها و کارخانه‌ها.'],
                ['icon' => 'part',    'title' => 'تأمین قطعات',    'text' => 'قطعات اصلی با گارانتی و امکان تأمین اقساطی.'],
                ['icon' => 'inspect', 'title' => 'بازرسی و پروانه','text' => 'تمدید پروانه بهره‌برداری و بازرسی دوره‌ای استاندارد.'],
            ]],
            2,
        ],
        [
            'process',
            'فرآیند کار با ما',
            'چهار گام تا آرامش خاطر شما',
            '',
            ['steps' => [
                ['title' => 'ثبت درخواست',     'text' => 'فرم آنلاین را تکمیل کنید یا تلفنی تماس بگیرید.'],
                ['title' => 'بازدید فنی',      'text' => 'کارشناس ما در کمتر از ۲۴ ساعت بازدید و برآورد ارائه می‌دهد.'],
                ['title' => 'اجرا و نظارت',    'text' => 'اجرای پروژه با نظارت کارشناس فنی و گزارش مرحله‌ای.'],
                ['title' => 'پشتیبانی مستمر',  'text' => 'سرویس دوره‌ای، پاسخ اضطراری و ضمانت خدمات.'],
            ]],
            3,
        ],
        [
            'cta',
            'همین حالا درخواست سرویس ثبت کنید',
            'کارشناسان ما در کمترین زمان با شما تماس می‌گیرند.',
            'ثبت درخواست کاملاً رایگان است و هیچ تعهدی برای شما ایجاد نمی‌کند.',
            ['cta' => 'ثبت درخواست سرویس آسانسور'],
            4,
        ],
        [
            'testimonials',
            'نظر مشتریان',
            'اعتمادی که با خدمت ساخته‌ایم',
            '',
            ['items' => [
                ['name' => 'مهندس رضایی', 'role' => 'مدیر ساختمان، تهران',    'text' => 'تیم فنی همیشه پاسخگو و دقیق است. سرویس منظم واقعاً تفاوت را نشان می‌دهد.'],
                ['name' => 'سمیه کریمی',  'role' => 'صاحب مغازه، خیابان صادقی','text' => 'سرویس آسانسور مغازه را همان روز انجام دادند و قیمت منصفانه‌ای داشت.'],
                ['name' => 'حسین مرادی',  'role' => 'مدیر فنی کارخانه',        'text' => 'برای ۴ آسانسور صنعتی قرارداد سرویس داریم؛ تیمی حرفه‌ای و منظم.'],
            ]],
            5,
        ],
        [
            'footer',
            'آسانسور خلیج فارس صادقی',
            'تخصص در نصب، سرویس و نگهداری آسانسور',
            'با بهره‌گیری از تیم متخصص و ابزارهای دقیق، تجربه‌ای مطمئن از سفر در آسانسور را برای شما رقم می‌زنیم.',
            ['quickLinks' => [
                ['label' => 'خدمات',          'href' => '#services'],
                ['label' => 'مزایا',          'href' => '#features'],
                ['label' => 'درخواست سرویس', 'href' => '#request'],
                ['label' => 'درخواست سرویس',  'href' => '#request'],
                ['label' => 'تماس با ما',     'href' => '#contact'],
            ]],
            6,
        ],
    ];
}

/** لوگوی پیش‌فرض به صورت SVG در قالب data-url */
function gf_default_logo(): string
{
    $svg = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#2a3f7a"/><stop offset="55%" stop-color="#1b2550"/><stop offset="100%" stop-color="#2a1b52"/>
    </linearGradient>
    <linearGradient id="gold" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#e8c98a"/><stop offset="100%" stop-color="#c99a3f"/>
    </linearGradient>
  </defs>
  <rect x="26" y="26" width="460" height="460" rx="120" fill="url(#g)"/>
  <rect x="56" y="56" width="400" height="400" rx="96" fill="none" stroke="rgba(160,190,255,.25)" stroke-width="6"/>
  <rect x="150" y="120" width="212" height="272" rx="20" fill="rgba(8,14,40,.6)" stroke="url(#gold)" stroke-width="8"/>
  <line x1="256" y1="120" x2="256" y2="392" stroke="rgba(190,210,255,.35)" stroke-width="6"/>
  <path d="M206 320 L256 246 L306 320 Z" fill="url(#gold)"/>
  <path d="M206 254 L256 180 L306 254 Z" fill="url(#gold)" opacity=".7"/>
  <rect x="150" y="392" width="212" height="16" rx="8" fill="rgba(200,215,255,.45)"/>
</svg>
SVG;
    return 'data:image/svg+xml;base64,' . base64_encode($svg);
}

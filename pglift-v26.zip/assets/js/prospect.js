(() => {
    const btn = document.querySelector('[data-prospect-copy]');
    if (!btn || !navigator.clipboard) return;
    btn.hidden = false;
    btn.addEventListener('click', async () => {
        const receipt = document.querySelector('[data-prospect-receipt]');
        const status = document.querySelector('[data-copy-status]');
        try {
            await navigator.clipboard.writeText(receipt.innerText);
            status.textContent = 'کد و کلید پیگیری کپی شد.';
        } catch (_) {
            status.textContent = 'کپی نشد؛ لطفاً کد و کلید را دستی ذخیره کنید.';
        }
    });
})();

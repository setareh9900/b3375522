<?php
declare(strict_types=1);

function prospect_default_statuses(): array
{
    return [
        'new' => 'سرنخ جدید', 'engaged' => 'تعامل با محتوا', 'consultation' => 'درخواست مشاوره',
        'awaiting_contact' => 'در انتظار تماس', 'contacted' => 'تماس انجام شد', 'technical' => 'بررسی فنی',
        'quote_prepared' => 'پیش‌فاکتور آماده', 'quote_sent' => 'پیش‌فاکتور ارسال شد', 'negotiation' => 'مذاکره',
        'awaiting_decision' => 'در انتظار تصمیم', 'converted' => 'تبدیل به مشتری خریدکرده', 'not_interested' => 'عدم تمایل',
    ];
}

function prospect_default_campaign(): array
{
    return [
        1 => ['معرفی شرکت','آشنایی اولیه با شرکت، خدمات و هویت فنی.'],
        2 => ['نکتهٔ فنی','ارائهٔ یک نکتهٔ عملی برای مالک یا مدیر ساختمان.'],
        3 => ['ویدیوی کوتاه','نمایش آموزشی تجهیزات؛ پیشنهاد: ۱۵ تا ۲۰ ثانیه.'],
        4 => ['اعتماد و شواهد','معرفی نمونهٔ اجرا، تیم یا تجربهٔ مستند و مجاز برای انتشار.'],
        5 => ['راهنمای تخصصی','کمک به مقایسهٔ گزینه‌ها و پاسخ به نگرانی‌های خرید.'],
        6 => ['قدردانی و ارتباط','قدردانی از مخاطب و دعوت به ارتباط یا پیگیری.'],
    ];
}

/** Additive DDL. Intentionally no foreign keys into tables from older installations. */
function prospect_schema_sql(string $driver): array
{
    $my = $driver !== 'sqlite';
    $id = $my ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $dt = $my ? 'DATETIME' : 'TEXT';
    $engine = $my ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';
    $extra = [];
    $indexes = static function (string $table, array $defs) use ($my, &$extra): string {
        $sql = '';
        foreach ($defs as $name => $fields) {
            if ($my) $sql .= ", INDEX $name ($fields)";
            else $extra[] = "CREATE INDEX IF NOT EXISTS $name ON $table ($fields)";
        }
        return $sql;
    };
    $t = [];
    $t[] = "CREATE TABLE IF NOT EXISTS prospect_statuses (
        code VARCHAR(30) PRIMARY KEY NOT NULL, title VARCHAR(110) NOT NULL, sort_order INT NOT NULL
    )$engine";
    $t[] = "CREATE TABLE IF NOT EXISTS prospects (
        id $id, full_name VARCHAR(150) NOT NULL, phone VARCHAR(30) NOT NULL UNIQUE,
        status VARCHAR(30) NOT NULL, assigned_to INT NULL, created_at $dt NOT NULL, updated_at $dt NOT NULL,
        FOREIGN KEY (status) REFERENCES prospect_statuses(code)
        {$indexes('prospects', ['pc_lead_status'=>'status, updated_at', 'pc_lead_owner'=>'assigned_to, updated_at'])}
    )$engine";
    $t[] = "CREATE TABLE IF NOT EXISTS prospect_inquiries (
        id $id, prospect_id INT NOT NULL, reference VARCHAR(30) NOT NULL UNIQUE, access_hash CHAR(64) NOT NULL,
        sender_name VARCHAR(150) NOT NULL, service VARCHAR(30) NOT NULL, source VARCHAR(20) NOT NULL,
        building_type VARCHAR(30) NOT NULL DEFAULT '', location VARCHAR(180) NOT NULL DEFAULT '', floors INT NULL,
        passengers INT NULL, capacity_kg INT NULL, installation_space VARCHAR(30) NOT NULL DEFAULT '',
        installation_kind VARCHAR(30) NOT NULL DEFAULT '', preferred_system VARCHAR(30) NOT NULL DEFAULT '',
        requirements TEXT NULL, description TEXT NULL, public_state VARCHAR(20) NOT NULL DEFAULT 'received',
        reviewed_at $dt NULL, reviewed_by INT NULL, created_at $dt NOT NULL,
        FOREIGN KEY (prospect_id) REFERENCES prospects(id)
        {$indexes('prospect_inquiries', ['pc_inquiry_lead'=>'prospect_id, id', 'pc_inquiry_inbox'=>'reviewed_at, created_at'])}
    )$engine";
    $t[] = "CREATE TABLE IF NOT EXISTS prospect_interactions (
        id $id, prospect_id INT NOT NULL, actor_id INT NULL, kind VARCHAR(30) NOT NULL,
        body TEXT NOT NULL, created_at $dt NOT NULL, FOREIGN KEY (prospect_id) REFERENCES prospects(id)
        {$indexes('prospect_interactions', ['pc_interaction_lead'=>'prospect_id, id'])}
    )$engine";
    $t[] = "CREATE TABLE IF NOT EXISTS prospect_followups (
        id $id, prospect_id INT NOT NULL, due_at $dt NOT NULL, body VARCHAR(300) NOT NULL,
        state VARCHAR(20) NOT NULL DEFAULT 'pending', created_by INT NOT NULL, created_at $dt NOT NULL,
        closed_by INT NULL, closed_at $dt NULL, FOREIGN KEY (prospect_id) REFERENCES prospects(id)
        {$indexes('prospect_followups', ['pc_followup_lead'=>'prospect_id, state, due_at', 'pc_followup_due'=>'state, due_at'])}
    )$engine";
    $t[] = "CREATE TABLE IF NOT EXISTS prospect_quotations (
        id $id, prospect_id INT NOT NULL, reference VARCHAR(120) NOT NULL, amount VARCHAR(120) NOT NULL DEFAULT '',
        notes TEXT NULL, created_by INT NOT NULL, created_at $dt NOT NULL, sent_at $dt NULL,
        FOREIGN KEY (prospect_id) REFERENCES prospects(id), UNIQUE (prospect_id, reference)
        {$indexes('prospect_quotations', ['pc_quote_sent'=>'sent_at'])}
    )$engine";
    $t[] = "CREATE TABLE IF NOT EXISTS prospect_rate_limits (
        bucket CHAR(64) PRIMARY KEY NOT NULL, hits INT NOT NULL, expires_at INT NOT NULL
        {$indexes('prospect_rate_limits', ['pc_rate_expiry'=>'expires_at'])}
    )$engine";
    $t[] = "CREATE TABLE IF NOT EXISTS prospect_content_categories (
        id $id, title VARCHAR(120) NOT NULL UNIQUE
    )$engine";
    $t[] = "CREATE TABLE IF NOT EXISTS prospect_campaigns (
        slot INT PRIMARY KEY NOT NULL, title VARCHAR(160) NOT NULL, objective VARCHAR(320) NOT NULL,
        sort_order INT NOT NULL, is_active INT NOT NULL DEFAULT 1, starts_at $dt NULL
    )$engine";
    $t[] = "CREATE TABLE IF NOT EXISTS prospect_content (
        id $id, kind VARCHAR(30) NOT NULL, category_id INT NULL, campaign_slot INT NULL,
        title VARCHAR(180) NOT NULL, summary VARCHAR(400) NOT NULL DEFAULT '', body TEXT NULL,
        state VARCHAR(20) NOT NULL DEFAULT 'draft', publish_at $dt NULL, is_featured INT NOT NULL DEFAULT 0,
        is_verified INT NOT NULL DEFAULT 0, verification_note VARCHAR(400) NOT NULL DEFAULT '',
        project_type VARCHAR(140) NOT NULL DEFAULT '', elevator_type VARCHAR(140) NOT NULL DEFAULT '',
        technical_info TEXT NULL, image_alt VARCHAR(180) NOT NULL DEFAULT '',
        seo_title VARCHAR(160) NOT NULL DEFAULT '', seo_description VARCHAR(240) NOT NULL DEFAULT '',
        created_by INT NOT NULL, updated_by INT NOT NULL, created_at $dt NOT NULL, updated_at $dt NOT NULL,
        FOREIGN KEY (category_id) REFERENCES prospect_content_categories(id),
        FOREIGN KEY (campaign_slot) REFERENCES prospect_campaigns(slot)
        {$indexes('prospect_content', ['pc_public_feed'=>'state, kind, publish_at', 'pc_campaign_items'=>'campaign_slot, state'])}
    )$engine";
    $t[] = "CREATE TABLE IF NOT EXISTS prospect_content_media (
        id $id, content_id INT NOT NULL, kind VARCHAR(20) NOT NULL, stored_name VARCHAR(80) NOT NULL UNIQUE,
        mime VARCHAR(30) NOT NULL, byte_size INT NOT NULL, alt_text VARCHAR(180) NOT NULL DEFAULT '',
        created_at $dt NOT NULL, FOREIGN KEY (content_id) REFERENCES prospect_content(id)
        {$indexes('prospect_content_media', ['pc_media_content'=>'content_id, kind, id'])}
    )$engine";
    // Readiness sentinel must be last; no lead creation or conversion is enabled on partial DDL.
    $t = array_merge($t, $extra);
    $t[] = "CREATE TABLE IF NOT EXISTS prospect_conversions (
        prospect_id INT PRIMARY KEY NOT NULL, customer_id INT NOT NULL, contract_id INT NULL,
        evidence_type VARCHAR(20) NOT NULL, evidence_reference VARCHAR(140) NOT NULL,
        evidence_key CHAR(64) NOT NULL UNIQUE, purchase_date VARCHAR(10) NOT NULL,
        admin_id INT NOT NULL, admin_username VARCHAR(80) NOT NULL, created_at $dt NOT NULL,
        FOREIGN KEY (prospect_id) REFERENCES prospects(id)
        {$indexes('prospect_conversions', ['pc_conversion_customer'=>'customer_id'])}
    )$engine";
    if (!$my) $t[] = end($extra);
    return $t;
}

/** Idempotent: never replace an administrator's customized stage labels or schedule. */
function prospect_seed_defaults(PDO $pdo): void
{
    $sqlite = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite';
    $st = $pdo->prepare('INSERT INTO prospect_statuses (code, title, sort_order) VALUES (?,?,?)'.
        ($sqlite ? ' ON CONFLICT(code) DO NOTHING' : ' ON DUPLICATE KEY UPDATE code=prospect_statuses.code'));
    $i = 0;
    foreach (prospect_default_statuses() as $code => $title) $st->execute([$code,$title,(++$i)*10]);
    $st = $pdo->prepare('INSERT INTO prospect_campaigns (slot, title, objective, sort_order) VALUES (?,?,?,?)'.
        ($sqlite ? ' ON CONFLICT(slot) DO NOTHING' : ' ON DUPLICATE KEY UPDATE slot=prospect_campaigns.slot'));
    foreach (prospect_default_campaign() as $slot => [$title,$objective]) $st->execute([$slot,$title,$objective,$slot*10]);
}

function prospect_apply_schema(PDO $pdo): void
{
    foreach (prospect_schema_sql($pdo->getAttribute(PDO::ATTR_DRIVER_NAME)) as $sql) $pdo->exec($sql);
    prospect_seed_defaults($pdo);
}

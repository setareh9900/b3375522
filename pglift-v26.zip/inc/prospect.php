<?php
declare(strict_types=1);

require_once __DIR__.'/fn.php';
require_once __DIR__.'/prospect-schema.php';

class ProspectValidation extends RuntimeException {}

function prospect_ready(bool $refresh = false): bool
{
    static $ready = null;
    if (!gf_is_configured()) return false;
    if ($ready === null || $refresh) {
        try {
            q('SELECT prospect_id FROM prospect_conversions WHERE 1=0');
            $ready = (int)q_val('SELECT COUNT(*) FROM prospect_statuses') >= count(prospect_default_statuses())
                && (int)q_val('SELECT COUNT(*) FROM prospect_campaigns') === 6;
        } catch (PDOException $ex) {
            $ready = false;
        }
    }
    return $ready;
}

function prospect_private_headers(): void
{
    header('Cache-Control: private, no-store, max-age=0');
    header('X-Robots-Tag: noindex, nofollow');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
}

function prospect_method(array $allowed): void
{
    if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', $allowed, true)) {
        header('Allow: '.implode(', ', $allowed));
        http_response_code(405);
        exit;
    }
}

function prospect_csrf(): void
{
    if (!csrf_check(prospect_scalar($_POST, 'csrf'))) {
        http_response_code(403);
        exit('توکن امنیتی نامعتبر است. صفحه را تازه کنید.');
    }
}

function prospect_redirect(string $url): void
{
    header('Location: '.$url, true, 303);
    exit;
}

function prospect_scalar(array $from, string $key, string $default = ''): string
{
    return is_string($from[$key] ?? null) ? $from[$key] : $default;
}

function prospect_id($value): int
{
    if ((!is_string($value) && !is_int($value)) || !preg_match('/^[0-9]{1,10}$/D', (string)$value)) return 0;
    return (float)$value <= 2147483647 ? (int)$value : 0;
}

function prospect_text(array $in, string $key, string $label, int $max, int $min = 0): string
{
    $value = $in[$key] ?? '';
    if (!is_string($value) || strlen($value) > 4*$max+64 || !preg_match('//u', $value)) {
        throw new ProspectValidation($label.' معتبر نیست.');
    }
    $value = trim(str_replace(["\r\n", "\r"], "\n", $value));
    if (preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $value) || mb_strlen($value, 'UTF-8') > $max
        || mb_strlen($value, 'UTF-8') < $min) {
        throw new ProspectValidation($label.' را با حداکثر '.fa_digits($max).' نویسه وارد کنید.'.($min ? ' این فیلد الزامی است.' : ''));
    }
    return $value;
}

function prospect_choice(array $in, string $key, string $label, array $options, bool $required = false): string
{
    $value = $in[$key] ?? '';
    if (!is_string($value) || ($value === '' ? $required : !isset($options[$value]))) {
        throw new ProspectValidation($label.' را از گزینه‌های فرم انتخاب کنید.');
    }
    return $value;
}

function prospect_number(array $in, string $key, string $label, int $min, int $max, bool $required = false): ?int
{
    $value = $in[$key] ?? '';
    if (is_string($value)) $value = en_digits(trim($value));
    if ($value === '' && !$required) return null;
    if (!is_string($value) || !preg_match('/^\d{1,6}$/D', $value) || (int)$value < $min || (int)$value > $max) {
        throw new ProspectValidation($label.' باید بین '.fa_digits($min).' و '.fa_digits($max).' باشد.');
    }
    return (int)$value;
}

/** The same Iranian telephone in local and +98/0098 forms is one lead. Letters are not discarded. */
function prospect_phone(string $raw): string
{
    $phone = preg_replace('/[\s().\-–]/u', '', en_digits(trim($raw))) ?? '';
    if (preg_match('/^(?:\+98|0098|98)([1-9]\d{9})$/D', $phone, $parts)) $phone = '0'.$parts[1];
    if (preg_match('/^9\d{9}$/D', $phone)) $phone = '0'.$phone;
    return preg_match('/^0[1-9]\d{9}$/D', $phone) ? $phone : '';
}

function prospect_services(): array
{
    return ['technical'=>'مشاورهٔ فنی', 'selection'=>'راهنمایی انتخاب آسانسور', 'quotation'=>'برآورد و پیش‌فاکتور اولیه',
        'inspection'=>'بازدید از محل', 'installation'=>'مشاورهٔ نصب', 'contact'=>'ارتباط با شرکت'];
}

function prospect_buildings(): array
{
    return ['residential'=>'مسکونی', 'office'=>'اداری', 'commercial'=>'تجاری', 'health'=>'درمانی',
        'industrial'=>'صنعتی یا باربری', 'mixed'=>'چندمنظوره', 'other'=>'سایر'];
}

function prospect_spaces(): array
{
    return ['inside'=>'داخل ساختمان', 'outside'=>'بیرون ساختمان', 'existing_shaft'=>'چاه موجود', 'unknown'=>'نیاز به بازدید'];
}

function prospect_installation_kinds(): array
{
    return ['new'=>'نصب جدید', 'replacement'=>'جایگزینی یا نوسازی'];
}

function prospect_systems(): array
{
    return ['traction'=>'کششی', 'gearless'=>'گیرلس', 'geared'=>'گیربکس‌دار', 'hydraulic'=>'هیدرولیک', 'unknown'=>'هنوز انتخاب نکرده‌ام'];
}

function prospect_public_states(): array
{
    return ['received'=>'دریافت شد', 'in_review'=>'در حال بررسی', 'closed'=>'رسیدگی شد'];
}

function prospect_project_input(array $input, bool $requireContext = false): array
{
    return [
        'building_type'=>prospect_choice($input, 'building_type', 'نوع ساختمان', prospect_buildings(), $requireContext),
        'location'=>prospect_text($input, 'location', 'محدودهٔ ساختمان', 180, $requireContext ? 2 : 0),
        'floors'=>prospect_number($input, 'floors', 'تعداد طبقات', 1, 150),
        'passengers'=>prospect_number($input, 'passengers', 'تعداد تقریبی مسافر', 1, 100),
        'capacity_kg'=>prospect_number($input, 'capacity_kg', 'ظرفیت مدنظر', 50, 50000),
        'installation_space'=>prospect_choice($input, 'installation_space', 'محل نصب', prospect_spaces()),
        'installation_kind'=>prospect_choice($input, 'installation_kind', 'نوع نصب', prospect_installation_kinds()),
        'preferred_system'=>prospect_choice($input, 'preferred_system', 'سامانهٔ مدنظر', prospect_systems()),
        'requirements'=>prospect_text($input, 'requirements', 'نیازهای آسانسور', 1400),
    ];
}

function prospect_project_facts(array $row): array
{
    return array_filter([
        'نوع ساختمان'=>prospect_buildings()[$row['building_type'] ?? ''] ?? '',
        'محدودهٔ ساختمان'=>$row['location'] ?? '',
        'تعداد طبقات'=>isset($row['floors']) ? fa_digits($row['floors']) : '',
        'مسافر تقریبی'=>isset($row['passengers']) ? fa_digits($row['passengers']).' نفر' : '',
        'ظرفیت مدنظر'=>isset($row['capacity_kg']) ? fa_digits($row['capacity_kg']).' کیلوگرم' : '',
        'محل نصب'=>prospect_spaces()[$row['installation_space'] ?? ''] ?? '',
        'نوع نصب'=>prospect_installation_kinds()[$row['installation_kind'] ?? ''] ?? '',
        'سامانهٔ مدنظر'=>prospect_systems()[$row['preferred_system'] ?? ''] ?? '',
    ], static fn($value) => $value !== '');
}

/** Shared short-lived rate limits also apply when the client drops its session cookie. */
function prospect_allow_attempt(string $name, int $ceiling, int $period = 900): bool
{
    $slot = intdiv(time(), $period);
    $key = hash('sha256', $name.'|'.$slot.'|'.($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    $sql = 'INSERT INTO prospect_rate_limits (bucket,hits,expires_at) VALUES (?,1,?)';
    $sql .= gf_driver() === 'sqlite' ? ' ON CONFLICT(bucket) DO UPDATE SET hits=hits+1' : ' ON DUPLICATE KEY UPDATE hits=hits+1';
    q($sql, [$key, ($slot+1)*$period]);
    if (random_int(1,32) === 1) q('DELETE FROM prospect_rate_limits WHERE expires_at<=?', [time()]);
    return (int)q_val('SELECT hits FROM prospect_rate_limits WHERE bucket=?', [$key]) <= $ceiling;
}

function prospect_now(): string { return gmdate('Y-m-d H:i:s'); }

function prospect_atomic(callable $work)
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $value = $work();
        $pdo->commit();
        return $value;
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $ex;
    }
}

function prospect_log(int $id, ?int $actor, string $kind, string $text): void
{
    q('INSERT INTO prospect_interactions (prospect_id,actor_id,kind,body,created_at) VALUES (?,?,?,?,?)',
        [$id, $actor, $kind, $text, prospect_now()]);
}

function prospect_submit(array $input, string $source): array
{
    if (!in_array($source, ['request','selection','contact'], true)) throw new InvalidArgumentException('Unknown inquiry source');
    $contact = $source === 'contact';
    if (($input['consent'] ?? '') !== '1' || !empty($input['website'])) {
        throw new ProspectValidation('برای ثبت درخواست، متن استفاده از اطلاعات تماس را تأیید کنید.');
    }
    $name = prospect_text($input, 'name', 'نام و نام خانوادگی', 150, 2);
    $phone = prospect_phone(prospect_text($input, 'phone', 'شمارهٔ تلفن', 40, 1));
    if ($phone === '') throw new ProspectValidation('شمارهٔ تماس معتبر با پیش‌شماره وارد کنید.');
    $services = prospect_services(); unset($services['contact']);
    $service = $contact ? 'contact' : prospect_choice($input, 'service', 'خدمت درخواستی', $services, true);
    $context = prospect_project_input($contact ? [] : $input, !$contact);
    $description = prospect_text($input, 'description', 'توضیحات درخواست', 2000, $contact ? 3 : 0);
    $reference = 'P-'.strtoupper(bin2hex(random_bytes(7)));
    $access = bin2hex(random_bytes(16));
    prospect_atomic(static function () use ($name,$phone,$source,$service,$context,$description,$reference,$access,$contact): void {
        $at = prospect_now();
        $sql = 'INSERT INTO prospects (full_name,phone,status,created_at,updated_at) VALUES (?,?,?,?,?)';
        // A new inquiry never changes the contact name, owner, or status of a previous lead.
        $sql .= gf_driver() === 'sqlite' ? ' ON CONFLICT(phone) DO NOTHING' : ' ON DUPLICATE KEY UPDATE id=prospects.id';
        q($sql, [$name,$phone,$contact ? 'new' : 'consultation',$at,$at]);
        $id = (int)q_val('SELECT id FROM prospects WHERE phone=?', [$phone]);
        q('INSERT INTO prospect_inquiries (prospect_id,reference,access_hash,sender_name,service,source,building_type,location,floors,
            passengers,capacity_kg,installation_space,installation_kind,preferred_system,requirements,description,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            array_merge([$id,$reference,hash('sha256', $access),$name,$service,$source], array_values($context), [$description,$at]));
        q('UPDATE prospects SET updated_at=? WHERE id=?', [$at,$id]);
        prospect_log($id, null, 'inquiry', 'درخواست جدید '.$reference.' دریافت شد.');
    });
    return ['reference'=>$reference,'access'=>$access];
}

/** A lookup credential belongs to exactly one inquiry, never the lead or the phone number. */
function prospect_track(string $reference, string $access): ?array
{
    $reference = strtoupper(trim($reference));
    $access = strtolower(trim($access));
    $row = preg_match('/^P-[A-F0-9]{14}$/D', $reference)
        ? q_one('SELECT reference,access_hash,service,public_state,created_at FROM prospect_inquiries WHERE reference=?', [$reference]) : null;
    if (!preg_match('/^[a-f0-9]{32}$/D', $access) || !hash_equals($row['access_hash'] ?? str_repeat('0', 64), hash('sha256', $access)) || !$row) return null;
    unset($row['access_hash']);
    return $row;
}

function prospect_datetime(string $value, string $label): ?string
{
    if ($value === '') return null;
    $value = en_digits($value);
    $local = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $value, new DateTimeZone('Asia/Tehran'));
    if (!$local || $local->format('Y-m-d\TH:i') !== $value || (int)$local->format('Y') < 2000 || (int)$local->format('Y') > 2100) {
        throw new ProspectValidation($label.' معتبر نیست.');
    }
    return $local->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
}

function prospect_local_time(?string $value): string
{
    return $value ? (new DateTimeImmutable($value, new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Tehran'))->format('Y-m-d\TH:i') : '';
}

function prospect_date(?string $value, bool $time = false): string
{
    if (!$value) return '—';
    $tehran = new DateTimeZone('Asia/Tehran');
    $local = (new DateTimeImmutable($value, new DateTimeZone(strlen($value) === 10 ? 'Asia/Tehran' : 'UTC')))->setTimezone($tehran);
    [$y,$m,$d] = gregorian_to_jalali((int)$local->format('Y'), (int)$local->format('n'), (int)$local->format('j'));
    return fa_digits(sprintf('%04d/%02d/%02d', $y, $m, $d).($time ? ' · '.$local->format('H:i') : ''));
}

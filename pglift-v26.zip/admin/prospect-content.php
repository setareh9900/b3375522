<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-admin-view.php';
require_once __DIR__.'/../inc/prospect-content-admin.php';
$staff = prospect_staff();
prospect_admin_only($staff);
prospect_method(['GET','HEAD','POST']);
if (!prospect_ready()) redirect('prospects.php');
$sections = ['library'=>'محتوا و ویدیو','campaign'=>'برنامهٔ شش‌مرحله‌ای','categories'=>'دسته‌ها','settings'=>'تماس و سئو'];
$section = prospect_scalar($_GET,'section','library');
if (!isset($sections[$section])) $section = 'library';
$edit = prospect_scalar($_GET,'edit');
$id = prospect_id($edit);
$error = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    prospect_csrf();
    $action = prospect_scalar($_POST,'action');
    try {
        $actor = (int)$staff['id'];
        if ($action === 'content') {
            $id = prospect_optional_id($_POST,'id','محتوا') ?? 0;
            $edit = $id ? (string)$id : 'new';
            $id = prospect_content_save($id,$actor,$_POST,$_FILES);
            $next = '?edit='.$id;
        } elseif (in_array($action,['media_delete','pause'],true)) {
            $id = prospect_optional_id($_POST,'id','محتوا') ?? 0;
            $edit = (string)$id;
            if ($action === 'media_delete') prospect_content_delete_media($id,prospect_id($_POST['media_id'] ?? null),$actor);
            else prospect_content_pause($id,$actor);
            $next = '?edit='.$id;
        } elseif ($action === 'campaign') { prospect_save_campaign($_POST); $next = '?section=campaign'; }
        elseif ($action === 'category') { prospect_save_category($_POST); $next = '?section=categories'; }
        elseif ($action === 'settings') { prospect_save_portal_settings($_POST); $next = '?section=settings'; }
        else throw new ProspectValidation('عملیات نامعتبر است.');
        log_activity($staff['username'],'prospect.content.'.$action,$id ? 'محتوا #'.$id : '');
        prospect_flash('تغییرات ذخیره شدند.');
        prospect_redirect('prospect-content.php'.$next);
    } catch (ProspectValidation | PDOException $ex) { $error = prospect_admin_error($ex,'content'); }
}
$item = $id ? q_one('SELECT * FROM prospect_content WHERE id=?',[$id]) : null;
if ($id && !$item && $error === '') { http_response_code(404); $error = 'محتوا پیدا نشد.'; }
$categories = array_column(q_all('SELECT id,title FROM prospect_content_categories ORDER BY title,id'),'title','id');
$campaign = prospect_campaigns();
$kinds = prospect_content_types();
prospect_admin_start($staff,'محتوای پرتال معرفی','content');
prospect_page_intro('انتشار مستقل از پنل خریداران','محتوای پرتال معرفی','مقاله، نمونهٔ پروژه و ویدیوی آموزشی در این بخش ثبت می‌شود؛ پیام‌ها و اعلان‌های عملیاتی مشتریان اینجا منتشر نمی‌شوند.');
prospect_show_flash($error);
?>
<nav class="pc-tabs" aria-label="بخش‌های محتوا"><?php foreach ($sections as $key=>$label): ?><a href="prospect-content.php?section=<?=e($key)?>"<?=$section === $key ? ' aria-current="page"' : ''?>><?=e($label)?></a><?php endforeach ?></nav>
<?php if ($section === 'library' && ($item || $edit === 'new')): require __DIR__.'/../inc/prospect-admin-views/editor.php'; ?>
<?php elseif ($section === 'library'):
    $filter = prospect_scalar($_GET,'kind');
    $state = prospect_scalar($_GET,'state');
    $where = ['1=1']; $arg = []; $params = [];
    if (isset($kinds[$filter])) { $where[]='kind=?'; $arg[]=$filter; $params['kind']=$filter; }
    if (isset(prospect_publish_states()[$state])) { $where[]='state=?'; $arg[]=$state; $params['state']=$state; }
    $condition = implode(' AND ',$where);
    [$page,$pages,$offset] = prospect_pagination((int)q_val("SELECT COUNT(*) FROM prospect_content WHERE $condition",$arg),prospect_id($_GET['page'] ?? null),24);
    $rows = q_all("SELECT id,title,kind,state,publish_at,campaign_slot,is_featured FROM prospect_content WHERE $condition ORDER BY updated_at DESC,id DESC LIMIT 24 OFFSET $offset",$arg);
    ?>
    <section class="pc-section">
    <div class="pc-head"><h2>فهرست محتوا</h2><a class="ps-btn ps-primary" href="prospect-content.php?edit=new">محتوای جدید</a></div>
    <form class="ps-panel pc-short-form pc-section" method="get" action="prospect-content.php">
        <?php prospect_select_field('kind','نوع محتوا',$kinds,$filter,false,'همه'); prospect_select_field('state','وضعیت',prospect_publish_states(),$state,false,'همه'); ?>
        <button type="submit" class="ps-btn ps-secondary">اعمال فیلتر</button>
    </form>
    <div class="pc-list">
        <?php if (!$rows): ?><p class="ps-empty">هنوز محتوایی برای این فیلتر ثبت نشده است.</p><?php endif ?>
        <?php foreach ($rows as $row): ?>
            <article class="pc-row"><div><a class="ps-link" href="?edit=<?=(int)$row['id']?>"><b><?=e($row['title'])?></b> <?=prospect_arrow(14)?></a><small><?=e($kinds[$row['kind']] ?? $row['kind'])?><?= $row['campaign_slot'] ? ' · مرحلهٔ '.fa_digits($row['campaign_slot']) : ''?></small></div>
                <div><span class="ps-chip"><?=e($row['state'] === 'published' ? ($row['publish_at'] > prospect_now() ? 'زمان‌بندی شده' : (prospect_public_post((int)$row['id']) ? 'منتشرشده' : 'مرحلهٔ پنهان')) : prospect_publish_states()[$row['state']])?></span><?php if ($row['publish_at']): ?><small><?=e(prospect_date($row['publish_at'],true))?></small><?php endif ?></div>
            </article>
        <?php endforeach ?>
    </div>
    <?php prospect_admin_pager('prospect-content.php',$params,$page,$pages); ?>
    </section>
<?php elseif ($section === 'campaign'): ?>
    <section class="pc-section"><h2>برنامهٔ شش‌مرحله‌ای انتشار</h2><p class="pc-hint">برنامه اجباری یا روزانه نیست. محتوا از ویرایشگر به مرحله متصل می‌شود؛ توقف مرحله، مطلب و فایل‌های وابسته را از دید عمومی پنهان می‌کند. زمان‌ها به وقت تهران‌اند.</p>
    <div class="pc-campaign-grid pc-section">
        <?php foreach ($campaign as $stage): ?>
        <form class="ps-panel ps-form" method="post" action="?section=campaign"><h3>مرحلهٔ <?=fa_digits($stage['slot'])?></h3>
            <?php prospect_admin_action('campaign'); ?><input type="hidden" name="slot" value="<?=(int)$stage['slot']?>">
            <?php prospect_input_field('title','عنوان مرحله',$stage['title'],'required maxlength="160"'); prospect_textarea('objective','هدف ارتباطی',$stage['objective'],320,2,true); ?>
            <?php prospect_input_field('sort_order','ترتیب نمایش',$stage['sort_order'],'required inputmode="numeric" maxlength="3"'); prospect_input_field('starts_at','زمان شروع اختیاری',prospect_local_time($stage['starts_at']),'','datetime-local'); ?>
            <?php prospect_checkbox('is_active','مرحله فعال باشد',(int)$stage['is_active'] === 1); ?><button class="ps-btn ps-primary ps-submit" type="submit">ذخیره مرحله</button>
        </form>
        <?php endforeach ?>
    </div></section>
<?php elseif ($section === 'categories'): ?>
    <section class="pc-section pc-settings-list"><h2>دسته‌بندی محتوا</h2><p class="pc-hint">فقط دسته‌های دارای مطلب منتشرشده در فیلتر عمومی نمایش داده می‌شوند.</p>
        <?php foreach ([''=>'']+$categories as $categoryId=>$label): ?>
        <form method="post" action="?section=categories" class="pc-list-item pc-short-form">
            <?php prospect_admin_action('category',(int)$categoryId); prospect_input_field('title',$categoryId ? 'ویرایش نام دسته' : 'نام دستهٔ جدید',$label,'required maxlength="120"'); ?>
            <button type="submit" class="ps-btn ps-secondary"><?=$categoryId ? 'ذخیره' : 'افزودن دسته'?></button>
        </form>
        <?php endforeach ?>
    </section>
<?php else:
    $contact = prospect_contact_settings(); ?>
    <form class="ps-panel ps-form pc-section" method="post" action="?section=settings">
        <h2>تماس و نمایش در جست‌وجو</h2><?php prospect_admin_action('settings'); ?>
        <?php prospect_input_field('seo_title','عنوان سئوی خانهٔ پرتال',setting('prospect.seo_title'),'maxlength="160"'); prospect_textarea('seo_description','توضیح سئوی خانهٔ پرتال',setting('prospect.seo_description'),240,2); ?>
        <h3>اطلاعات تماس ثبت‌شده در برند</h3><p class="pc-hint">مقادیر واقعی را از <a class="ps-link" href="index.php?tab=settings">تنظیمات اصلی</a> وارد کنید. اگر بعداً تغییر کردند، باید دوباره در اینجا بررسی شوند.</p>
        <?php prospect_facts(array_combine(['تلفن دفتر','همراه','ایمیل','نشانی','ساعات','واتس‌اپ','اینستاگرام'], array_map(static fn($v)=>$v ?: 'ثبت نشده', $contact))); ?>
        <?php prospect_checkbox('contact_reviewed','اطلاعات واقعی و به‌روز هستند و تأیید می‌کنم در پرتال نمایش داده شوند.',hash_equals(setting('prospect.contact_reviewed'), prospect_contact_digest($contact))); ?>
        <button class="ps-btn ps-primary ps-submit">ذخیره تنظیمات</button>
    </form>
<?php endif ?>
<?php prospect_admin_end(); ?>

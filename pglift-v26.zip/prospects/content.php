<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-editorial-view.php';
prospect_method(['GET','HEAD']);
$item = prospect_public_post(prospect_id($_GET['id'] ?? null));
if (!$item) prospect_not_found();
$kind = $item['kind'];
$media = prospect_content_media((int)$item['id']);
$back = $kind === 'project' ? 'showcase.php' : (in_array($kind,['tip','article','short_video','weekly_video'],true) ? 'knowledge.php' : 'index.php');
prospect_start($item['seo_title'] ?: $item['title'], $back === 'knowledge.php' ? 'learn' : '', $item['seo_description'] ?: $item['summary']);
?>
<a class="ps-link" href="<?=e($back)?>">بازگشت <?=prospect_arrow(14)?></a>
<?php prospect_page_intro(prospect_content_types()[$kind] ?? 'مطلب', $item['title'], $item['summary']); ?>
<article class="ps-panel ps-prose">
    <div class="ps-content-meta">
        <?php if ($item['category_title']): ?><span class="ps-chip"><?=e($item['category_title'])?></span><?php endif ?>
        <?php if ($item['stage_title']): ?><span class="ps-chip"><?=e($item['stage_title'])?></span><?php endif ?>
        <time class="ps-caption" datetime="<?=e(str_replace(' ','T',$item['publish_at']).'Z')?>"><?=e(prospect_date($item['publish_at']))?></time>
    </div>
    <?php if (prospect_is_video($kind) && $media['video']): ?>
        <video class="ps-video" controls playsinline preload="none" aria-label="<?=e($item['title'])?>"<?= $media['cover'] ? ' poster="'.e(prospect_media_url($media['cover'])).'"' : ''?>>
            <source src="<?=e(prospect_media_url($media['video']))?>" type="<?=e($media['video']['mime'])?>">
            <a href="<?=e(prospect_media_url($media['video']))?>">باز کردن ویدیو</a>
        </video>
    <?php elseif ($media['cover']): ?><img class="ps-content-cover" src="<?=e(prospect_media_url($media['cover']))?>" alt="<?=e($item['image_alt'])?>" decoding="async"><?php endif ?>
    <?php if ($kind === 'project'): ?>
        <?php prospect_facts(['نوع پروژه'=>$item['project_type'],'نوع آسانسور'=>$item['elevator_type']]); ?>
        <h2>اطلاعات فنی پروژه</h2><p><?=e($item['technical_info'])?></p>
    <?php endif ?>
    <h2><?=prospect_is_video($kind) ? 'شرح ویدیو' : ($kind === 'project' ? 'شرح پروژه' : 'متن مطلب')?></h2><p><?=e($item['body'])?></p>
    <?php if ($media['gallery']): ?><div class="ps-gallery"><?php foreach ($media['gallery'] as $photo): ?>
        <a href="<?=e(prospect_media_url($photo))?>"><img src="<?=e(prospect_media_url($photo))?>" alt="<?=e($photo['alt_text'])?>" loading="lazy" decoding="async"></a>
    <?php endforeach ?></div><?php endif ?>
</article>
<section class="ps-section ps-callout"><div><h2>شرایط پروژهٔ شما متفاوت است</h2><p>برای تصمیم فنی، مشخصات ساختمان و محل نصب باید بررسی شود.</p></div><a href="request-consultation.php" class="ps-btn ps-primary">درخواست مشاوره <?=prospect_arrow()?></a></section>
<?php prospect_end(); ?>

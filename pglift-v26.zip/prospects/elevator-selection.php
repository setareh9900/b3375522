<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-forms.php';
require_once __DIR__.'/../inc/prospect-selection.php';
prospect_method(['GET','HEAD','POST']);
prospect_private_headers();
$system = prospect_scalar($_GET,'system');
$in = isset(prospect_systems()[$system]) ? ['preferred_system'=>$system] : [];
$result = null;
$error = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    prospect_csrf();
    try {
        $in = array_filter($_POST,'is_string');
        $result = prospect_project_input($_POST,true);
        $_SESSION['prospect_selection'] = ['context'=>$result,'until'=>time()+7200];
    } catch (ProspectValidation $ex) {
        http_response_code(422);
        $error = $ex->getMessage();
    }
}
prospect_start('راهنمای انتخاب آسانسور','guide','',true);
prospect_page_intro('ابزار شناخت نیاز','راهنمای انتخاب برای ساختمان شما','شرایط ساختمان را بگویید تا نکات مناسب برای گفت‌وگو با کارشناس را ببینید. این راهنما محاسبه یا تأیید مهندسی نیست.');
?>
<?php if ($result): ?>
<section class="ps-panel ps-guide-result" aria-labelledby="result-heading">
    <span class="ps-chip">راهنمایی اولیه</span><h2 id="result-heading">چک‌لیست بررسی ساختمان</h2>
    <p>مشخصات نهایی، ظرفیت، سرعت، نوع تجهیزات و قیمت با این فرم تعیین نمی‌شوند. اندازه‌گیری محل و بررسی مهندس ضروری است.</p>
    <?php prospect_facts(prospect_project_facts($result)); ?>
    <div class="ps-guide-checks"><?php foreach (prospect_guidance($result) as $label=>$note): ?><div><h3><?=icon('inspect',16)?> <?=e($label)?></h3><p><?=e($note)?></p></div><?php endforeach ?></div>
    <?php $preferred = prospect_elevator_types()[$result['preferred_system']] ?? null; if ($preferred): ?>
        <a class="ps-link" href="elevator-type.php?type=<?=e($result['preferred_system'])?>">دربارهٔ <?=e($preferred[0])?> بخوانید <?=prospect_arrow(14)?></a>
    <?php else: ?><a class="ps-link" href="elevator-types.php">روش کار سامانه‌های مختلف را مقایسه کنید <?=prospect_arrow(14)?></a><?php endif ?>
    <div class="ps-actions"><a class="ps-btn ps-primary" href="request-consultation.php?source=selection">درخواست بررسی و مشاوره فنی <?=prospect_arrow()?></a><a class="ps-btn ps-secondary" href="#selection-form">اصلاح ورودی‌ها</a></div>
    <p class="ps-caption">تا وقتی فرم مشاوره را تأیید نکرده‌اید، سرنخی ایجاد نمی‌شود.</p>
</section>
<?php endif ?>
<div class="ps-form-layout" id="selection-form">
    <form method="post" action="elevator-selection.php" class="ps-panel ps-form">
        <h2>مشخصات اولیهٔ ساختمان</h2><?php if ($error) prospect_notice($error,true); ?><?=csrf_field()?>
        <?php prospect_project_fields($in,true); ?>
        <button class="ps-btn ps-primary ps-submit" type="submit">دیدن راهنمای اولیه <?=prospect_arrow()?></button>
    </form>
    <aside class="ps-panel ps-note-panel"><h2>چطور از این راهنما استفاده کنم؟</h2><ol class="ps-steps"><li><span>۱</span>اطلاعاتی را که می‌دانید وارد کنید؛ ظرفیت نامشخص را خالی بگذارید.</li><li><span>۲</span>چک‌لیست را مرور و سامانه‌ها را مطالعه کنید.</li><li><span>۳</span>اگر مایل بودید، فرم جداگانهٔ مشاوره را ارسال کنید.</li></ol></aside>
</div>
<?php prospect_end(); ?>

<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-forms.php';
prospect_method(['GET','HEAD','POST']);
prospect_private_headers();
$ready = prospect_ready();
$demo = !empty(gf_config()['prospect_demo']);
$selection = $_SESSION['prospect_selection'] ?? null;
$mode = prospect_scalar($_GET, 'source');
$source = $mode === 'contact' ? 'contact' : ($mode === 'selection' && $selection && $selection['until'] > time() ? 'selection' : 'request');
$contact = $source === 'contact';
$form = $source === 'selection' ? $selection['context'] + ['service'=>'technical'] : [];
if (!$contact && isset(prospect_systems()[prospect_scalar($_GET, 'system')])) $form['preferred_system'] = prospect_scalar($_GET, 'system');
$prefillService = prospect_scalar($_GET, 'service');
$services = prospect_services(); unset($services['contact']);
if (!$contact && isset($services[$prefillService])) $form['service'] = $prefillService;
$receipt = null;
$error = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    prospect_csrf();
    if (!$ready || $demo) {
        http_response_code(503);
    } else {
        $form = array_filter($_POST, 'is_string');
        try {
            if (!prospect_allow_attempt('submit', 8)) {
                http_response_code(429);
                $error = 'تعداد درخواست‌ها زیاد است. لطفاً چند دقیقهٔ دیگر تلاش کنید.';
            } else {
                $_SESSION['prospect_receipt'] = prospect_submit($_POST, $source);
                unset($_SESSION['prospect_selection']);
                prospect_redirect('request-consultation.php?received=1');
            }
        } catch (ProspectValidation $ex) {
            http_response_code(422);
            $error = $ex->getMessage();
        } catch (PDOException $ex) {
            error_log('Prospect submission database error ('.$ex->getCode().')');
            http_response_code(503);
            $error = 'ثبت درخواست در حال حاضر ممکن نیست. لطفاً دوباره تلاش کنید.';
        }
    }
} elseif (prospect_scalar($_GET, 'received') === '1' && ($_SERVER['REQUEST_METHOD'] ?? '') !== 'HEAD') {
    $receipt = $_SESSION['prospect_receipt'] ?? null;
    unset($_SESSION['prospect_receipt']);
}
$title = $receipt ? 'درخواست شما ثبت شد' : ($contact ? 'ارسال پیام و درخواست تماس' : 'درخواست مشاورهٔ تخصصی');
prospect_start($title, '', '', true);
prospect_page_intro('ارتباط پیش از خرید', $title, $receipt ? 'درخواست در صندوق پیگیری تیم مشاوره ثبت شد.' : 'این فرم برای بررسی و تماس است؛ ثبت آن خرید، قرارداد یا ایجاد حساب خریدار محسوب نمی‌شود.');
?>
<div class="ps-form-layout">
<?php if ($receipt): ?>
    <section class="ps-panel" role="status">
        <h2>رسید برای شما</h2><p>کد و کلید را همین حالا ذخیره کنید. برای دیدن وضعیت فقط همین درخواست، هر دو لازم‌اند. کلید را با دیگران به اشتراک نگذارید.</p>
        <div class="ps-receipt" data-prospect-receipt><div>کد پیگیری: <bdi dir="ltr" data-reference><?=e($receipt['reference'])?></bdi></div><div>کلید خصوصی: <bdi dir="ltr" data-access><?=e($receipt['access'])?></bdi></div></div>
        <div class="ps-actions"><a class="ps-btn ps-primary" href="track.php">پیگیری درخواست <?=prospect_arrow()?></a><button hidden type="button" class="ps-btn ps-secondary" data-prospect-copy>کپی کد و کلید</button></div>
        <p data-copy-status aria-live="polite"></p>
    </section>
<?php elseif (!$ready): ?>
    <div class="ps-panel"><h2>ثبت آنلاین هنوز فعال نیست.</h2><p>تا زمان فعال‌سازی، از <a class="ps-link" href="index.php#contact">بخش تماس</a> استفاده کنید.</p></div>
<?php else: ?>
    <form method="post" class="ps-panel ps-form" action="request-consultation.php<?= $contact ? '?source=contact' : ($source === 'selection' ? '?source=selection' : '') ?>">
        <?php if ($error) prospect_notice($error, true); ?>
        <?php if ($demo) prospect_notice('در پیش‌نمایش ثبت اطلاعات غیرفعال است.'); ?>
        <?php if ($source === 'selection') prospect_notice('اطلاعات راهنمای انتخاب آمادهٔ بازبینی است. در صورت نیاز تغییر دهید.'); ?>
        <?=csrf_field()?>
        <?php prospect_contact_fields($form); ?>
        <?php if (!$contact): ?>
            <?php prospect_select_field('service','نوع درخواست',$services,$form['service'] ?? '',true); ?>
            <?php prospect_project_fields($form, true, true); ?>
        <?php endif ?>
        <?php prospect_textarea('description', $contact ? 'پیام شما *' : 'توضیحات تکمیلی', $form['description'] ?? '', 2000, 4, $contact); ?>
        <?php prospect_consent($form); ?>
        <button type="submit" class="ps-btn ps-primary ps-submit"<?=$demo ? ' disabled' : ''?>>ثبت <?=$contact ? 'پیام' : 'درخواست مشاوره'?> <?=prospect_arrow()?></button>
    </form>
<?php endif ?>
<aside class="ps-panel ps-note-panel"><h2>پس از ثبت چه می‌شود؟</h2><ol class="ps-steps"><li><span>۱</span>رسید و کلید خصوصی پیگیری می‌گیرید.</li><li><span>۲</span>تیم مشاوره درخواست را بررسی و در صورت نیاز تماس می‌گیرد.</li><li><span>۳</span>برای تصمیم فنی نهایی، شرایط محل بررسی می‌شود.</li></ol><a class="ps-link" href="track.php">قبلاً درخواست ثبت کرده‌اید؟ <?=prospect_arrow(14)?></a></aside>
</div>
<?php prospect_end(); ?>

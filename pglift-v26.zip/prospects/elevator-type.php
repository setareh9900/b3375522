<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-view.php';
prospect_method(['GET','HEAD']);
$key = prospect_scalar($_GET, 'type');
$type = prospect_elevator_types()[$key] ?? null;
if (!$type) prospect_not_found();
[$title,$tag,$image,$summary,$body,$checks] = $type;
prospect_start($title, 'types', $summary);
?>
<a class="ps-link ps-back" href="elevator-types.php">همهٔ انواع آسانسور</a>
<?php prospect_page_intro('شناخت سامانه‌ها', $title, $summary); ?>
<div class="ps-detail-grid">
    <figure class="ps-reference-art"><img src="../assets/img/types/<?=e($image)?>" alt="تصویر مرجع <?=e($title)?>" decoding="async"><figcaption>تصویر مرجع آموزشی؛ نمونهٔ پروژه نیست.</figcaption></figure>
    <article class="ps-panel ps-prose"><h2>چگونه کار می‌کند؟</h2><p><?=e($body)?></p><h2>در بررسی فنی بپرسید</h2><ul><?php foreach ($checks as $check): ?><li><?=e($check)?></li><?php endforeach ?></ul>
    <p class="ps-muted">برای تعیین ظرفیت، سرعت، چیدمان و تجهیزات، بررسی تخصصی محل و ضوابط پروژه ضروری است.</p>
    <div class="ps-actions"><a class="ps-btn ps-primary" href="request-consultation.php?system=<?=e($key)?>">درخواست مشاوره <?=prospect_arrow()?></a><a class="ps-btn ps-secondary" href="elevator-selection.php?system=<?=e($key)?>">راهنمای انتخاب</a></div></article>
</div>
<?php prospect_end(); ?>

<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/prospect-editorial-view.php';
prospect_method(['GET','HEAD']);
$total = prospect_public_count(['project'], 0);
$pages = max(1,(int)ceil($total/12));
$page = max(1,min($pages,prospect_id($_GET['page'] ?? null)));
$rows = prospect_public_items(['project'],12,($page-1)*12);
prospect_start('پروژه‌های مستند','', 'پروژه‌هایی که اطلاعات و تصاویرشان برای نمایش عمومی تأیید شده‌اند.');
prospect_page_intro('نمونه‌های اجرا','پروژه‌های مستند','فقط نمونه‌هایی که داده‌ها و حق انتشار تصاویرشان بررسی شده، در این بخش قرار می‌گیرند.');
if ($rows) prospect_card_list($rows);
else echo '<p class="ps-empty">هنوز پروژه‌ای برای نمایش عمومی منتشر نشده است.</p>';
?>
<?php if ($pages > 1): ?><nav class="ps-pager" aria-label="صفحه‌بندی نمونه‌ها"><?php if ($page > 1): ?><a class="ps-btn ps-secondary" href="?page=<?=$page-1?>">صفحه قبل</a><?php endif ?><span><?=fa_digits($page)?> از <?=fa_digits($pages)?></span><?php if ($page < $pages): ?><a class="ps-btn ps-secondary" href="?page=<?=$page+1?>">صفحه بعد</a><?php endif ?></nav><?php endif ?>
<?php prospect_end(); ?>

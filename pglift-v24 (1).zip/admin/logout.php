<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/fn.php';

$u = current_user();
if ($u) log_activity($u['username'], 'auth.logout', 'خروج از پنل');
logout_user();
redirect('login.php');

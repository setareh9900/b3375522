<?php
/**
 * پردازش تمام عملیات پنل مدیریت
 * خروجی: JSON — برای فراخوانی از طریق fetch در app.js
 */
declare(strict_types=1);
require_once __DIR__ . '/../inc/fn.php';

$user = require_login_api();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['ok' => false, 'error' => 'متد نامعتبر'], 405);
}

$in = $_POST ?: json_in();
csrf_require($in['csrf'] ?? null);

$do = (string)($in['do'] ?? '');

try {
    switch ($do) {

        /* ---------- به‌روزرسانی درخواست سرویس ---------- */
        case 'request.update': {
            $id = (int)($in['id'] ?? 0);
            if ($id <= 0) json_out(['ok' => false, 'error' => 'شناسه نامعتبر'], 422);

            $sets = []; $args = [];
            if (isset($in['status'])) {
                $s = (string)$in['status'];
                if (!in_array($s, ['new','contacted','scheduled','done','canceled'], true)) {
                    json_out(['ok' => false, 'error' => 'وضعیت نامعتبر'], 422);
                }
                $sets[] = 'status = ?'; $args[] = $s;
            }
            if (isset($in['admin_note']))  { $sets[] = 'admin_note = ?';  $args[] = clean_multiline((string)$in['admin_note'], 2000); }
            if (isset($in['technician']))  { $sets[] = 'technician = ?';  $args[] = clean((string)$in['technician'], 150); }
            if (isset($in['estimated_cost'])) {
                $sets[] = 'estimated_cost = ?';
                $args[] = max(0, (int) en_digits((string)$in['estimated_cost']));
            }
            if (!$sets) json_out(['ok' => false, 'error' => 'چیزی برای ذخیره نیست'], 422);

            $sets[] = 'updated_at = ?'; $args[] = now();
            $args[] = $id;
            q('UPDATE service_requests SET ' . implode(', ', $sets) . ' WHERE id = ?', $args);

            $ev = clean((string)($in['event'] ?? ''), 400);
            if ($ev !== '') {
                q('INSERT INTO request_events (request_id, message, actor, created_at) VALUES (?,?,?,?)',
                  [$id, $ev, $user['username'], now()]);
            }
            log_activity($user['username'], 'request.update', 'درخواست #' . $id . ' به‌روزرسانی شد');
            json_out(['ok' => true]);
        }

        case 'request.delete': {
            $id = (int)($in['id'] ?? 0);
            if ($id <= 0) json_out(['ok' => false, 'error' => 'شناسه نامعتبر'], 422);
            q('DELETE FROM request_events WHERE request_id = ?', [$id]);
            q('DELETE FROM service_requests WHERE id = ?', [$id]);
            log_activity($user['username'], 'request.delete', 'درخواست #' . $id . ' حذف شد');
            json_out(['ok' => true]);
        }

        /* ---------- تیکت پشتیبانی ---------- */
        case 'support.update': {
            $id = (int)($in['id'] ?? 0);
            if ($id <= 0) json_out(['ok' => false, 'error' => 'شناسه نامعتبر'], 422);

            $sets = []; $args = [];
            if (isset($in['status'])) {
                $s = (string)$in['status'];
                if (!in_array($s, ['open','answered','closed'], true)) {
                    json_out(['ok' => false, 'error' => 'وضعیت نامعتبر'], 422);
                }
                $sets[] = 'status = ?'; $args[] = $s;
            }
            if (isset($in['priority'])) {
                $p = (string)$in['priority'];
                if (!in_array($p, ['low','normal','high'], true)) $p = 'normal';
                $sets[] = 'priority = ?'; $args[] = $p;
            }
            if (isset($in['reply'])) { $sets[] = 'reply = ?'; $args[] = clean_multiline((string)$in['reply'], 4000); }
            if (!$sets) json_out(['ok' => false, 'error' => 'چیزی برای ذخیره نیست'], 422);

            $sets[] = 'updated_at = ?'; $args[] = now();
            $args[] = $id;
            q('UPDATE support_tickets SET ' . implode(', ', $sets) . ' WHERE id = ?', $args);
            log_activity($user['username'], 'support.update', 'تیکت #' . $id . ' به‌روزرسانی شد');
            json_out(['ok' => true]);
        }

        case 'support.delete': {
            $id = (int)($in['id'] ?? 0);
            if ($id <= 0) json_out(['ok' => false, 'error' => 'شناسه نامعتبر'], 422);
            q('DELETE FROM support_tickets WHERE id = ?', [$id]);
            log_activity($user['username'], 'support.delete', 'تیکت #' . $id . ' حذف شد');
            json_out(['ok' => true]);
        }

        /* ---------- ویرایش محتوای سایت ---------- */
        case 'content.update': {
            $id = (int)($in['id'] ?? 0);
            if ($id <= 0) json_out(['ok' => false, 'error' => 'شناسه نامعتبر'], 422);

            $extraRaw = (string)($in['extra'] ?? '');
            $extraJson = null;
            if ($extraRaw !== '') {
                $parsed = json_decode($extraRaw, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    json_out(['ok' => false, 'error' => 'ساختار JSON داده‌های پیشرفته نامعتبر است'], 422);
                }
                $extraJson = json_encode($parsed, JSON_UNESCAPED_UNICODE);
            }

            if (array_key_exists('hero_height', $in)) {
                $heroHeight = filter_var($in['hero_height'], FILTER_VALIDATE_INT);
                if ($heroHeight === false || $heroHeight < 70 || $heroHeight > 140) {
                    json_out(['ok' => false, 'error' => 'ارتفاع هیرو باید بین ۷۰ تا ۱۴۰ باشد'], 422);
                }
                $current = q_one('SELECT section, extra FROM site_content WHERE id = ?', [$id]);
                if ($current && $current['section'] === 'hero') {
                    $extra = $extraJson !== null ? (json_decode($extraJson, true) ?: []) : (json_decode((string)$current['extra'], true) ?: []);
                    $extra['heroHeight'] = $heroHeight;
                    $extraJson = json_encode($extra, JSON_UNESCAPED_UNICODE);
                }
            }

            q('UPDATE site_content SET title = ?, subtitle = ?, body = ?, extra = COALESCE(?, extra),
               is_visible = ?, updated_at = ? WHERE id = ?', [
                clean((string)($in['title'] ?? ''), 255),
                clean((string)($in['subtitle'] ?? ''), 255),
                clean_multiline((string)($in['body'] ?? ''), 4000),
                $extraJson,
                !empty($in['is_visible']) ? 1 : 0,
                now(), $id,
            ]);
            log_activity($user['username'], 'content.update', 'بخش #' . $id . ' به‌روزرسانی شد');
            json_out(['ok' => true]);
        }

        /* ---------- پاک کردن کش CDN ---------- */
        case 'cache.purge': {
            $ver = (string)time();
            set_setting('asset_ver', $ver);
            $msgs = ['نسخه‌ی فایل‌های سایت برای شکستن کش به‌روز شد (v=' . $ver . ')'];

            $zone  = trim(setting('cf_zone'));
            $token = trim(setting('cf_token'));
            if ($zone !== '' && $token !== '') {
                $url = 'https://api.cloudflare.com/client/v4/zones/' . rawurlencode($zone) . '/purge_cache';
                $body = json_encode(['purge_everything' => true]);
                $head = ['Authorization: Bearer ' . $token, 'Content-Type: application/json'];
                $res = false; $err = ''; $code = 0;
                if (function_exists('curl_init')) {
                    $ch = curl_init($url);
                    curl_setopt_array($ch, [
                        CURLOPT_POST => true,
                        CURLOPT_POSTFIELDS => $body,
                        CURLOPT_HTTPHEADER => $head,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_TIMEOUT => 20,
                    ]);
                    $res  = curl_exec($ch);
                    $err  = (string)curl_error($ch);
                    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                    curl_close($ch);
                } else {
                    $ctx = stream_context_create(['http' => [
                        'method' => 'POST', 'header' => implode("\r\n", $head),
                        'content' => $body, 'timeout' => 20, 'ignore_errors' => true,
                    ]]);
                    $res = @file_get_contents($url, false, $ctx);
                    if (isset($http_response_header[0])) {
                        preg_match('/\s(\d{3})\s/', $http_response_header[0], $m);
                        $code = (int)($m[1] ?? 0);
                    }
                    if ($res === false) $err = 'connection failed';
                }
                $json = is_string($res) ? json_decode($res, true) : null;
                if ($err === '' && $code === 200 && !empty($json['success'])) {
                    $msgs[] = 'کش Cloudflare به‌طور کامل پاک شد.';
                } else {
                    $msgs[] = 'پاک‌سازی Cloudflare ناموفق بود: ' . ($err !== '' ? $err : 'HTTP ' . $code);
                }
            } else {
                $msgs[] = 'اعتبارنامه‌ی Cloudflare تنظیم نشده؛ فقط نسخه‌ی فایل‌ها عوض شد.';
            }

            log_activity($user['username'], 'cache.purge', 'درخواست پاک کردن کش CDN');
            json_out(['ok' => true, 'message' => implode(' ', $msgs)]);
        }

        /* ---------- ذخیره تنظیمات ---------- */
        case 'settings.save': {
            $pairs = $in['settings'] ?? [];
            if (!is_array($pairs) || !$pairs) json_out(['ok' => false, 'error' => 'داده‌ای ارسال نشد'], 422);
            $n = 0;
            foreach ($pairs as $k => $v) {
                $k = (string) $k;
                if (!preg_match('/^[a-zA-Z0-9._-]{2,100}$/', $k)) continue;
                $max = ($k === 'site.hq_images') ? 4000 : 1000;
                $val = clean_multiline((string)$v, $max);
                if (in_array($k, ['site.cabin_bg', 'site.cabin_bg2', 'site.cabin_bg3', 'cinema.image'], true) && $val !== '' && !is_bg_image_path($val)) {
                    json_out(['ok' => false, 'error' => 'مسیر تصویر بک‌گراند نامعتبر است'], 422);
                }
                if ($k === 'site.hq_images' && $val !== '') {
                    $parts = array_filter(array_map('trim', explode('|', $val)));
                    foreach ($parts as $p) {
                        if (!is_bg_image_path($p)) {
                            json_out(['ok' => false, 'error' => 'مسیر نامعتبر در گالری: ' . $p], 422);
                        }
                    }
                    $val = implode('|', $parts);
                }
                $group = (strpos($k, 'site.') === 0) ? 'appearance' : 'general';
                set_setting($k, $val, $group);
                $n++;
            }
            log_activity($user['username'], 'settings.update', $n . ' تنظیم ذخیره شد');
            json_out(['ok' => true, 'saved' => $n, 'message' => $n . ' تنظیم ذخیره شد — صفحه اصلی را رفرش کنید']);
        }

        /* ---------- انواع آسانسور (مقاله، نقشه، صدا) ---------- */
        case 'types.save': {
            require_once __DIR__ . '/../inc/types.php';
            $j = json_decode((string)($in['data'] ?? ''), true);
            $list = types_sanitize($j);
            if (!$list) json_out(['ok' => false, 'error' => 'حداقل یک نوع با عنوان لازم است'], 422);
            $json = json_encode($list, JSON_UNESCAPED_UNICODE);
            if ($json === false || strlen($json) > 60000) json_out(['ok' => false, 'error' => 'حجم متن‌ها زیاد است؛ مقاله‌ها را کوتاه‌تر کنید'], 422);
            set_setting('elevator_types', $json);

            // پاک‌سازی فایل‌های صوتی بدون استفاده (قدیمی‌تر از یک روز)
            $used = [];
            foreach ($list as $t) { if ($t['audio'] !== '') $used[basename($t['audio'])] = 1; }
            $usedImg = [];
            foreach ($list as $t) { foreach (['image', 'cabin_img', 'pano'] as $fk) { if (($t[$fk] ?? '') !== '') $usedImg[basename($t[$fk])] = 1; } }
            foreach ([['/uploads/audio', 'a_*', $used], ['/uploads/types', 't_*', $usedImg]] as [$sub, $pat, $keep]) {
                $dir = dirname(__DIR__) . $sub;
                if (!is_dir($dir)) continue;
                foreach (glob($dir . '/' . $pat) ?: [] as $f) {
                    if (!isset($keep[basename($f)]) && @filemtime($f) < time() - 86400) @unlink($f);
                }
            }
            log_activity($user['username'], 'types.save', count($list) . ' نوع آسانسور ذخیره شد');
            json_out(['ok' => true, 'count' => count($list)]);
        }

        case 'types.reset': {
            set_setting('elevator_types', '');
            log_activity($user['username'], 'types.reset', 'انواع آسانسور به پیش‌فرض برگشت');
            json_out(['ok' => true]);
        }

        /* ---------- قطعات و متعلقات ---------- */
        case 'parts.save': {
            require_once __DIR__ . '/../inc/parts.php';
            $j = json_decode((string)($in['data'] ?? ''), true);
            $clean = parts_sanitize($j);
            if (!$clean || !$clean['items']) json_out(['ok' => false, 'error' => 'حداقل یک دسته و یک قطعه لازم است'], 422);
            $json = json_encode($clean, JSON_UNESCAPED_UNICODE);
            if ($json === false || strlen($json) > 60000) json_out(['ok' => false, 'error' => 'حجم متن‌ها زیاد است؛ توضیحات را کوتاه‌تر کنید'], 422);
            set_setting('elevator_parts', $json);
            $usedP = []; $usedModels = [];
            foreach ($clean['items'] as $it) { if ($it['image'] !== '') $usedP[basename($it['image'])] = 1; if (($it['model'] ?? '') !== '') $usedModels[basename($it['model'])] = 1; }
            $dirM = dirname(__DIR__) . '/uploads/models';
            if (is_dir($dirM)) foreach (glob($dirM . '/model_*.glb') ?: [] as $f) if (!isset($usedModels[basename($f)]) && @filemtime($f) < time() - 86400) @unlink($f);
            $dirP = dirname(__DIR__) . '/uploads/parts';
            if (is_dir($dirP)) {
                foreach (glob($dirP . '/p_*') ?: [] as $f) {
                    if (!isset($usedP[basename($f)]) && @filemtime($f) < time() - 86400) @unlink($f);
                }
            }
            log_activity($user['username'], 'parts.save', count($clean['items']) . ' قطعه ذخیره شد');
            json_out(['ok' => true, 'count' => count($clean['items'])]);
        }

        case 'parts.reset': {
            set_setting('elevator_parts', '');
            log_activity($user['username'], 'parts.reset', 'قطعات به پیش‌فرض برگشت');
            json_out(['ok' => true]);
        }

        /* ---------- تغییر رمز عبور ---------- */
        case 'password.change': {
            $cur = (string)($in['current'] ?? '');
            $new = (string)($in['new'] ?? '');
            if (mb_strlen($new, 'UTF-8') < 6) {
                json_out(['ok' => false, 'error' => 'رمز جدید باید حداقل ۶ کاراکتر باشد'], 422);
            }
            $row = q_one('SELECT password_hash FROM admin_users WHERE id = ?', [$user['id']]);
            if (!$row || !password_verify($cur, $row['password_hash'])) {
                json_out(['ok' => false, 'error' => 'رمز عبور فعلی نادرست است'], 401);
            }
            q('UPDATE admin_users SET password_hash = ? WHERE id = ?',
              [password_hash($new, PASSWORD_DEFAULT), $user['id']]);
            log_activity($user['username'], 'password.change', 'رمز عبور تغییر یافت');
            json_out(['ok' => true]);
        }

        /* ---------- حذف لوگو ---------- */
        case 'logo.delete': {
            $id = (int)($in['id'] ?? 0);
            if ($id <= 0) json_out(['ok' => false, 'error' => 'شناسه نامعتبر'], 422);
            q('DELETE FROM brand_assets WHERE id = ?', [$id]);
            log_activity($user['username'], 'brand.logo.delete', 'تصویر #' . $id . ' حذف شد');
            json_out(['ok' => true]);
        }

        default:
            json_out(['ok' => false, 'error' => 'عملیات ناشناخته'], 400);
    }

} catch (Throwable $ex) {
    json_out(['ok' => false, 'error' => 'خطای سرور: ' . $ex->getMessage()], 500);
}

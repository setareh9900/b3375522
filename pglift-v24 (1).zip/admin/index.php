<?php
/** پنل مدیریت — آسانسور خلیج فارس صادقی */
declare(strict_types=1);
require_once __DIR__ . '/../inc/db.php';
if (!gf_is_configured()) { header('Location: ../install.php'); exit; }
require_once __DIR__ . '/../inc/fn.php';
require_once __DIR__ . '/../inc/types.php';
require_once __DIR__ . '/../inc/parts.php';
if (!function_exists('gf_default_settings')) require_once __DIR__ . '/../inc/schema.php';

$user = require_login();
$tab  = (string)($_GET['tab'] ?? 'overview');
$allowedTabs = ['overview','requests','support','content','types','parts','settings','brand','logs'];
if (!in_array($tab, $allowedTabs, true)) $tab = 'overview';

/* ---------- داده‌ها ---------- */
$stat = [
    'total'   => (int) q_val('SELECT COUNT(*) FROM service_requests', [], 0),
    'new'     => (int) q_val("SELECT COUNT(*) FROM service_requests WHERE status='new'", [], 0),
    'prog'    => (int) q_val("SELECT COUNT(*) FROM service_requests WHERE status IN ('contacted','scheduled')", [], 0),
    'done'    => (int) q_val("SELECT COUNT(*) FROM service_requests WHERE status='done'", [], 0),
    'urgent'  => (int) q_val("SELECT COUNT(*) FROM service_requests WHERE urgency='emergency' AND status IN ('new','contacted')", [], 0),
    'support' => (int) q_val("SELECT COUNT(*) FROM support_tickets WHERE status='open'", [], 0),
];

$fStatus = (string)($_GET['status'] ?? 'all');
$search  = trim((string)($_GET['q'] ?? ''));

$reqSql = 'SELECT * FROM service_requests';
$reqArg = [];
$where  = [];
if ($fStatus !== 'all' && in_array($fStatus, ['new','contacted','scheduled','done','canceled'], true)) {
    $where[] = 'status = ?'; $reqArg[] = $fStatus;
}
if ($search !== '') {
    $where[] = '(subject LIKE ? OR customer_name LIKE ? OR phone LIKE ? OR ticket LIKE ?)';
    $like = '%' . $search . '%';
    array_push($reqArg, $like, $like, $like, $like);
}
if ($where) $reqSql .= ' WHERE ' . implode(' AND ', $where);
$reqSql .= ' ORDER BY id DESC LIMIT 200';
$requests = q_all($reqSql, $reqArg);

$tickets  = q_all('SELECT * FROM support_tickets ORDER BY id DESC LIMIT 200');
$contents = q_all('SELECT * FROM site_content ORDER BY sort_order ASC');
$setts    = q_all('SELECT * FROM site_settings ORDER BY sgroup ASC, id ASC');
$logos    = q_all('SELECT * FROM brand_assets ORDER BY id DESC');
$logs     = q_all('SELECT * FROM activity_log ORDER BY id DESC LIMIT 150');
$recent   = array_slice($requests, 0, 6);

$ST = [
    'new'       => ['جدید', 'new'],
    'contacted' => ['تماس گرفته شد', 'contacted'],
    'scheduled' => ['زمان‌بندی شده', 'scheduled'],
    'done'      => ['انجام شد', 'done'],
    'canceled'  => ['لغو شد', 'canceled'],
];
$SUP = ['open' => ['باز','open'], 'answered' => ['پاسخ داده شد','answered'], 'closed' => ['بسته شد','closed']];
$TYPE = ['service' => 'سرویس و تعمیر', 'install' => 'نصب آسانسور', 'maintenance' => 'قرارداد نگهداری'];
$URG  = ['low' => 'عادی', 'normal' => 'نرمال', 'high' => 'فوری', 'emergency' => 'اضطراری'];
$GRP  = ['brand' => 'برند', 'contact' => 'اطلاعات تماس', 'seo' => 'سئو', 'appearance' => 'ظاهر سایت', 'general' => 'عمومی'];
$cabinChoices = [
    'assets/img/cabin-copper.webp' => 'کابین مسی',
    'assets/img/cabin-red.webp' => 'کابین قرمز',
    'assets/img/cabin-black.webp' => 'کابین مشکی',
    'assets/img/types/hydraulic.webp' => 'هیدرولیک',
    'assets/img/types/gearless.webp' => 'گیرلس',
    'assets/img/types/mrl-traction.webp' => 'کششی MRL',
    'assets/img/types/home-f7.webp' => 'خانگی',
    'assets/img/customer-background.webp' => 'پس‌زمینه مشتریان',
];
$bgUploadDir = dirname(__DIR__) . '/uploads/bg';
if (is_dir($bgUploadDir)) {
    foreach (glob($bgUploadDir . '/*.{webp,png,jpg,jpeg,WEBP,PNG,JPG,JPEG}', GLOB_BRACE) ?: [] as $f) {
        $rel = 'uploads/bg/' . basename($f);
        if (!isset($cabinChoices[$rel])) $cabinChoices[$rel] = 'آپلود · ' . basename($f);
    }
}
$curCabinPath = setting('site.cabin_bg', 'assets/img/cabin-copper.webp');
if ($curCabinPath !== '' && is_bg_image_path($curCabinPath) && !isset($cabinChoices[$curCabinPath])) {
    $cabinChoices[$curCabinPath] = 'فعلی · ' . basename($curCabinPath);
}
/* اطمینان از وجود کلیدهای ظاهر (نصب‌های قدیمی) */
foreach (gf_default_settings() as $def) {
    if (($def[2] ?? '') !== 'appearance') continue;
    if (q_val('SELECT id FROM site_settings WHERE skey=?', [$def[0]])) continue;
    set_setting($def[0], (string)$def[1], (string)$def[2], (string)$def[3]);
}

$TABS = [
    'overview' => ['داشبورد', 'gauge'],
    'requests' => ['درخواست‌ها', 'wrench'],
    'support'  => ['پشتیبانی', 'life'],
    'content'  => ['محتوای سایت', 'layers'],
    'types'    => ['انواع آسانسور', 'install'],
    'parts'    => ['قطعات و متعلقات', 'gauge'],
    'settings' => ['تنظیمات', 'chip'],
    'brand'    => ['لوگو و برند', 'sparkle'],
    'logs'     => ['گزارش فعالیت', 'clock'],
];

$grouped = [];
foreach ($setts as $s) { $grouped[$s['sgroup']][] = $s; }
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>پنل مدیریت | آسانسور خلیج فارس صادقی</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/admin-themes.css?v=<?= (int) @filemtime(__DIR__ . '/../assets/css/admin-themes.css') ?>">
<script src="../assets/js/admin-themes.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/js/admin-themes.js') ?>"></script>
</head>
<body class="page-admin">
<div class="install-bg" aria-hidden="true"></div>

<!-- نوار بالا -->
<header class="adm-top">
  <div class="adm-top-in">
    <div class="brand">
      <span class="brand-mark sm"><?= icon('elevator', 22) ?></span>
      <span class="brand-text"><b>پنل مدیریت خلیج فارس</b><i>خوش آمدید، <?= e($user['username']) ?></i></span>
    </div>
    <div class="adm-top-actions">
      <label class="admin-theme-picker" for="admin-theme-select"><span>تم پنل</span><select id="admin-theme-select" aria-label="انتخاب تم پنل مدیریت"><option value="copper">کلاسیک مسی</option><option value="ocean">آبی مدرن</option><option value="forest">سبز فشرده</option></select></label>
      <a class="btn btn-ghost btn-sm" href="orders.php">سفارش‌ها</a>
      <a class="btn btn-ghost btn-sm" href="stories.php">استوری‌ها</a>
      <a class="btn btn-ghost btn-sm" href="sms.php">فراز SMS</a>
      <a class="btn btn-ghost btn-sm" href="projects.php">قرارداد و سرویس</a>
      <a class="btn btn-ghost btn-sm" href="customers.php">مدیریت مشتریان</a>
      <a class="btn btn-ghost btn-sm" href="../index.php" target="_blank"><?= icon('arrow', 15) ?> مشاهده سایت</a>
      <a class="btn btn-danger btn-sm" href="logout.php"><?= icon('close', 15) ?> خروج</a>
    </div>
  </div>
</header>

<div class="adm-shell">
  <!-- منوی کناری -->
  <aside class="adm-side">
    <nav>
      <?php foreach ($TABS as $k => [$label, $ic]): ?>
        <a class="tab <?= $tab === $k ? 'active' : '' ?>" href="?tab=<?= e($k) ?>">
          <?= icon($ic, 16) ?><span><?= e($label) ?></span>
          <?php if ($k === 'requests' && $stat['new']): ?><b class="badge red"><?= e(fa_digits($stat['new'])) ?></b><?php endif; ?>
          <?php if ($k === 'support' && $stat['support']): ?><b class="badge gold"><?= e(fa_digits($stat['support'])) ?></b><?php endif; ?>
        </a>
      <?php endforeach; ?>
    </nav>
  </aside>

  <main class="adm-main">

  <?php /* ============ داشبورد ============ */ if ($tab === 'overview'): ?>
    <div class="kpi-grid">
      <?php foreach ([
          ['کل درخواست‌ها', $stat['total'], 'wrench'],
          ['درخواست جدید',  $stat['new'],   'sparkle'],
          ['در حال انجام',  $stat['prog'],  'clock'],
          ['تیکت باز',      $stat['support'],'life'],
      ] as [$lbl, $val, $ic]): ?>
        <div class="kpi">
          <div><span><?= e($lbl) ?></span><b><?= e(fa_digits($val)) ?></b></div>
          <span class="kpi-ic"><?= icon($ic, 20) ?></span>
        </div>
      <?php endforeach; ?>
    </div>

    <?php if ($stat['urgent']): ?>
      <div class="alert-urgent"><?= icon('sparkle', 17) ?> <?= e(fa_digits($stat['urgent'])) ?> درخواست اضطراری در انتظار رسیدگی است.</div>
    <?php endif; ?>

    <div class="two-col">
      <section class="card">
        <h3 class="card-title small-title">آخرین درخواست‌ها</h3>
        <ul class="mini-list">
          <?php if (!$recent): ?><li class="empty">هنوز درخواستی ثبت نشده است.</li><?php endif; ?>
          <?php foreach ($recent as $r): ?>
            <li>
              <span class="mini-ic"><?= icon('wrench', 16) ?></span>
              <span class="mini-tx"><b><?= e($r['subject']) ?></b><i><?= e($r['customer_name']) ?> • <?= e(jdate($r['created_at'])) ?></i></span>
              <span class="pill pill-<?= e($ST[$r['status']][1] ?? 'new') ?>"><?= e($ST[$r['status']][0] ?? $r['status']) ?></span>
            </li>
          <?php endforeach; ?>
        </ul>
      </section>

      <section class="card">
        <h3 class="card-title small-title">آخرین فعالیت‌ها</h3>
        <ul class="mini-list">
          <?php if (!$logs): ?><li class="empty">فعالیتی ثبت نشده است.</li><?php endif; ?>
          <?php foreach (array_slice($logs, 0, 8) as $l): ?>
            <li>
              <span class="mini-ic"><?= icon('clock', 14) ?></span>
              <span class="mini-tx"><b><?= e($l['detail'] ?: $l['action']) ?></b><i><?= e($l['actor']) ?> • <?= e(jdate($l['created_at'])) ?></i></span>
            </li>
          <?php endforeach; ?>
        </ul>
      </section>
    </div>

  <?php /* ============ درخواست‌ها ============ */ elseif ($tab === 'requests'): ?>
    <form class="card filter-bar" method="get">
      <input type="hidden" name="tab" value="requests">
      <div class="chips">
        <?php foreach (array_merge(['all' => ['همه','']], $ST) as $k => $v): ?>
          <a class="chip <?= $fStatus === $k ? 'active' : '' ?>"
             href="?tab=requests&status=<?= e($k) ?><?= $search !== '' ? '&q=' . urlencode($search) : '' ?>"><?= e($v[0]) ?></a>
        <?php endforeach; ?>
      </div>
      <div class="search">
        <input class="input" type="search" name="q" value="<?= e($search) ?>" placeholder="جستجو: موضوع، نام، تلفن، کد پیگیری">
        <button class="btn btn-ghost btn-sm" type="submit">جستجو</button>
      </div>
    </form>

    <?php if (!$requests): ?>
      <div class="card empty-box">درخواستی با این فیلتر یافت نشد.</div>
    <?php endif; ?>

    <?php foreach ($requests as $r): ?>
      <?php $events = q_all('SELECT * FROM request_events WHERE request_id = ? ORDER BY id DESC LIMIT 20', [$r['id']]); ?>
      <details class="card req-card" data-id="<?= (int)$r['id'] ?>">
        <summary>
          <span class="req-ic <?= $r['urgency'] === 'emergency' ? 'danger' : '' ?>"><?= icon('wrench', 19) ?></span>
          <span class="req-sum">
            <b><?= e($r['subject']) ?></b>
            <i><?= e($r['customer_name']) ?> • <span dir="ltr"><?= e($r['phone']) ?></span>
               • <?= e($TYPE[$r['request_type']] ?? $r['request_type']) ?> • <?= e(jdate($r['created_at'])) ?></i>
          </span>
          <?php if ($r['urgency'] !== 'normal'): ?>
            <span class="pill pill-<?= $r['urgency'] === 'emergency' ? 'emergency' : 'scheduled' ?>"><?= e($URG[$r['urgency']]) ?></span>
          <?php endif; ?>
          <span class="pill pill-<?= e($ST[$r['status']][1] ?? 'new') ?>"><?= e($ST[$r['status']][0] ?? $r['status']) ?></span>
          <span class="chev"><?= icon('chevron', 17) ?></span>
        </summary>

        <div class="req-body">
          <div class="req-info">
            <?php foreach ([
                ['کد پیگیری', $r['ticket'], true],
                ['نوع درخواست', $TYPE[$r['request_type']] ?? $r['request_type'], false],
                ['ایمیل', $r['email'] ?: '—', true],
                ['شهر', $r['city'] ?: '—', false],
                ['آدرس', $r['address'] ?: '—', false],
                ['نوع آسانسور', $r['elevator_type'] ?: '—', false],
                ['برند فعلی', $r['brand'] ?: '—', false],
                ['طبقات / ظرفیت', fa_digits($r['floors']) . ' طبقه — ' . fa_digits($r['passengers']) . ' نفر', false],
                ['تاریخ دلخواه', $r['preferred_date'] ?: '—', false],
                ['توضیحات', $r['message'] ?: '—', false],
            ] as [$lb, $vl, $ltr]): ?>
              <div class="irow"><span><?= e($lb) ?></span><b <?= $ltr ? 'dir="ltr"' : '' ?>><?= e($vl) ?></b></div>
            <?php endforeach; ?>

            <?php if ($events): ?>
              <div class="events">
                <span class="ev-title">تاریخچه</span>
                <?php foreach ($events as $ev): ?>
                  <div class="ev"><b><?= e($ev['message']) ?></b><i><?= e($ev['actor']) ?> • <?= e(jdate($ev['created_at'])) ?></i></div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>

          <form class="req-form js-ajax" data-do="request.update">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">

            <div class="field">
              <label>وضعیت</label>
              <select class="input" name="status">
                <?php foreach ($ST as $k => $v): ?>
                  <option value="<?= e($k) ?>" <?= $r['status'] === $k ? 'selected' : '' ?>><?= e($v[0]) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="field-row two">
              <div class="field">
                <label>تکنسین</label>
                <input class="input" name="technician" value="<?= e($r['technician']) ?>" placeholder="نام تکنسین">
              </div>
              <div class="field">
                <label>برآورد هزینه (تومان)</label>
                <input class="input ltr" name="estimated_cost" type="number" min="0" value="<?= (int)$r['estimated_cost'] ?>">
              </div>
            </div>
            <div class="field">
              <label>یادداشت مدیر</label>
              <textarea class="input" name="admin_note" rows="3" placeholder="یادداشت داخلی..."><?= e($r['admin_note']) ?></textarea>
            </div>
            <div class="field">
              <label>افزودن رویداد به تاریخچه</label>
              <input class="input" name="event" placeholder="مثال: تماس گرفته شد، بازدید فردا ساعت ۱۰">
            </div>

            <div class="req-actions">
              <button class="btn btn-primary btn-sm" type="submit"><?= icon('check', 16) ?> ذخیره</button>
              <a class="btn btn-ghost btn-sm" href="tel:<?= e(en_digits($r['phone'])) ?>"><?= icon('phone', 15) ?> تماس</a>
              <button class="btn btn-danger btn-sm js-delete" type="button"
                      data-do="request.delete" data-id="<?= (int)$r['id'] ?>"
                      data-confirm="این درخواست حذف شود؟"><?= icon('trash', 15) ?> حذف</button>
            </div>
          </form>
        </div>
      </details>
    <?php endforeach; ?>

  <?php /* ============ پشتیبانی ============ */ elseif ($tab === 'support'): ?>
    <?php if (!$tickets): ?><div class="card empty-box">تیکت پشتیبانی وجود ندارد.</div><?php endif; ?>
    <?php foreach ($tickets as $t): ?>
      <section class="card">
        <div class="tk-head">
          <div>
            <h3><?= e($t['subject']) ?>
              <span class="pill pill-<?= e($SUP[$t['status']][1] ?? 'open') ?>"><?= e($SUP[$t['status']][0] ?? $t['status']) ?></span>
            </h3>
            <i class="muted small"><?= e($t['sender_name'] ?: 'ناشناس') ?> • <?= e($t['sender_email'] ?: 'بدون ایمیل') ?> • <?= e(jdate($t['created_at'])) ?></i>
          </div>
          <code dir="ltr" class="tk-code"><?= e($t['ticket']) ?></code>
        </div>

        <p class="tk-body"><?= nl2br(e($t['body'])) ?></p>

        <form class="js-ajax tk-form" data-do="support.update">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
          <div class="field">
            <label>پاسخ مدیر</label>
            <textarea class="input" name="reply" rows="3" placeholder="پاسخ خود را بنویسید..."><?= e($t['reply']) ?></textarea>
          </div>
          <div class="field-row two">
            <div class="field">
              <label>وضعیت</label>
              <select class="input" name="status">
                <?php foreach ($SUP as $k => $v): ?>
                  <option value="<?= e($k) ?>" <?= $t['status'] === $k ? 'selected' : '' ?>><?= e($v[0]) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="field">
              <label>اولویت</label>
              <select class="input" name="priority">
                <?php foreach (['low'=>'کم','normal'=>'عادی','high'=>'زیاد'] as $k => $v): ?>
                  <option value="<?= e($k) ?>" <?= $t['priority'] === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="req-actions">
            <button class="btn btn-primary btn-sm" type="submit"><?= icon('check', 16) ?> ذخیره</button>
            <?php if ($t['sender_email']): ?>
              <a class="btn btn-ghost btn-sm" href="mailto:<?= e($t['sender_email']) ?>"><?= icon('mail', 15) ?> پاسخ ایمیلی</a>
            <?php endif; ?>
            <button class="btn btn-danger btn-sm js-delete" type="button"
                    data-do="support.delete" data-id="<?= (int)$t['id'] ?>"
                    data-confirm="این تیکت حذف شود؟"><?= icon('trash', 15) ?> حذف</button>
          </div>
        </form>
      </section>
    <?php endforeach; ?>

  <?php /* ============ محتوای سایت ============ */ elseif ($tab === 'content'): ?>
    <?php foreach ($contents as $c): ?>
      <?php $cExtra = json_decode((string)$c['extra'], true) ?: []; ?>
      <section class="card">
        <div class="ct-head">
          <code class="sect-tag"><?= e($c['section']) ?></code>
          <h3><?= e($c['title'] ?: '(بدون عنوان)') ?></h3>
        </div>
        <form class="js-ajax" data-do="content.update">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
          <div class="field-row two">
            <div class="field"><label>عنوان</label>
              <input class="input" name="title" value="<?= e($c['title']) ?>"></div>
            <div class="field"><label>زیرعنوان</label>
              <input class="input" name="subtitle" value="<?= e($c['subtitle']) ?>"></div>
          </div>
          <div class="field"><label>متن</label>
            <textarea class="input" name="body" rows="3"><?= e($c['body']) ?></textarea></div>

          <?php if ($c['section'] === 'hero'): $heroHeight = max(70, min(140, (int)($cExtra['heroHeight'] ?? 100))); ?>
          <div class="field hero-size-field">
            <label for="hero-height-<?= (int)$c['id'] ?>">ارتفاع هیرو: <output data-hero-height-output><?= e(fa_digits($heroHeight)) ?>٪ ارتفاع صفحه</output></label>
            <input class="input hero-height-range" id="hero-height-<?= (int)$c['id'] ?>" type="range" name="hero_height" min="70" max="140" step="5" value="<?= $heroHeight ?>" aria-label="تنظیم ارتفاع هیرو بر حسب درصد ارتفاع صفحه">
            <small class="hint">از ۷۰٪ تا ۱۴۰٪ ارتفاع صفحه؛ تغییر اندازه بلافاصله پس از ذخیره در سایت اعمال می‌شود.</small>
          </div>
          <?php endif; ?>

          <details class="json-box">
            <summary>ویرایش داده‌های پیشرفته (JSON) — آیتم‌ها، آمار، لینک‌ها</summary>
            <textarea class="input mono" name="extra" dir="ltr" rows="12"><?= e(json_encode($cExtra, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) ?></textarea>
          </details>

          <label class="switch">
            <input type="checkbox" name="is_visible" value="1" <?= (int)$c['is_visible'] === 1 ? 'checked' : '' ?>>
            <span>نمایش این بخش در سایت</span>
          </label>

          <div class="req-actions">
            <button class="btn btn-primary btn-sm" type="submit"><?= icon('check', 16) ?> ذخیره تغییرات</button>
          </div>
        </form>
      </section>
    <?php endforeach; ?>

  <?php /* ============ انواع آسانسور ============ */ elseif ($tab === 'types'): ?>
    <?php
      $__flags = JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
    ?>
    <section class="card">
      <h3 class="card-title small-title">انواع آسانسور (مقاله + نقشه‌ی تعاملی + توضیح صوتی)</h3>
      <p class="muted small">برای هر مدل، عکس، نقاط کلیک‌پذیر روی عکس، مقاله‌ی کوتاه، مشخصات (نوع ریل و غیره) و صدا را تنظیم کنید. اگر فایل صوتی بگذارید همان پخش می‌شود؛ اگر نگذارید، متن «متن گفتار» با صدای مرورگر کاربر خوانده می‌شود (روی گوشی‌هایی که صدای فارسی دارند). برای صدای حرفه‌ای، فایل MP3/M4A آپلود کنید.</p>
      <input type="hidden" id="types-csrf" value="<?= e(csrf_token()) ?>">
      <div class="req-actions">
        <button class="btn btn-primary btn-sm" type="button" id="types-save"><?= icon('check', 16) ?> ذخیره‌ی همه</button>
        <button class="btn btn-ghost btn-sm" type="button" id="types-add">+ افزودن نوع جدید</button>
        <button class="btn btn-ghost btn-sm" type="button" id="types-reset">بازگشت به متن‌های پیش‌فرض</button>
      </div>
    </section>
    <div id="types-editor"></div>
    <script type="application/json" id="types-json"><?= json_encode(types_load(), $__flags) ?></script>
    <script type="application/json" id="types-defaults"><?= json_encode(types_defaults(), $__flags) ?></script>

  <?php /* ============ قطعات و متعلقات ============ */ elseif ($tab === 'parts'): ?>
    <?php $__pf = JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT; ?>
    <section class="card">
      <h3 class="card-title small-title">قفسه‌ی قطعات و متعلقات</h3>
      <p class="muted small">دسته‌ها (قفسه‌ها) و قطعه‌های هر دسته را بسازید یا ویرایش کنید. برای هر قطعه عکس (ترجیحاً PNG/WebP شفاف)، توضیح و مشخصات فنی (مثل نوع ریل، جنس، اندازه) وارد کنید. کاربر روی هر قطعه می‌زند و جزئیات و دکمه‌ی استعلام قیمت را می‌بیند.</p>
      <input type="hidden" id="parts-csrf" value="<?= e(csrf_token()) ?>">
      <div class="req-actions">
        <button class="btn btn-primary btn-sm" type="button" id="parts-save"><?= icon('check', 16) ?> ذخیره‌ی همه</button>
        <button class="btn btn-ghost btn-sm" type="button" id="parts-add-cat">+ دسته‌ی جدید</button>
        <button class="btn btn-ghost btn-sm" type="button" id="parts-reset">بازگشت به پیش‌فرض</button>
      </div>
    </section>
    <div id="parts-editor"></div>
    <script type="application/json" id="parts-json"><?= json_encode(parts_load(), $__pf) ?></script>

  <?php /* ============ تنظیمات ============ */ elseif ($tab === 'settings'): ?>
    <?php
      $curTheme = setting('site.theme', 'copper');
      $curFx = setting('site.bg_fx', 'sparkles');
      $curCabin = setting('site.cabin_bg', 'assets/img/cabin-copper.webp');
      $curHq = setting('site.hq_images');
    ?>
    <form class="js-ajax" data-do="settings.save" id="customer-ui-form">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <section class="card customer-ui-settings">
        <h3 class="card-title small-title">رابط کاربری پنل مشتریان</h3>
        <p class="muted small">تم و چیدمان پنل پس از خرید را انتخاب کنید. این تنظیم روی همه مشتریان اعمال می‌شود و رنگ سایت اصلی را تغییر نمی‌دهد.</p>
        <div class="field-row two">
          <div class="field"><label>تم پنل مشتری</label><select class="input" name="settings[customer.ui_kit]"><?php $ct=setting('customer.ui_kit','gradient');foreach(['gradient'=>'UI Kit — گرادیان آبی و Neumorphism','porcelain'=>'Porcelain — سفید مینیمال','azure'=>'Azure — سفید و آبی','sage'=>'Sage — سفید و سبز','sand'=>'Sand — کرم و مسی','midnight'=>'Midnight — تیره حرفه‌ای'] as $k=>$v):?><option value="<?=$k?>" <?=$ct===$k?'selected':''?>><?=$v?></option><?php endforeach ?></select></div>
          <div class="field"><label>چیدمان رابط</label><select class="input" name="settings[customer.layout]"><?php $cl=setting('customer.layout','sidebar');foreach(['sidebar'=>'سایدبار شناور — مدرن','compact'=>'فشرده — مدیریتی'] as $k=>$v):?><option value="<?=$k?>" <?=$cl===$k?'selected':''?>><?=$v?></option><?php endforeach ?></select></div>
        </div>
        <p class="muted">لوگو از بخش «برند و لوگو» مدیریت می‌شود؛ برای حذف پس‌زمینه از لوگوی PNG یا WebP شفاف استفاده کنید.</p><div class="field-row two"><div class="field"><label>نام برند پنل مشتری</label><input class="input" name="settings[customer.brand_name]" value="<?=e(setting('customer.brand_name'))?>" placeholder="پیش‌فرض نام برند سایت"></div><div class="field"><label>زیرعنوان پنل</label><input class="input" name="settings[customer.subtitle]" value="<?=e(setting('customer.subtitle','پنل اختصاصی مشتریان'))?>"></div></div><div class="field-row two"><div class="field"><label>عنوان قطعات</label><input class="input" name="settings[customer.catalog_title]" value="<?=e(setting('customer.catalog_title','قطعات آسانسور شما'))?>"></div><div class="field"><label>عنوان قراردادها</label><input class="input" name="settings[customer.contracts_title]" value="<?=e(setting('customer.contracts_title','قراردادهای من'))?>"></div><div class="field"><label>عنوان سرویس‌ها</label><input class="input" name="settings[customer.services_title]" value="<?=e(setting('customer.services_title','سرویس‌های دوره‌ای'))?>"></div></div><div class="customer-theme-preview" aria-hidden="true"><i style="background:linear-gradient(135deg,#28b8ed,#4b25ed);border-color:#dce7e9"></i><i style="background:#f7f8fa;border-color:#dfe3e8"></i><i style="background:#eff6ff;border-color:#3b82f6"></i><i style="background:#f2f8f4;border-color:#4d8061"></i><i style="background:#faf7f2;border-color:#b5794c"></i><i style="background:#161a21;border-color:#303845"></i></div>
        <div class="req-actions"><button class="btn btn-primary" type="submit">ذخیره رابط پنل مشتری</button><a class="btn btn-ghost btn-sm" href="../customer/" target="_blank">پیش‌نمایش پنل</a></div>
      </section>
    </form>
    <form class="js-ajax" data-do="settings.save" id="appearance-form">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <section class="card">
        <h3 class="card-title small-title">ظاهر سایت · تم و بک‌گراند</h3>
        <p class="muted small">تم‌های Amber / Darkmatter از ۲۱st، افکت Sparkles و ذرات دنبال‌کننده موس. تصویر کابین بک‌گراند را هم از اینجا عوض کنید.</p>
        <div class="field-row two">
          <div class="field">
            <label>تم رنگ سایت</label>
            <select class="input" name="settings[site.theme]">
              <?php foreach (['copper'=>'مسی کلاسیک','amber'=>'کهربایی (Amber Dark)','darkmatter'=>'دارک‌متر','slate'=>'اسلیت آبی'] as $k=>$lab): ?>
                <option value="<?=e($k)?>"<?= $curTheme===$k?' selected':'' ?>><?=e($lab)?></option>
              <?php endforeach ?>
            </select>
          </div>
          <div class="field">
            <label>افکت بک‌گراند</label>
            <select class="input" name="settings[site.bg_fx]">
              <?php foreach (['sparkles'=>'Sparkles (ستاره)','particles'=>'ذرات با دنبال موس','aurora'=>'شفق رنگی','mouse'=>'جرقه موس','none'=>'خاموش'] as $k=>$lab): ?>
                <option value="<?=e($k)?>"<?= $curFx===$k?' selected':'' ?>><?=e($lab)?></option>
              <?php endforeach ?>
            </select>
          </div>
        </div>
        <?php
          $slots = ['site.cabin_bg' => ['کابین اول (هیرو + بک‌گراند)', $curCabin],
                    'site.cabin_bg2' => ['کابین دوم (با اسکرول)', setting('site.cabin_bg2', 'assets/img/cabin-red.webp')],
                    'site.cabin_bg3' => ['کابین سوم (با اسکرول)', setting('site.cabin_bg3', 'assets/img/cabin-black.webp')],
                    'cinema.image' => ['کابین صحنه سینمایی اول سایت', setting('cinema.image', 'assets/img/cabin-black.webp')]];
          foreach ($slots as $sk => [$slab, $scur]):
            if ($scur !== '' && is_bg_image_path($scur) && !isset($cabinChoices[$scur])) $cabinChoices[$scur] = 'فعلی · ' . basename($scur);
        ?>
        <div class="field">
          <label><?= e($slab) ?></label>
          <div class="type-pick cabin-pick" data-slot="<?= e($sk) ?>" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:.55rem;margin:.4rem 0 1rem">
            <?php foreach ($cabinChoices as $path=>$lab): ?>
              <label style="display:grid;gap:.3rem;padding:.45rem;border-radius:12px;border:1px solid #ffffff22;background:#ffffff08;cursor:pointer;text-align:center;font-size:.72rem<?= $scur===$path ? ';outline:2px solid #d4a06a' : '' ?>">
                <input type="radio" name="settings[<?= e($sk) ?>]" value="<?=e($path)?>"<?= $scur===$path?' checked':'' ?> style="position:absolute;opacity:0;pointer-events:none">
                <img src="../<?=e($path)?>" alt="" loading="lazy" style="width:100%;height:72px;object-fit:contain;border-radius:8px;background:#0c0a09">
                <span><?=e($lab)?></span>
              </label>
            <?php endforeach ?>
          </div>
        </div>
        <?php endforeach ?>
        <div class="field-row two" style="align-items:end;margin:.2rem 0 1rem">
          <div class="field">
            <label>آپلود عکس جدید (PNG شفاف برای کابین بهتر است)</label>
            <input class="input" type="file" id="bg-file" accept="image/jpeg,image/png,image/webp">
          </div>
          <div class="field">
            <label>قرار گرفتن در</label>
            <select class="input" id="bg-slot">
              <?php foreach ($slots as $sk => [$slab, $_]): ?><option value="<?= e($sk) ?>"><?= e($slab) ?></option><?php endforeach ?>
            </select>
          </div>
        </div>
        <div class="field" style="display:flex;gap:.5rem;flex-wrap:wrap;align-items:center">
          <button type="button" class="btn btn-ghost btn-sm" id="bg-upload">آپلود و انتخاب</button>
          <span class="muted small" id="bg-upload-msg"></span>
        </div>
        <div class="field">
          <label>گالری تصاویر بک‌گراند (مسیرها با | جدا شوند)</label>
          <textarea class="input ltr" rows="3" name="settings[site.hq_images]" id="hq-images" dir="ltr"><?=e($curHq)?></textarea>
          <p class="muted small">بعد از آپلود می‌توانید مسیر را به این لیست اضافه کنید. تصاویر آپلودشده در <code>uploads/bg/</code> ذخیره می‌شوند.</p>
        </div>
        <div class="req-actions">
          <button class="btn btn-primary" type="submit"><?= icon('check', 17) ?> ذخیره ظاهر سایت</button>
          <a class="btn btn-ghost btn-sm" href="../index.php" target="_blank">پیش‌نمایش سایت</a>
        </div>
      </section>
<section class="card"><h3 class="card-title small-title">صحنه سینمایی کابین — ابتدای سایت</h3><p class="muted small">تصویر از بخش «ظاهر سایت» قابل آپلود و انتخاب است. متن هر سه مرحله را اینجا ویرایش کنید.</p><div class="field"><label>نوشتار کوچک بالای صحنه</label><input class="input" name="settings[cinema.brandline]" value="<?=e(setting('cinema.brandline','PG LIFT · SIGNATURE CABINS'))?>"></div><div class="field"><label>کلمه بزرگ پس‌زمینه</label><input class="input" name="settings[cinema.word]" value="<?=e(setting('cinema.word','ELEVATE'))?>"></div><div class="field-row two"><div class="field"><label>عنوان کوچک مرحله 1</label><input class="input" name="settings[cinema.kicker1]" value="<?=e(setting('cinema.kicker1','طراحی اختصاصی'))?>"></div><div class="field"><label>عنوان مرحله 1</label><input class="input" name="settings[cinema.title1]" value="<?=e(setting('cinema.title1','فضا را تجربه کنید.'))?>"></div></div><div class="field"><label>توضیح مرحله 1</label><textarea class="input" rows="2" name="settings[cinema.text1]"><?=e(setting('cinema.text1','هر کابین، امضای معماری ساختمان شماست.'))?></textarea></div><div class="field-row two"><div class="field"><label>عنوان کوچک مرحله 2</label><input class="input" name="settings[cinema.kicker2]" value="<?=e(setting('cinema.kicker2','جزئیات ماندگار'))?>"></div><div class="field"><label>عنوان مرحله 2</label><input class="input" name="settings[cinema.title2]" value="<?=e(setting('cinema.title2','مهندسی، در کمال زیبایی.'))?>"></div></div><div class="field"><label>توضیح مرحله 2</label><textarea class="input" rows="2" name="settings[cinema.text2]"><?=e(setting('cinema.text2','متریال، نور و فرم در هماهنگی کامل.'))?></textarea></div><div class="field-row two"><div class="field"><label>عنوان کوچک مرحله 3</label><input class="input" name="settings[cinema.kicker3]" value="<?=e(setting('cinema.kicker3','ساخته‌شده برای شما'))?>"></div><div class="field"><label>عنوان مرحله 3</label><input class="input" name="settings[cinema.title3]" value="<?=e(setting('cinema.title3','فراتر از یک آسانسور.'))?>"></div></div><div class="field"><label>متن دکمه مرحله آخر</label><input class="input" name="settings[cinema.cta]" value="<?=e(setting('cinema.cta','طراحی کابین پروژه شما'))?>"></div><div class="req-actions"><button class="btn btn-primary" type="submit">ذخیره متن صحنه سینمایی</button></div></section>
    </form>
    <script>
    (function(){
      var csrf = <?= json_encode(csrf_token(), JSON_UNESCAPED_UNICODE) ?>;
      var file = document.getElementById('bg-file'), btn = document.getElementById('bg-upload'),
          msg = document.getElementById('bg-upload-msg'), slot = document.getElementById('bg-slot'),
          hq = document.getElementById('hq-images');
      if (!btn || !file) return;
      var LS = 'display:grid;gap:.3rem;padding:.45rem;border-radius:12px;border:1px solid #ffffff22;background:#ffffff08;cursor:pointer;text-align:center;font-size:.72rem';
      function mark(box){ box.querySelectorAll('label').forEach(function(l){ l.style.outline = l.querySelector('input:checked') ? '2px solid #d4a06a' : ''; }); }
      document.querySelectorAll('.cabin-pick').forEach(function(box){ box.addEventListener('change', function(){ mark(box); }); });
      function addOption(box, key, path){
        var lab = document.createElement('label'); lab.style.cssText = LS;
        lab.innerHTML = '<input type="radio" style="position:absolute;opacity:0;pointer-events:none"><img alt="" style="width:100%;height:72px;object-fit:contain;border-radius:8px;background:#0c0a09"><span></span>';
        var r = lab.querySelector('input'); r.name = 'settings[' + key + ']'; r.value = path;
        lab.querySelector('img').src = '../' + path; lab.querySelector('span').textContent = 'آپلود · ' + path.split('/').pop();
        box.appendChild(lab); return r;
      }
      btn.addEventListener('click', function(){
        if (!file.files || !file.files[0]) { msg.textContent = 'ابتدا فایل را انتخاب کنید.'; return; }
        var key = slot.value;
        btn.disabled = true; btn.textContent = 'در حال آپلود…'; msg.textContent = '';
        var fd = new FormData(); fd.append('csrf', csrf); fd.append('file', file.files[0]);
        fetch('upload-bg.php', { method:'POST', body:fd, credentials:'same-origin' })
          .then(function(r){ return r.text().then(function(t){ try { return JSON.parse(t); } catch(e){ return { ok:false, error:'پاسخ نامعتبر از سرور (احتمالاً حجم فایل از حد هاست بیشتر است)' }; } }); })
          .then(function(j){
            if (!j.ok) { msg.textContent = j.error || 'خطا در آپلود'; return; }
            var path = j.path, chosen = null;
            document.querySelectorAll('.cabin-pick').forEach(function(box){
              var k = box.getAttribute('data-slot'), r = addOption(box, k, path);
              if (k === key) { box.querySelectorAll('input[type=radio]').forEach(function(x){ x.checked = false; }); r.checked = true; chosen = box; }
              mark(box);
            });
            if (hq) { var cur = (hq.value || '').trim(); if (cur.indexOf(path) === -1) hq.value = cur ? (cur + '|' + path) : path; }
            msg.textContent = 'آپلود شد — «ذخیره ظاهر سایت» را بزنید.'; file.value = '';
          })
          .catch(function(){ msg.textContent = 'ارتباط برقرار نشد.'; })
          .finally(function(){ btn.disabled = false; btn.textContent = 'آپلود و انتخاب'; });
      });
    })();
    </script>

    <form class="js-ajax" data-do="settings.save" id="settings-form">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <?php foreach ($grouped as $g => $rows):
        if ($g === 'appearance') continue; /* در فرم جداگانه بالا */
        ?>
        <section class="card">
          <h3 class="card-title small-title"><?= e($GRP[$g] ?? $g) ?></h3>
          <div class="field-row two">
            <?php foreach ($rows as $s): ?>
              <div class="field">
                <label><?= e($s['slabel'] ?: $s['skey']) ?> <code class="k"><?= e($s['skey']) ?></code></label>
                <?php if (mb_strlen((string)$s['svalue'], 'UTF-8') > 90): ?>
                  <textarea class="input" rows="3" name="settings[<?= e($s['skey']) ?>]"><?= e($s['svalue']) ?></textarea>
                <?php else: ?>
                  <input class="input<?= preg_match('/phone|mobile|whatsapp/', $s['skey']) ? ' ltr' : '' ?>"
                         name="settings[<?= e($s['skey']) ?>]" value="<?= e($s['svalue']) ?>">
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
        </section>
      <?php endforeach; ?>
      <div class="req-actions sticky-save">
        <button class="btn btn-primary" type="submit"><?= icon('check', 17) ?> ذخیره همه تنظیمات</button>
      </div>
    </form>

    <section class="card">
      <h3 class="card-title small-title">تغییر رمز عبور</h3>
      <p class="muted small">برای امنیت بیشتر، رمز پیش‌فرض را حتماً تغییر دهید.</p>
      <form class="js-ajax" data-do="password.change" data-reset="1">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <div class="field-row three">
          <div class="field"><label>رمز فعلی</label><input class="input ltr" type="password" name="current" required></div>
          <div class="field"><label>رمز جدید</label><input class="input ltr" type="password" name="new" required minlength="6"></div>
          <div class="field"><label>تکرار رمز جدید</label><input class="input ltr" type="password" name="new2" required minlength="6"></div>
        </div>
        <div class="req-actions">
          <button class="btn btn-primary btn-sm" type="submit"><?= icon('shield', 16) ?> تغییر رمز عبور</button>
        </div>
      </form>
    </section>

    <section class="card">
      <h3 class="card-title small-title">کش CDN و فایل‌ها</h3>
      <p class="muted small">با این دکمه، رشته‌ی نسخه‌ی فایل‌های CSS/JS سایت عوض می‌شود تا کش CDN و مرورگرها بشکند؛ اگر شناسه‌ی Zone و توکن Cloudflare را ذخیره کنید، درخواست purge_everything هم به Cloudflare ارسال می‌شود.</p>
      <form class="js-ajax" data-do="settings.save">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <div class="field-row two">
          <div class="field"><label>شناسه‌ی Zone کلودفلر <code class="k">cf_zone</code></label>
            <input class="input ltr" name="settings[cf_zone]" value="<?= e(setting('cf_zone')) ?>" placeholder="اختیاری"></div>
          <div class="field"><label>توکن API کلودفلر <code class="k">cf_token</code></label>
            <input class="input ltr" name="settings[cf_token]" value="<?= e(setting('cf_token')) ?>" placeholder="اختیاری"></div>
        </div>
        <div class="req-actions"><button class="btn btn-ghost btn-sm" type="submit"><?= icon('check', 16) ?> ذخیره اعتبارنامه</button></div>
      </form>
      <form class="js-ajax" data-do="cache.purge">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <div class="req-actions"><button class="btn btn-primary btn-sm" type="submit"><?= icon('gear', 16) ?> پاک کردن کش CDN</button></div>
      </form>
    </section>

  <?php /* ============ لوگو و برند ============ */ elseif ($tab === 'brand'): ?>
    <section class="card">
      <h3 class="card-title small-title">مدیریت لوگو و تصاویر برند</h3>
      <p class="muted small">فرمت‌های PNG، JPG، WEBP و SVG تا حجم ۲ مگابایت پذیرفته می‌شود. بهترین کیفیت با SVG یا PNG شفاف (بدون پس‌زمینه) است؛ اگر لوگوی شما پس‌زمینه‌ی تک‌رنگ دارد، گزینه‌ی «حذف خودکار پس‌زمینه» را تیک بزنید.</p>

      <div class="logo-grid">
        <?php foreach (['logo' => 'لوگوی اصلی', 'favicon' => 'فاوآیکون سایت'] as $kind => $label):
          $active = null;
          foreach ($logos as $L) { if ($L['kind'] === $kind && (int)$L['is_active'] === 1) { $active = $L; break; } }
        ?>
          <div class="logo-box">
            <b><?= e($label) ?></b>
            <div class="logo-prev">
              <?php if ($active): ?><img src="<?= e($active['data_url']) ?>" alt="<?= e($label) ?>">
              <?php else: ?><span class="muted small">تصویری ثبت نشده</span><?php endif; ?>
            </div>
            <form class="js-upload" data-kind="<?= e($kind) ?>">
              <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="kind" value="<?= e($kind) ?>">
              <input type="file" name="file" accept="image/png,image/jpeg,image/webp,image/svg+xml,.svg" required>
              <label class="bg-opt"><input type="checkbox" class="js-bgremove"> حذف خودکار پس‌زمینه‌ی تک‌رنگ (برای PNG / JPG)</label>
              <div class="bg-tol" hidden>
                <label>حساسیت حذف <output class="js-tol-out">36</output></label>
                <input type="range" class="js-tol" min="8" max="90" value="36">
              </div>
              <div class="bg-prev" hidden><canvas></canvas></div>
              <div class="req-actions">
                <button class="btn btn-primary btn-sm" type="submit"><?= icon('install', 15) ?> آپلود</button>
                <?php if ($active): ?>
                  <button class="btn btn-danger btn-sm js-delete" type="button" data-do="logo.delete"
                          data-id="<?= (int)$active['id'] ?>" data-confirm="این تصویر حذف شود؟"><?= icon('trash', 15) ?> حذف</button>
                <?php endif; ?>
              </div>
            </form>
          </div>
        <?php endforeach; ?>
      </div>
    </section>


    <section class="card">
      <h3 class="card-title small-title">اندازه‌ی لوگو در سایت</h3>
      <p class="muted small">ارتفاع و عرض لوگو را جدا برای هدر (بالای سایت) و فوتر تنظیم کنید. عرض «۰» یعنی خودکار؛ تصویر هیچ‌وقت کشیده نمی‌شود و نسبت اصلی‌اش حفظ می‌شود. در موبایل خودکار کمی کوچک‌تر نمایش داده می‌شود.</p>
      <?php
        $__logoNow = null;
        foreach ($logos as $L) { if ($L['kind'] === 'logo' && (int)$L['is_active'] === 1) { $__logoNow = $L['data_url']; break; } }
        $lv = function (string $k, int $d, int $mx): int { $v = (int) setting($k, (string)$d); return max(0, min($mx, $v)); };
      ?>
      <form class="js-ajax js-logo-size" data-do="settings.save">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <div class="logo-size-grid">
          <?php foreach ([
            ['nav', 'هدر (بالای سایت)', 48, 20, 160],
            ['ft',  'فوتر (پایین سایت)', 64, 20, 200],
          ] as [$z, $zl, $dh, $mnh, $mxh]): ?>
          <div class="logo-size-box" data-zone="<?= $z ?>">
            <b><?= e($zl) ?></b>
            <div class="size-prev"><?php if ($__logoNow): ?><img src="<?= e($__logoNow) ?>" alt=""><?php else: ?><span class="muted small">ابتدا لوگو آپلود کنید</span><?php endif; ?></div>
            <div class="field"><label>ارتفاع <output data-out="h"><?= $lv('logo_'.$z.'_h', $dh, $mxh) ?></output> پیکسل</label>
              <input type="range" class="js-lh" name="settings[logo_<?= $z ?>_h]" min="<?= $mnh ?>" max="<?= $mxh ?>" value="<?= $lv('logo_'.$z.'_h', $dh, $mxh) ?>"></div>
            <div class="field"><label>عرض <output data-out="w"><?= ($w = $lv('logo_'.$z.'_w', 0, 480)) ? $w . ' پیکسل' : 'خودکار' ?></output></label>
              <input type="range" class="js-lw" name="settings[logo_<?= $z ?>_w]" min="0" max="480" step="2" value="<?= $lv('logo_'.$z.'_w', 0, 480) ?>"></div>
          </div>
          <?php endforeach; ?>
        </div>
        <div class="req-actions">
          <button class="btn btn-primary btn-sm" type="submit"><?= icon('check', 16) ?> ذخیره‌ی اندازه‌ها</button>
          <button class="btn btn-ghost btn-sm js-logo-reset" type="button">بازگشت به پیش‌فرض</button>
        </div>
      </form>
    </section>

    <section class="card">
      <h3 class="card-title small-title">همه تصاویر ذخیره‌شده</h3>
      <div class="thumbs">
        <?php if (!$logos): ?><p class="muted small">تصویری بارگذاری نشده است.</p><?php endif; ?>
        <?php foreach ($logos as $L): ?>
          <figure class="thumb">
            <img src="<?= e($L['data_url']) ?>" alt="<?= e($L['kind']) ?>">
            <figcaption><?= e($L['kind']) ?></figcaption>
            <button class="thumb-x js-delete" type="button" data-do="logo.delete"
                    data-id="<?= (int)$L['id'] ?>" data-confirm="حذف شود؟" aria-label="حذف">×</button>
          </figure>
        <?php endforeach; ?>
      </div>
    </section>

  <?php /* ============ گزارش فعالیت ============ */ elseif ($tab === 'logs'): ?>
    <section class="card">
      <h3 class="card-title small-title">گزارش فعالیت‌ها</h3>
      <div class="table-wrap">
        <table class="tbl">
          <thead><tr><th>کاربر</th><th>عملیات</th><th>جزئیات</th><th>زمان</th></tr></thead>
          <tbody>
            <?php if (!$logs): ?><tr><td colspan="4" class="empty">فعالیتی ثبت نشده است.</td></tr><?php endif; ?>
            <?php foreach ($logs as $l): ?>
              <tr>
                <td class="acc"><?= e($l['actor']) ?></td>
                <td><code><?= e($l['action']) ?></code></td>
                <td><?= e($l['detail']) ?></td>
                <td class="muted small"><?= e(jdate($l['created_at'])) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>
  <?php endif; ?>

  </main>
</div>

<div class="toast" id="toast" hidden></div>
<script src="../assets/js/admin.js"></script>
<?php if ($tab === 'parts'): ?><script src="../assets/js/admin-parts.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/js/admin-parts.js') ?>"></script><?php endif; ?>
<?php if ($tab === 'types'): ?><script src="../assets/js/admin-types.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/js/admin-types.js') ?>"></script><?php endif; ?>
</body>
</html>

<?php
/** آپلود لوگو / فاوآیکون — ذخیره به صورت data-url در پایگاه داده */
declare(strict_types=1);
require_once __DIR__ . '/../inc/fn.php';

$user = require_login_api();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['ok' => false, 'error' => 'متد نامعتبر'], 405);
}
csrf_require($_POST['csrf'] ?? null);

$kind = (string)($_POST['kind'] ?? 'logo');
if (!in_array($kind, ['logo', 'favicon'], true)) $kind = 'logo';

if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    json_out(['ok' => false, 'error' => 'فایلی ارسال نشد یا آپلود ناموفق بود'], 422);
}

$f = $_FILES['file'];
$MAX = 2 * 1024 * 1024; // ۲ مگابایت

if ($f['size'] > $MAX) {
    json_out(['ok' => false, 'error' => 'حجم فایل باید کمتر از ۲ مگابایت باشد'], 422);
}

$allowed = [
    'image/png'     => 'png',
    'image/jpeg'    => 'jpg',
    'image/webp'    => 'webp',
    'image/svg+xml' => 'svg',
];

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime  = (string) $finfo->file($f['tmp_name']);

// SVG گاهی text/plain یا text/xml تشخیص داده می‌شود
$ext = strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION));
if ($ext === 'svg' && in_array($mime, ['text/plain', 'text/xml', 'application/xml', 'image/svg+xml'], true)) {
    $mime = 'image/svg+xml';
}

if (!isset($allowed[$mime])) {
    json_out(['ok' => false, 'error' => 'فقط فایل PNG، JPG، WEBP یا SVG مجاز است'], 422);
}

$bytes = (string) file_get_contents($f['tmp_name']);
if ($bytes === '') {
    json_out(['ok' => false, 'error' => 'فایل خالی است'], 422);
}

// پاک‌سازی ساده SVG از اسکریپت
if ($mime === 'image/svg+xml') {
    if (preg_match('/<script|<foreignObject|<iframe|<embed|<object|\bon[a-z]+\s*=|javascript:|data:text\/html/i', $bytes)) {
        json_out(['ok' => false, 'error' => 'فایل SVG حاوی کد اجرایی است و پذیرفته نشد'], 422);
    }
}

$dataUrl = 'data:' . $mime . ';base64,' . base64_encode($bytes);

try {
    $exists = q_one('SELECT id FROM brand_assets WHERE kind = ? AND is_active = 1 ORDER BY id DESC', [$kind]);
    if ($exists) {
        q('UPDATE brand_assets SET data_url = ?, created_at = ? WHERE id = ?',
          [$dataUrl, now(), $exists['id']]);
    } else {
        q('INSERT INTO brand_assets (kind, label, data_url, is_active, created_at) VALUES (?,?,?,1,?)',
          [$kind, $kind === 'logo' ? 'لوگوی اصلی' : 'فاوآیکون سایت', $dataUrl, now()]);
    }
    log_activity($user['username'], 'brand.logo.update', 'تصویر ' . $kind . ' به‌روزرسانی شد');
    json_out(['ok' => true, 'dataUrl' => $dataUrl]);

} catch (Throwable $ex) {
    json_out(['ok' => false, 'error' => 'خطا در ذخیره تصویر'], 500);
}

<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/fn.php';
if (!gf_is_configured()) redirect('../install.php');
$user = require_login();
require_once __DIR__.'/../inc/customer-schema.php';
require_once __DIR__.'/../inc/parts.php';
require_once __DIR__.'/../inc/types.php';
customer_schema();
header('Cache-Control: no-store');
$catalog = parts_load()['items'];
$catalogImages = [];
foreach ($catalog as $item) {
    $img = (string)($item['image'] ?? '');
    if (preg_match('#^(assets/img/parts|uploads/parts)/[A-Za-z0-9_.-]+\.(webp|png|jpg|jpeg)$#i', $img)) $catalogImages[$img] = (string)$item['title'];
}
$elevatorTypes = array_values(array_filter(types_load(), static fn($t) => !empty($t['active'])));
$typeById = [];
foreach ($elevatorTypes as $t) $typeById[(string)$t['id']] = $t;

$error = '';
$magicUrl = '';
$id = max(0, (int)($_GET['id'] ?? $_POST['customer_id'] ?? 0));
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) { http_response_code(403); exit('توکن امنیتی نامعتبر است.'); }
    try {
        $action = $_POST['action'] ?? '';
        if ($action === 'account') {
            $name = clean((string)($_POST['name'] ?? ''), 200);
            $username = trim((string)($_POST['username'] ?? ''));
            $password = (string)($_POST['password'] ?? '');
            $details = clean_multiline((string)($_POST['details'] ?? ''), 4000);
            $phone = en_digits(clean((string)($_POST['phone'] ?? ''),30));
            if ($phone !== '' && !preg_match('/^09\d{9}$/',$phone)) throw new RuntimeException('موبایل مشتری باید ۱۱ رقم و با ۰۹ شروع شود.');
            $elevatorType = clean((string)($_POST['elevator_type'] ?? ''), 80);
            $elevatorAudio = clean((string)($_POST['elevator_audio'] ?? ''), 255);
            if ($elevatorType !== '' && !isset($typeById[$elevatorType])) throw new RuntimeException('نوع آسانسور نامعتبر است.');
            if ($elevatorAudio !== '' && !preg_match('#^uploads/audio/[a-zA-Z0-9_.-]+\.(mp3|m4a|ogg|wav|webm)$#i', $elevatorAudio)) {
                throw new RuntimeException('مسیر فایل صوتی نامعتبر است.');
            }
            if (!$name || !preg_match('/^[a-zA-Z0-9_.-]{3,100}$/D', $username) || (!$id && strlen($password) < 8) || ($password !== '' && strlen($password) < 8)) throw new RuntimeException('نام، نام کاربری لاتین (حداقل ۳ حرف) و رمز حداقل ۸ کاراکتری را بررسی کنید.');
            if ($id) {
                if (!q_one('SELECT id FROM customer_accounts WHERE id=?', [$id])) throw new RuntimeException('مشتری پیدا نشد.');
                q('UPDATE customer_accounts SET name=?, username=?, phone=?, elevator_details=?, elevator_type=?, elevator_audio=? WHERE id=?', [$name,$username,$phone,$details,$elevatorType,$elevatorAudio,$id]);
                if ($password !== '') q('UPDATE customer_accounts SET password_hash=? WHERE id=?', [password_hash($password, PASSWORD_DEFAULT),$id]);
            } else {
                q('INSERT INTO customer_accounts (name,username,password_hash,phone,elevator_details,elevator_type,elevator_audio) VALUES (?,?,?,?,?,?,?)', [$name,$username,password_hash($password,PASSWORD_DEFAULT),$phone,$details,$elevatorType,$elevatorAudio]);
                $id = last_id();
            }
        } elseif ($action === 'magic_link') {
            if (!q_one('SELECT id FROM customer_accounts WHERE id=?', [$id])) throw new RuntimeException('مشتری پیدا نشد.');
            $magicUrl = customer_make_magic_link($id);
            log_activity($user['username'], 'customer.magic_link', 'مشتری #'.$id);
            // fall through to render with URL (no redirect)
        } elseif ($action === 'disable_magic_link') {
            q('UPDATE customer_accounts SET login_link_enabled=0 WHERE id=?', [$id]);
            log_activity($user['username'], 'customer.disable_magic_link', 'مشتری #'.$id);
        } elseif ($action === 'enable_magic_link') {
            if (!q_one('SELECT id FROM customer_accounts WHERE id=?', [$id])) throw new RuntimeException('مشتری پیدا نشد.');
            $magicUrl = customer_make_magic_link($id, false);
            log_activity($user['username'], 'customer.enable_magic_link', 'مشتری #'.$id);
        } elseif ($action === 'part') {
            if (!q_one('SELECT id FROM customer_accounts WHERE id=?', [$id])) throw new RuntimeException('مشتری پیدا نشد.');
            $partId = (int)($_POST['part_id'] ?? 0);
            $name = clean((string)($_POST['part_name'] ?? ''),200);
            if (!$name) throw new RuntimeException('نام قطعه الزامی است.');
            $existing = $partId ? q_one('SELECT image_ref FROM customer_parts WHERE id=? AND customer_id=?', [$partId, $id]) : null;
            if ($partId && !$existing) throw new RuntimeException('قطعه پیدا نشد.');
            $choice = (string)($_POST['image_choice'] ?? 'keep');
            if ($choice === 'keep') $image = $existing['image_ref'] ?? '';
            elseif ($choice === 'none') $image = '';
            elseif (isset($catalogImages[$choice])) $image = $choice;
            else throw new RuntimeException('تصویر انتخاب‌شده معتبر نیست.');
            $file = $_FILES['part_image'] ?? null;
            if ($file && $file['error'] !== UPLOAD_ERR_NO_FILE) {
                if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > 5 * 1024 * 1024) throw new RuntimeException('آپلود ناموفق است؛ حجم تصویر حداکثر ۵ مگابایت باشد.');
                $info = @getimagesize($file['tmp_name']);
                $allowed = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
                if (!$info || !isset($allowed[$info[2]]) || $info[0] > 4000 || $info[1] > 4000) throw new RuntimeException('تصویر JPG، PNG یا WebP با ابعاد حداکثر ۴۰۰۰ پیکسل انتخاب کنید.');
                $dir = dirname(__DIR__).'/data/customer-images';
                if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) throw new RuntimeException('پوشه تصاویر قابل ساخت نیست.');
                $image = 'private/'.bin2hex(random_bytes(16)).'.'.$allowed[$info[2]];
                if (!move_uploaded_file($file['tmp_name'], $dir.'/'.basename($image))) throw new RuntimeException('ذخیره تصویر ناموفق بود.');
            }
            $args = [$name,clean_multiline((string)($_POST['specifications'] ?? ''),4000),clean((string)($_POST['quantity'] ?? ''),100),clean((string)($_POST['price'] ?? ''),100),$image,clean((string)($_POST['brand'] ?? ''),200),clean((string)($_POST['model'] ?? ''),200),clean((string)($_POST['serial_number'] ?? ''),200),clean((string)($_POST['installed_at'] ?? ''),100),clean((string)($_POST['warranty'] ?? ''),200)];
            if ($partId) q('UPDATE customer_parts SET name=?, specifications=?, quantity=?, price=?, image_ref=?, brand=?, model=?, serial_number=?, installed_at=?, warranty=? WHERE id=? AND customer_id=?', [...$args,$partId,$id]);
            else q('INSERT INTO customer_parts (name,specifications,quantity,price,image_ref,brand,model,serial_number,installed_at,warranty,customer_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)', [...$args,$id]);
        } elseif ($action === 'delete_part') {
            q('DELETE FROM customer_parts WHERE id=? AND customer_id=?', [(int)($_POST['part_id'] ?? 0),$id]);
        } else throw new RuntimeException('عملیات نامعتبر است.');
        if (!in_array($action, ['magic_link', 'enable_magic_link'], true)) {
            log_activity($user['username'], 'customer.'.$action, 'مشتری #'.$id);
            redirect('customers.php?id='.$id.'&saved=1');
        }
    } catch (Throwable $ex) { $error = $ex instanceof RuntimeException && !($ex instanceof PDOException) ? $ex->getMessage() : 'ذخیره انجام نشد؛ نام کاربری تکراری یا اطلاعات نامعتبر است.'; }
}
$customers = q_all('SELECT id,name,username FROM customer_accounts ORDER BY id DESC');
$customer = $id ? q_one('SELECT * FROM customer_accounts WHERE id=?', [$id]) : null;
$parts = $customer ? q_all('SELECT * FROM customer_parts WHERE customer_id=? ORDER BY id DESC', [$id]) : [];
$editing = null;
foreach ($parts as $part) if ((int)$part['id'] === (int)($_GET['part'] ?? 0)) $editing = $part;
if ($customer && !empty($customer['login_token']) && !empty($customer['login_link_enabled']) && !$magicUrl) $magicUrl = customer_make_magic_link($id, false);
$currentType = (string)($customer['elevator_type'] ?? '');
$currentAudio = (string)($customer['elevator_audio'] ?? '');
$csrf = csrf_token();
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>مدیریت مشتریان</title><link rel="stylesheet" href="../assets/css/customer.css?v=<?= (int) @filemtime(__DIR__ . '/../assets/css/customer.css') ?>"><link rel="stylesheet" href="../assets/css/admin-themes.css?v=<?= (int) @filemtime(__DIR__ . '/../assets/css/admin-themes.css') ?>">
<script src="../assets/js/admin-themes.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/js/admin-themes.js') ?>"></script>
<style>
.type-pick{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:.6rem;margin:.4rem 0 1rem}
.type-pick label{display:grid;gap:.35rem;padding:.55rem;border-radius:14px;border:1px solid #ffffff22;background:#ffffff08;cursor:pointer;text-align:center;font-size:.78rem}
.type-pick label.on,.type-pick input:checked+span{outline:2px solid #d4a06a}
.type-pick input{position:absolute;opacity:0;pointer-events:none}
.type-pick img{width:100%;height:88px;object-fit:contain;border-radius:10px;background:#0c0a09}
.magic-box{margin-top:1rem;padding:1rem;border-radius:14px;border:1px dashed #d4a06a66;background:#d4a06a12}
.magic-box input{width:100%;direction:ltr;font-size:.82rem;padding:.55rem .7rem;border-radius:10px;border:1px solid #ffffff33;background:#0006;color:inherit}
.audio-box{margin:.5rem 0 1rem;padding:.9rem;border-radius:14px;border:1px solid #ffffff22;background:#ffffff08}
.audio-box audio{width:100%;margin:.4rem 0}.audio-box .row{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center}
</style>
</head><body class="admin-customers"><main class="wrap">
<header><h1>مدیریت مشتریان</h1><label class="admin-theme-picker" for="admin-theme-select"><span>تم پنل</span><select id="admin-theme-select" aria-label="انتخاب تم پنل مدیریت"><option value="copper">کلاسیک مسی</option><option value="ocean">آبی مدرن</option><option value="forest">سبز فشرده</option></select></label><nav><a href="index.php">بازگشت به مدیریت</a> <a href="../customer/">ورود مشتریان</a></nav></header>
<?php if ($error): ?><p class="notice error"><?=e($error)?></p><?php elseif (isset($_GET['saved'])): ?><p class="notice">اطلاعات ذخیره شد.</p><?php endif ?>
<div class="columns"><aside class="card"><h2>مشتریان</h2><a href="customers.php">+ مشتری جدید</a><ul><?php foreach ($customers as $c): ?><li><a href="?id=<?=(int)$c['id']?>"><?=e($c['name'])?> (<?=e($c['username'])?>)</a></li><?php endforeach ?></ul></aside><section>
<form method="post" class="card" id="account-form"><h2><?=$customer ? 'ویرایش مشتری' : 'مشتری جدید'?></h2><?=csrf_field()?><input type="hidden" name="action" value="account"><input type="hidden" name="customer_id" value="<?= $customer ? (int)$customer['id'] : 0 ?>">
<label>نام مشتری<input required name="name" maxlength="200" value="<?=e($customer['name'] ?? '')?>"></label>
<label>موبایل مشتری (برای پیامک)<input name="phone" inputmode="numeric" dir="ltr" maxlength="11" placeholder="09121234567" value="<?=e($customer['phone'] ?? '')?>"></label>
<label>نام کاربری لاتین<input required name="username" pattern="[A-Za-z0-9_.-]{3,100}" value="<?=e($customer['username'] ?? '')?>" dir="ltr"></label>
<label>رمز عبور <?= $customer ? '(برای عدم تغییر خالی بگذارید)' : '(حداقل ۸ کاراکتر)' ?><input type="password" name="password" minlength="8" autocomplete="new-password" <?=$customer ? '' : 'required'?>></label>
<label>نوع آسانسور مشتری</label>
<div class="type-pick" role="radiogroup" aria-label="نوع آسانسور">
  <label><input type="radio" name="elevator_type" value=""<?= $currentType === '' ? ' checked' : '' ?>><span>بدون انتخاب</span></label>
  <?php foreach ($elevatorTypes as $t):
    $tid = (string)$t['id']; $timg = (string)($t['image'] ?? ''); ?>
  <label class="<?= $currentType === $tid ? 'on' : '' ?>">
    <input type="radio" name="elevator_type" value="<?=e($tid)?>"<?= $currentType === $tid ? ' checked' : '' ?>>
    <?php if ($timg): ?><img src="../<?=e($timg)?>" alt=""><?php endif ?>
    <span><?=e((string)$t['title'])?></span>
  </label>
  <?php endforeach ?>
</div>
<label>مشخصات آسانسور<textarea name="details" rows="4" id="elevator-details"><?=e($customer['elevator_details'] ?? '')?></textarea></label>
<label>فایل صوتی مشخصات (شنیدن در پنل مشتری)</label>
<div class="audio-box" id="audio-box">
  <input type="hidden" name="elevator_audio" id="elevator_audio" value="<?=e($currentAudio)?>">
  <div id="audio-preview"><?php if ($currentAudio): ?>
    <audio controls preload="none" src="../<?=e($currentAudio)?>"></audio>
    <p class="hint" dir="ltr"><?=e($currentAudio)?></p>
  <?php else: ?><p class="hint">فایلی انتخاب نشده؛ اگر خالی بماند، متن مشخصات با صدای مرورگر خوانده می‌شود.</p><?php endif ?></div>
  <div class="row">
    <input type="file" id="audio-file" accept="audio/mpeg,audio/mp4,audio/x-m4a,audio/ogg,audio/wav,.mp3,.m4a,.ogg,.wav">
    <button type="button" class="secondary" id="audio-upload">آپلود فایل صوتی</button>
    <button type="button" class="secondary" id="audio-clear"<?= $currentAudio ? '' : ' hidden' ?>>حذف صوت</button>
  </div>
  <p class="hint" id="audio-msg"></p>
</div>
<button>ذخیره مشتری</button></form>

<?php if ($customer): ?>
<form method="post" class="card">
  <?=csrf_field()?><input type="hidden" name="customer_id" value="<?=$id?>">
  <h2>لینک ورود دائمی و بدون رمز</h2>
  <p class="hint">لینک تاریخ انقضا ندارد و هر بار قابل استفاده است. فقط با «لینک جدید» باطل و با «غیرفعال‌سازی» متوقف می‌شود.</p>
  <p class="hint">وضعیت: <b><?=!empty($customer['login_link_enabled'])?'فعال':'غیرفعال'?></b></p>
  <button type="submit" name="action" value="magic_link" onclick="return !document.getElementById('magic-url')||confirm('لینک فعلی باطل و لینک جدید ساخته شود؟')">صدور لینک جدید</button>
  <button type="submit" class="secondary" name="action" value="<?=!empty($customer['login_link_enabled'])?'disable_magic_link':'enable_magic_link'?>"><?=!empty($customer['login_link_enabled'])?'غیرفعال‌سازی لینک':'فعال‌سازی لینک'?></button>
  <?php if ($magicUrl): ?>
  <div class="magic-box">
    <label>لینک آماده — کپی و برای مشتری بفرستید
      <input id="magic-url" readonly value="<?=e($magicUrl)?>" onclick="this.select()">
    </label>
    <button type="button" class="secondary" onclick="navigator.clipboard.writeText(document.getElementById('magic-url').value)">کپی لینک</button>
  </div>
  <?php endif ?>
</form>

<form method="post" enctype="multipart/form-data" class="card"><h2><?=$editing ? 'ویرایش قطعه' : 'افزودن قطعه'?></h2><?=csrf_field()?><input type="hidden" name="action" value="part"><input type="hidden" name="customer_id" value="<?=$id?>"><input type="hidden" name="part_id" value="<?=(int)($editing['id'] ?? 0)?>"><label>نام قطعه<input name="part_name" required maxlength="200" value="<?=e($editing['name'] ?? '')?>"></label><label>مشخصات<textarea name="specifications" rows="3"><?=e($editing['specifications'] ?? '')?></textarea></label><div class="admin-details-grid"><label>برند / سازنده<input name="brand" maxlength="200" value="<?=e($editing['brand'] ?? '')?>"></label><label>مدل<input name="model" maxlength="200" value="<?=e($editing['model'] ?? '')?>"></label><label>شماره سریال<input name="serial_number" maxlength="200" value="<?=e($editing['serial_number'] ?? '')?>"></label><label>تاریخ نصب<input name="installed_at" maxlength="100" placeholder="مثلاً ۱۴۰۴/۰۵/۰۱" value="<?=e($editing['installed_at'] ?? '')?>"></label><label>گارانتی / پایان ضمانت<input name="warranty" maxlength="200" value="<?=e($editing['warranty'] ?? '')?>"></label></div><label>تصویر قطعه از کاتالوگ<select name="image_choice"><option value="keep"><?= $editing ? 'حفظ تصویر فعلی' : 'بدون تصویر' ?></option><option value="none">حذف تصویر</option><?php foreach ($catalogImages as $path => $title): ?><option value="<?=e($path)?>"><?=e($title)?></option><?php endforeach ?></select></label><label>یا بارگذاری تصویر اختصاصی (حداکثر ۵ مگابایت)<input type="file" name="part_image" accept="image/jpeg,image/png,image/webp"></label><p class="hint">تصویر بارگذاری‌شده جایگزین انتخاب کاتالوگ می‌شود. مشخصات قطعه را مطابق محصول نصب‌شده وارد کنید.</p><label>تعداد<input name="quantity" maxlength="100" value="<?=e($editing['quantity'] ?? '')?>"></label><label>قیمت و واحد پول<input name="price" maxlength="100" placeholder="مثلاً ۱۰۰٬۰۰۰ تومان" value="<?=e($editing['price'] ?? '')?>"></label><button>ذخیره قطعه</button> <?php if ($editing): ?><a href="?id=<?=$id?>">انصراف</a><?php endif ?></form>
<div class="card"><h2>قطعات ثبت‌شده</h2><?php if (!$parts): ?><p>هنوز قطعه‌ای ثبت نشده است.</p><?php endif ?><?php foreach ($parts as $part): ?><article class="part"><?php if (!empty($part['image_ref'])): ?><img class="admin-part-img" src="../customer/image.php?id=<?=(int)$part['id']?>" alt=""><?php endif ?><h3><?=e($part['name'])?></h3><p><?=nl2br(e($part['specifications']))?></p><p>تعداد: <?=e($part['quantity'])?> | قیمت: <?=e($part['price'])?></p><a href="?id=<?=$id?>&amp;part=<?=(int)$part['id']?>">ویرایش</a><form method="post" onsubmit="return confirm('قطعه حذف شود؟')"><?=csrf_field()?><input type="hidden" name="action" value="delete_part"><input type="hidden" name="customer_id" value="<?=$id?>"><input type="hidden" name="part_id" value="<?=(int)$part['id']?>"><button class="secondary">حذف</button></form></article><?php endforeach ?></div>
<?php endif ?></section></div></main>
<script>
var typeMeta = <?= json_encode(array_reduce($elevatorTypes, static function ($acc, $t) {
    $acc[(string)$t['id']] = [
        'title' => (string)($t['title'] ?? ''),
        'tag' => (string)($t['tag'] ?? ''),
        'speech' => (string)($t['speech'] ?? ''),
        'article' => (string)($t['article'] ?? ''),
    ];
    return $acc;
}, []), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
document.querySelectorAll('.type-pick input').forEach(function(r){
  r.addEventListener('change',function(){
    document.querySelectorAll('.type-pick label').forEach(function(l){l.classList.toggle('on',l.querySelector('input').checked)});
    var id = this.value, box = document.getElementById('elevator-details'), meta = typeMeta[id];
    if (!box || !meta) return;
    var blank = !box.value.trim();
    var fill = meta.speech || meta.article || ((meta.title || '') + (meta.tag ? ' — ' + meta.tag : ''));
    if (blank && fill) box.value = fill;
    else if (!blank && fill && confirm('مشخصات متنی با توضیح نوع «' + (meta.title || id) + '» جایگزین شود؟')) box.value = fill;
  });
});
(function(){
  var csrf = <?= json_encode($csrf, JSON_UNESCAPED_UNICODE) ?>;
  var pathEl = document.getElementById('elevator_audio');
  var prev = document.getElementById('audio-preview');
  var msg = document.getElementById('audio-msg');
  var clearBtn = document.getElementById('audio-clear');
  var up = document.getElementById('audio-upload');
  var file = document.getElementById('audio-file');
  if (!up || !file) return;
  function show(path) {
    pathEl.value = path || '';
    if (path) {
      prev.innerHTML = '<audio controls preload="none" src="../' + path.replace(/"/g,'') + '"></audio><p class="hint" dir="ltr"></p>';
      prev.querySelector('.hint').textContent = path;
      clearBtn.hidden = false;
    } else {
      prev.innerHTML = '<p class="hint">فایلی انتخاب نشده؛ اگر خالی بماند، متن مشخصات با صدای مرورگر خوانده می‌شود.</p>';
      clearBtn.hidden = true;
    }
  }
  clearBtn.addEventListener('click', function(){ show(''); msg.textContent = 'صوت حذف شد؛ ذخیره مشتری را بزنید.'; });
  up.addEventListener('click', function(){
    if (!file.files || !file.files[0]) { msg.textContent = 'ابتدا فایل را انتخاب کنید.'; return; }
    up.disabled = true; up.textContent = 'در حال آپلود…'; msg.textContent = '';
    var fd = new FormData(); fd.append('csrf', csrf); fd.append('file', file.files[0]);
    fetch('upload-audio.php', { method:'POST', body:fd, credentials:'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(j){
        if (j.ok) { show(j.path); msg.textContent = 'آپلود شد؛ ذخیره مشتری را بزنید.'; }
        else msg.textContent = j.error || 'خطا در آپلود';
      })
      .catch(function(){ msg.textContent = 'ارتباط برقرار نشد.'; })
      .finally(function(){ up.disabled = false; up.textContent = 'آپلود فایل صوتی'; });
  });
})();
</script>
</body></html>

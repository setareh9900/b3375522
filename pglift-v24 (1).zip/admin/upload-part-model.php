<?php
declare(strict_types=1);
require_once __DIR__ . '/../inc/fn.php';
$user = require_login_api();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok'=>false,'error'=>'متد نامعتبر'],405);
csrf_require($_POST['csrf'] ?? null);
if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    $code = $_FILES['file']['error'] ?? -1;
    $msg = in_array($code,[UPLOAD_ERR_INI_SIZE,UPLOAD_ERR_FORM_SIZE],true) ? 'حجم فایل از محدودیت PHP هاست بیشتر است؛ upload_max_filesize و post_max_size را افزایش دهید.' : 'فایل GLB ارسال نشد یا آپلود کامل نشد.';
    json_out(['ok'=>false,'error'=>$msg],422);
}
$f=$_FILES['file'];
if ($f['size'] > 100*1024*1024) json_out(['ok'=>false,'error'=>'حجم مدل GLB باید حداکثر ۱۰۰ مگابایت باشد.'],422);
if ($f['size'] < 20 || !preg_match('/\.glb$/i',(string)$f['name'])) json_out(['ok'=>false,'error'=>'فقط فایل با فرمت Binary glTF و پسوند .glb مجاز است.'],422);
$fh=@fopen($f['tmp_name'],'rb');
$header=$fh ? fread($fh,12) : '';
if ($fh) fclose($fh);
if (strlen($header)!==12 || substr($header,0,4)!=='glTF') json_out(['ok'=>false,'error'=>'ساختار GLB معتبر نیست؛ خروجی را به‌صورت glTF Binary (.glb) ذخیره کنید.'],422);
$version=unpack('Vversion',substr($header,4,4))['version'] ?? 0;
$declared=unpack('Vlength',substr($header,8,4))['length'] ?? 0;
if ($version!==2 || (int)$declared!==(int)$f['size']) json_out(['ok'=>false,'error'=>'نسخه یا طول فایل GLB نامعتبر/ناقص است.'],422);
$dir=dirname(__DIR__).'/uploads/models';
if (!is_dir($dir) && !@mkdir($dir,0755,true) && !is_dir($dir)) json_out(['ok'=>false,'error'=>'پوشه uploads/models قابل ساخت نیست؛ دسترسی نوشتن را بررسی کنید.'],500);
gf_upload_htaccess($dir);
$name='model_'.bin2hex(random_bytes(16)).'.glb';
if (!@move_uploaded_file($f['tmp_name'],$dir.'/'.$name)) json_out(['ok'=>false,'error'=>'ذخیره مدل ناموفق بود.'],500);
@chmod($dir.'/'.$name,0644);
log_activity($user['username'],'parts.model.upload',$name.' — '.round($f['size']/1048576,2).' MB');
json_out(['ok'=>true,'path'=>'uploads/models/'.$name,'size'=>(int)$f['size']]);

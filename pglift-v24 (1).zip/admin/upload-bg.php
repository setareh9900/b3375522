<?php
/** آپلود تصویر بک‌گراند سایت → uploads/bg/ */
declare(strict_types=1);
require_once __DIR__ . '/../inc/fn.php';

$user = require_login_api();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'متد نامعتبر'], 405);
csrf_require($_POST['csrf'] ?? null);

if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    $code = $_FILES['file']['error'] ?? -1;
    $msg = in_array($code, [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)
        ? 'حجم فایل بیشتر از حد مجاز سرور است' : 'فایلی ارسال نشد یا آپلود ناموفق بود';
    json_out(['ok' => false, 'error' => $msg], 422);
}
$f = $_FILES['file'];
if ($f['size'] > 8 * 1024 * 1024) json_out(['ok' => false, 'error' => 'حجم تصویر باید کمتر از ۸ مگابایت باشد'], 422);

$info = @getimagesize($f['tmp_name']);
$map = [IMAGETYPE_PNG => 'png', IMAGETYPE_JPEG => 'jpg', IMAGETYPE_WEBP => 'webp'];
if (!$info || !isset($map[$info[2]])) json_out(['ok' => false, 'error' => 'فقط PNG، JPG یا WebP مجاز است'], 422);
if ($info[0] > 8192 || $info[1] > 8192) json_out(['ok' => false, 'error' => 'ابعاد تصویر زیاد است (حداکثر ۸۱۹۲×۸۱۹۲)'], 422);

$dir = dirname(__DIR__) . '/uploads/bg';
if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
    json_out(['ok' => false, 'error' => 'ساخت پوشه‌ی uploads/bg ممکن نیست؛ دسترسی نوشتن را بررسی کنید'], 500);
}
gf_upload_htaccess($dir);

$name = 'bg_' . bin2hex(random_bytes(8)) . '.' . $map[$info[2]];
$saved = false;
/* بهینه‌سازی خودکار برای موبایل: حداکثر ۱۶۰۰px و WebP (شفافیت حفظ می‌شود) */
if (function_exists('imagewebp') && function_exists('imagecreatefromstring')) {
    $raw = @file_get_contents($f['tmp_name']);
    $im = $raw !== false ? @imagecreatefromstring($raw) : false;
    if ($im) {
        $w = imagesx($im); $h = imagesy($im); $max = 1600;
        if (max($w, $h) > $max) {
            $k = $max / max($w, $h); $nw = max(1, (int) round($w * $k)); $nh = max(1, (int) round($h * $k));
            $dst = imagecreatetruecolor($nw, $nh);
            imagealphablending($dst, false); imagesavealpha($dst, true);
            imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127));
            imagecopyresampled($dst, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
            imagedestroy($im); $im = $dst; $info[0] = $nw; $info[1] = $nh;
        }
        imagepalettetotruecolor($im); imagealphablending($im, false); imagesavealpha($im, true);
        $webp = 'bg_' . bin2hex(random_bytes(8)) . '.webp';
        if (@imagewebp($im, $dir . '/' . $webp, 86)) { $name = $webp; $saved = true; }
        imagedestroy($im);
    }
}
if (!$saved && !@move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
    json_out(['ok' => false, 'error' => 'ذخیره‌ی فایل ناموفق بود؛ دسترسی نوشتن پوشه را بررسی کنید'], 500);
}
$path = 'uploads/bg/' . $name;
log_activity($user['username'], 'bg.image', 'آپلود بک‌گراند ' . $name);
json_out(['ok' => true, 'path' => $path, 'w' => $info[0], 'h' => $info[1]]);

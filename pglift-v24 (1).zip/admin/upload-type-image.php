<?php
/** آپلود عکس هر نوع آسانسور (ترجیحاً PNG/WebP شفاف) → uploads/types/ */
declare(strict_types=1);
require_once __DIR__ . '/../inc/fn.php';

$user = require_login_api();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'متد نامعتبر'], 405);
csrf_require($_POST['csrf'] ?? null);

if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    $code = $_FILES['file']['error'] ?? -1;
    $msg = in_array($code, [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)
        ? 'حجم فایل بیشتر از حد مجاز سرور است' : 'فایلی ارسال نشد یا آپلود ناموفق بود';
    json_out(['ok' => false, 'error' => $msg], 422);
}
$f = $_FILES['file'];
$kind = in_array(($_POST['kind'] ?? ''), ['pano', 'parts'], true) ? (string)$_POST['kind'] : 'type';
$maxMb = $kind === 'pano' ? 12 : 5;
if ($f['size'] > $maxMb * 1024 * 1024) json_out(['ok' => false, 'error' => 'حجم تصویر باید کمتر از ' . $maxMb . ' مگابایت باشد'], 422);

$info = @getimagesize($f['tmp_name']);
$map = [IMAGETYPE_PNG => 'png', IMAGETYPE_JPEG => 'jpg', IMAGETYPE_WEBP => 'webp'];
if (!$info || !isset($map[$info[2]])) json_out(['ok' => false, 'error' => 'فقط PNG، JPG یا WebP مجاز است'], 422);
$maxW = $kind === 'pano' ? 8192 : 4000; $maxH = $kind === 'pano' ? 4096 : 6000;
if ($info[0] > $maxW || $info[1] > $maxH) json_out(['ok' => false, 'error' => 'ابعاد تصویر زیاد است (حداکثر ' . $maxW . '×' . $maxH . ')'], 422);

$sub = $kind === 'parts' ? 'parts' : 'types';
$dir = dirname(__DIR__) . '/uploads/' . $sub;
if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
    json_out(['ok' => false, 'error' => 'ساخت پوشه‌ی uploads/' . $sub . ' ممکن نیست؛ دسترسی نوشتن پوشه‌ی اصلی سایت را بررسی کنید'], 500);
}
gf_upload_htaccess($dir);

$name = ($kind === 'parts' ? 'p_' : 't_') . bin2hex(random_bytes(8)) . '.' . $map[$info[2]];
if (!@move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
    json_out(['ok' => false, 'error' => 'ذخیره‌ی فایل ناموفق بود؛ دسترسی نوشتن پوشه را بررسی کنید'], 500);
}
log_activity($user['username'], 'types.image', 'آپلود تصویر ' . $name);
json_out(['ok' => true, 'path' => 'uploads/' . $sub . '/' . $name, 'w' => $info[0], 'h' => $info[1], 'alpha' => $info[2] !== IMAGETYPE_JPEG]);

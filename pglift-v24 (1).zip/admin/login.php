<?php
/** ورود مدیر */
declare(strict_types=1);
require_once __DIR__ . '/../inc/db.php';
if (!gf_is_configured()) { header('Location: ../install.php'); exit; }
require_once __DIR__ . '/../inc/fn.php';

if (current_user()) redirect('index.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) {
        $error = 'توکن امنیتی نامعتبر است. دوباره تلاش کنید.';
    } else {
        $u = trim((string)($_POST['username'] ?? ''));
        $p = (string)($_POST['password'] ?? '');

        // محدودیت نرخ تلاش ناموفق
        $_SESSION['try'] = $_SESSION['try'] ?? ['n' => 0, 't' => 0];
        if ($_SESSION['try']['n'] >= 6 && (time() - $_SESSION['try']['t']) < 300) {
            $error = 'تلاش‌های ناموفق زیاد. ۵ دقیقه دیگر تلاش کنید.';
        } elseif ($u === '' || $p === '') {
            $error = 'نام کاربری و رمز عبور را وارد کنید.';
        } else {
            $row = q_one('SELECT * FROM admin_users WHERE username = ?', [$u]);
            if ($row && (int)$row['is_active'] === 1 && password_verify($p, $row['password_hash'])) {
                $_SESSION['try'] = ['n' => 0, 't' => 0];
                login_user($row);
                log_activity($row['username'], 'auth.login', 'ورود موفق به پنل');
                redirect('index.php');
            }
            $_SESSION['try']['n']++;
            $_SESSION['try']['t'] = time();
            $error = 'نام کاربری یا رمز عبور نادرست است.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>ورود به پنل مدیریت | آسانسور خلیج فارس صادقی</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="page-install">
<div class="install-bg" aria-hidden="true"></div>

<main class="login-wrap">
  <a class="login-brand" href="../index.php">
    <span class="install-logo sm"><?= icon('elevator', 26) ?></span>
    <span><b>آسانسور خلیج فارس صادقی</b><i>پنل مدیریت</i></span>
  </a>

  <form class="card" method="post" autocomplete="on">
    <h1 class="card-title">ورود به پنل مدیریت</h1>
    <p class="muted small">برای مدیریت محتوا، درخواست‌ها و پشتیبانی وارد شوید.</p>

    <?php if ($error): ?><div class="alert-error"><?= e($error) ?></div><?php endif; ?>

    <?= csrf_field() ?>
    <div class="field mt">
      <label for="username">نام کاربری</label>
      <input class="input ltr" id="username" name="username" dir="ltr" required autocomplete="username"
             value="<?= e($_POST['username'] ?? '') ?>" placeholder="admin">
    </div>
    <div class="field">
      <label for="password">رمز عبور</label>
      <input class="input ltr" id="password" name="password" type="password" dir="ltr" required
             autocomplete="current-password" placeholder="••••••••">
    </div>

    <button class="btn btn-primary full" type="submit"><?= icon('shield', 18) ?> ورود</button>

    <p class="muted small mt">
      رمز را فراموش کرده‌اید؟ از <a class="link" href="../install.php">نصب‌کننده</a> حساب جدید بسازید.
    </p>
  </form>
</main>
</body>
</html>

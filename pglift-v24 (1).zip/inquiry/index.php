<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/fn.php';
if (!gf_is_configured()) redirect('../install.php');
header('Cache-Control: no-store');
$source = (string)($_GET['source'] ?? 'catalog');
$id = (string)($_GET['id'] ?? '');
$mode = (string)($_GET['mode'] ?? 'full');
if (!in_array($mode, ['full','quick'], true)) $mode = 'full';
$part = null; $customer = null;
if ($source === 'customer') { http_response_code(404); exit('استعلام فقط از سایت اصلی امکان‌پذیر است.');
} elseif ($source === 'catalog') {
    require_once __DIR__.'/../inc/parts.php';
    foreach (parts_load()['items'] as $candidate) if ((string)$candidate['id'] === $id && !empty($candidate['active'])) { $part = $candidate; break; }
    if ($part) {
        $details = [];
        foreach ((array)($part['specs'] ?? []) as $spec) if (isset($spec[0],$spec[1])) $details[] = $spec[0].': '.$spec[1];
        $part['quote_details'] = implode("\n", $details);
    }
    if ($part && !empty($part['image']) && preg_match('#^(assets/img/parts|uploads/parts)/[A-Za-z0-9_.-]+\.(webp|png|jpg|jpeg)$#i', $part['image'])) $part['image'] = '../'.$part['image'];
    elseif ($part) $part['image'] = '';
} else { http_response_code(404); exit('قطعه پیدا نشد.'); }
if (!$part) { http_response_code(404); exit('قطعه پیدا نشد یا دسترسی به آن وجود ندارد.'); }
$self = 'index.php?source='.rawurlencode($source).'&id='.rawurlencode($id).'&mode='.rawurlencode($mode);
$error = ''; $name = $customer['name'] ?? ''; $phone = ''; $message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) { http_response_code(403); exit('توکن امنیتی نامعتبر است.'); }
    $name = clean((string)($_POST['name'] ?? ''), 150);
    $phone = clean((string)($_POST['phone'] ?? ''), 40);
    $message = $mode === 'full' ? clean_multiline((string)($_POST['message'] ?? ''), 1500) : '';
    if (mb_strlen($name, 'UTF-8') < 3 || !valid_phone($phone)) $error = 'نام و شماره تماس معتبر را وارد کنید.';
    elseif (!empty($_SESSION['quote_time']) && time() - (int)$_SESSION['quote_time'] < 15) $error = 'لطفاً پیش از ثبت درخواست بعدی کمی صبر کنید.';
    else {
        try {
            db()->beginTransaction();
            $description = 'استعلام '.($mode === 'quick' ? 'سریع' : 'جزئی').' قطعه: '.$part['title']."\nشناسه قطعه: ".$part['id']."\nمبدأ: ".($source === 'customer' ? 'پنل مشتری #'.(int)$customer['id'] : 'کاتالوگ سایت');
            if (!empty($part['tag'])) $description .= "\nمدل/معرفی: ".$part['tag'];
            if ($message !== '') $description .= "\nتوضیحات مشتری: ".$message;
            if (!empty($part['quote_details'])) $description .= "\nاطلاعات قطعه: ".$part['quote_details'];
            $description = clean_multiline($description, 4000);
            $tmp = 'TMP-'.bin2hex(random_bytes(6));
            q('INSERT INTO service_requests (ticket,request_type,subject,customer_name,phone,email,address,city,elevator_type,floors,passengers,brand,preferred_date,message,urgency,status,admin_note,technician,estimated_cost,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [$tmp,'service','استعلام قیمت: '.clean($part['title'],160),$name,$phone,'','','','',1,1,'','',$description,'normal','new','','',0,now(),now()]);
            $requestId = last_id(); $ticket = ticket_code('GF', $requestId);
            q('UPDATE service_requests SET ticket=? WHERE id=?', [$ticket,$requestId]);
            q('INSERT INTO request_events (request_id,message,actor,created_at) VALUES (?,?,?,?)', [$requestId,'استعلام قطعه ثبت شد','customer',now()]);
            db()->commit(); $_SESSION['quote_time'] = time(); $_SESSION['quote_success'] = $ticket;
            redirect($self.'&success=1');
        } catch (Throwable $ex) { if (db()->inTransaction()) db()->rollBack(); $error = 'ثبت درخواست انجام نشد؛ لطفاً دوباره تلاش کنید.'; }
    }
}
$success = isset($_GET['success']) && !empty($_SESSION['quote_success']) ? (string)$_SESSION['quote_success'] : '';
if ($success !== '') unset($_SESSION['quote_success']);
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>استعلام قیمت قطعه</title><link rel="stylesheet" href="../assets/css/customer.css?v=<?= (int)@filemtime(__DIR__.'/../assets/css/customer.css') ?>"></head><body class="customer-page"><div class="customer-shell"><header class="customer-top"><a class="customer-brand" href="../index.php"><span class="brand-icon">↟</span><span><strong>خلیج فارس</strong><small>استعلام قطعات</small></span></a><a href="<?=$source === 'customer' ? '../customer/' : '../index.php#catalog'?>">بازگشت</a></header><main class="inquiry-layout">
<div class="inquiry-product"><span class="eyebrow-c">استعلام قیمت قطعه</span><h1><?=e($part['title'])?></h1><p><?=e($part['tag'] ?? '')?></p><?php if ($part['image']): ?><img src="<?=e($part['image'])?>" alt="<?=e($part['title'])?>"><?php endif ?><small>اطلاعات این قطعه همراه درخواست به مدیریت ارسال می‌شود.</small></div>
<div class="inquiry-card"><?php if ($success): ?><div class="inquiry-success" role="status"><span>✓</span><h2>درخواست شما ثبت شد</h2><p>درخواست شما ثبت شد و تا ۲۴ ساعت آینده اطلاع‌رسانی خواهد شد.</p><p>کد پیگیری: <b dir="ltr"><?=e($success)?></b></p><a href="<?=$source === 'customer' ? '../customer/' : '../index.php#catalog'?>">بازگشت به قطعات ←</a></div><?php else: ?><span class="eyebrow-c"><?=$mode === 'quick' ? 'استعلام سریع' : 'فرم اختصاصی قطعه'?></span><h2><?=$mode === 'quick' ? 'درخواست تماس' : 'جزئیات استعلام'?></h2><p>برای اطلاع‌رسانی به شما، شماره تماس لازم است.</p><?php if ($error): ?><p class="notice error" role="alert"><?=e($error)?></p><?php endif ?><form method="post" action="<?=e($self)?>"><?=csrf_field()?><label>نام و نام خانوادگی<input name="name" required minlength="3" maxlength="150" autocomplete="name" value="<?=e($name)?>"></label><label>شماره تماس<input name="phone" required maxlength="40" autocomplete="tel" inputmode="tel" dir="ltr" value="<?=e($phone)?>"></label><?php if ($mode === 'full'): ?><label>توضیحات یا تعداد مورد نیاز<textarea name="message" rows="4" maxlength="1500" placeholder="مدل، تعداد یا توضیح مورد نظر شما"><?=e($message)?></textarea></label><?php endif ?><button class="primary-btn" type="submit">ثبت استعلام <span>←</span></button></form><small>پس از ثبت، درخواست در پنل مدیریت قابل پیگیری است.</small><?php endif ?></div></main></div></body></html>

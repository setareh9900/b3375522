<?php
// Run from the authenticated admin page. Compatible with existing installations.
function customer_schema(): void {
    $id = gf_driver() === 'sqlite' ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'INT AUTO_INCREMENT PRIMARY KEY';
    db()->exec("CREATE TABLE IF NOT EXISTS customer_accounts (id $id, username VARCHAR(100) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, name VARCHAR(200) NOT NULL, elevator_details TEXT NOT NULL)");
    db()->exec("CREATE TABLE IF NOT EXISTS customer_parts (id $id, customer_id INT NOT NULL, name VARCHAR(200) NOT NULL, specifications TEXT NOT NULL, quantity VARCHAR(100) NOT NULL, price VARCHAR(100) NOT NULL)");
    // Upgrade existing installations without removing any customer data.
    $accCols = gf_driver() === 'sqlite'
        ? array_column(q_all('PRAGMA table_info(customer_accounts)'), 'name')
        : array_column(q_all('SHOW COLUMNS FROM customer_accounts'), 'Field');
    $accAdds = [
        'phone' => "VARCHAR(30) NOT NULL DEFAULT ''",
        'elevator_type' => "VARCHAR(80) NOT NULL DEFAULT ''",
        'elevator_audio' => "VARCHAR(255) NOT NULL DEFAULT ''",
        'login_token' => "VARCHAR(64) NOT NULL DEFAULT ''",
        'login_token_expires' => gf_driver() === 'sqlite' ? 'INTEGER NOT NULL DEFAULT 0' : 'INT NOT NULL DEFAULT 0',
        'login_link_enabled' => gf_driver() === 'sqlite' ? 'INTEGER NOT NULL DEFAULT 1' : 'TINYINT(1) NOT NULL DEFAULT 1',
    ];
    foreach ($accAdds as $column => $def) {
        if (in_array($column, $accCols, true)) continue;
        try { db()->exec("ALTER TABLE customer_accounts ADD COLUMN $column $def"); }
        catch (PDOException $e) {
            $accCols = gf_driver() === 'sqlite' ? array_column(q_all('PRAGMA table_info(customer_accounts)'), 'name') : array_column(q_all('SHOW COLUMNS FROM customer_accounts'), 'Field');
            if (!in_array($column, $accCols, true)) throw $e;
        }
    }
    $columns = gf_driver() === 'sqlite'
        ? array_column(q_all('PRAGMA table_info(customer_parts)'), 'name')
        : array_column(q_all('SHOW COLUMNS FROM customer_parts'), 'Field');
    foreach (['image_ref','brand','model','serial_number','installed_at','warranty'] as $column) {
        if (in_array($column, $columns, true)) continue;
        try { db()->exec("ALTER TABLE customer_parts ADD COLUMN $column VARCHAR(255) NOT NULL DEFAULT ''"); }
        catch (PDOException $e) {
            $columns = gf_driver() === 'sqlite' ? array_column(q_all('PRAGMA table_info(customer_parts)'), 'name') : array_column(q_all('SHOW COLUMNS FROM customer_parts'), 'Field');
            if (!in_array($column, $columns, true)) throw $e;
        }
    }
    db()->exec("CREATE TABLE IF NOT EXISTS customer_login_attempts (attempt_key VARCHAR(64) PRIMARY KEY, attempts INT NOT NULL, last_attempt INT NOT NULL)");
}

/** لینک دائمی؛ فقط با غیرفعال‌سازی یا صدور لینک جدید باطل می‌شود. */
function customer_make_magic_link(int $customerId, bool $regenerate = true): string {
    $account = q_one('SELECT login_token FROM customer_accounts WHERE id=?', [$customerId]);
    $token = !$regenerate && !empty($account['login_token']) ? $account['login_token'] : bin2hex(random_bytes(24));
    q('UPDATE customer_accounts SET login_token=?, login_token_expires=0, login_link_enabled=1 WHERE id=?', [$token, $customerId]);
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ((int)($_SERVER['SERVER_PORT'] ?? 0) === 443);
    $host = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
    $base = ($https ? 'https://' : 'http://') . $host;
    $path = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/admin')), '/');
    // از /admin به /customer
    if (substr($path, -6) === '/admin') $path = substr($path, 0, -6) . '/customer';
    else $path = rtrim(dirname($path), '/') . '/customer';
    return $base . $path . '/?t=' . urlencode($token);
}

<?php
declare(strict_types=1);

/** امکانات v16: سفارش مشتری، استوری ویدیویی و گزارش پیامک. اجرای مجدد امن است. */
function feature_schema(): void
{
    $id = gf_driver() === 'sqlite' ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'INT AUTO_INCREMENT PRIMARY KEY';
    $dt = gf_driver() === 'sqlite' ? 'TEXT' : 'DATETIME';
    db()->exec("CREATE TABLE IF NOT EXISTS customer_orders (id $id, customer_id INT NOT NULL, order_no VARCHAR(40) NOT NULL UNIQUE, title VARCHAR(200) NOT NULL, details TEXT NOT NULL DEFAULT '', quantity VARCHAR(60) NOT NULL DEFAULT '1', status VARCHAR(30) NOT NULL DEFAULT 'pending', total_price VARCHAR(100) NOT NULL DEFAULT '', admin_note TEXT NOT NULL DEFAULT '', created_at $dt NULL, updated_at $dt NULL)");
    db()->exec("CREATE TABLE IF NOT EXISTS video_stories (id $id, title VARCHAR(180) NOT NULL, subtitle VARCHAR(255) NOT NULL DEFAULT '', company VARCHAR(180) NOT NULL DEFAULT '', video_path VARCHAR(255) NOT NULL, poster_path VARCHAR(255) NOT NULL DEFAULT '', is_active TINYINT(1) NOT NULL DEFAULT 1, sort_order INT NOT NULL DEFAULT 0, created_at $dt NULL)");
    db()->exec("CREATE TABLE IF NOT EXISTS sms_messages (id $id, customer_id INT NULL, recipient VARCHAR(30) NOT NULL, body TEXT NOT NULL, provider VARCHAR(40) NOT NULL DEFAULT 'farazsms', status VARCHAR(30) NOT NULL DEFAULT 'queued', provider_id VARCHAR(190) NOT NULL DEFAULT '', error_message VARCHAR(500) NOT NULL DEFAULT '', created_at $dt NULL)");
    db()->exec("CREATE TABLE IF NOT EXISTS customer_contracts (id $id, customer_id INT NOT NULL, contract_no VARCHAR(80) NOT NULL, title VARCHAR(200) NOT NULL, project_address VARCHAR(500) NOT NULL DEFAULT '', start_date VARCHAR(40) NOT NULL DEFAULT '', end_date VARCHAR(40) NOT NULL DEFAULT '', status VARCHAR(30) NOT NULL DEFAULT 'active', coverage TEXT NOT NULL DEFAULT '', created_at $dt NULL)");
    db()->exec("CREATE TABLE IF NOT EXISTS customer_service_visits (id $id, customer_id INT NOT NULL, service_date VARCHAR(40) NOT NULL, next_service_date VARCHAR(40) NOT NULL DEFAULT '', technician VARCHAR(160) NOT NULL DEFAULT '', summary TEXT NOT NULL DEFAULT '', status VARCHAR(30) NOT NULL DEFAULT 'done', created_at $dt NULL)");
    $upgrades = [
        'video_stories' => ['show_public' => 'INTEGER NOT NULL DEFAULT 1', 'show_customer' => 'INTEGER NOT NULL DEFAULT 1'],
        'customer_contracts' => ['contract_date' => "VARCHAR(40) NOT NULL DEFAULT ''", 'contract_text' => 'TEXT', 'total_amount' => "VARCHAR(150) NOT NULL DEFAULT ''", 'contract_parts' => 'TEXT'],
        'customer_service_visits' => ['replaced_parts' => 'TEXT', 'resolved_problems' => 'TEXT'],
    ];
    foreach ($upgrades as $table => $adds) {
        $columns = gf_driver() === 'sqlite' ? array_column(q_all('PRAGMA table_info('.$table.')'), 'name') : array_column(q_all('SHOW COLUMNS FROM '.$table), 'Field');
        foreach ($adds as $column => $definition) {
            if (in_array($column, $columns, true)) continue;
            try { db()->exec("ALTER TABLE $table ADD COLUMN $column $definition"); }
            catch (PDOException $e) {
                $columns = gf_driver() === 'sqlite' ? array_column(q_all('PRAGMA table_info('.$table.')'), 'name') : array_column(q_all('SHOW COLUMNS FROM '.$table), 'Field');
                if (!in_array($column, $columns, true)) throw $e;
            }
        }
    }
    foreach (['idx_orders_customer ON customer_orders(customer_id)', 'idx_stories_active ON video_stories(is_active,sort_order)', 'idx_sms_created ON sms_messages(created_at)'] as $index) {
        try { db()->exec('CREATE INDEX ' . $index); } catch (PDOException $e) { /* موجود است */ }
    }
}

function order_statuses(): array
{
    return ['pending' => 'در انتظار بررسی', 'confirmed' => 'تأیید شده', 'preparing' => 'در حال آماده‌سازی', 'sent' => 'ارسال شده', 'done' => 'تحویل شده', 'canceled' => 'لغو شده'];
}

function active_stories(int $limit = 30, string $destination = 'public'): array
{
    feature_schema();
    $column = $destination === 'customer' ? 'show_customer' : 'show_public';
    return q_all('SELECT * FROM video_stories WHERE is_active=1 AND '.$column.'=1 ORDER BY sort_order ASC,id DESC LIMIT ' . max(1, min($limit, 50)));
}

/** ارسال از سرویس فراز SMS / IPPanel. پاسخ خطا بدون افشای نام کاربری و رمز ثبت می‌شود. */
function farazsms_send(string $to, string $message): array
{
    $to = en_digits(trim($to));
    if (preg_match('/^98\d{10}$/', $to)) $to = '0' . substr($to, 2);
    if (preg_match('/^9\d{9}$/', $to)) $to = '0' . $to;
    if (!preg_match('/^09\d{9}$/', $to)) throw new RuntimeException('شماره موبایل گیرنده معتبر نیست.');
    if (trim($message) === '' || mb_strlen($message) > 900) throw new RuntimeException('متن پیامک باید بین ۱ تا ۹۰۰ کاراکتر باشد.');
    $username = trim(setting('sms.username'));
    $password = trim(setting('sms.password'));
    $from = en_digits(trim(setting('sms.sender')));
    if ($username === '' || $password === '' || $from === '') throw new RuntimeException('ابتدا نام کاربری، رمز و خط فرستنده فراز SMS را در تنظیمات پیامک وارد کنید.');
    $endpoint = trim(setting('sms.endpoint', 'https://ippanel.com/api/select')) ?: 'https://ippanel.com/api/select';
    if (!preg_match('#^https://(ippanel\.com|[^/]*ippanel\.com)/#i', $endpoint)) throw new RuntimeException('آدرس API باید متعلق به سرویس فراز SMS باشد.');
    $payload = json_encode(['op' => 'send', 'uname' => $username, 'pass' => $password, 'message' => $message, 'to' => [$to], 'from' => $from, 'time' => null], JSON_UNESCAPED_UNICODE);
    $headers = ['Content-Type: application/json', 'Accept: application/json'];
    $response = false; $error = ''; $code = 0;
    if (function_exists('curl_init')) {
        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => $payload, CURLOPT_HTTPHEADER => $headers, CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 25, CURLOPT_SSL_VERIFYPEER => true]);
        $response = curl_exec($ch); $error = curl_error($ch); $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE); curl_close($ch);
    } else {
        $context = stream_context_create(['http' => ['method' => 'POST', 'header' => implode("\r\n", $headers), 'content' => $payload, 'timeout' => 25, 'ignore_errors' => true]]);
        $response = @file_get_contents($endpoint, false, $context);
        if ($response === false) $error = 'اتصال به فراز SMS برقرار نشد.';
        foreach ($http_response_header ?? [] as $h) if (preg_match('#HTTP/\S+\s+(\d+)#', $h, $m)) $code = (int)$m[1];
    }
    $json = is_string($response) ? json_decode($response, true) : null;
    /* API های مختلف IPPanel ممکن است کد صفر یا رشته‌ی عددی موفقیت برگردانند. */
    $remoteCode = $json['code'] ?? $json['status'] ?? $json[0] ?? null;
    $ok = $code >= 200 && $code < 300 && is_array($json) && ($remoteCode === 0 || $remoteCode === '0' || !empty($json['success']));
    if (!$ok) {
        $msg = $error !== '' ? $error : (string)($json['message'] ?? $json['error'] ?? $json[1] ?? ('پاسخ نامعتبر سرویس؛ HTTP ' . $code));
        throw new RuntimeException(mb_substr($msg, 0, 450));
    }
    $providerId = $json['data'] ?? $json['message_id'] ?? $json['result'] ?? '';
    if (is_array($providerId)) $providerId = json_encode($providerId, JSON_UNESCAPED_UNICODE);
    return ['id' => mb_substr((string)$providerId, 0, 180), 'recipient' => $to];
}

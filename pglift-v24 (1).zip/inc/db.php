<?php
/**
 * اتصال به پایگاه داده — آسانسور خلیج فارس صادقی
 * پشتیبانی از MySQL / MariaDB و SQLite
 */
declare(strict_types=1);

define('GF_CONFIG_FILE', __DIR__ . '/config.php');

/** آیا سیستم نصب شده است؟ */
function gf_is_configured(): bool
{
    return is_file(GF_CONFIG_FILE);
}

/** خواندن تنظیمات اتصال */
function gf_config(): array
{
    static $cfg = null;
    if ($cfg === null) {
        $cfg = gf_is_configured() ? (require GF_CONFIG_FILE) : [];
    }
    return $cfg;
}

/** ساخت DSN بر اساس درایور */
function gf_dsn(array $c): string
{
    $driver = $c['driver'] ?? 'mysql';
    if ($driver === 'sqlite') {
        return 'sqlite:' . $c['database'];
    }
    $host = $c['host'] ?? '127.0.0.1';
    $port = $c['port'] ?? 3306;
    $db   = $c['database'] ?? '';
    return "mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4";
}

/** اتصال PDO (singleton) */
function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $c = gf_config();
    if (!$c) {
        throw new RuntimeException('سیستم هنوز نصب نشده است.');
    }
    $pdo = gf_connect($c);
    return $pdo;
}

/** ساخت اتصال جدید با تنظیمات دلخواه (برای تست در نصب‌کننده) */
function gf_connect(array $c): PDO
{
    $opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO(gf_dsn($c), $c['user'] ?? null, $c['pass'] ?? null, $opts);

    if (($c['driver'] ?? 'mysql') === 'sqlite') {
        $pdo->exec('PRAGMA foreign_keys = ON');
    } else {
        $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
    }
    return $pdo;
}

/** درایور فعلی */
function gf_driver(): string
{
    $c = gf_config();
    return $c['driver'] ?? 'mysql';
}

/* ------------------------------------------------------------------ */
/* کمک‌کننده‌های کوتاه برای کوئری                                      */
/* ------------------------------------------------------------------ */

function q(string $sql, array $params = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function q_all(string $sql, array $params = []): array
{
    return q($sql, $params)->fetchAll();
}

function q_one(string $sql, array $params = []): ?array
{
    $row = q($sql, $params)->fetch();
    return $row === false ? null : $row;
}

function q_val(string $sql, array $params = [], $default = null)
{
    $row = q($sql, $params)->fetch(PDO::FETCH_NUM);
    return $row === false ? $default : $row[0];
}

function last_id(): int
{
    return (int) db()->lastInsertId();
}

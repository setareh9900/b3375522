<?php
/** فیلدهای مشترک فرم نصب — توسط install.php include می‌شود */
if (!isset($d)) { $d = []; }
$v = static function (string $k, string $def = '') use ($d) {
    return htmlspecialchars((string)($d[$k] ?? $def), ENT_QUOTES, 'UTF-8');
};
?>
<div class="field-row">
  <div class="field">
    <label for="driver">نوع پایگاه داده</label>
    <select name="driver" id="driver" class="input" onchange="gfToggleDriver(this.value)">
      <option value="mysql"  <?= ($d['driver'] ?? 'mysql') === 'mysql'  ? 'selected' : '' ?>>MySQL / MariaDB (پیشنهادی برای هاست)</option>
      <option value="sqlite" <?= ($d['driver'] ?? '')      === 'sqlite' ? 'selected' : '' ?>>SQLite (بدون نیاز به سرور)</option>
    </select>
  </div>
</div>

<div id="mysql-fields">
  <div class="field-row two">
    <div class="field">
      <label for="host">میزبان (Host)</label>
      <input class="input" dir="ltr" type="text" id="host" name="host" value="<?= $v('host', '127.0.0.1') ?>" placeholder="localhost">
    </div>
    <div class="field">
      <label for="port">پورت</label>
      <input class="input" dir="ltr" type="text" id="port" name="port" value="<?= $v('port', '3306') ?>" placeholder="3306">
    </div>
  </div>
  <div class="field-row two">
    <div class="field">
      <label for="user">نام کاربری پایگاه داده</label>
      <input class="input" dir="ltr" type="text" id="user" name="user" value="<?= $v('user', 'root') ?>">
    </div>
    <div class="field">
      <label for="pass">رمز عبور پایگاه داده</label>
      <input class="input" dir="ltr" type="password" id="pass" name="pass" value="">
    </div>
  </div>
</div>

<div class="field-row">
  <div class="field">
    <label for="database"><span id="db-label">نام پایگاه داده</span></label>
    <input class="input" dir="ltr" type="text" id="database" name="database" value="<?= $v('database', 'gulfpars_elevator') ?>">
    <small class="hint" id="db-hint">پایگاه داده باید از قبل در هاست ساخته شده باشد.</small>
  </div>
</div>

<div class="divider"></div>

<div class="field-row two">
  <div class="field">
    <label for="admin_user">نام کاربری مدیر</label>
    <input class="input" dir="ltr" type="text" id="admin_user" name="admin_user" value="<?= $v('admin_user', 'admin') ?>">
  </div>
  <div class="field">
    <label for="admin_pass">رمز عبور مدیر</label>
    <input class="input" dir="ltr" type="text" id="admin_pass" name="admin_pass" placeholder="Admin@12345">
    <small class="hint">خالی بگذارید تا رمز پیش‌فرض ساخته شود.</small>
  </div>
</div>

<script>
function gfToggleDriver(v){
  var m = document.getElementById('mysql-fields');
  var db = document.getElementById('database');
  var lbl = document.getElementById('db-label');
  var hint = document.getElementById('db-hint');
  if (v === 'sqlite') {
    m.style.display = 'none';
    lbl.textContent = 'مسیر فایل پایگاه داده';
    hint.textContent = 'خالی بگذارید تا در data/gulfpars.sqlite ساخته شود.';
    if (db.value === 'gulfpars_elevator') db.value = '';
  } else {
    m.style.display = '';
    lbl.textContent = 'نام پایگاه داده';
    hint.textContent = 'پایگاه داده باید از قبل در هاست ساخته شده باشد.';
    if (!db.value) db.value = 'gulfpars_elevator';
  }
}
gfToggleDriver(document.getElementById('driver').value);
</script>

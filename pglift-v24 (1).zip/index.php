<?php
/**
 * صفحه اصلی سایت — آسانسور خلیج فارس صادقی
 */
declare(strict_types=1);

require_once __DIR__ . '/inc/db.php';

if (!gf_is_configured()) {
    header('Location: install.php');
    exit;
}

require_once __DIR__ . '/inc/fn.php';
require_once __DIR__ . '/inc/types.php';
require_once __DIR__ . '/inc/parts.php';
require_once __DIR__ . '/inc/features.php';

try {
    $installed = (int) q_val('SELECT COUNT(*) FROM installer_state WHERE is_complete = 1', [], 0);
} catch (Throwable $e) {
    header('Location: install.php');
    exit;
}
if (!$installed) {
    header('Location: install.php');
    exit;
}

try { $stories = active_stories(); } catch (Throwable $e) { $stories = []; }
$S     = settings();
$logo  = active_logo();
$brand = setting('brand.name', 'آسانسور خلیج فارس صادقی');
$phone = setting('brand.phone');
$mobile= setting('brand.mobile');
$email = setting('brand.email');
$addr  = setting('brand.address');
$hours = setting('brand.hours');
$wa    = setting('brand.whatsapp');
$insta = setting('brand.instagram');
$siteTheme = setting('site.theme', 'copper');
if (!in_array($siteTheme, ['copper', 'amber', 'darkmatter', 'slate'], true)) $siteTheme = 'copper';
$siteBgFx = setting('site.bg_fx', 'sparkles');
if (!in_array($siteBgFx, ['sparkles', 'particles', 'aurora', 'mouse', 'none'], true)) $siteBgFx = 'sparkles';
$cabinBg = setting('site.cabin_bg', 'assets/img/cabin-copper.webp');
if (!is_bg_image_path($cabinBg)) {
    $cabinBg = 'assets/img/cabin-copper.webp';
}
$cabinBg2 = setting('site.cabin_bg2', 'assets/img/cabin-red.webp');   if (!is_bg_image_path($cabinBg2)) $cabinBg2 = 'assets/img/cabin-red.webp';
$cabinBg3 = setting('site.cabin_bg3', 'assets/img/cabin-black.webp'); if (!is_bg_image_path($cabinBg3)) $cabinBg3 = 'assets/img/cabin-black.webp';
/* تصویر کابین سه‌بعدی اسکرول: اگر از تصاویر پیش‌فرض باشد srcset سبک دارد، اگر آپلودی باشد ابعاد واقعی خوانده می‌شود */
$__cab = function (string $src, string $fp) {
    $sm = ['assets/img/cabin-copper.webp' => ['assets/img/cabin-copper-sm.webp 386w', 386], 'assets/img/cabin-red.webp' => ['assets/img/cabin-red-sm.webp 281w', 281], 'assets/img/cabin-black.webp' => ['assets/img/cabin-black-sm.webp 346w', 346]];
    $d = @getimagesize(__DIR__ . '/' . $src);
    $wh = $d ? ' width="' . (int)$d[0] . '" height="' . (int)$d[1] . '"' : '';
    $set = isset($sm[$src]) ? ' srcset="' . e($sm[$src][0]) . ', ' . e($src) . ' ' . (int)($d[0] ?? 600) . 'w" sizes="(max-width:999px) 40vh, 51vh"' : '';
    return '<img src="' . e($src) . '"' . $set . $wh . ' alt="" decoding="async" fetchpriority="' . $fp . '" draggable="false">';
};
$hqRaw = setting('site.hq_images');
$hqSlides = array_values(array_filter(array_map('trim', explode('|', $hqRaw)), static function ($p) {
    return $p !== '' && is_bg_image_path($p);
}));
if (!$hqSlides) {
    $hqSlides = [$cabinBg, 'assets/img/types/hydraulic.webp', 'assets/img/cabin-red.webp', 'assets/img/types/gearless.webp', 'assets/img/cabin-black.webp', 'assets/img/customer-background.webp'];
}
if (!in_array($cabinBg, $hqSlides, true)) array_unshift($hqSlides, $cabinBg);

$hero  = section('hero');
$heroHeight = max(70, min(140, (int)($hero['extra']['heroHeight'] ?? 100)));
$heroScrollHeight = (int)round($heroHeight * 1.5);
/* نسخه‌ی خودکار فایل‌ها: با هر تغییر CSS/JS کش مرورگر خودش تازه می‌شود */
$assetVer = e(setting('asset_ver', '1')) . '.' . (string) max(
    (int) @filemtime(__DIR__ . '/assets/css/style.css'),
    (int) @filemtime(__DIR__ . '/assets/js/app.js'),
    (int) @filemtime(__DIR__ . '/assets/js/scene.js'),
    (int) @filemtime(__DIR__ . '/assets/js/cabin.js'),
    (int) @filemtime(__DIR__ . '/assets/js/types.js'),
    (int) @filemtime(__DIR__ . '/assets/js/parts.js'),
    (int) @filemtime(__DIR__ . '/assets/js/showcase.js'),
    (int) @filemtime(__DIR__ . '/assets/css/showcase.css'),
    (int) @filemtime(__DIR__ . '/assets/react/liquid-metal-buttons.js'),
    (int) @filemtime(__DIR__ . '/assets/css/v13.css'),
    (int) @filemtime(__DIR__ . '/assets/js/flow.js'),
    (int) @filemtime(__DIR__ . '/assets/js/building3d.js')
);
$feat  = section('features');
$serv  = section('services');
$cta   = section('cta');
$test  = section('testimonials');
$foot  = section('footer');

$heroStats  = $hero['extra']['stats']   ?? [];
$featItems  = $feat['extra']['items']   ?? [];
$servItems  = $serv['extra']['items']   ?? [];
$testItems  = $test['extra']['items']   ?? [];
$quickLinks = array_values(array_filter($foot['extra']['quickLinks'] ?? [], static function ($l) {
    $href = (string)($l['href'] ?? '');
    return $href !== '#process' && stripos((string)($l['label'] ?? ''), 'فرآیند') === false;
}));

$navLinks = [
    ['#services', 'خدمات'],
    ['#types',    'انواع آسانسور'],
    ['#catalog',  'قطعات و متعلقات'],
    ['#stories',  'استوری و پروژه‌ها'],
    ['#features', 'مزایا'],
    ['#request',  'درخواست سرویس'],
    ['#contact',  'تماس'],
];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl" data-site-theme="<?= e($siteTheme) ?>" data-bg-fx="<?= e($siteBgFx) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e(setting('seo.title', $brand)) ?></title>
<meta name="description" content="<?= e(setting('seo.description')) ?>">
<meta name="keywords" content="<?= e(setting('seo.keywords')) ?>">
<meta name="theme-color" content="#0a0b0d">
<meta property="og:title" content="<?= e($brand) ?>">
<meta property="og:description" content="<?= e(setting('seo.description')) ?>">
<meta property="og:type" content="website">
<meta property="og:locale" content="fa_IR">
<?php if ($logo): ?><link rel="icon" href="<?= e($logo) ?>"><?php endif; ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css?v=<?= $assetVer ?>">
<link rel="stylesheet" href="assets/css/coverflow.css?v=<?= (int) @filemtime(__DIR__ . '/assets/css/coverflow.css') ?>">
<link rel="stylesheet" href="assets/css/elevator3d.css?v=<?= (int) @filemtime(__DIR__ . '/assets/css/elevator3d.css') ?>">
<link rel="stylesheet" href="assets/css/showcase.css?v=<?= (int) @filemtime(__DIR__ . '/assets/css/showcase.css') ?>">
<link rel="stylesheet" href="assets/css/bg-fx.css?v=<?= (int) @filemtime(__DIR__ . '/assets/css/bg-fx.css') ?>">
<link rel="stylesheet" href="assets/css/v13.css?v=<?= (int) @filemtime(__DIR__ . '/assets/css/v13.css') ?>">
<link rel="stylesheet" href="assets/css/cinema-footer.css?v=<?= (int) @filemtime(__DIR__ . '/assets/css/cinema-footer.css') ?>">
<link rel="stylesheet" href="assets/css/gfx.css?v=<?= (int) @filemtime(__DIR__ . '/assets/css/gfx.css') ?>">
<link rel="stylesheet" href="assets/css/fx.css?v=<?= (int) @filemtime(__DIR__ . '/assets/css/fx.css') ?>">
<link rel="stylesheet" href="assets/css/stories.css?v=<?= (int) @filemtime(__DIR__ . '/assets/css/stories.css') ?>">
<script>
/* تشخیص دستگاه ضعیف — فقط موبایل کوچک / حافظه یا هسته‌ی خیلی کم؛ دسکتاپ full می‌ماند تا افکت موس و بک‌گراند کار کند */
(function(){var d=document.documentElement;try{
  var n=navigator,c=n.connection||{},rm=matchMedia('(prefers-reduced-motion: reduce)').matches,
      touch=matchMedia('(pointer: coarse)').matches,lite=false;
  try{if(localStorage.getItem('gfPerf')==='lite')lite=true}catch(e){}
  if(c.saveData||rm)lite=true;
  else if(n.deviceMemory&&n.deviceMemory<=2)lite=true;
  else if(n.hardwareConcurrency&&n.hardwareConcurrency<=2)lite=true;
  else if(touch&&innerWidth<700)lite=true; /* فقط گوشی‌های باریک */
  d.setAttribute('data-perf',lite?'lite':'full');
  var seen=false;try{seen=sessionStorage.getItem('gfIntro')==='1'}catch(e){}
  if(!seen&&!rm)d.className+=' intro-on';
}catch(e){}})();
</script>
<noscript><style>[data-reveal],[data-rd]{opacity:1!important}.doors,.finale{display:none!important}</style></noscript>
<?php
/* اندازه‌ی لوگو از پنل ادمین (px)؛ عرض ۰ = خودکار */
$__lg = function (string $k, int $d, int $mx): int { return max(0, min($mx, (int) setting($k, (string) $d))); };
$__nh = max(16, $__lg('logo_nav_h', 48, 160)); $__nw = $__lg('logo_nav_w', 0, 480);
$__fh = max(16, $__lg('logo_ft_h', 64, 200));  $__fw = $__lg('logo_ft_w', 0, 480);
$__m  = 0.82; // ضریب موبایل
$__logoCss = ':root{'
  . '--logo-nav-h:' . $__nh . 'px;--logo-nav-w:' . ($__nw ? $__nw . 'px' : 'auto') . ';'
  . '--logo-nav-h-m:' . round($__nh * $__m) . 'px;--logo-nav-w-m:' . ($__nw ? round($__nw * $__m) . 'px' : 'auto') . ';'
  . '--logo-ft-h:' . $__fh . 'px;--logo-ft-w:' . ($__fw ? $__fw . 'px' : 'auto') . ';'
  . '--logo-ft-h-m:' . round($__fh * $__m) . 'px;--logo-ft-w-m:' . ($__fw ? round($__fw * $__m) . 'px' : 'auto') . ';}';
?>
<style id="logo-vars"><?= $__logoCss ?></style>
</head>
<body>

<!-- انیمیشن ورود: دو لنگه‌ی در آسانسور باز می‌شوند (فقط CSS و transform؛ بدون عکس و فیلتر) -->
<div class="intro-doors" id="intro" aria-hidden="true">
  <i class="id-glow"></i>
  <i class="id-panel id-l"></i>
  <i class="id-panel id-r"></i>
</div>

<!-- بک‌گراند شفت + گالری تصاویر باکیفیت (گاهی تمام‌صفحه می‌شوند) -->
<div class="lift-bg" id="lift-bg" aria-hidden="true">
  <div class="lift-hq" id="lift-hq">
    <?php foreach ($hqSlides as $i => $hq): ?>
    <i class="lift-hq-slide<?= $i === 0 ? ' is-on' : '' ?>" style="background-image:url(<?= e($hq) ?>)"></i>
    <?php endforeach ?>
  </div>
  <div class="lift-bg-well">
    <div class="lift-bg-rails"></div>
    <div class="lift-bg-track" id="lift-bg-track">
      <?php
        /* هم‌تراز با سفر کابین‌ها (مس / قرمز / مشکی) — بدون برچسب عددی روی تصویر */
        $shaftImgs = [
          $cabinBg,
          $cabinBg2,
          $cabinBg3,
          'assets/img/types/gearless.webp',
        ];
        foreach ($shaftImgs as $fi => $src):
          if (!is_bg_image_path($src)) $src = $cabinBg;
      ?>
      <figure class="lift-floor<?= $fi === 0 ? ' is-on' : '' ?>" data-f="<?= $fi + 1 ?>" style="--fi:<?= $fi ?>">
        <img src="<?= e($src) ?>" alt="" decoding="async"<?= $fi === 0 ? ' fetchpriority="low"' : ' loading="lazy"' ?> draggable="false">
      </figure>
      <?php endforeach ?>
    </div>
    <div class="lift-bg-cable"></div>
    <div class="lift-bg-vignette"></div>
  </div>
</div>
<!-- سفر کابین‌ها روی شفت (بدون هاله‌ی رنگی) -->
<div class="cstage" id="cstage" aria-hidden="true">
  <div class="cs-bg">
    <div class="cs-floor"></div>
    <div class="cs-grain"></div>
  </div>
  <div class="cs-3d">
    <figure class="cs-obj o1" id="o1"><div class="cs-in">
      <?= $__cab($cabinBg, 'high') ?>
    </div></figure>
    <figure class="cs-obj o2" id="o2"><div class="cs-in">
      <?= $__cab($cabinBg2, 'low') ?>
    </div></figure>
    <figure class="cs-obj o3" id="o3"><div class="cs-in">
      <?= $__cab($cabinBg3, 'low') ?>
    </div></figure>
  </div>
  <div class="cs-dim" id="cs-dim"></div>
</div>
<div class="globe-vignette" aria-hidden="true"></div>
<!-- grid-overlay حذف شد (خط‌خط روی بک‌گراند) -->
<div id="scroll-progress" class="scroll-progress" aria-hidden="true"></div>

<!-- ============ هدر ============ -->
<header class="nav" id="site-nav">
  <div class="nav-inner">
    <a class="brand" href="index.php" aria-label="<?= e($brand) ?>">
      <?php if ($logo): ?><img class="site-logo" src="<?= e($logo) ?>" alt="<?= e($brand) ?>" decoding="async"><?php endif; ?>
      <span class="vh"><?= e($brand) ?></span>
    </a>

    <div class="nav-actions">
      <a class="nav-phone" href="tel:<?= e(en_digits($phone)) ?>">
        <?= icon('phone', 16) ?><span dir="ltr"><?= e($phone) ?></span>
      </a>
    </div>
  </div>
</header>

<main>

<!-- ============ هیرو: کابین سه‌بعدی اسکرولی ============ -->
<?php
$__g = static fn(string $k, string $d): string => e(setting('gfx.' . $k, $d));
?>
<section class="gfx" id="hero" aria-label="<?= e($brand) ?>">
  <div class="gfx-pin" id="gfx-pin">
    <div class="gfx-sky"></div>
    <div class="gfx-streaks" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
    <div class="gfx-rails" aria-hidden="true"><i class="gfx-rail l"><b></b></i><i class="gfx-rail r"><b></b></i></div>
    <div class="gfx-shadow" aria-hidden="true"></div>
    <div class="gfx-cab" aria-hidden="true">
      <i class="gfx-ring" aria-hidden="true"></i><i class="gfx-ring r2" aria-hidden="true"></i>
      <img class="gfx-f" src="assets/img/gfx2/c000.webp" alt="" width="608" height="1323" decoding="async" fetchpriority="high" draggable="false"><canvas class="gfx-cv" width="608" height="1323"></canvas>
      <i class="gfx-glow"></i>
    </div>
    <div class="gfx-dark" aria-hidden="true"></div>
    <div class="gfx-top" aria-hidden="true"></div>
    <div class="gfx-floor" aria-hidden="true"><i>▲</i><b>۱</b><small>طبقه</small></div>

    <article class="gfx-card">
      <span class="gfx-kick"><?= $__g('kick1', 'مهندسی، نصب و خدمات آسانسور') ?></span>
      <h1><?= $__g('title1', 'چرا خلیج فارس؟') ?></h1>
      <h3><?= $__g('sub1', 'از یک کابین ساده تا یک سفر امن') ?></h3>
      <p><?= $__g('text1', 'ما آسانسور را از نخستین قطعه تا آخرین طبقه می‌سازیم، نصب می‌کنیم و همراه شما نگه می‌داریم؛ همه‌چیز زیر یک سقف، با پاسخ‌گویی واقعی.') ?></p>
      <div class="gfx-hint"><i>↓</i><span>اسکرول کنید تا کابین را از نزدیک ببینید</span></div>
    </article>
    <article class="gfx-card">
      <span class="gfx-kick"><?= $__g('kick2', 'مهندسی دقیق') ?></span>
      <h2><?= $__g('title2', 'هر کابین، دقیقاً در ریل خودش.') ?></h2>
      <p><?= $__g('text2', 'ریل‌کشی، تراز و تنظیم کفشک‌ها با دقت انجام می‌شود تا حرکت کابین نرم، بی‌صدا و ایمن باشد.') ?></p>
    </article>
    <article class="gfx-card">
      <span class="gfx-kick"><?= $__g('kick3', 'حرکت و ایمنی') ?></span>
      <h2><?= $__g('title3', 'بالا می‌رویم، بدون نگرانی.') ?></h2>
      <p><?= $__g('text3', 'گاورنر، ترمز ایمنی و تابلوی کنترل هوشمند با بازرسی دوره‌ای؛ تا هر سفر مثل اولین سفر مطمئن باشد.') ?></p>
    </article>
    <article class="gfx-card">
      <span class="gfx-kick"><?= $__g('kick4', 'طبقه‌ی بعد') ?></span>
      <h2><?= $__g('title4', 'بقیه‌ی ماجرا را پایین‌تر ببینید.') ?></h2>
      <p><?= $__g('text4', 'خدمات، انواع آسانسور، قطعات و فرم درخواست سرویس؛ همه در ادامه‌ی همین مسیر.') ?></p>
      <div class="gfx-cta"><a class="p" href="#request"><?= e($hero['extra']['ctaPrimary'] ?? 'درخواست سرویس فوری') ?></a><a href="#features"><?= e($hero['extra']['ctaSecondary'] ?? 'مشاوره رایگان') ?></a></div>
    </article>
    <div class="gfx-bar" aria-hidden="true"><i></i></div>
  </div>
</section>

<!-- ============ نوار متحرک ============ -->
<section class="marquee">
  <div class="marquee-track">
    <?php for ($k = 0; $k < 2; $k++): ?>
      <?php foreach (['نصب آسانسور','سرویس دوره‌ای','تعمیر تخصصی','پروانه بهره‌برداری','قطعات اصل','پاسخ ۲۴ ساعته','سرویس سازمانی','نگهداری پیشگیرانه'] as $m): ?>
        <span><?= e($m) ?><i></i></span>
      <?php endforeach; ?>
    <?php endfor; ?>
  </div>
</section>

<?php if ($stories): ?>
<section class="section public-stories" id="stories" aria-labelledby="public-stories-title">
  <div class="section-head"><span class="eyebrow">▶ داستان‌ها و پروژه‌ها</span><h2 id="public-stories-title">ما را بهتر بشناسید</h2><p>ویدیوهای معرفی شرکت و روایت همکاری با مجموعه‌های صنعتی و ساختمانی</p></div>
  <div class="public-story-rail"><?php foreach($stories as $si=>$story): ?><button class="public-story" type="button" data-public-story="<?=$si?>"><span class="public-story-ring"><span style="<?=$story['poster_path']?'background-image:url('.e($story['poster_path']).')':''?>"><i>▶</i></span></span><b><?=e($story['company']?:$story['title'])?></b><small><?=e($story['title'])?></small></button><?php endforeach ?></div>
</section>
<script type="application/json" id="public-stories-json"><?=json_encode(array_map(static fn($s)=>['title'=>$s['title'],'subtitle'=>$s['subtitle'],'company'=>$s['company'],'video'=>$s['video_path'],'poster'=>$s['poster_path']],$stories),JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?></script>
<div class="public-story-viewer" id="public-story-viewer" hidden role="dialog" aria-modal="true" aria-label="پخش ویدیو"><button class="ps-close" aria-label="بستن">✕</button><button class="ps-prev" aria-label="قبلی">‹</button><div><video id="public-story-video" controls playsinline preload="metadata"></video><article><b id="ps-company"></b><h3 id="ps-title"></h3><p id="ps-subtitle"></p></article></div><button class="ps-next" aria-label="بعدی">›</button></div>
<?php endif; ?>

<!-- ============ مزایا ============ -->
<section class="section" id="features">
  <div class="section-head">
    <span class="eyebrow" data-reveal><?= icon('sparkle', 14) ?> مزایای همکاری با ما</span>
    <h2 class="grad" data-reveal data-rd="80"><?= e($feat['title']) ?></h2>
    <p data-reveal data-rd="160"><?= e($feat['subtitle']) ?></p>
  </div>
  <div class="grid-3">
    <?php foreach ($featItems as $i => $f): ?>
      <article class="card tilt" data-reveal data-rd="<?= $i * 90 ?>">
        <span class="card-icon"><?= icon($f['icon'] ?? 'sparkle', 24) ?></span>
        <h3><?= e($f['title']) ?></h3>
        <p><?= e($f['text']) ?></p>
      </article>
    <?php endforeach; ?>
  </div>
</section>


<!-- ============ راهنمای طبقات سایت (آسانسور سه‌بعدی) ============ -->
<section class="section" id="shaft3d">
  <div class="section-head">
    <span class="eyebrow" data-reveal><?= icon('sparkle', 14) ?> راهنمای طبقات</span>
    <h2 class="grad" data-reveal data-rd="80">کجا می‌روید؟</h2>
    <p data-reveal data-rd="160">اشاره‌گر یا شاسی را انتخاب کنید؛ کابین می‌رسد و همان بخش سایت باز می‌شود</p>
  </div>
  <div id="e3" class="e3" data-reveal></div>
</section>

<?php $__parts = parts_load();
  $__pItems = array_values(array_filter($__parts['items'], static fn($x) => !empty($x['active'])));
  $__catIcon = ['rails' => 'install', 'motors' => 'gauge', 'panels' => 'chip', 'moving' => 'layers', 'doors' => 'shield', 'safety' => 'life'];
?>
<?php if ($__pItems): ?>
<!-- ============ قفسه‌ی قطعات و متعلقات ============ -->
<section class="section" id="catalog">
  <div class="section-head">
    <span class="eyebrow" data-reveal><?= icon('install', 14) ?> قفسه‌ی قطعات</span>
    <h2 class="grad" data-reveal data-rd="80">قطعات و متعلقات آسانسور</h2>
    <p data-reveal data-rd="160">دسته‌ی مورد نظر را انتخاب کنید؛ روی هر قطعه بزنید تا مشخصات و توضیحاتش را ببینید و استعلام قیمت بگیرید.</p>
  </div>

  <nav class="cat-rail" aria-label="دسته‌بندی قفسه‌ها">
    <a class="cat-chip cat-chip-main" href="#types"><?= icon('layers', 16) ?><span>انواع آسانسور</span></a>
    <?php foreach ($__parts['cats'] as $c):
      $n = count(array_filter($__pItems, static fn($x) => $x['cat'] === $c['id'])); if (!$n) continue; ?>
      <a class="cat-chip" href="#shelf-<?= e($c['id']) ?>"><?= icon($__catIcon[$c['id']] ?? 'wrench', 16) ?><span><?= e($c['title']) ?></span><em><?= $n ?></em></a>
    <?php endforeach; ?>
  </nav>

  <div class="shelves">
    <?php foreach ($__parts['cats'] as $c):
      $list = array_values(array_filter($__pItems, static fn($x) => $x['cat'] === $c['id'])); if (!$list) continue; ?>
    <section class="shelf" id="shelf-<?= e($c['id']) ?>" aria-label="<?= e($c['title']) ?>">
      <header class="shelf-head"><h3><?= icon($__catIcon[$c['id']] ?? 'wrench', 18) ?> <?= e($c['title']) ?></h3><span><?= count($list) ?> قطعه</span></header>
      <div data-panoramic-shelf="<?= e($c['id']) ?>" data-title="<?= e($c['title']) ?>"></div>
      <div class="shelf-row">
        <?php foreach ($list as $it): ?>
        <button type="button" class="pcard" data-part="<?= e($it['id']) ?>">
          <span class="pimg"><?php if ($it['image']): ?><img src="<?= e($it['image']) ?>" alt="<?= e($it['title']) ?>" loading="lazy" decoding="async"><?php endif; ?></span>
          <b><?= e($it['title']) ?></b>
          <?php if ($it['tag'] !== ''): ?><small><?= e($it['tag']) ?></small><?php endif; ?>
        </button>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endforeach; ?>
  </div>
  <script type="application/json" id="parts-data"><?= json_encode($__pItems, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
</section>
<?php endif; ?>

<!-- ============ خدمات ============ -->
<section class="section" id="services">
  <div class="section-head">
    <span class="eyebrow" data-reveal><?= icon('layers', 14) ?> سرویس‌های تخصصی</span>
    <h2 class="grad" data-reveal data-rd="80"><?= e($serv['title']) ?></h2>
    <p data-reveal data-rd="160"><?= e($serv['subtitle']) ?></p>
  </div>
  <div class="grid-3">
    <?php foreach ($servItems as $i => $s): ?>
      <article class="svc tilt" data-reveal data-rd="<?= $i * 70 ?>">
        <span class="svc-icon"><?= icon($s['icon'] ?? 'gear', 22) ?></span>
        <div>
          <h3><?= e($s['title']) ?></h3>
          <p><?= e($s['text']) ?></p>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<?php
$__types = array_values(array_filter(types_load(), static fn($t) => !empty($t['active'])));
?>
<?php if ($__types): ?>
<!-- ============ انواع آسانسور: مقاله‌ی کوتاه + عکس با نقاط کلیک‌پذیر + توضیح صوتی ============ -->
<section class="section" id="types">
  <div class="section-head">
    <span class="eyebrow" data-reveal><?= icon('layers', 14) ?> آشنایی با آسانسور</span>
    <h2 class="grad" data-reveal data-rd="80">انواع آسانسور را بشناسید</h2>
    <p data-reveal data-rd="160">هر مدل را انتخاب کنید، توضیح صوتی‌اش را بشنوید و روی نقطه‌های نارنجی تصویر بزنید تا قطعه بزرگ شود.</p>
  </div>

  <div id="floor-gallery"></div>
  <script type="application/json" id="floor-gallery-data"><?= json_encode(array_map(static fn($t, $i) => ['id'=>(string)$t['id'],'title'=>(string)$t['title'],'src'=>(string)($t['image'] ?? ''),'caption'=>(string)($t['tag'] ?? ''),'floor'=>$i+1], $__types, array_keys($__types)), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
  <div class="tx" id="tx">
    <div class="tx-tabs" role="tablist" aria-label="انواع آسانسور">
      <?php foreach ($__types as $i => $t): ?>
        <button class="tx-tab" role="tab" type="button" id="txt-<?= e($t['id']) ?>" aria-controls="tx-<?= e($t['id']) ?>" aria-selected="<?= $i === 0 ? 'true' : 'false' ?>" data-tab="<?= e($t['id']) ?>"><?= e($t['title']) ?></button>
      <?php endforeach; ?>
    </div>

    <?php foreach ($__types as $i => $t):
      $hot = (array)($t['hotspots'] ?? []);
      $img = (string)($t['image'] ?? '');
      $dim = $img !== '' ? @getimagesize(__DIR__ . '/' . $img) : false;
      $price = (array)($t['price'] ?? []);
      $paras = preg_split('/\n{2,}/', trim((string)$t['article'])) ?: [];
      $speech = trim((string)$t['speech']) !== '' ? $t['speech'] : ('سلام. ' . $t['title'] . '. ' . strip_tags((string)$t['article']));
    ?>
    <div class="tx-panel<?= $img === '' ? ' noimg' : '' ?>" id="tx-<?= e($t['id']) ?>" role="tabpanel" aria-labelledby="txt-<?= e($t['id']) ?>" <?= $i === 0 ? '' : 'hidden' ?>
         data-title="<?= e($t['title']) ?>" data-audio="<?= e((string)$t['audio']) ?>" data-speech="<?= e($speech) ?>"
         data-base="<?= (int)($price['base'] ?? 0) ?>" data-per="<?= (int)($price['per_stop'] ?? 0) ?>"
         data-pano="<?= e((string)($t['pano'] ?? '')) ?>"
         data-hot="<?= e(json_encode(array_map(static fn($h) => ['title' => $h[0], 'desc' => $h[1]], $hot), JSON_UNESCAPED_UNICODE)) ?>">

      <?php if ($img !== ''): ?>
      <div class="tx-fig">
        <div class="tx-stage" style="--ar:<?= $dim ? round($dim[0] / $dim[1], 4) : 0.6 ?>">
          <div class="tx-zoomer">
            <img src="<?= e($img) ?>" alt="<?= e($t['title']) ?>" decoding="async" <?= $i === 0 ? '' : 'loading="lazy"' ?><?= $dim ? ' width="' . (int)$dim[0] . '" height="' . (int)$dim[1] . '"' : '' ?>>
            <?php $__cr = (array)($t['cabin_rect'] ?? []); $__ci = (string)($t['cabin_img'] ?? '');
              if ($__ci !== '' && count($__cr) === 4): ?>
              <img class="tx-cabin-img" src="<?= e($__ci) ?>" alt="" decoding="async" loading="lazy" style="left:<?= e((string)$__cr[0]) ?>%;top:<?= e((string)$__cr[1]) ?>%;width:<?= e((string)$__cr[2]) ?>%;height:<?= e((string)$__cr[3]) ?>%">
            <?php endif; ?>
            <?php if (!empty($t['pano']) && !in_array((string)$t['id'], ['freight','hospital','car'], true)): ?>
              <button type="button" class="tx-cabin-entry" data-pano-open aria-label="ورود به نمای ۳۶۰ درجه کابین"><span>نمای داخل کابین ۳۶۰° ↗</span></button>
            <?php endif; ?>
            <?php foreach ($hot as $hi => $h): ?>
              <button type="button" class="tx-dot" data-i="<?= $hi ?>" data-z="<?= e((string)$h[4]) ?>"<?= (($h[5] ?? '') === 'pano' && !empty($t['pano'])) ? ' data-act="pano"' : '' ?> style="left:<?= e((string)$h[2]) ?>%;top:<?= e((string)$h[3]) ?>%" aria-label="<?= e((string)$h[0]) ?>"><span></span></button>
            <?php endforeach; ?>
          </div>
        </div>
        <?php if (in_array($img, ['assets/img/types/freight-f7.webp','assets/img/types/hospital-f7.webp','assets/img/types/home-f7.webp','assets/img/types/car-f7.webp'], true)): ?><p class="tx-spec-note">تصویر مفهومی تولیدشده است و لزوماً نمونهٔ اجرایی پروژه نیست.</p><?php endif; ?>
        <?php if ($hot): ?>
        <div class="tx-callout" aria-live="polite"><b></b><p></p><button type="button" class="tx-back">بازگشت به نمای کامل</button></div>
        <p class="tx-hint"><i></i> روی نقطه‌های نارنجی بزنید تا قطعه بزرگ شود</p>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <div class="tx-info">
        <h3><?= e($t['title']) ?></h3>
        <?php if (!empty($t['tag'])): ?><p class="tx-tag"><?= e($t['tag']) ?></p><?php endif; ?>

        <div class="tx-actions">
          <button type="button" class="tx-listen" data-listen<?= (trim((string)$t['audio']) !== '' || trim((string)$speech) !== '') ? '' : ' hidden' ?>>
            <span class="eq" aria-hidden="true"><i></i><i></i><i></i></span><span class="tx-listen-label">شنیدن توضیحات</span>
          </button>
          <?php if (!empty($t['pano'])): ?>
          <button type="button" class="tx-ghost tx-pano-btn" data-pano-open>🔄 نمای ۳۶۰° داخل کابین</button>
          <?php endif; ?>
        </div>

        <div class="tx-art">
          <?php foreach ($paras as $para): ?><p><?= e(trim($para)) ?></p><?php endforeach; ?>
        </div>

        <?php if (!empty($t['specs'])): ?>
        <ul class="tx-specs">
          <?php foreach ($t['specs'] as $sp): ?><li><b><?= e((string)$sp[0]) ?></b><span><?= e((string)$sp[1]) ?></span></li><?php endforeach; ?>
        </ul>
        <p class="tx-spec-note">مقادیر نمونه و تقریبی هستند؛ سرعت و ظرفیت نهایی با طراحی پروژه و استانداردهای مربوط تعیین می‌شود.</p>
        <?php endif; ?>

        <?php if ($img !== '' && $hot): ?>
        <div class="tx-parts" role="group" aria-label="قطعات اصلی">
          <?php foreach ($hot as $hi => $h): ?>
            <button type="button" class="tx-part" data-i="<?= $hi ?>"><?= e((string)$h[0]) ?></button>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="tx-quote">
          <h4>استعلام قیمت این مدل</h4>
          <div class="tx-q-row">
            <div><label>تعداد توقف (طبقه)</label>
              <input class="input tx-stops" type="number" inputmode="numeric" min="2" max="60" value="3"></div>
            <div><label>ظرفیت (نفر)</label>
              <select class="input tx-cap"><?php foreach ([4, 6, 8, 10, 13, 16] as $c): ?><option value="<?= $c ?>"<?= $c === 6 ? ' selected' : '' ?>><?= $c ?> نفر</option><?php endforeach; ?></select></div>
          </div>
          <p class="tx-est" aria-live="polite"></p>
          <a class="btn btn-primary tx-ask" href="#request" data-type-title="<?= e($t['title']) ?>"><?= icon('send', 16) ?> ثبت استعلام قیمت</a>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<?php endif; ?>

<!-- ============ درخواست + تماس ============ -->
<section class="section" id="request">
  <div class="section-head">
    <span class="eyebrow" data-reveal><?= icon('send', 14) ?> اقدام سریع</span>
    <h2 class="grad" data-reveal data-rd="80"><?= e($cta['title']) ?></h2>
    <p data-reveal data-rd="160"><?= e($cta['subtitle']) ?></p>
  </div>

  <div class="req-grid">
    <!-- فرم درخواست سرویس -->
    <div class="panel" data-reveal>
      <div class="panel-head">
        <span class="panel-icon"><?= icon('send', 26) ?></span>
        <div><h3>ثبت درخواست سرویس</h3><p>فرم را پر کنید تا در کمترین زمان تماس بگیریم</p></div>
      </div>

      <form id="request-form" class="form" novalidate>
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

        <div class="field">
          <label>نوع درخواست</label>
          <div class="seg">
            <label class="seg-opt"><input type="radio" name="request_type" value="service" checked><span><?= icon('wrench', 18) ?> سرویس و تعمیر</span></label>
            <label class="seg-opt"><input type="radio" name="request_type" value="install"><span><?= icon('install', 18) ?> نصب آسانسور</span></label>
            <label class="seg-opt"><input type="radio" name="request_type" value="maintenance"><span><?= icon('shield', 18) ?> قرارداد نگهداری</span></label>
          </div>
        </div>

        <div class="field">
          <label for="r-subject">موضوع درخواست *</label>
          <input class="input" id="r-subject" name="subject" required minlength="3" placeholder="مثال: سرویس دوره‌ای آسانسور ساختمان مسکونی">
        </div>

        <div class="field-row two">
          <div class="field">
            <label for="r-name">نام و نام خانوادگی *</label>
            <input class="input" id="r-name" name="customer_name" required minlength="3" placeholder="نام شما">
          </div>
          <div class="field">
            <label for="r-phone">شماره موبایل *</label>
            <input class="input ltr" id="r-phone" name="phone" required dir="ltr" placeholder="09121234567">
          </div>
        </div>

        <div class="field-row two">
          <div class="field">
            <label for="r-email">ایمیل (اختیاری)</label>
            <input class="input ltr" id="r-email" name="email" type="email" dir="ltr" placeholder="name@example.com">
          </div>
          <div class="field">
            <label for="r-city">شهر</label>
            <input class="input" id="r-city" name="city" placeholder="تهران">
          </div>
        </div>

        <div class="field">
          <label for="r-address">آدرس محل آسانسور</label>
          <input class="input" id="r-address" name="address" placeholder="خیابان، کوچه، پلاک، واحد">
        </div>

        <div class="field-row two">
          <div class="field">
            <label for="r-etype">نوع آسانسور</label>
            <select class="input" id="r-etype" name="elevator_type">
              <option value="">انتخاب کنید</option>
              <?php $__opts = ['آسانسور برقی','آسانسور هیدرولیک','آسانسور کششی','آسانسور ریلی','آسانسور گودالی','پلکان‌برقی']; foreach ($__types ?? [] as $__tt) { $__opts[] = $__tt['title']; } $__opts[] = 'نمی‌دانم'; foreach (array_values(array_unique($__opts)) as $t): ?>
                <option value="<?= e($t) ?>"><?= e($t) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label for="r-brand">برند / سازنده فعلی</label>
            <input class="input" id="r-brand" name="brand" placeholder="مثال: کیدا، آتیس، OTIS">
          </div>
        </div>

        <div class="field-row three">
          <div class="field">
            <label for="r-floors">تعداد طبقات</label>
            <input class="input" id="r-floors" name="floors" type="number" min="1" max="120" value="5">
          </div>
          <div class="field">
            <label for="r-pass">ظرفیت (نفر)</label>
            <input class="input" id="r-pass" name="passengers" type="number" min="1" max="100" value="6">
          </div>
          <div class="field">
            <label for="r-date">تاریخ دلخواه (شمسی)</label>
            <input class="input" id="r-date" name="preferred_date" type="text" inputmode="numeric" placeholder="مثلاً ۱۴۰۴/۰۸/۱۵" autocomplete="off" data-jalali-date maxlength="14">
          </div>
        </div>

        <div class="field">
          <label for="r-urgency">فوریت</label>
          <select class="input" id="r-urgency" name="urgency">
            <option value="low">عادی — ظرف یک هفته</option>
            <option value="normal" selected>نرمال — ظرف ۴۸ ساعت</option>
            <option value="high">فوری — ظرف ۲۴ ساعت</option>
            <option value="emergency">اضطراری — همین حالا</option>
          </select>
        </div>

        <div class="field">
          <label for="r-msg">توضیحات تکمیلی</label>
          <textarea class="input" id="r-msg" name="message" rows="4" placeholder="شرح مشکل، زمان مناسب مراجعه و ..."></textarea>
        </div>

        <div class="form-msg" id="request-msg" hidden></div>
        <div class="liquid-metal-mount liquid-metal-form" data-liquid-metal data-label="ارسال درخواست" data-button-id="request-btn" data-type="submit" data-width="300" role="presentation"></div>
        <p class="form-note">اطلاعات شما محفوظ است و تنها برای تماس کارشناس فنی استفاده می‌شود.</p>
      </form>

      <div class="form-success" id="request-success" hidden>
        <span class="ok-icon"><?= icon('check', 36) ?></span>
        <h3>درخواست شما ثبت شد</h3>
        <p>کارشناسان ما در کمتر از ۲۴ ساعت با شما تماس می‌گیرند.</p>
        <div class="ticket-box"><span>کد پیگیری</span><b dir="ltr" id="request-ticket"></b></div>
        <div class="liquid-metal-mount" data-liquid-metal data-label="ثبت درخواست جدید" data-button-id="request-again" data-width="190" role="presentation"></div>
      </div>
    </div>

    <!-- تماس + پشتیبانی -->
    <div class="side-col" data-reveal data-rd="140">
      <div class="panel" id="contact">
        <h3 class="panel-title">تماس مستقیم با کارشناس</h3>
        <p class="muted small">برای مشاوره فوری و پیگیری وضعیت درخواست تماس بگیرید.</p>

        <div class="contact-list">
          <a class="crow" href="tel:<?= e(en_digits($phone)) ?>">
            <span class="crow-ic gold"><?= icon('phone', 20) ?></span>
            <span class="crow-tx"><i>تلفن ثابت</i><b dir="ltr"><?= e($phone) ?></b></span>
          </a>
          <a class="crow" href="tel:<?= e(en_digits($mobile)) ?>">
            <span class="crow-ic blue"><?= icon('phone', 20) ?></span>
            <span class="crow-tx"><i>همراه / پشتیبانی ۲۴ ساعته</i><b dir="ltr"><?= e($mobile) ?></b></span>
          </a>
          <?php if ($email): ?>
          <a class="crow" href="mailto:<?= e($email) ?>">
            <span class="crow-ic violet"><?= icon('mail', 20) ?></span>
            <span class="crow-tx"><i>ایمیل</i><b dir="ltr"><?= e($email) ?></b></span>
          </a>
          <?php endif; ?>
          <?php if ($addr): ?>
          <div class="crow static">
            <span class="crow-ic blue"><?= icon('pin', 20) ?></span>
            <span class="crow-tx"><i>نشانی</i><b class="wrap"><?= e($addr) ?></b></span>
          </div>
          <?php endif; ?>
          <?php if ($hours): ?>
          <div class="crow static">
            <span class="crow-ic blue"><?= icon('clock', 20) ?></span>
            <span class="crow-tx"><i>ساعات کاری</i><b class="wrap"><?= e($hours) ?></b></span>
          </div>
          <?php endif; ?>
        </div>

        <?php if ($wa): ?>
        <div class="liquid-metal-mount liquid-metal-wide" data-liquid-metal data-label="گفتگو در واتس‌اپ" data-href="https://wa.me/<?= e(en_digits($wa)) ?>" data-width="230" data-target="_blank" role="presentation"></div>
        <?php endif; ?>
      </div>

      <!-- فرم پشتیبانی -->
      <div class="panel">
        <div class="panel-head small">
          <span class="panel-icon sm"><?= icon('life', 22) ?></span>
          <h3>پشتیبانی سایت</h3>
        </div>
        <form id="support-form" class="form" novalidate>
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <div class="field">
            <label for="s-subject">موضوع *</label>
            <input class="input" id="s-subject" name="subject" required minlength="3" placeholder="موضوع پیام">
          </div>
          <div class="field">
            <label for="s-body">متن پیام *</label>
            <textarea class="input" id="s-body" name="body" rows="4" required minlength="10" placeholder="پیام خود را بنویسید..."></textarea>
          </div>
          <div class="field-row two">
            <div class="field">
              <label for="s-name">نام شما</label>
              <input class="input" id="s-name" name="sender_name" placeholder="نام">
            </div>
            <div class="field">
              <label for="s-email">ایمیل</label>
              <input class="input ltr" id="s-email" name="sender_email" type="email" dir="ltr" placeholder="you@example.com">
            </div>
          </div>
          <div class="form-msg" id="support-msg" hidden></div>
          <div class="liquid-metal-mount liquid-metal-form" data-liquid-metal data-label="ارسال پیام" data-button-id="support-btn" data-type="submit" data-width="260" role="presentation"></div>
        </form>
        <div class="form-success" id="support-success" hidden>
          <span class="ok-icon sm"><?= icon('check', 28) ?></span>
          <h3>پیام شما ثبت شد</h3>
          <b dir="ltr" id="support-ticket" class="ticket-inline"></b>
          <div class="liquid-metal-mount" data-liquid-metal data-label="ارسال پیام جدید" data-button-id="support-again" data-width="190" role="presentation"></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ============ نظرات ============ -->
<?php if ($testItems): ?>
<section class="section">
  <div class="section-head">
    <span class="eyebrow" data-reveal><?= icon('star', 14) ?> رضایت مشتریان</span>
    <h2 class="grad" data-reveal data-rd="80"><?= e($test['title']) ?></h2>
    <p data-reveal data-rd="160"><?= e($test['subtitle']) ?></p>
  </div>
  <div class="grid-3">
    <?php foreach ($testItems as $i => $t): ?>
      <figure class="quote tilt" data-reveal data-rd="<?= $i * 110 ?>">
        <div class="stars"><?php for ($k=0;$k<5;$k++) echo icon('star', 15); ?></div>
        <blockquote>«<?= e($t['text']) ?>»</blockquote>
        <figcaption>
          <span class="avatar"><?= e(mb_substr(trim($t['name']), 0, 1, 'UTF-8')) ?></span>
          <span><b><?= e($t['name']) ?></b><i><?= e($t['role']) ?></i></span>
        </figcaption>
      </figure>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<!-- صحنه سینمایی کابین: ترکیب‌بندی‌های متوالی وابسته به اسکرول -->


<!-- ============ بنر پایانی ============ -->
<section class="section">
  <div class="cta-banner" data-reveal>
    <h2 class="grad"><?= e($cta['title']) ?></h2>
    <p><?= e($cta['body']) ?></p>
    <div class="hero-actions center">
      <div class="liquid-metal-mount" data-liquid-metal data-label="<?= e($cta['extra']['cta'] ?? 'ثبت درخواست سرویس آسانسور') ?>" data-href="#request" data-width="190" role="presentation"></div>
      <div class="liquid-metal-mount" data-liquid-metal data-label="تماس تلفنی" data-href="tel:<?= e(en_digits($mobile)) ?>" data-width="150" role="presentation"></div>
    </div>
  </div>
</section>


</main>

<!-- ============ فوتر ============ -->
<footer class="footer ft" id="footer">
  <div class="ft-seam" aria-hidden="true"></div>
  <div class="footer-inner">

    <div class="ft-top">
      <div class="ft-call">
        <span class="ft-eyebrow">پاسخ‌گویی ۲۴ ساعته — تماس مستقیم</span>
        <a class="ft-phone" href="tel:<?= e(en_digits($mobile ?: $phone)) ?>" dir="ltr"><?= e($mobile ?: $phone) ?></a>
      </div>
      <a class="ft-up" href="#hero" id="ft-up"><i>▲</i><span>بازگشت به طبقه‌ی همکف</span></a>
    </div>

    <div class="footer-grid">
      <div class="footer-brand">
        <div class="brand" aria-label="<?= e($brand) ?>">
          <?php if ($logo): ?><img class="site-logo" src="<?= e($logo) ?>" alt="<?= e($brand) ?>" decoding="async" loading="lazy"><?php endif; ?>
          <span class="vh"><?= e($brand) ?></span>
        </div>
        <p><?= e($foot['body']) ?></p>
        <div class="socials">
          <?php if ($wa): ?><a href="https://wa.me/<?= e(en_digits($wa)) ?>" target="_blank" rel="noreferrer" aria-label="واتس‌اپ" class="so green"><?= icon('whatsapp', 20) ?></a><?php endif; ?>
          <a href="https://t.me/" target="_blank" rel="noreferrer" aria-label="تلگرام" class="so blue"><?= icon('telegram', 20) ?></a>
          <a href="<?= e($insta ?: 'https://www.instagram.com/') ?>" target="_blank" rel="noreferrer" aria-label="اینستاگرام" class="so pink"><?= icon('instagram', 20) ?></a>
          <?php if ($email): ?><a href="mailto:<?= e($email) ?>" aria-label="ایمیل" class="so"><?= icon('mail', 20) ?></a><?php endif; ?>
        </div>
      </div>

      <div class="footer-col">
        <h4>طبقه‌های سایت</h4>
        <ul class="ft-floors">
          <?php foreach ($quickLinks as $l): ?>
            <li><a href="<?= e($l['href']) ?>"><?= e($l['label']) ?></a></li>
          <?php endforeach; ?>
        </ul>
      </div>

      <div class="footer-col">
        <h4>تماس با ما</h4>
        <ul class="contact-ul">
          <li><?= icon('phone', 16) ?><span dir="ltr"><?= e($phone) ?></span></li>
          <li><?= icon('phone', 16) ?><span dir="ltr"><?= e($mobile) ?></span></li>
          <?php if ($email): ?><li><?= icon('mail', 16) ?><span dir="ltr"><?= e($email) ?></span></li><?php endif; ?>
          <?php if ($addr): ?><li><?= icon('pin', 16) ?><span><?= e($addr) ?></span></li><?php endif; ?>
          <?php if ($hours): ?><li><?= icon('clock', 16) ?><span><?= e($hours) ?></span></li><?php endif; ?>
        </ul>
      </div>
    </div>

    <div class="copyright">
      <p>© <?= e(fa_digits((int)date('Y'))) ?> — تمامی حقوق برای <b><?= e($brand) ?></b> محفوظ است.</p>
    </div>

  </div>
</footer>

<!-- ناوبری شناور پایین صفحه، با تعامل شبیه تب‌های تلگرام -->
<nav class="bottom-dock" id="bottom-dock" aria-label="ناوبری اصلی">
  <i class="dock-pill" id="dock-pill" aria-hidden="true"></i>
  <a class="dock-link is-active" href="#hero" data-dock-link><span class="dock-icon" data-ic="home"><svg aria-hidden="true" focusable="false" viewBox="0 0 256 256" fill="currentColor"><path d="M184,104V216H72V104Z" opacity="0.2"/><path d="M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm-32,80v96H136V112Zm-56,96H80V112h40Zm88,0H192V104a8,8,0,0,0-8-8H72a8,8,0,0,0-8,8V208H48V48H208V208ZM152,72a8,8,0,0,1-8,8H112a8,8,0,0,1,0-16h32A8,8,0,0,1,152,72Z"/></svg></span><span>خانه</span></a>
  <a class="dock-link" href="#types" data-dock-link><span class="dock-icon" data-ic="cube"><svg aria-hidden="true" focusable="false" viewBox="0 0 256 256" fill="currentColor"><path d="M128,129.09V232a8,8,0,0,1-3.84-1l-88-48.16a8,8,0,0,1-4.16-7V80.2a8,8,0,0,1,.7-3.27Z" opacity="0.2"/><path d="M223.68,66.15,135.68,18h0a15.88,15.88,0,0,0-15.36,0l-88,48.17a16,16,0,0,0-8.32,14v95.64a16,16,0,0,0,8.32,14l88,48.17a15.88,15.88,0,0,0,15.36,0l88-48.17a16,16,0,0,0,8.32-14V80.18A16,16,0,0,0,223.68,66.15ZM128,32h0l80.34,44L128,120,47.66,76ZM40,90l80,43.78v85.79L40,175.82Zm96,129.57V133.82L216,90v85.78Z"/></svg></span><span>انواع</span></a>
  <a class="dock-link" href="#catalog" data-dock-link><span class="dock-icon" data-ic="box"><svg aria-hidden="true" focusable="false" viewBox="0 0 256 256" fill="currentColor"><path d="M232,120v72a8,8,0,0,1-8,8H32a8,8,0,0,1-8-8V120Z" opacity="0.2"/><path d="M224,64H176V56a24,24,0,0,0-24-24H104A24,24,0,0,0,80,56v8H32A16,16,0,0,0,16,80V192a16,16,0,0,0,16,16H224a16,16,0,0,0,16-16V80A16,16,0,0,0,224,64ZM96,56a8,8,0,0,1,8-8h48a8,8,0,0,1,8,8v8H96ZM32,80H224v32H192v-8a8,8,0,0,0-16,0v8H80v-8a8,8,0,0,0-16,0v8H32ZM224,192H32V128H64v8a8,8,0,0,0,16,0v-8h96v8a8,8,0,0,0,16,0v-8h32v64Z"/></svg></span><span>قطعات</span></a>
  <a class="dock-link" href="#services" data-dock-link><span class="dock-icon" data-ic="tools"><svg aria-hidden="true" focusable="false" viewBox="0 0 256 256" fill="currentColor"><path d="M224,96a64,64,0,0,1-94.94,56L73,217A24,24,0,0,1,39,183L104,126.94a64,64,0,0,1,80-90.29L144,80l5.66,26.34L176,112l43.35-40A63.8,63.8,0,0,1,224,96Z" opacity="0.2"/><path d="M226.76,69a8,8,0,0,0-12.84-2.88l-40.3,37.19-17.23-3.7-3.7-17.23,37.19-40.3A8,8,0,0,0,187,29.24,72,72,0,0,0,88,96,72.34,72.34,0,0,0,94,124.94L33.79,177c-.15.12-.29.26-.43.39a32,32,0,0,0,45.26,45.26c.13-.13.27-.28.39-.42L131.06,162A72,72,0,0,0,232,96,71.56,71.56,0,0,0,226.76,69ZM160,152a56.14,56.14,0,0,1-27.07-7,8,8,0,0,0-9.92,1.77L67.11,211.51a16,16,0,0,1-22.62-22.62L109.18,133a8,8,0,0,0,1.77-9.93,56,56,0,0,1,58.36-82.31l-31.2,33.81a8,8,0,0,0-1.94,7.1L141.83,108a8,8,0,0,0,6.14,6.14l26.35,5.66a8,8,0,0,0,7.1-1.94l33.81-31.2A56.06,56.06,0,0,1,160,152Z"/></svg></span><span>خدمات</span></a>
  <a class="dock-link dock-primary" href="#request" data-dock-link><span class="dock-icon" data-ic="send"><svg aria-hidden="true" focusable="false" viewBox="0 0 256 256" fill="currentColor"><path d="M223.69,42.18l-58.22,192a8,8,0,0,1-14.92,1.25L108,148,20.58,105.45a8,8,0,0,1,1.25-14.92l192-58.22A8,8,0,0,1,223.69,42.18Z" opacity="0.2"/><path d="M227.32,28.68a16,16,0,0,0-15.66-4.08l-.15,0L19.57,82.84a16,16,0,0,0-2.49,29.8L102,154l41.3,84.87A15.86,15.86,0,0,0,157.74,248q.69,0,1.38-.06a15.88,15.88,0,0,0,14-11.51l58.2-191.94c0-.05,0-.1,0-.15A16,16,0,0,0,227.32,28.68ZM157.83,231.85l-.05.14,0-.07-40.06-82.3,48-48a8,8,0,0,0-11.31-11.31l-48,48L24.08,98.25l-.07,0,.14,0L216,40Z"/></svg></span><span>درخواست</span></a>
</nav>

<!-- دکمه‌های تماس شناور -->


<script>
/* دستگاه ضعیف: دکمه‌های ساده؛ دستگاه قوی: Liquid Metal پایدار (بدون WebGL) */
(function(){
  if(document.documentElement.getAttribute('data-perf')!=='lite')return;
  [].forEach.call(document.querySelectorAll('[data-liquid-metal]'),function(m){
    var href=m.getAttribute('data-href'),el=document.createElement(href?'a':'button');
    el.className='btn btn-primary lm-static';
    el.textContent=m.getAttribute('data-label')||'';
    var id=m.getAttribute('data-button-id');if(id)el.id=id;
    if(href){el.href=href;if(m.getAttribute('data-target')==='_blank'){el.target='_blank';el.rel='noopener noreferrer'}}
    else el.type=m.getAttribute('data-type')==='submit'?'submit':'button';
    m.setAttribute('data-static','1');m.appendChild(el);
  });
})();
</script>
<script src="assets/js/liquid-metal.js?v=<?= (int) @filemtime(__DIR__ . '/assets/js/liquid-metal.js') ?>"></script>
<script src="assets/js/fx.js?v=<?= (int) @filemtime(__DIR__ . '/assets/js/fx.js') ?>" defer></script>
<script src="assets/js/bg-fx.js?v=<?= (int) @filemtime(__DIR__ . '/assets/js/bg-fx.js') ?>" defer></script>
<script src="assets/js/app.js?v=<?= $assetVer ?>"></script>
<script src="assets/js/scene.js?v=<?= $assetVer ?>"></script>
<script src="assets/js/cabin.js?v=<?= $assetVer ?>"></script>
<script src="assets/js/types.js?v=<?= $assetVer ?>" defer></script>
<script src="assets/js/parts.js?v=<?= $assetVer ?>" defer></script>
<script src="assets/js/coverflow.js?v=<?= $assetVer ?>" defer></script>
<script src="assets/js/building3d.js?v=<?= $assetVer ?>" defer></script>
<script src="assets/js/elevator3d.js?v=<?= $assetVer ?>" defer></script>
<script src="assets/js/showcase.js?v=<?= $assetVer ?>" defer></script>
<script src="assets/js/flow.js?v=<?= $assetVer ?>" defer></script>
<script src="assets/js/jalali-date.js?v=<?= $assetVer ?>" defer></script>
<script src="assets/js/gfx.js?v=<?= (int) @filemtime(__DIR__ . '/assets/js/gfx.js') ?>"></script>
<script src="assets/js/stories.js?v=<?= (int) @filemtime(__DIR__ . '/assets/js/stories.js') ?>" defer></script>
</body>
</html>

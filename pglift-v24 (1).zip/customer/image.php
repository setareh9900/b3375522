<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/fn.php';
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
$id = max(0, (int)($_GET['id'] ?? 0));
$part = $id ? q_one('SELECT customer_id,image_ref FROM customer_parts WHERE id=?', [$id]) : null;
$admin = current_user();
$customer = !empty($_SESSION['customer_id']) ? q_one('SELECT id,password_hash FROM customer_accounts WHERE id=?', [(int)$_SESSION['customer_id']]) : null;
$validCustomer = $customer && hash_equals($customer['password_hash'], (string)($_SESSION['customer_password_hash'] ?? ''));
if (!$part || (!$admin && (!$validCustomer || (int)$customer['id'] !== (int)$part['customer_id']))) { http_response_code(404); exit; }
$ref = (string)$part['image_ref'];
if (preg_match('#^private/([a-f0-9]{32}\.(?:jpg|png|webp))$#D', $ref, $m)) {
    $file = dirname(__DIR__).'/data/customer-images/'.$m[1];
} elseif (preg_match('#^(assets/img/parts|uploads/parts)/[A-Za-z0-9_.-]+\.(?:webp|png|jpg|jpeg)$#iD', $ref)) {
    $file = dirname(__DIR__).'/'.$ref;
} else { http_response_code(404); exit; }
$info = @getimagesize($file);
$mime = [IMAGETYPE_JPEG => 'image/jpeg', IMAGETYPE_PNG => 'image/png', IMAGETYPE_WEBP => 'image/webp'];
if (!$info || !isset($mime[$info[2]]) || !is_file($file)) { http_response_code(404); exit; }
header('Content-Type: '.$mime[$info[2]]);
header('Content-Length: '.filesize($file));
readfile($file);

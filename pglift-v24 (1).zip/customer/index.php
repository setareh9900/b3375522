<?php
declare(strict_types=1);
require_once __DIR__.'/../inc/fn.php';
if (!gf_is_configured()) redirect('../install.php');
require_once __DIR__.'/../inc/customer-schema.php';
require_once __DIR__.'/../inc/types.php';
require_once __DIR__.'/../inc/parts.php';
require_once __DIR__.'/../inc/features.php';
header('Cache-Control: no-store');
try { customer_schema(); } catch (Throwable $e) { /* admin must open panel once */ }

$brandName = setting('customer.brand_name') ?: setting('brand.name', 'خلیج فارس');
$panelSubtitle = setting('customer.subtitle', 'پنل اختصاصی مشتریان');
$catalogTitle = setting('customer.catalog_title', 'قطعات آسانسور شما');
$contractsTitle = setting('customer.contracts_title', 'قراردادهای من');
$servicesTitle = setting('customer.services_title', 'سرویس‌های دوره‌ای');
$supportPhone = trim(setting('brand.phone'));
$logoUrl = active_logo();
$error = '';

try {
    /* ورود با لینک جادویی (بدون رمز) */
    $magic = trim((string)($_GET['t'] ?? ''));
    if ($magic !== '' && preg_match('/^[a-f0-9]{32,64}$/i', $magic)) {
        $acc = q_one("SELECT * FROM customer_accounts WHERE login_token=? AND login_token<>'' AND login_link_enabled=1", [$magic]);
        if ($acc) {
            session_regenerate_id(true);
            $_SESSION['customer_id'] = (int)$acc['id'];
            $_SESSION['customer_password_hash'] = $acc['password_hash'];
            redirect('index.php');
        }
        $error = 'لینک ورود غیرفعال یا نامعتبر است. از مدیریت لینک فعال بگیرید.';
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!csrf_check($_POST['csrf'] ?? null)) { http_response_code(403); exit('توکن امنیتی نامعتبر است.'); }
        if (($_POST['action'] ?? '') === 'logout') { unset($_SESSION['customer_id'], $_SESSION['customer_password_hash']); session_regenerate_id(true); redirect('index.php'); }
        if (($_POST['action'] ?? 'login') === 'login') {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $key = hash('sha256', (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
        $attempt = q_one('SELECT * FROM customer_login_attempts WHERE attempt_key=?', [$key]);
        if ($attempt && (int)$attempt['attempts'] >= 6 && (int)$attempt['last_attempt'] > time()-300) {
            $error = 'تلاش‌های ورود بیش از حد است؛ پنج دقیقه بعد دوباره تلاش کنید.';
        } else {
            $account = q_one('SELECT * FROM customer_accounts WHERE username=?', [$username]);
            if ($account && password_verify($password, $account['password_hash'])) {
                q('DELETE FROM customer_login_attempts WHERE attempt_key=?', [$key]);
                session_regenerate_id(true); $_SESSION['customer_id'] = (int)$account['id']; $_SESSION['customer_password_hash'] = $account['password_hash']; redirect('index.php');
            }
            $count = $attempt && (int)$attempt['last_attempt'] > time()-300 ? (int)$attempt['attempts']+1 : 1;
            q('DELETE FROM customer_login_attempts WHERE attempt_key=?', [$key]);
            q('INSERT INTO customer_login_attempts (attempt_key,attempts,last_attempt) VALUES (?,?,?)', [$key,$count,time()]);
            $error = 'نام کاربری یا رمز عبور نادرست است.';
        }
        }
    }
    $customer = !empty($_SESSION['customer_id']) ? q_one('SELECT id,name,elevator_details,elevator_type,elevator_audio,password_hash FROM customer_accounts WHERE id=?', [(int)$_SESSION['customer_id']]) : null;
    if ($customer && !hash_equals($customer['password_hash'], (string)($_SESSION['customer_password_hash'] ?? ''))) { unset($_SESSION['customer_id'], $_SESSION['customer_password_hash']); $customer = null; }
    feature_schema();
    $orders = [];
    $contracts = $customer ? q_all('SELECT * FROM customer_contracts WHERE customer_id=? ORDER BY id DESC', [(int)$customer['id']]) : [];
    $serviceVisits = $customer ? q_all('SELECT * FROM customer_service_visits WHERE customer_id=? ORDER BY id DESC LIMIT 100', [(int)$customer['id']]) : [];
    $lastService = $serviceVisits[0] ?? null;
    $nextServiceDate = (string)($lastService['next_service_date'] ?? '');
    $servicePercent = min(100, count($serviceVisits) * 20);
    $stories = active_stories(30, 'customer');
    $parts = $customer ? q_all('SELECT id,name,specifications,quantity,price,image_ref,brand,model,serial_number,installed_at,warranty FROM customer_parts WHERE customer_id=? ORDER BY id DESC', [(int)$customer['id']]) : [];
} catch (Throwable $ex) { $error = $ex instanceof RuntimeException ? $ex->getMessage() : 'پنل مشتریان آماده نیست. مدیر سایت باید ابتدا بخش مدیریت مشتریان را باز کند.'; $customer = null; $parts = []; $orders = []; $contracts = []; $serviceVisits = []; $lastService = null; $nextServiceDate = ''; $servicePercent = 0; $stories = []; }

$elevatorTypeMeta = null;
if ($customer) {
    $tid = trim((string)($customer['elevator_type'] ?? ''));
    if ($tid !== '') {
        foreach (types_load() as $t) {
            if ((string)$t['id'] === $tid) { $elevatorTypeMeta = $t; break; }
        }
    }
}
$typeImg = $elevatorTypeMeta ? (string)($elevatorTypeMeta['image'] ?? '') : '';
$typeTitle = $elevatorTypeMeta ? (string)($elevatorTypeMeta['title'] ?? '') : '';
$typeTag = $elevatorTypeMeta ? (string)($elevatorTypeMeta['tag'] ?? '') : '';
$typeArticle = $elevatorTypeMeta ? trim((string)($elevatorTypeMeta['article'] ?? '')) : '';
$typeSpecs = ($elevatorTypeMeta && is_array($elevatorTypeMeta['specs'] ?? null)) ? $elevatorTypeMeta['specs'] : [];
$typeHotspots = ($elevatorTypeMeta && is_array($elevatorTypeMeta['hotspots'] ?? null)) ? $elevatorTypeMeta['hotspots'] : [];
$typeSpeech = $elevatorTypeMeta ? trim((string)($elevatorTypeMeta['speech'] ?? '')) : '';
$elevatorAudio = '';
if ($customer) {
    $rawAudio = trim((string)($customer['elevator_audio'] ?? '')) ?: trim((string)($elevatorTypeMeta['audio'] ?? ''));
    if ($rawAudio !== '' && preg_match('#^uploads/audio/[a-zA-Z0-9_.-]+\.(mp3|m4a|ogg|wav|webm)$#i', $rawAudio)) {
        $elevatorAudio = '../api/audio.php?f=' . rawurlencode(basename($rawAudio));
    }
}
$customDetails = $customer ? trim((string)($customer['elevator_details'] ?? '')) : '';
$elevatorSpeech = $customDetails !== '' ? $customDetails : ($typeSpeech !== '' ? $typeSpeech : $typeArticle);
$detailsDisplay = $customDetails !== ''
    ? $customDetails
    : ($typeArticle !== '' ? $typeArticle : ($typeTitle !== '' ? $typeTitle . ($typeTag !== '' ? ' — ' . $typeTag : '') : 'مشخصات آسانسور هنوز توسط مدیریت ثبت نشده است.'));
$customerTheme = setting('customer.ui_kit','gradient');
if (!in_array($customerTheme,['gradient','porcelain','azure','sage','sand','midnight'],true)) $customerTheme='gradient';
$customerLayout = setting('customer.layout','sidebar') === 'compact' ? 'compact' : 'sidebar';
?>
<!doctype html>
<html lang="fa" dir="rtl" class="no-js" data-customer-theme="<?=e($customerTheme)?>" data-customer-layout="<?=e($customerLayout)?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#0b0a0c">
<title>پنل مشتریان | <?=e($brandName)?></title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/coverflow.css?v=<?= (int) @filemtime(__DIR__ . '/../assets/css/coverflow.css') ?>">
<link rel="stylesheet" href="../assets/css/customer-v12.css?v=<?= (int) @filemtime(__DIR__ . '/../assets/css/customer-v12.css') ?>">
<link rel="stylesheet" href="../assets/css/customer-v16.css?v=<?= (int) @filemtime(__DIR__ . '/../assets/css/customer-v16.css') ?>">
<link rel="stylesheet" href="../assets/css/customer-ui.css?v=<?= (int) @filemtime(__DIR__ . '/../assets/css/customer-ui.css') ?>">
<link rel="stylesheet" href="../assets/react/customer/customer-sidebar.css?v=<?= (int) @filemtime(__DIR__ . '/../assets/react/customer/customer-sidebar.css') ?>">
<link rel="stylesheet" href="../assets/css/customer-kit.css?v=<?= (int) @filemtime(__DIR__ . '/../assets/css/customer-kit.css') ?>">
<script>document.documentElement.className='js';try{var n=navigator,touch=matchMedia('(pointer:coarse)').matches,lite=false;if(matchMedia('(prefers-reduced-motion:reduce)').matches)lite=true;else if(n.deviceMemory&&n.deviceMemory<=2)lite=true;else if(n.hardwareConcurrency&&n.hardwareConcurrency<=2)lite=true;else if(touch&&innerWidth<700)lite=true;if(lite)document.documentElement.setAttribute('data-perf','lite')}catch(e){}</script>
</head>
<body class="cp">
<div class="cp-shaft" aria-hidden="true">
  <div class="cp-shaft-rails"></div>
  <div class="cp-shaft-cab">
    <img src="<?= $typeImg ? '../'.e($typeImg) : '../assets/img/cabin-copper.webp' ?>" alt="" decoding="async" fetchpriority="high" draggable="false">
  </div>
  <div class="cp-shaft-floors">
    <i data-n="۴"></i><i data-n="۳"></i><i data-n="۲"></i><i class="on" data-n="۱"></i>
  </div>
  <div class="cp-shaft-vignette"></div>
</div>
<div class="cp-grain" aria-hidden="true"></div>
<div class="cp-shell">
<header class="cp-top">
  <a class="cp-brand" href="index.php" aria-label="<?=e($brandName)?>">
    <?php if ($logoUrl): ?><img src="<?=e($logoUrl)?>" alt="" class="cp-logo"><?php else: ?><span class="cp-mark" aria-hidden="true">↟</span><?php endif ?>
    <span><strong><?=e($brandName)?></strong><small><?=e($panelSubtitle)?></small></span>
  </a>
  <?php if ($customer): ?>
  <div class="cp-top-actions">
    <span class="cp-user"><i aria-hidden="true"><?=e(mb_substr(trim($customer['name']), 0, 1))?></i><b><?=e($customer['name'])?></b></span>
    <form method="post" id="legacy-logout-form"><?=csrf_field()?><input type="hidden" name="action" value="logout"><button class="pill pill-ghost pill-sm">خروج</button></form>
  </div>
  <?php endif ?>
</header>
<?php if ($customer): ?>
<div data-customer-sidebar data-name="<?=e($customer['name'])?>" data-brand="<?=e($brandName)?>" data-logo="<?=e($logoUrl)?>" data-phone="<?=e(en_digits($supportPhone))?>" data-parts="<?=count($parts)?>" data-contracts="<?=count($contracts)?>" data-services="<?=count($serviceVisits)?>"></div>
<?php if($customerTheme==='gradient'): ?>
<header class="kit-header"><a class="kit-brand" href="index.php"><?php if($logoUrl):?><img src="<?=e($logoUrl)?>" alt=""><?php else:?><i>↟</i><?php endif ?><span><b><?=e($brandName)?></b><small><?=e($panelSubtitle)?></small></span></a><nav class="kit-nav" aria-label="بخش‌های پنل"><a href="#overview" class="active"><span>⌂</span><small>نمای کلی</small></a><a href="#products"><span>▦</span><small>قطعات پروژه</small></a><a href="#services"><span>◷</span><small>سرویس‌ها</small></a><a href="#contracts"><span>▤</span><small>قراردادها</small></a><a href="#stories"><span>▶</span><small>استوریها</small></a></nav><div class="kit-account"><i><?=e(mb_substr(trim($customer['name']),0,1))?></i><span><b><?=e($customer['name'])?></b><small>حساب مشتری</small></span><button type="button" onclick="document.getElementById('legacy-logout-form').requestSubmit()" title="خروج">↪</button></div></header>
<?php endif ?>
<?php endif ?>

<?php if (!$customer): ?>
<main class="cp-login">
  <section class="cp-login-intro">
    <span class="cp-tag"><i></i>همراه شما در هر طبقه</span>
    <h1>همه‌چیز درباره آسانسور شما، <em>در یک نگاه.</em></h1>
    <p>مشخصات آسانسور، قطعات نصب‌شده، برند، سریال و وضعیت ضمانت هر قطعه را در فضای اختصاصی خودتان ببینید.</p>
    <div class="cp-lift-preview" aria-hidden="true">
      <div class="cp-lift-frame">
        <img src="../assets/img/cabin-copper.webp" srcset="../assets/img/cabin-copper-sm.webp 386w, ../assets/img/cabin-copper.webp 666w" sizes="280px" alt="" decoding="async" loading="lazy" draggable="false">
        <span class="cp-lift-lcd"><em>▲</em><b>۱</b></span>
        <i class="cp-lift-door l"></i><i class="cp-lift-door r"></i>
      </div>
      <small>کابین شما · طبقه همکف</small>
    </div>
    <ul class="cp-points">
      <li><b>۱</b><span>وارد شوید</span></li>
      <li><b>۲</b><span>قطعه را پیدا کنید</span></li>
      <li><b>۳</b><span>مشخصات را ببینید یا بفرستید</span></li>
    </ul>
  </section>
  <form method="post" class="cp-glass cp-login-card" id="login-form" novalidate>
    <span class="cp-tag"><i></i>حساب مشتری</span>
    <h2>خوش آمدید</h2>
    <p class="cp-muted">با نام کاربری و رمز، یا لینک اختصاصی که مدیریت برایتان فرستاده وارد شوید.</p>
    <?php if ($error): ?><p class="cp-notice" role="alert"><?=e($error)?></p><?php endif ?>
    <?=csrf_field()?>
    <label class="cp-field"><span>نام کاربری</span><input name="username" required autocomplete="username" autocapitalize="off" spellcheck="false" dir="ltr" placeholder="Username" autofocus></label>
    <label class="cp-field"><span>رمز عبور</span>
      <span class="cp-pw"><input type="password" name="password" id="pw" required autocomplete="current-password" dir="ltr" placeholder="••••••••"><button type="button" class="cp-eye" id="pw-eye" aria-label="نمایش رمز عبور" aria-pressed="false">نمایش</button></span>
      <small class="cp-caps" id="caps" hidden>Caps Lock روشن است.</small>
    </label>
    <button class="pill pill-coral pill-block" id="login-btn"><span>ورود به پنل</span><i aria-hidden="true">←</i></button>
    <small class="cp-muted">اطلاعات ورود را ندارید؟ <?php if ($supportPhone): ?><a href="tel:<?=e(en_digits($supportPhone))?>" dir="ltr"><?=e($supportPhone)?></a><?php else: ?>با مدیریت تماس بگیرید.<?php endif ?></small>
  </form>
</main>
<?php else:
  $hour = (int) date('G');
  $withWarranty = count(array_filter($parts, static fn($x) => trim((string)$x['warranty']) !== ''));
  $brands = array_values(array_unique(array_filter(array_map(static fn($x) => trim((string)$x['brand']), $parts))));
  $partsJson = array_map(static fn($x) => [
      'id' => (int)$x['id'], 'name' => (string)$x['name'], 'spec' => (string)$x['specifications'], 'qty' => (string)$x['quantity'],
      'brand' => (string)$x['brand'], 'model' => (string)$x['model'], 'serial' => (string)$x['serial_number'], 'installed' => (string)$x['installed_at'],
      'warranty' => (string)$x['warranty'], 'img' => !empty($x['image_ref']) ? 'image.php?id=' . (int)$x['id'] : '',
  ], $parts);
?>
<main class="cp-main">
  <section class="cp-stories cp-stories-premier" id="stories" aria-labelledby="stories-title">
    <div class="cp-ph"><div><span class="cp-tag"><i></i>پشت صحنه و پروژه‌ها</span><h2 id="stories-title">داستان ما را ببینید</h2><p class="cp-muted">معرفی شرکت، تیم فنی و تجربه همکاری با مجموعه‌های صنعتی و ساختمانی.</p></div></div>
    <div class="cp-story-showcase"><?php if (!$stories): ?><div class="cp-story-empty"><span class="cp-story-empty-play">▶</span><div><small>ویدیوهای شرکت</small><h3>داستان ما، پروژه‌ها و همکاری‌ها</h3><p>اولین ویدیو را از پنل مدیریت منتشر کنید تا اینجا نمایش داده شود.</p></div></div><?php endif ?><?php foreach ($stories as $si=>$story): $storyBg=$story['poster_path'] ?: ['assets/img/types/mrl-traction.webp','assets/img/types/gearless.webp','assets/img/cabin-copper.webp'][$si%3]; ?><button class="cp-story-card <?=$si===0?'featured':''?>" type="button" data-story="<?=$si?>"><span class="cp-story-media" style="background-image:url('../<?=e($storyBg)?>')"><span class="cp-story-shade"></span><span class="cp-story-top"><i></i><?=$si===0?'ویدیوی شاخص':'تماشای ویدیو'?></span><span class="cp-story-play">▶</span><span class="cp-story-content"><small><?=e($story['company'] ?: 'آسانسور خلیج فارس')?></small><b><?=e($story['title'])?></b><?php if($story['subtitle']): ?><span><?=e($story['subtitle'])?></span><?php endif ?></span></span></button><?php endforeach ?></div>
    <div class="cp-story-swipe"><span>برای تماشا روی ویدیو بزنید</span><i></i><small>تجربه ما را ببینید</small></div>
  </section>
  <script type="application/json" id="stories-json"><?=json_encode(array_map(static fn($s)=>['title'=>$s['title'],'subtitle'=>$s['subtitle'],'company'=>$s['company'],'video'=>'../'.$s['video_path'],'poster'=>$s['poster_path']?'../'.$s['poster_path']:''],$stories),JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?></script>
  <div class="cp-story-viewer" id="cp-story-viewer" hidden role="dialog" aria-modal="true" aria-label="پخش استوری"><div class="cp-story-progress" id="cp-story-progress"></div><button class="cp-story-close" type="button" aria-label="بستن">✕</button><div class="cp-story-video"><video id="cp-story-video" playsinline controls preload="metadata"></video><div class="cp-story-caption"><b id="cp-story-company"></b><h3 id="cp-story-title"></h3><p id="cp-story-subtitle"></p></div></div><button class="cp-story-prev" type="button" aria-label="قبلی">‹</button><button class="cp-story-next" type="button" aria-label="بعدی">›</button></div>
  <?php if ($error): ?><p class="cp-notice" role="alert"><?=e($error)?></p><?php endif ?>
  <section class="cp-hero cp-glass" id="overview" aria-labelledby="hello">
    <div class="cp-hero-top">
      <span class="cp-avatars" aria-hidden="true"><i><?=e(mb_substr(trim($customer['name']), 0, 1))?></i><i></i><i></i></span>
      <span class="cp-tag"><i></i>داشبورد شما</span>
    </div>
    <div class="cp-hero-grid">
      <div>
        <div class="cp-who">
          <span class="cp-avatar" aria-hidden="true"><?=e(mb_substr(trim($customer['name']), 0, 1))?></span>
          <div>
            <h1 id="hello"><span id="greet" data-h="<?=$hour?>">سلام</span>، <?=e($customer['name'])?></h1>
            <p class="cp-muted">مشتری ویژه · <?=e($brandName)?><?= $typeTitle ? ' · '.e($typeTitle) : '' ?></p>
          </div>
        </div>
        <p class="cp-details" id="cp-details"><?=nl2br(e($detailsDisplay))?></p>
        <div class="cp-listen-row"
             id="cp-listen-host"
             data-audio="<?=e($elevatorAudio)?>"
             data-speech="<?=e($elevatorSpeech)?>">
          <button type="button" class="cp-listen" id="cp-listen"<?= ($elevatorAudio || $elevatorSpeech) ? '' : ' hidden' ?>>
            <span class="eq" aria-hidden="true"><i></i><i></i><i></i></span>
            <span class="cp-listen-label">شنیدن مشخصات</span>
          </button>
        </div>
        <dl class="cp-stats">
          <div><dt>قطعه ثبت‌شده</dt><dd data-count="<?=count($parts)?>"><?=count($parts)?></dd></div>
          <div><dt>قرارداد ثبت‌شده</dt><dd data-count="<?=count($contracts)?>"><?=count($contracts)?></dd></div>
          <div><dt>سرویس انجام‌شده</dt><dd data-count="<?=count($serviceVisits)?>"><?=count($serviceVisits)?></dd></div>
        </dl>
        <div class="cp-actions">
          <?php if ($elevatorTypeMeta): ?><a class="pill pill-ghost" href="#type-dossier">مشخصات نوع آسانسور</a><?php endif ?>
          <a class="pill pill-ghost" href="#products">کاتالوگ قطعات</a>
          <?php if ($supportPhone): ?><a class="pill pill-coral" href="tel:<?=e(en_digits($supportPhone))?>">تماس با پشتیبانی</a><?php endif ?>
        </div>
      </div>
      <figure class="cp-type-card customer-lift-simple"><img src="../<?=e($typeImg ?: 'assets/img/types/hydraulic.webp')?>" alt="<?=e($typeTitle ?: 'آسانسور پروژه شما')?>" decoding="async"></figure>
    </div>
  </section>

  <section class="kit-insights" aria-label="خلاصه سرویس و قرارداد">
    <article class="kit-ring-card"><div class="kit-card-copy"><small>وضعیت نگهداری پروژه</small><b><?=e(fa_digits($servicePercent))?>٪</b><span><?=count($serviceVisits)?count($serviceVisits).' سرویس ثبت‌شده':'در انتظار اولین سرویس'?></span></div><div class="kit-ring" style="--percent:<?=$servicePercent?>"><svg viewBox="0 0 120 120" aria-hidden="true"><defs><linearGradient id="kitBlue"><stop stop-color="#25b9ed"/><stop offset="1" stop-color="#4d24ed"/></linearGradient></defs><circle class="ring-bg" cx="60" cy="60" r="48"/><circle class="ring-value" cx="60" cy="60" r="48" pathLength="100" stroke-dasharray="<?=$servicePercent?> 100"/></svg><span><?=e(fa_digits($servicePercent))?>٪</span></div></article>
    <article class="kit-chart-card"><div><small>آخرین سرویس انجام‌شده</small><b><?=e($lastService['service_date']??'ثبت نشده')?></b><span>◷ سرویس بعدی: <?=e($nextServiceDate?:'هماهنگی نشده')?></span></div><svg class="kit-spark" viewBox="0 0 260 80" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="sparkBlue" x1="0" x2="1"><stop stop-color="#25b9ed"/><stop offset="1" stop-color="#4d24ed"/></linearGradient></defs><path d="M4 65 C28 60,35 22,58 34 S91 73,117 49 S151 48,172 23 S209 10,223 31 S242 64,256 57" fill="none" stroke="url(#sparkBlue)" stroke-width="4" stroke-linecap="round"/></svg></article>
    <article class="kit-next-card"><span class="kit-next-icon">◷</span><small>بازدید پیش‌رو</small><b><?=e($nextServiceDate?:'در انتظار زمان‌بندی')?></b><a href="#services">مشاهده برنامه سرویس <i>←</i></a></article>
  </section>

  <?php if ($elevatorTypeMeta): ?>
  <section class="cp-dossier cp-glass" id="type-dossier" aria-labelledby="dtype">
    <div class="cp-ph">
      <div>
        <span class="cp-tag"><i></i>نوع آسانسور شما</span>
        <h2 id="dtype"><?=e($typeTitle)?></h2>
        <?php if ($typeTag): ?><p class="cp-muted"><?=e($typeTag)?></p><?php endif ?>
      </div>
    </div>
    <?php if ($typeArticle): ?>
      <p class="cp-dossier-article"><?=nl2br(e($typeArticle))?></p>
    <?php endif ?>
    <?php if ($typeSpecs): ?>
    <div class="cp-spec-wrap">
      <h3>جدول مشخصات فنی</h3>
      <dl class="cp-spec-table">
        <?php foreach ($typeSpecs as $row):
          if (!is_array($row) || count($row) < 2) continue;
          $k = (string)$row[0]; $v = (string)$row[1];
          if ($k === '' && $v === '') continue; ?>
        <div><dt><?=e($k)?></dt><dd><?=e($v)?></dd></div>
        <?php endforeach ?>
      </dl>
    </div>
    <?php endif ?>
    <?php if ($typeHotspots): ?>
    <div class="cp-guide-parts">
      <h3>قطعات و اجزای اصلی این نوع</h3>
      <p class="cp-muted">راهنمای قطعات استاندارد <?=e($typeTitle)?> — علاوه بر قطعات اختصاصی ثبت‌شده برای شما در کاتالوگ پایین.</p>
      <div class="cp-guide-grid">
        <?php foreach ($typeHotspots as $hs):
          if (!is_array($hs) || count($hs) < 2) continue;
          $ht = (string)$hs[0]; $hd = (string)$hs[1];
          if ($ht === '') continue; ?>
        <article class="cp-guide-card" data-tilt>
          <h4><?=e($ht)?></h4>
          <p><?=e($hd)?></p>
        </article>
        <?php endforeach ?>
      </div>
    </div>
    <?php endif ?>
  </section>
  <?php endif ?>

  <section class="cp-products" id="products" aria-labelledby="ptitle">
    <div class="cp-ph">
      <div><span class="cp-tag"><i></i>کاتالوگ پیشرفته</span><h2 id="ptitle"><?=e($catalogTitle)?></h2><p class="cp-muted">جستجو، فیلتر، نمای شبکه‌ای یا لیست — الهام‌گرفته از پورتال‌های B2B قطعات صنعتی.</p></div>
    </div>

    <?php if (!$parts): ?>
      <div class="cp-empty cp-glass"><span aria-hidden="true">◇</span><h3>هنوز قطعه‌ای ثبت نشده است</h3><p>بعد از ثبت اطلاعات توسط مدیریت، قطعات شما اینجا نمایش داده می‌شوند.</p></div>
    <?php else: ?>
    <div class="cp-tools cp-glass">
      <label class="cp-search"><span class="sr-only">جستجو در قطعات</span><input id="part-search" type="search" placeholder="جستجوی نام، برند، مدل یا سریال…" autocomplete="off" aria-controls="part-list"><kbd aria-hidden="true">/</kbd></label>
      <div class="cp-chips" role="group" aria-label="فیلتر قطعات" id="chips">
        <button type="button" class="chip on" data-f="all" aria-pressed="true">همه</button>
        <button type="button" class="chip" data-f="image" aria-pressed="false">دارای تصویر</button>
        <button type="button" class="chip" data-f="warranty" aria-pressed="false">دارای ضمانت</button>
        <?php foreach (array_slice($brands, 0, 6) as $b): ?><button type="button" class="chip" data-f="brand:<?=e($b)?>" aria-pressed="false"><?=e($b)?></button><?php endforeach ?>
      </div>
      <div class="cp-tools-end">
        <div class="cp-view" role="group" aria-label="نمای کاتالوگ">
          <button type="button" class="pill pill-ghost pill-sm on" id="view-grid" aria-pressed="true">شبکه</button>
          <button type="button" class="pill pill-ghost pill-sm" id="view-list" aria-pressed="false">لیست</button>
        </div>
        <label class="cp-sort"><span class="sr-only">مرتب‌سازی</span><select id="sort"><option value="new">جدیدترین</option><option value="name">نام قطعه</option><option value="brand">برند</option></select></label>
        <button type="button" class="pill pill-ghost pill-sm" id="btn-print-cat">چاپ کاتالوگ</button>
      </div>
    </div>
    <p class="cp-count" id="count" aria-live="polite"></p>

    <div class="cp-shelf is-grid" id="catalog-shelf">
      <div class="cp-row" id="part-list" tabindex="0" aria-label="کاتالوگ قطعات مشتری">
        <?php foreach ($parts as $part):
          $pid = (int)$part['id']; ?>
        <article class="pc" id="customer-part-<?=$pid?>" data-id="<?=$pid?>" data-image="<?=!empty($part['image_ref']) ? '1' : '0'?>" data-warranty="<?=trim((string)$part['warranty']) !== '' ? '1' : '0'?>" data-brand="<?=e(trim((string)$part['brand']))?>"
          data-search="<?=e(implode(' ', [$part['name'], $part['specifications'], $part['brand'], $part['model'], $part['serial_number'], $part['warranty']]))?>">
          <button type="button" class="pc-open" data-open="<?=$pid?>" aria-label="مشخصات کامل <?=e($part['name'])?>">
            <span class="pc-frame"><?php if (!empty($part['image_ref'])): ?><img src="image.php?id=<?=$pid?>" alt="" loading="lazy" decoding="async"><?php else: ?><span class="pc-none"><b>◇</b><small>تصویر ثبت نشده</small></span><?php endif ?><span class="pc-status" data-status hidden></span></span>
            <span class="pc-name"><?=e($part['name'])?></span>
            <span class="pc-brand"><?=e($part['brand'] ?: 'برند ثبت نشده')?><?= $part['model'] ? ' · '.e($part['model']) : '' ?></span>
            <span class="pc-spec"><?=e($part['specifications'] ?: 'مشخصاتی ثبت نشده است.')?></span>
            <span class="pc-meta"><span><small>تعداد</small><b><?=e($part['quantity'] ?: '—')?></b></span><span><small>تاریخ نصب</small><b><?=e($part['installed_at'] ?: '—')?></b></span></span>
            <span class="pc-more">مشاهده جزئیات ↗</span>
          </button>
          <details class="part-details"><summary>جزئیات و اطلاعات نصب</summary><dl><?php foreach (['brand'=>'برند / سازنده','model'=>'مدل','serial_number'=>'شماره سریال','installed_at'=>'تاریخ نصب','warranty'=>'گارانتی'] as $key => $label): ?><div><dt><?=e($label)?></dt><dd><?=e($part[$key] ?: 'ثبت نشده')?></dd></div><?php endforeach ?></dl></details>
        </article>
        <?php endforeach ?>
      </div>
    </div>
    <p class="cp-empty cp-glass" id="no-results" hidden>قطعه‌ای با این شرایط پیدا نشد. عبارت جستجو یا فیلتر را تغییر دهید.</p>
    <script type="application/json" id="parts-json"><?=json_encode($partsJson, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)?></script>
    <?php endif ?>
  </section>

  <section class="cp-contracts" id="contracts" aria-labelledby="contracts-title">
    <div class="cp-ph"><div><span class="cp-tag"><i></i>اسناد پروژه</span><h2 id="contracts-title"><?=e($contractsTitle)?></h2><p class="cp-muted">شرایط، مدت و پوشش خدمات قرارداد شما به‌صورت شفاف.</p></div></div>
    <div class="cp-contract-grid"><?php if(!$contracts): ?><div class="cp-empty cp-glass"><span>▤</span><h3>قراردادی ثبت نشده است</h3><p>مدیر پروژه می‌تواند قرارداد و شرح پوشش آن را از پنل مدیریت ثبت کند.</p></div><?php endif ?><?php foreach($contracts as $contract): ?><article class="cp-contract-card cp-glass"><div class="cp-contract-head"><span class="cp-contract-icon">▤</span><span class="cp-contract-status st-<?=e($contract['status'])?>"><?=e(['active'=>'فعال','expired'=>'پایان‌یافته','suspended'=>'متوقف'][$contract['status']]??$contract['status'])?></span></div><small dir="ltr"><?=e($contract['contract_no'])?></small><h3><?=e($contract['title'])?></h3><?php if($contract['project_address']): ?><p class="cp-contract-address">⌖ <?=e($contract['project_address'])?></p><?php endif ?><dl><div><dt>شروع قرارداد</dt><dd><?=e($contract['start_date']?:'ثبت نشده')?></dd></div><div><dt>پایان قرارداد</dt><dd><?=e($contract['end_date']?:'ثبت نشده')?></dd></div></dl><?php foreach (['contract_date'=>'تاریخ قرارداد','total_amount'=>'مبلغ کل','contract_text'=>'متن قرارداد','contract_parts'=>'قطعات و مبالغ'] as $key=>$label): if(!empty($contract[$key])): ?><div class="cp-contract-coverage"><b><?=e($label)?></b><p><?=nl2br(e($contract[$key]))?></p></div><?php endif; endforeach ?><?php if($contract['coverage']): ?><div class="cp-contract-coverage"><b>پوشش خدمات</b><p><?=nl2br(e($contract['coverage']))?></p></div><?php endif ?></article><?php endforeach ?></div>
  </section>

  <section class="cp-services" id="services" aria-labelledby="services-title">
    <div class="cp-ph"><div><span class="cp-tag"><i></i>نگهداری پیشگیرانه</span><h2 id="services-title"><?=e($servicesTitle)?></h2><p class="cp-muted">تاریخ، تکنسین و شرح کارهای انجام‌شده در هر بازدید.</p></div></div>
    <div class="cp-service-summary cp-glass"><div><span class="cp-service-summary-icon">✓</span><span><small>آخرین سرویس انجام‌شده</small><b><?=e($lastService['service_date']??'هنوز ثبت نشده')?></b></span></div><div class="cp-next-service"><span class="cp-service-summary-icon">◷</span><span><small>سرویس بعدی شما</small><b><?=e($nextServiceDate?:'پس از هماهنگی اعلام می‌شود')?></b></span></div></div>
    <div class="cp-service-timeline"><?php if(!$serviceVisits): ?><div class="cp-empty cp-glass"><span>◷</span><h3>سابقه سرویسی ثبت نشده است</h3><p>پس از اولین بازدید، گزارش سرویس در این بخش قرار می‌گیرد.</p></div><?php endif ?><?php foreach($serviceVisits as $si=>$visit): ?><article class="cp-service-item"><span class="cp-service-dot <?= $visit['status']==='scheduled'?'scheduled':'' ?>"></span><div class="cp-service-card cp-glass"><div class="cp-service-card-head"><div><small><?=e(['done'=>'سرویس انجام‌شده','scheduled'=>'سرویس زمان‌بندی‌شده','canceled'=>'لغو شده'][$visit['status']]??$visit['status'])?></small><h3><?=e($visit['service_date'])?></h3></div><span><?=e($visit['technician']?:'تیم فنی')?></span></div><?php if($visit['summary']): ?><p><?=nl2br(e($visit['summary']))?></p><?php endif ?><?php foreach (['replaced_parts'=>'قطعات تعویض‌شده و تاریخ','resolved_problems'=>'مشکلات رفع‌شده'] as $key=>$label): if(!empty($visit[$key])): ?><p><b><?=e($label)?></b><br><?=nl2br(e($visit[$key]))?></p><?php endif; endforeach ?><?php if($visit['next_service_date']): ?><small class="cp-service-next">سرویس بعدی: <?=e($visit['next_service_date'])?></small><?php endif ?></div></article><?php endforeach ?></div>
  </section>

  <footer class="cp-foot"><span>پنل اختصاصی مشتریان <?=e($brandName)?></span><a href="../index.php">بازگشت به سایت اصلی ↗</a></footer>
</main>

<div class="cp-dlg" id="dlg" hidden role="dialog" aria-modal="true" aria-labelledby="dlg-title">
  <div class="cp-dlg-box cp-glass">
    <button type="button" class="cp-x" id="dlg-x" aria-label="بستن">✕</button>
    <div class="cp-dlg-img" id="dlg-img"></div>
    <div class="cp-dlg-body">
      <span class="cp-tag" id="dlg-status" hidden></span>
      <h3 id="dlg-title"></h3>
      <p class="cp-muted" id="dlg-brand"></p>
      <p class="cp-dlg-spec" id="dlg-spec"></p>
      <dl class="cp-dl" id="dlg-dl"></dl>
      <div class="cp-actions">
        <button type="button" class="pill pill-coral" id="dlg-share">ارسال مشخصات</button>
        <button type="button" class="pill pill-ghost" id="dlg-copy">کپی سریال</button>
        <?php if ($supportPhone): ?><a class="pill pill-ghost" id="dlg-call" href="tel:<?=e(en_digits($supportPhone))?>">تماس درباره این قطعه</a><?php endif ?>
      </div>
      <div class="cp-dlg-nav"><button type="button" id="dlg-prev">← قبلی</button><span id="dlg-pos"></span><button type="button" id="dlg-next">بعدی →</button></div>
    </div>
  </div>
</div>
<div class="cp-toast" id="toast" role="status" aria-live="polite" hidden></div>
<?php endif ?>
</div>
<script src="../assets/js/coverflow.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/js/coverflow.js') ?>" defer></script>
<script src="../assets/js/customer-v12.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/js/customer-v12.js') ?>" defer></script>
<script src="../assets/react/customer/customer-sidebar.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/react/customer/customer-sidebar.js') ?>" defer></script>
<script src="../assets/js/customer-kit.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/js/customer-kit.js') ?>" defer></script>
<script src="../assets/js/customer-v16.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/js/customer-v16.js') ?>" defer></script>
</body></html>

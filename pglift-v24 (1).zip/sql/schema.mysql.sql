-- =====================================================================
--  آسانسور خلیج فارس صادقی — ساختار پایگاه داده (MySQL / MariaDB)
--  در صورت تمایل می‌توانید این فایل را دستی import کنید،
--  اما معمولاً نیازی نیست چون install.php همه چیز را خودکار می‌سازد.
-- =====================================================================

SET NAMES utf8mb4;
SET time_zone = '+03:30';

-- ---------------------------------------------------------------------
-- تنظیمات سایت
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `site_settings` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `skey`       VARCHAR(100) NOT NULL UNIQUE,
  `svalue`     TEXT NOT NULL,
  `sgroup`     VARCHAR(50) NOT NULL DEFAULT 'general',
  `slabel`     VARCHAR(190) NOT NULL DEFAULT '',
  `updated_at` DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- محتوای بخش‌های سایت
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `site_content` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `section`    VARCHAR(50) NOT NULL,
  `title`      VARCHAR(255) NOT NULL DEFAULT '',
  `subtitle`   VARCHAR(255) NOT NULL DEFAULT '',
  `body`       TEXT NULL,
  `extra`      TEXT NULL COMMENT 'داده‌های JSON: آیتم‌ها، آمار، لینک‌ها',
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_visible` TINYINT(1) NOT NULL DEFAULT 1,
  `updated_at` DATETIME NULL,
  INDEX `idx_sc_section` (`section`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- تصاویر برند (لوگو / فاوآیکون) به صورت data-url
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `brand_assets` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `kind`       VARCHAR(30) NOT NULL,
  `label`      VARCHAR(190) NOT NULL DEFAULT '',
  `data_url`   LONGTEXT NOT NULL,
  `is_active`  TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- درخواست‌های سرویس / نصب آسانسور
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `service_requests` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `ticket`         VARCHAR(40) NOT NULL UNIQUE,
  `request_type`   VARCHAR(30) NOT NULL DEFAULT 'service',
  `subject`        VARCHAR(255) NOT NULL,
  `customer_name`  VARCHAR(150) NOT NULL,
  `phone`          VARCHAR(40) NOT NULL,
  `email`          VARCHAR(190) NOT NULL DEFAULT '',
  `address`        VARCHAR(400) NOT NULL DEFAULT '',
  `city`           VARCHAR(100) NOT NULL DEFAULT '',
  `elevator_type`  VARCHAR(100) NOT NULL DEFAULT '',
  `floors`         INT NOT NULL DEFAULT 1,
  `passengers`     INT NOT NULL DEFAULT 6,
  `brand`          VARCHAR(100) NOT NULL DEFAULT '',
  `preferred_date` VARCHAR(40) NOT NULL DEFAULT '',
  `message`        TEXT NULL,
  `urgency`        VARCHAR(20) NOT NULL DEFAULT 'normal',
  `status`         VARCHAR(20) NOT NULL DEFAULT 'new',
  `admin_note`     TEXT NULL,
  `technician`     VARCHAR(150) NOT NULL DEFAULT '',
  `estimated_cost` BIGINT NOT NULL DEFAULT 0,
  `created_at`     DATETIME NULL,
  `updated_at`     DATETIME NULL,
  INDEX `idx_sr_status`  (`status`),
  INDEX `idx_sr_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- تاریخچه رویدادهای هر درخواست
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `request_events` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `request_id` INT NOT NULL,
  `message`    TEXT NOT NULL,
  `actor`      VARCHAR(100) NOT NULL DEFAULT 'system',
  `created_at` DATETIME NULL,
  INDEX `idx_re_request` (`request_id`),
  CONSTRAINT `fk_re_request` FOREIGN KEY (`request_id`)
    REFERENCES `service_requests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- تیکت‌های پشتیبانی سایت
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `support_tickets` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `ticket`       VARCHAR(40) NOT NULL UNIQUE,
  `subject`      VARCHAR(255) NOT NULL,
  `body`         TEXT NOT NULL,
  `sender_name`  VARCHAR(150) NOT NULL DEFAULT '',
  `sender_email` VARCHAR(190) NOT NULL DEFAULT '',
  `priority`     VARCHAR(20) NOT NULL DEFAULT 'normal',
  `status`       VARCHAR(20) NOT NULL DEFAULT 'open',
  `reply`        TEXT NULL,
  `created_at`   DATETIME NULL,
  `updated_at`   DATETIME NULL,
  INDEX `idx_st_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- کاربران مدیر
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `username`      VARCHAR(80) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `full_name`     VARCHAR(150) NOT NULL DEFAULT '',
  `role`          VARCHAR(30) NOT NULL DEFAULT 'admin',
  `is_active`     TINYINT(1) NOT NULL DEFAULT 1,
  `last_login_at` DATETIME NULL,
  `created_at`    DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- گزارش فعالیت
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `activity_log` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `actor`      VARCHAR(100) NOT NULL DEFAULT 'system',
  `action`     VARCHAR(80) NOT NULL,
  `detail`     VARCHAR(400) NOT NULL DEFAULT '',
  `created_at` DATETIME NULL,
  INDEX `idx_log_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- وضعیت نصب
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `installer_state` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `step`         VARCHAR(40) NOT NULL DEFAULT 'pending',
  `message`      VARCHAR(255) NOT NULL DEFAULT '',
  `is_complete`  TINYINT(1) NOT NULL DEFAULT 0,
  `installed_at` DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- v16: سفارش‌ها، استوریها و گزارش پیامک (در اجرای PHP نیز خودکار ساخته می‌شوند)
CREATE TABLE IF NOT EXISTS `customer_orders` (
  `id` INT AUTO_INCREMENT PRIMARY KEY, `customer_id` INT NOT NULL,
  `order_no` VARCHAR(40) NOT NULL UNIQUE, `title` VARCHAR(200) NOT NULL,
  `details` TEXT NOT NULL, `quantity` VARCHAR(60) NOT NULL DEFAULT '1',
  `status` VARCHAR(30) NOT NULL DEFAULT 'pending', `total_price` VARCHAR(100) NOT NULL DEFAULT '',
  `admin_note` TEXT NOT NULL, `created_at` DATETIME NULL, `updated_at` DATETIME NULL,
  INDEX `idx_orders_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `video_stories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY, `title` VARCHAR(180) NOT NULL,
  `subtitle` VARCHAR(255) NOT NULL DEFAULT '', `company` VARCHAR(180) NOT NULL DEFAULT '',
  `video_path` VARCHAR(255) NOT NULL, `poster_path` VARCHAR(255) NOT NULL DEFAULT '',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1, `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NULL, INDEX `idx_stories_active` (`is_active`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `sms_messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY, `customer_id` INT NULL,
  `recipient` VARCHAR(30) NOT NULL, `body` TEXT NOT NULL,
  `provider` VARCHAR(40) NOT NULL DEFAULT 'farazsms', `status` VARCHAR(30) NOT NULL DEFAULT 'queued',
  `provider_id` VARCHAR(190) NOT NULL DEFAULT '', `error_message` VARCHAR(500) NOT NULL DEFAULT '',
  `created_at` DATETIME NULL, INDEX `idx_sms_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- v17.2: قرارداد و سرویسهای دوره‌ای مشتری
CREATE TABLE IF NOT EXISTS `customer_contracts` (
 `id` INT AUTO_INCREMENT PRIMARY KEY, `customer_id` INT NOT NULL,
 `contract_no` VARCHAR(80) NOT NULL, `title` VARCHAR(200) NOT NULL,
 `project_address` VARCHAR(500) NOT NULL DEFAULT '', `start_date` VARCHAR(40) NOT NULL DEFAULT '',
 `end_date` VARCHAR(40) NOT NULL DEFAULT '', `status` VARCHAR(30) NOT NULL DEFAULT 'active',
 `coverage` TEXT NOT NULL, `created_at` DATETIME NULL, INDEX `idx_contract_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `customer_service_visits` (
 `id` INT AUTO_INCREMENT PRIMARY KEY, `customer_id` INT NOT NULL,
 `service_date` VARCHAR(40) NOT NULL, `next_service_date` VARCHAR(40) NOT NULL DEFAULT '',
 `technician` VARCHAR(160) NOT NULL DEFAULT '', `summary` TEXT NOT NULL,
 `status` VARCHAR(30) NOT NULL DEFAULT 'done', `created_at` DATETIME NULL,
 INDEX `idx_service_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

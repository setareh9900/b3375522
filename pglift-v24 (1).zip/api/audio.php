<?php
/** پخش فایل صوتی توضیحات (با پشتیبانی Range برای seek و iOS) — جایگزین مطمئن وقتی دسترسی مستقیم به uploads مسدود است */
declare(strict_types=1);
$f = basename((string)($_GET['f'] ?? ''));
if (!preg_match('/^[a-zA-Z0-9_.-]+\.(mp3|m4a|ogg|wav|webm)$/i', $f)) { http_response_code(404); exit; }
$path = dirname(__DIR__) . '/uploads/audio/' . $f;
if (!is_file($path)) { http_response_code(404); exit; }
$ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
$mime = ['mp3' => 'audio/mpeg', 'm4a' => 'audio/mp4', 'ogg' => 'audio/ogg', 'wav' => 'audio/wav', 'webm' => 'audio/webm'][$ext];
$size = filesize($path); $start = 0; $end = $size - 1;
header('Content-Type: ' . $mime);
header('Accept-Ranges: bytes');
header('Cache-Control: public, max-age=86400');
header('X-Content-Type-Options: nosniff');
if (isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', $_SERVER['HTTP_RANGE'], $m)) {
    if ($m[1] !== '') $start = (int)$m[1];
    if ($m[2] !== '') $end = min($end, (int)$m[2]);
    if ($m[1] === '' && $m[2] !== '') { $start = max(0, $size - (int)$m[2]); $end = $size - 1; }
    if ($start > $end || $start >= $size) { http_response_code(416); header("Content-Range: bytes */$size"); exit; }
    http_response_code(206);
    header("Content-Range: bytes $start-$end/$size");
}
header('Content-Length: ' . ($end - $start + 1));
if (function_exists('session_status') && session_status() === PHP_SESSION_ACTIVE) session_write_close();
$fh = fopen($path, 'rb'); fseek($fh, $start); $left = $end - $start + 1;
while ($left > 0 && !feof($fh)) { $buf = fread($fh, min(8192, $left)); echo $buf; $left -= strlen($buf); flush(); }
fclose($fh);

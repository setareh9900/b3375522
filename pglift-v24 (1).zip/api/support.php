<?php
/** ثبت تیکت پشتیبانی سایت */
declare(strict_types=1);
require_once __DIR__ . '/../inc/fn.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['ok' => false, 'error' => 'متد نامعتبر'], 405);
}

$in = $_POST ?: json_in();
csrf_require($in['csrf'] ?? null);

$subject = clean((string)($in['subject'] ?? ''), 200);
$body    = clean_multiline((string)($in['body'] ?? ''), 4000);
$email   = clean((string)($in['sender_email'] ?? ''), 190);

$errors = [];
if (mb_strlen($subject, 'UTF-8') < 3) $errors['subject'] = 'موضوع را وارد کنید';
if (mb_strlen($body, 'UTF-8') < 10)   $errors['body'] = 'متن پیام را کامل بنویسید';
if ($email !== '' && !valid_email($email)) $errors['sender_email'] = 'ایمیل معتبر نیست';

if ($errors) {
    json_out(['ok' => false, 'error' => reset($errors), 'fields' => $errors], 422);
}

$priority = (string)($in['priority'] ?? 'normal');
if (!in_array($priority, ['low', 'normal', 'high'], true)) $priority = 'normal';

try {
    $tmp = 'TMP-' . bin2hex(random_bytes(6));
    q('INSERT INTO support_tickets
        (ticket, subject, body, sender_name, sender_email, priority, status, reply, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?)', [
        $tmp, $subject, $body,
        clean((string)($in['sender_name'] ?? ''), 150),
        $email, $priority, 'open', '', now(), now(),
    ]);

    $id = last_id();
    $ticket = ticket_code('SF', $id);
    q('UPDATE support_tickets SET ticket = ? WHERE id = ?', [$ticket, $id]);
    log_activity('visitor', 'support.create', 'تیکت ' . $ticket . ' ثبت شد');

    json_out(['ok' => true, 'ticket' => $ticket]);

} catch (Throwable $ex) {
    json_out(['ok' => false, 'error' => 'خطا در ثبت پیام. دوباره تلاش کنید.'], 500);
}

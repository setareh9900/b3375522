<?php
/** ثبت درخواست سرویس آسانسور */
declare(strict_types=1);
require_once __DIR__ . '/../inc/fn.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['ok' => false, 'error' => 'متد نامعتبر'], 405);
}

$in = $_POST ?: json_in();
csrf_require($in['csrf'] ?? null);

$subject = clean((string)($in['subject'] ?? ''), 200);
$name    = clean((string)($in['customer_name'] ?? ''), 150);
$phoneIn = clean((string)($in['phone'] ?? ''), 40);

$errors = [];
if (mb_strlen($subject, 'UTF-8') < 3) $errors['subject'] = 'موضوع را کامل وارد کنید';
if (mb_strlen($name, 'UTF-8') < 3)    $errors['customer_name'] = 'نام خود را وارد کنید';
if (!valid_phone($phoneIn))           $errors['phone'] = 'شماره موبایل معتبر نیست';

$email = clean((string)($in['email'] ?? ''), 190);
if ($email !== '' && !valid_email($email)) $errors['email'] = 'ایمیل معتبر نیست';

$type = (string)($in['request_type'] ?? 'service');
if (!in_array($type, ['service', 'install', 'maintenance'], true)) $type = 'service';

$urgency = (string)($in['urgency'] ?? 'normal');
if (!in_array($urgency, ['low', 'normal', 'high', 'emergency'], true)) $urgency = 'normal';

if ($errors) {
    json_out(['ok' => false, 'error' => reset($errors), 'fields' => $errors], 422);
}

$floors = max(1, min(120, (int) en_digits((string)($in['floors'] ?? '1'))));
$pass   = max(1, min(100, (int) en_digits((string)($in['passengers'] ?? '6'))));

try {
    $tmp = 'TMP-' . bin2hex(random_bytes(6));
    q('INSERT INTO service_requests
        (ticket, request_type, subject, customer_name, phone, email, address, city,
         elevator_type, floors, passengers, brand, preferred_date, message, urgency,
         status, admin_note, technician, estimated_cost, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [
        $tmp, $type, $subject, $name, $phoneIn, $email,
        clean((string)($in['address'] ?? ''), 400),
        clean((string)($in['city'] ?? ''), 100),
        clean((string)($in['elevator_type'] ?? ''), 100),
        $floors, $pass,
        clean((string)($in['brand'] ?? ''), 100),
        clean((string)($in['preferred_date'] ?? ''), 40),
        clean_multiline((string)($in['message'] ?? ''), 2000),
        $urgency, 'new', '', '', 0, now(), now(),
    ]);

    $id = last_id();
    $ticket = ticket_code('GF', $id);
    q('UPDATE service_requests SET ticket = ? WHERE id = ?', [$ticket, $id]);
    q('INSERT INTO request_events (request_id, message, actor, created_at) VALUES (?,?,?,?)',
      [$id, 'درخواست توسط کاربر ثبت شد', 'customer', now()]);
    log_activity('customer', 'request.create', 'درخواست ' . $ticket . ' ثبت شد');

    json_out(['ok' => true, 'ticket' => $ticket]);

} catch (Throwable $ex) {
    json_out(['ok' => false, 'error' => 'خطا در ثبت درخواست. دوباره تلاش کنید.'], 500);
}

<?php
/**
 * پنل نصب‌کننده خودکار پایگاه داده — آسانسور خلیج فارس صادقی
 */
declare(strict_types=1);

require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/schema.php';

if (session_status() === PHP_SESSION_NONE) session_start();

function esc($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$alreadyInstalled = false;
if (gf_is_configured()) {
    try {
        $pdo = gf_connect(gf_config());
        $r = $pdo->query("SELECT is_complete FROM installer_state LIMIT 1")->fetch(PDO::FETCH_ASSOC);
        $alreadyInstalled = !empty($r['is_complete']);
    } catch (Throwable $e) {
        $alreadyInstalled = false;
    }
}

$steps   = [];
$done    = false;
$error   = '';
$creds   = null;
$posted  = ($_SERVER['REQUEST_METHOD'] === 'POST');
$force   = !empty($_POST['force']);

if ($posted && (!$alreadyInstalled || $force)) {

    $cfg = [
        'driver'   => $_POST['driver'] === 'sqlite' ? 'sqlite' : 'mysql',
        'host'     => trim((string)($_POST['host'] ?? '127.0.0.1')),
        'port'     => (int)($_POST['port'] ?? 3306),
        'database' => trim((string)($_POST['database'] ?? '')),
        'user'     => trim((string)($_POST['user'] ?? '')),
        'pass'     => (string)($_POST['pass'] ?? ''),
    ];
    $adminUser = trim((string)($_POST['admin_user'] ?? 'admin')) ?: 'admin';
    $adminPass = (string)($_POST['admin_pass'] ?? '') ?: 'Admin@12345';

    if ($cfg['driver'] === 'sqlite' && $cfg['database'] === '') {
        $cfg['database'] = __DIR__ . '/data/gulfpars.sqlite';
    }

    $add = function (string $label, string $status, string $msg = '') use (&$steps) {
        $steps[] = ['label' => $label, 'status' => $status, 'msg' => $msg];
    };

    try {
        /* ۱ — اتصال */
        if ($cfg['driver'] === 'sqlite') {
            $dir = dirname($cfg['database']);
            if (!is_dir($dir)) @mkdir($dir, 0775, true);
        }
        $pdo = gf_connect($cfg);
        $add('اتصال به پایگاه داده', 'done', 'اتصال با درایور ' . $cfg['driver'] . ' برقرار شد');

        /* ۲ — ساخت جداول */
        $tables = gf_schema_sql($cfg['driver']);
        $madeIdx = 0;
        foreach ($tables as $sql) {
            try {
                $pdo->exec($sql);
                $madeIdx++;
            } catch (PDOException $ex) {
                // ایندکس تکراری را نادیده بگیر
                if (stripos($sql, 'CREATE INDEX') === false) throw $ex;
            }
        }
        $add('ایجاد جداول سیستم', 'done', $madeIdx . ' دستور با موفقیت اجرا شد');

        /* ۳ — محتوای پیش‌فرض */
        $cnt = (int) $pdo->query('SELECT COUNT(*) FROM site_content')->fetchColumn();
        if ($cnt === 0) {
            $st = $pdo->prepare('INSERT INTO site_content (section,title,subtitle,body,extra,sort_order,is_visible,updated_at) VALUES (?,?,?,?,?,?,1,?)');
            foreach (gf_default_content() as $c) {
                $st->execute([$c[0], $c[1], $c[2], $c[3],
                    json_encode($c[4], JSON_UNESCAPED_UNICODE), $c[5], date('Y-m-d H:i:s')]);
            }
            $add('بارگذاری محتوای پیش‌فرض سایت', 'done', count(gf_default_content()) . ' بخش ایجاد شد');
        } else {
            $add('بارگذاری محتوای پیش‌فرض سایت', 'done', 'محتوا از قبل موجود بود');
        }

        /* ۴ — تنظیمات */
        $st  = $pdo->prepare('INSERT INTO site_settings (skey,svalue,sgroup,slabel,updated_at) VALUES (?,?,?,?,?)');
        $chk = $pdo->prepare('SELECT COUNT(*) FROM site_settings WHERE skey = ?');
        $n = 0;
        foreach (gf_default_settings() as $s) {
            $chk->execute([$s[0]]);
            if ((int)$chk->fetchColumn() === 0) {
                $st->execute([$s[0], $s[1], $s[2], $s[3], date('Y-m-d H:i:s')]);
                $n++;
            }
        }
        $add('ثبت تنظیمات برند و تماس', 'done', $n . ' تنظیم جدید ثبت شد');

        /* ۵ — لوگوی پیش‌فرض */
        $hasLogo = (int) $pdo->query("SELECT COUNT(*) FROM brand_assets WHERE kind='logo'")->fetchColumn();
        if ($hasLogo === 0) {
            $logo = gf_default_logo();
            $st = $pdo->prepare('INSERT INTO brand_assets (kind,label,data_url,is_active,created_at) VALUES (?,?,?,1,?)');
            $st->execute(['logo', 'لوگوی اصلی', $logo, date('Y-m-d H:i:s')]);
            $st->execute(['favicon', 'فاوآیکون سایت', $logo, date('Y-m-d H:i:s')]);
            $add('ثبت لوگوی پیش‌فرض برند', 'done', 'لوگوی SVG پیش‌فرض ذخیره شد');
        } else {
            $add('ثبت لوگوی پیش‌فرض برند', 'done', 'لوگو از قبل موجود بود');
        }

        /* ۶ — حساب مدیر */
        $users = (int) $pdo->query('SELECT COUNT(*) FROM admin_users')->fetchColumn();
        if ($users === 0) {
            $st = $pdo->prepare('INSERT INTO admin_users (username,password_hash,full_name,role,is_active,created_at) VALUES (?,?,?,?,1,?)');
            $st->execute([$adminUser, password_hash($adminPass, PASSWORD_DEFAULT),
                          'مدیر سیستم', 'admin', date('Y-m-d H:i:s')]);
            $creds = ['u' => $adminUser, 'p' => $adminPass];
            $add('ساخت حساب مدیر پنل', 'done', 'حساب «' . $adminUser . '» ایجاد شد');
        } else {
            $add('ساخت حساب مدیر پنل', 'done', 'حساب مدیر از قبل وجود دارد');
        }

        /* ۷ — نوشتن فایل تنظیمات */
        $php = "<?php\n// فایل تنظیمات — به صورت خودکار توسط نصب‌کننده ساخته شد\nreturn " . var_export($cfg, true) . ";\n";
        if (@file_put_contents(GF_CONFIG_FILE, $php) === false) {
            throw new RuntimeException('نوشتن فایل inc/config.php ممکن نشد. دسترسی نوشتن پوشه inc را بررسی کنید.');
        }
        @chmod(GF_CONFIG_FILE, 0640);
        $add('ذخیره فایل پیکربندی', 'done', 'inc/config.php نوشته شد');

        /* ۸ — نهایی‌سازی */
        $hasState = (int) $pdo->query('SELECT COUNT(*) FROM installer_state')->fetchColumn();
        if ($hasState === 0) {
            $pdo->prepare('INSERT INTO installer_state (step,message,is_complete,installed_at) VALUES (?,?,1,?)')
                ->execute(['complete', 'نصب با موفقیت انجام شد', date('Y-m-d H:i:s')]);
        } else {
            $pdo->prepare('UPDATE installer_state SET step=?, message=?, is_complete=1, installed_at=?')
                ->execute(['complete', 'نصب با موفقیت انجام شد', date('Y-m-d H:i:s')]);
        }
        $pdo->prepare('INSERT INTO activity_log (actor,action,detail,created_at) VALUES (?,?,?,?)')
            ->execute(['installer', 'install', 'نصب خودکار پایگاه داده انجام شد', date('Y-m-d H:i:s')]);

        $add('نهایی‌سازی و ثبت وضعیت نصب', 'done', 'نصب کامل شد');
        $done = true;

    } catch (Throwable $ex) {
        $error = $ex->getMessage();
        $steps[] = ['label' => 'خطا در فرآیند نصب', 'status' => 'error', 'msg' => $error];
    }
}

$d = [
    'driver'   => $_POST['driver']   ?? 'mysql',
    'host'     => $_POST['host']     ?? '127.0.0.1',
    'port'     => $_POST['port']     ?? '3306',
    'database' => $_POST['database'] ?? 'gulfpars_elevator',
    'user'     => $_POST['user']     ?? 'root',
    'admin_user' => $_POST['admin_user'] ?? 'admin',
];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>نصب‌کننده خودکار | آسانسور خلیج فارس صادقی</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="page-install">

<div class="install-bg" aria-hidden="true"></div>

<main class="install-wrap">

  <header class="install-head">
    <span class="install-logo">
      <svg width="30" height="30" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2 3 7v10l9 5 9-5V7l-9-5Zm0 2.3 6.5 3.6-6.5 3.6L5.5 7.9 12 4.3ZM5 9.6l6 3.3v6.6l-6-3.3V9.6Zm8 9.9v-6.6l6-3.3v6.6l-6 3.3Z"/></svg>
    </span>
    <h1 class="grad">پنل نصب‌کننده خودکار</h1>
    <p>نصب‌کننده به‌صورت خودکار جداول پایگاه داده را می‌سازد، محتوای پیش‌فرض سایت را بارگذاری می‌کند، لوگو را ثبت می‌نماید و حساب مدیر را ایجاد می‌کند.</p>
  </header>

  <?php if ($done): ?>
    <section class="card success-card">
      <div class="success-head">
        <span class="success-icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M9.6 16.2 5.4 12l-1.5 1.5 5.7 5.7L20.1 8.7 18.6 7.2 9.6 16.2Z"/></svg>
        </span>
        <div>
          <h2>نصب با موفقیت انجام شد</h2>
          <p>پایگاه داده، محتوا و پنل مدیریت آماده بهره‌برداری هستند.</p>
        </div>
      </div>

      <?php if ($creds): ?>
      <div class="creds">
        <p class="creds-title">اطلاعات ورود مدیر — این اطلاعات را ذخیره کنید</p>
        <div class="creds-grid">
          <div><span>نام کاربری</span><b dir="ltr"><?= esc($creds['u']) ?></b></div>
          <div><span>رمز عبور</span><b dir="ltr" class="gold"><?= esc($creds['p']) ?></b></div>
        </div>
      </div>
      <?php endif; ?>

      <div class="warn">
        ⚠ برای امنیت، پس از ورود رمز عبور را تغییر دهید و فایل <code>install.php</code> را حذف یا تغییر نام دهید.
      </div>

      <div class="actions">
        <a class="btn btn-primary" href="admin/login.php"><?= '' ?>ورود به پنل مدیریت</a>
        <a class="btn btn-ghost" href="index.php">مشاهده سایت</a>
      </div>
    </section>

  <?php elseif ($alreadyInstalled && !$posted): ?>
    <section class="card">
      <h2 class="card-title">سیستم قبلاً نصب شده است</h2>
      <p class="muted">پایگاه داده پیکربندی شده و آماده استفاده است.</p>
      <div class="actions">
        <a class="btn btn-primary" href="admin/login.php">ورود به پنل مدیریت</a>
        <a class="btn btn-ghost" href="index.php">مشاهده سایت</a>
      </div>
      <details class="reinstall">
        <summary>نصب مجدد (پیشرفته)</summary>
        <p class="muted small">در صورت نیاز می‌توانید اطلاعات اتصال را دوباره وارد کنید. داده‌های موجود حفظ می‌شوند.</p>
        <form method="post" class="mt">
          <input type="hidden" name="force" value="1">
          <?php include __DIR__ . '/inc/_install_fields.php'; ?>
          <button class="btn btn-primary full" type="submit">اجرای نصب مجدد</button>
        </form>
      </details>
    </section>

  <?php else: ?>
    <section class="card">
      <h2 class="card-title">تنظیمات نصب</h2>
      <p class="muted">اطلاعات اتصال پایگاه داده را وارد کنید. اگر MySQL در دسترس نیست می‌توانید SQLite را انتخاب کنید که نیازی به سرور پایگاه داده ندارد.</p>

      <?php if ($error): ?>
        <div class="alert-error"><?= esc($error) ?></div>
      <?php endif; ?>

      <form method="post" class="mt">
        <?php include __DIR__ . '/inc/_install_fields.php'; ?>
        <button class="btn btn-primary full" type="submit">
          اجرای نصب خودکار پایگاه داده
        </button>
      </form>
    </section>
  <?php endif; ?>

  <?php if ($steps): ?>
    <section class="card">
      <h3 class="card-title small-title">گزارش مراحل نصب</h3>
      <ul class="steps">
        <?php foreach ($steps as $s): ?>
          <li class="step step-<?= esc($s['status']) ?>">
            <span class="step-dot">
              <?php if ($s['status'] === 'done'): ?>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M9.6 16.2 5.4 12l-1.5 1.5 5.7 5.7L20.1 8.7 18.6 7.2 9.6 16.2Z"/></svg>
              <?php else: ?>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18.3 5.7 12 12l6.3 6.3-1.4 1.4L10.6 13.4 5.7 18.3 4.3 16.9 10.6 12 4.3 6.4 5.7 5l4.9 4.9 6.3-6.3 1.4 1.3Z"/></svg>
              <?php endif; ?>
            </span>
            <span class="step-text">
              <b><?= esc($s['label']) ?></b>
              <?php if ($s['msg']): ?><i><?= esc($s['msg']) ?></i><?php endif; ?>
            </span>
          </li>
        <?php endforeach; ?>
      </ul>
    </section>
  <?php endif; ?>

  <p class="install-foot">آسانسور خلیج فارس صادقی — نصب‌کننده خودکار نسخه ۱.۰</p>
</main>

</body>
</html>

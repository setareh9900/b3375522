# منابع تصویری

- `control-panel-interior.webp`: برش تصویر تابلو فرمان واقعی آسانسور پایا کنترل، برای نمایش بافت داخل کابینت سه‌بعدی. منبع: https://omidelevator.com/product/تابلو-فرمان-آسانسور-پایا-کنترل/
- `control-panel-source.jpg`: تصویر مرجع اصلی همان منبع.
- `gearless-reference.png`: تصویر مرجع موتور گیرلس KA100 از Kisa Global: https://www.kisa-global.com/hot-product/belt-gearless-elevator-traction-machine-for.html

این تصاویر متعلق به صاحبان respective هستند. برای انتشار تجاری، مجوز استفاده را از منبع بگیرید یا آنها را با عکس محصولات خود شرکت جایگزین کنید. مسیر بافت تابلو: `assets/img/real/control-panel-interior.webp`.

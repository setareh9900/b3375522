/* تقویم شمسی سبک برای فرم درخواست — بدون وابستگی خارجی */
(function () {
  'use strict';
  var MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  var WEEK = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

  function toFa(n) { return String(n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; }); }
  function toEn(s) {
    return String(s || '').replace(/[۰-۹]/g, function (c) { return c.charCodeAt(0) - 1776; })
      .replace(/[٠-٩]/g, function (c) { return c.charCodeAt(0) - 1632; });
  }
  function g2j(gy, gm, gd) {
    var g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    var gy2 = gm > 2 ? gy + 1 : gy;
    var days = 355666 + 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100)
      + Math.floor((gy2 + 399) / 400) + gd + g_d_m[gm - 1];
    var jy = -1595 + 33 * Math.floor(days / 12053); days %= 12053;
    jy += 4 * Math.floor(days / 1461); days %= 1461;
    if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    var jm, jd;
    if (days < 186) { jm = 1 + Math.floor(days / 31); jd = 1 + (days % 31); }
    else { jm = 7 + Math.floor((days - 186) / 30); jd = 1 + ((days - 186) % 30); }
    return [jy, jm, jd];
  }
  function j2g(jy, jm, jd) {
    jy += 1595;
    var days = -355668 + 365 * jy + Math.floor(jy / 33) * 8 + Math.floor((jy % 33 + 3) / 4) + jd
      + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
    var gy = 400 * Math.floor(days / 146097); days %= 146097;
    if (days > 36524) { gy += 100 * Math.floor(--days / 36524); days %= 36524; if (days >= 365) days++; }
    gy += 4 * Math.floor(days / 1461); days %= 1461;
    if (days > 365) { gy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    var gd = days + 1, sal = [0, 31, (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], gm;
    for (gm = 0; gm < 13 && gd > sal[gm]; gm++) gd -= sal[gm];
    return [gy, gm, gd];
  }
  function isLeap(jy) {
    var breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
    var bl = breaks.length, jp = breaks[0], jm = jy + 1, jump = 0, leap;
    for (var i = 1; i < bl; i++) {
      var jm2 = breaks[i]; jump = jm2 - jp;
      if (jy < jm2) break;
      jp = jm2;
    }
    var n = jy - jp;
    if (jump - n < 6) n = n - jump + Math.floor((jump + 4) / 33) * 33;
    leap = (((n + 1) % 33) - 1) % 4;
    if (leap === -1) leap = 4;
    return leap === 0;
  }
  function daysInMonth(jy, jm) {
    if (jm <= 6) return 31;
    if (jm <= 11) return 30;
    return isLeap(jy) ? 30 : 29;
  }
  function fmt(jy, jm, jd) {
    return toFa(jy) + '/' + toFa(jm < 10 ? '0' + jm : jm) + '/' + toFa(jd < 10 ? '0' + jd : jd);
  }
  function parse(val) {
    var m = toEn(val).match(/^(\d{3,4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})$/);
    if (!m) return null;
    var jy = +m[1], jm = +m[2], jd = +m[3];
    if (jm < 1 || jm > 12 || jd < 1 || jd > daysInMonth(jy, jm)) return null;
    return [jy, jm, jd];
  }

  var openPop = null;
  function close() {
    if (openPop) { openPop.remove(); openPop = null; }
    document.removeEventListener('pointerdown', onDoc, true);
  }
  function onDoc(e) {
    if (openPop && !openPop.contains(e.target) && e.target !== openPop._input) close();
  }

  function mount(input) {
    if (!input || input._jalali) return;
    input._jalali = true;
    input.setAttribute('readonly', 'readonly');
    input.style.cursor = 'pointer';

    var now = new Date();
    var cur = g2j(now.getFullYear(), now.getMonth() + 1, now.getDate());
    var viewY = cur[0], viewM = cur[1];

    function paint() {
      var pop = openPop; if (!pop) return;
      var head = pop.querySelector('.jd-head');
      var grid = pop.querySelector('.jd-grid');
      head.querySelector('.jd-title').textContent = MONTHS[viewM - 1] + ' ' + toFa(viewY);
      grid.innerHTML = '';
      WEEK.forEach(function (w) {
        var s = document.createElement('span'); s.className = 'jd-w'; s.textContent = w; grid.appendChild(s);
      });
      var g = j2g(viewY, viewM, 1);
      var first = new Date(g[0], g[1] - 1, g[2]);
      /* شنبه = ۰ در تقویم ایران؛ getDay: 0=یکشنبه → تبدیل */
      var start = (first.getDay() + 1) % 7;
      var dim = daysInMonth(viewY, viewM);
      var selected = parse(input.value);
      for (var i = 0; i < start; i++) grid.appendChild(document.createElement('span'));
      for (var d = 1; d <= dim; d++) {
        (function (day) {
          var b = document.createElement('button');
          b.type = 'button'; b.className = 'jd-d'; b.textContent = toFa(day);
          if (selected && selected[0] === viewY && selected[1] === viewM && selected[2] === day) b.classList.add('on');
          if (cur[0] === viewY && cur[1] === viewM && cur[2] === day) b.classList.add('today');
          b.addEventListener('click', function () {
            input.value = fmt(viewY, viewM, day);
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
            close();
          });
          grid.appendChild(b);
        })(d);
      }
    }

    function open() {
      close();
      var p = parse(input.value);
      if (p) { viewY = p[0]; viewM = p[1]; }
      var pop = document.createElement('div');
      pop.className = 'jd-pop';
      pop.innerHTML =
        '<div class="jd-head">' +
          '<button type="button" class="jd-nav" data-dir="-1" aria-label="ماه قبل">›</button>' +
          '<strong class="jd-title"></strong>' +
          '<button type="button" class="jd-nav" data-dir="1" aria-label="ماه بعد">‹</button>' +
        '</div>' +
        '<div class="jd-grid"></div>' +
        '<div class="jd-foot"><button type="button" class="jd-today">امروز</button><button type="button" class="jd-clear">پاک کردن</button></div>';
      pop._input = input;
      document.body.appendChild(pop);
      openPop = pop;

      var r = input.getBoundingClientRect();
      var top = r.bottom + window.scrollY + 6;
      var left = Math.min(r.left + window.scrollX, window.scrollX + document.documentElement.clientWidth - 292);
      if (getComputedStyle(document.documentElement).direction === 'rtl') {
        left = Math.max(8, r.right + window.scrollX - 280);
      }
      pop.style.top = top + 'px';
      pop.style.left = left + 'px';

      pop.querySelectorAll('.jd-nav').forEach(function (btn) {
        btn.addEventListener('click', function () {
          viewM += Number(btn.getAttribute('data-dir'));
          if (viewM < 1) { viewM = 12; viewY--; }
          if (viewM > 12) { viewM = 1; viewY++; }
          paint();
        });
      });
      pop.querySelector('.jd-today').addEventListener('click', function () {
        viewY = cur[0]; viewM = cur[1];
        input.value = fmt(cur[0], cur[1], cur[2]);
        input.dispatchEvent(new Event('change', { bubbles: true }));
        close();
      });
      pop.querySelector('.jd-clear').addEventListener('click', function () {
        input.value = '';
        input.dispatchEvent(new Event('change', { bubbles: true }));
        close();
      });
      paint();
      setTimeout(function () { document.addEventListener('pointerdown', onDoc, true); }, 0);
    }

    input.addEventListener('click', open);
    input.addEventListener('focus', function () { if (!openPop) open(); });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') close();
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
    });
  }

  function boot() {
    document.querySelectorAll('[data-jalali-date]').forEach(mount);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();

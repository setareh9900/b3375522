/* =========================================================================
   سفر در کابین‌ها — اسکرول سه‌بعدی (بدون WebGL / Three.js، فقط transform و opacity)
   -------------------------------------------------------------------------
   ۱) ورود: درهای آسانسور باز می‌شوند (CSS) و کابین مسی در هیرو دیده می‌شود
   ۲) با اسکرول، «داخل کابین مسی می‌رویم» (زوم عمیق) و از دل آن، قاب قرمز/مشکی بیرون می‌آید
   ۳) کمی پایین‌تر، قاب مشکی با نرده‌های زرد وارد می‌شود
   ۴) آخر صفحه: درهای کابین باز و دوباره بسته می‌شوند (بخش .finale)
   ۵) پس‌زمینه: ابرهای نور (مسی/قرمز/زرد) که با پیشرفت صفحه جابه‌جا می‌شوند + کف شبکه‌ای + خطوط شفت
   • دستگاه ضعیف (data-perf="lite"): فقط transform/opacity ساده؛ بدون موس، بدون انیمیشن‌های پس‌زمینه
   • prefers-reduced-motion: کابین مسی ثابت، درهای پایانی باز
   ========================================================================= */
(function () {
  'use strict';

  var html = document.documentElement;
  var $ = function (id) { return document.getElementById(id); };
  var clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
  var seg = function (v, a, b) { return clamp((v - a) / (b - a), 0, 1); };            // پیشرفت خطی در بازه
  var sm = function (a, b, v) { var t = seg(v, a, b); return t * t * (3 - 2 * t); };   // smoothstep
  var eo = function (t) { return 1 - Math.pow(1 - t, 3); };                           // ease-out
  var eio = function (t) { return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
  var lerp = function (a, b, t) { return a + (b - a) * t; };

  var stage = $('cstage');
  if (!stage) return;
  var o1 = $('o1'), o2 = $('o2'), o3 = $('o3');
  var dimEl = $('cs-dim'), streaks = $('cs-streaks');
  var fin = $('finale');
  var up = $('ft-up');

  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = matchMedia('(hover: hover) and (pointer: fine)').matches;

  var vw = innerWidth, vh = innerHeight, scrollMax = 1, storyMax = 1, finTop = 0, finRange = 1, wide = vw >= 1000;
  var gBase = 0, mx = 0, my = 0, tx = 0, ty = 0, raf = 0, lastY = -1, sy = 0;

  function measure() {
    vw = innerWidth; vh = innerHeight; wide = vw >= 1000;
    scrollMax = Math.max(html.scrollHeight - vh, 1);
    lastY = -1;
    if (fin) { finTop = fin.getBoundingClientRect().top + scrollY; finRange = Math.max(fin.offsetHeight - vh, 1); }
    var g = $('hero'); gBase = g && g.classList.contains('gfx') ? Math.max(g.offsetHeight - vh, 0) : 0;
    storyMax = (fin ? Math.max(finTop - vh * 0.15, vh) : scrollMax) - gBase;     // داستان کابین‌ها تا شروع بخش پایانی
  }

  /* یک کابین را جای‌گذاری می‌کند: x,y (px) · s مقیاس · ry,rx (درجه) · a شفافیت */
  function place(el, x, y, s, ry, rx, a) {
    if (!el) return;
    if (a < 0.003) { if (el.style.opacity !== '0') el.style.opacity = '0'; return; }
    el.style.opacity = a.toFixed(3);
    el.style.transform = 'translate3d(-50%,-50%,0) translate3d(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px,0) ' +
      'rotateY(' + ry.toFixed(2) + 'deg) rotateX(' + rx.toFixed(2) + 'deg) scale(' + s.toFixed(3) + ')';
  }

  function frame() {
    raf = 0;
    var y = Math.max(scrollY - gBase, 0), p = clamp(y / storyMax, 0, 1);
    var lite = html.getAttribute('data-perf') === 'lite';
    var moving = Math.abs(tx - mx) > 0.002 || Math.abs(ty - my) > 0.002;
    if (y === lastY && !moving) return;                 // چیزی تغییر نکرده؛ هیچ نوشتنی در DOM انجام نشود
    mx += (tx - mx) * 0.07; my += (ty - my) * 0.07;

    /* ---------- موقعیت پایه: دسکتاپ = کابین سمت چپ (متن سمت راست)، موبایل = وسط ---------- */
    var bx = wide ? -vw * 0.235 : 0;
    var by = wide ? 0 : -vh * 0.06;
    var vis = wide ? 1 : 0.5;                       // روی موبایل کمی کم‌رنگ‌تر تا متن خوانا بماند
    var px = reduce ? 0 : mx, py = reduce ? 0 : my;

    if (reduce) {
      place(o1, bx, by, 1, -10, 0, vis);
      place(o2, 0, 0, 1, 0, 0, 0); place(o3, 0, 0, 1, 0, 0, 0);
    } else {
      /* ① کابین مسی: ورود به داخل کابین (زوم عمیق به سمت دهانه‌ی کابین) */
      var out1 = eio(seg(p, 0.015, 0.215));
      place(o1,
        lerp(bx, 0, out1) + px * -12,
        lerp(by, vh * 0.04, out1) + py * -8,
        1 + out1 * 2.7,
        -14 + out1 * 14 + px * 5,
        out1 * -4 + py * -3,
        (1 - sm(0.125, 0.225, p)) * vis);

      /* ② قاب قرمز/مشکی: از عمق می‌آید، می‌ایستد، و در ادامه از وسطش رد می‌شویم */
      var in2 = eo(seg(p, 0.125, 0.30)), out2 = eio(seg(p, 0.455, 0.60));
      var x2 = wide ? vw * 0.2 : 0;
      place(o2,
        lerp(x2 * 0.2, x2, in2) * (1 - out2) + px * -14,
        lerp(vh * 0.05, by, in2) + py * -9,
        (0.42 + 0.58 * in2) * (1 + out2 * 2.0),
        lerp(30, -12, in2) + out2 * -16 + px * 6,
        lerp(6, 0, in2) + py * -3,
        sm(0.12, 0.27, p) * (1 - sm(0.50, 0.605, p)) * vis);

      /* ③ قاب مشکی با نرده‌های زرد: وارد می‌شود، می‌ایستد، آخر کار بالا می‌رود و محو می‌شود */
      var in3 = eo(seg(p, 0.50, 0.665)), out3 = eio(seg(p, 0.835, 0.95));
      var x3 = wide ? -vw * 0.2 : 0;
      place(o3,
        lerp(x3 * 0.3, x3, in3) + px * -12,
        lerp(vh * 0.06, by, in3) - out3 * vh * 0.22 + py * -8,
        (0.5 + 0.5 * in3) * (1 + out3 * 0.25),
        lerp(-26, 10, in3) + px * 5,
        lerp(8, 0, in3) + out3 * 10 + py * -3,
        sm(0.49, 0.63, p) * (1 - sm(0.86, 0.95, p)) * vis);
    }

    /* ---------- پس‌زمینه: «منطقه‌ی رنگی» هر کابین ---------- */
    var zc = 1 - sm(0.12, 0.30, p) * 0.85 + sm(0.9, 1, p) * 0.5;
    var zr = sm(0.10, 0.30, p) * (1 - sm(0.46, 0.62, p));
    var zy = sm(0.46, 0.64, p) * (1 - sm(0.88, 1, p) * 0.6);
    stage.style.setProperty('--zc', zc.toFixed(3));
    stage.style.setProperty('--zr', zr.toFixed(3));
    stage.style.setProperty('--zy', zy.toFixed(3));
    if (!lite && !reduce) {
      stage.style.setProperty('--mx', (mx * 22).toFixed(1) + 'px');
      stage.style.setProperty('--my', (my * 14).toFixed(1) + 'px');
      /* خطوط شفت با اسکرول حرکت می‌کنند (حس بالا رفتن) */
      /* خطوط شفت غیرفعال — فقط اسپارکل بک‌گراند */
    }

    /* خوانایی متن: هیرو روشن، بقیه‌ی صفحه تیره‌تر */
    if (dimEl) dimEl.style.opacity = (0.08 + sm(0.1, 0.9, Math.min(y / vh, 1)) * (wide ? 0.5 : 0.62)).toFixed(3);

    /* ---------- پایان صفحه: با رسیدن به انتها، در بزرگ خودکار باز می‌شود (نه با اسکرول) ---------- */
    if (fin && !fin.classList.contains('is-open') && innerHeight + y >= html.scrollHeight - 6) fin.classList.add('is-open');

    lastY = y;
    if (!lite && !reduce && (Math.abs(tx - mx) > 0.002 || Math.abs(ty - my) > 0.002)) schedule();
  }

  function schedule() { if (!raf) raf = requestAnimationFrame(frame); }

  addEventListener('scroll', schedule, { passive: true });
  addEventListener('resize', function () { measure(); schedule(); });
  if (typeof ResizeObserver !== 'undefined') new ResizeObserver(function () { measure(); schedule(); }).observe(document.body);
  if (fine && !reduce) {
    addEventListener('pointermove', function (e) {
      if (html.getAttribute('data-perf') === 'lite') return;
      tx = (e.clientX / innerWidth - 0.5) * 2; ty = (e.clientY / innerHeight - 0.5) * 2; schedule();
    }, { passive: true });
  }

  /* درِ پایانی: وقتی در به‌اندازه‌ی کافی دیده شد، خودکار باز می‌شود؛ با برگشتن به بالا دوباره بسته می‌شود */
  if (fin) {
    var bigDoor = fin.querySelector('.dr') || fin;
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (es) {
        es.forEach(function (e) {
          if (e.isIntersecting && e.intersectionRatio >= 0.6) fin.classList.add('is-open');
          else if (!e.isIntersecting) fin.classList.remove('is-open');
        });
      }, { threshold: [0, 0.6] }).observe(bigDoor);
    } else { fin.classList.add('is-open'); }
  }

  /* دکمه‌ی «بازگشت به همکف» در فوتر */
  if (up) up.addEventListener('click', function (ev) {
    ev.preventDefault();
    scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
  });


  measure(); schedule();
  addEventListener('load', function () { measure(); schedule(); });
})();

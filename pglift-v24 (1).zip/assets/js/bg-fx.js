/* بک‌گراندهای تعاملی سایت: sparkles / particles / aurora / mouse-spark
   الهام از 21st Sparkles + افکت‌های دنبال‌کننده موس */
(function () {
  'use strict';
  var root = document.documentElement;
  if (root.getAttribute('data-perf') === 'lite') return;
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  var mode = (root.getAttribute('data-bg-fx') || 'sparkles').toLowerCase();
  if (mode === 'none' || mode === 'off') return;

  var host = document.getElementById('bg-fx');
  if (!host) {
    host = document.createElement('div');
    host.id = 'bg-fx';
    host.setAttribute('aria-hidden', 'true');
    document.body.insertBefore(host, document.body.firstChild);
  }
  host.className = 'bg-fx bg-fx-' + mode;

  var canvas = document.createElement('canvas');
  host.appendChild(canvas);
  var ctx = canvas.getContext('2d');
  if (!ctx) return;

  var dpr = Math.min(window.devicePixelRatio || 1, 2);
  var W = 0, H = 0, parts = [], mx = -9999, my = -9999, raf = 0, running = true;
  var theme = root.getAttribute('data-site-theme') || 'copper';
  var palette = {
    copper: ['#f0d4b0', '#d4a06a', '#ffffff', '#e8c49a'],
    amber: ['#e3af35', '#f5d76e', '#ffffff', '#c2820a'],
    darkmatter: ['#e78a53', '#fbcb97', '#5f8787', '#ffffff'],
    slate: ['#94a3b8', '#e2e8f0', '#38bdf8', '#ffffff']
  };
  var colors = palette[theme] || palette.copper;

  function resize() {
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width = Math.floor(W * dpr);
    canvas.height = Math.floor(H * dpr);
    canvas.style.width = W + 'px';
    canvas.style.height = H + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    seed();
  }

  function rand(a, b) { return a + Math.random() * (b - a); }
  function pick() { return colors[(Math.random() * colors.length) | 0]; }

  function seed() {
    parts = [];
    /* چگالی ملایم — بدون خط‌خط ستاره‌ای روی بک‌گراند */
    var density = mode === 'sparkles' ? Math.min(70, Math.floor((W * H) / 22000))
      : mode === 'particles' ? Math.min(55, Math.floor((W * H) / 28000))
      : mode === 'aurora' ? 28
      : Math.min(50, Math.floor((W * H) / 26000));
    for (var i = 0; i < density; i++) {
      var rising = mode === 'sparkles' || mode === 'particles';
      parts.push({
        x: rand(0, W), y: rand(0, H),
        r: mode === 'aurora' ? rand(40, 120) : rand(0.5, rising ? 2.0 : 1.8),
        vx: rand(-0.12, 0.12),
        vy: rising ? rand(-0.7, -0.18) : rand(-0.25, 0.25),
        a: rand(0.18, 0.7), da: rand(0.004, 0.014) * (Math.random() < 0.5 ? -1 : 1),
        c: pick(), life: 1, tw: false
      });
    }
  }

  function drawSparkles() {
    ctx.clearRect(0, 0, W, H);
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      p.x += p.vx + Math.sin((performance.now() / 900) + i) * 0.08;
      p.y += p.vy;
      p.a += p.da;
      if (p.a <= 0.12 || p.a >= 1) p.da *= -1;
      if (p.x < -6) p.x = W + 6; if (p.x > W + 6) p.x = -6;
      if (p.y < -10) { p.y = H + 8; p.x = rand(0, W); }
      if (p.y > H + 10) p.y = -8;
      ctx.globalAlpha = p.a * 0.75;
      ctx.fillStyle = p.c;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function drawParticles() {
    ctx.clearRect(0, 0, W, H);
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      var dx = mx - p.x, dy = my - p.y, dist = Math.hypot(dx, dy) || 1;
      if (dist < 160) { p.vx += dx / dist * 0.04; p.vy += dy / dist * 0.04; }
      p.vx *= 0.96; p.vy *= 0.96;
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > W) p.vx *= -1;
      if (p.y < 0 || p.y > H) p.vy *= -1;
      ctx.globalAlpha = 0.5;
      ctx.fillStyle = p.c;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function drawAurora() {
    ctx.clearRect(0, 0, W, H);
    ctx.globalCompositeOperation = 'lighter';
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      p.x += p.vx * 0.4; p.y += Math.sin((performance.now() / 1800) + i) * 0.15;
      if (p.x < -p.r) p.x = W + p.r; if (p.x > W + p.r) p.x = -p.r;
      var g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r);
      g.addColorStop(0, p.c + '88');
      g.addColorStop(1, 'transparent');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalCompositeOperation = 'source-over';
  }

  function drawMouseSpark() {
    ctx.clearRect(0, 0, W, H);
    for (var i = parts.length - 1; i >= 0; i--) {
      var p = parts[i];
      p.life -= 0.02; p.r *= 0.98; p.x += p.vx; p.y += p.vy;
      if (p.life <= 0 || p.r < 0.2) { parts.splice(i, 1); continue; }
      ctx.globalAlpha = p.life;
      ctx.fillStyle = p.c;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function frame() {
    if (!running) return;
    if (mode === 'sparkles') drawSparkles();
    else if (mode === 'particles') drawParticles();
    else if (mode === 'aurora') drawAurora();
    else drawMouseSpark();
    raf = requestAnimationFrame(frame);
  }

  addEventListener('pointermove', function (e) {
    mx = e.clientX; my = e.clientY;
    if (mode === 'mouse' || mode === 'mouse-spark') {
      for (var i = 0; i < 3; i++) {
        parts.push({
          x: mx + rand(-6, 6), y: my + rand(-6, 6),
          r: rand(1.2, 3.2), vx: rand(-1.2, 1.2), vy: rand(-1.6, 0.2),
          a: 1, da: 0, c: pick(), life: 1
        });
      }
      if (parts.length > 180) parts.splice(0, parts.length - 180);
    }
  }, { passive: true });

  addEventListener('pointerleave', function () { mx = -9999; my = -9999; });
  addEventListener('resize', function () {
    clearTimeout(resize._t);
    resize._t = setTimeout(resize, 120);
  });

  if ('IntersectionObserver' in window) {
    /* همیشه روی viewport است؛ pause وقتی تب مخفی */
  }
  document.addEventListener('visibilitychange', function () {
    running = !document.hidden;
    if (running && !raf) raf = requestAnimationFrame(frame);
  });

  resize();
  raf = requestAnimationFrame(frame);
})();

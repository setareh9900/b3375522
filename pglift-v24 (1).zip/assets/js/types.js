/* =========================================================================
   انواع آسانسور — تب‌ها، زوم روی قطعات نقشه، توضیح صوتی (فایل یا گفتار مرورگر) و استعلام قیمت
   ========================================================================= */
(function () {
  'use strict';
  var root = document.getElementById('tx');
  if (!root) return;

  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var tabs = [].slice.call(root.querySelectorAll('.tx-tab'));
  var panels = [].slice.call(root.querySelectorAll('.tx-panel'));
  var current = panels[0] || null;
  var synth = window.speechSynthesis || null;
  var voice = null;

  var clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
  var fa = function (n) { return Number(n).toLocaleString('fa-IR'); };

  function initPanel(panel) {
    var stage = panel.querySelector('.tx-stage'), zoomer = panel.querySelector('.tx-zoomer');
    var st = panel._st = { stage: stage, zoomer: zoomer, focus: -1, tour: 0, playing: false, audio: null };
    var callout = panel.querySelector('.tx-callout');
    var dots = [].slice.call(panel.querySelectorAll('.tx-dot'));
    var chips = [].slice.call(panel.querySelectorAll('.tx-part'));
    var infoT = panel.querySelectorAll('.tx-dot');
    st.count = dots.length;

    function meta(i) {
      var d = dots[i];
      return { title: d.getAttribute('aria-label') || '', desc: '' };
    }
    /* عنوان و توضیح هر نقطه از JSON درون صفحه خوانده می‌شود */
    var info = [];
    try { info = JSON.parse(panel.getAttribute('data-hot') || '[]'); } catch (e) { info = []; }

    st.focusAt = function (i) {
      if (!zoomer || !dots[i]) return;
      var d = dots[i], z = parseFloat(d.getAttribute('data-z')) || 2.6;
      var W = stage.clientWidth, H = stage.clientHeight;
      var x = parseFloat(d.style.left) / 100 * W, y = parseFloat(d.style.top) / 100 * H;
      var tx = clamp(W / 2 - x * z, W - W * z, 0), ty = clamp(H / 2 - y * z, H - H * z, 0);
      zoomer.style.setProperty('--s', z);
      zoomer.style.transform = 'translate3d(' + tx.toFixed(1) + 'px,' + ty.toFixed(1) + 'px,0) scale(' + z + ')';
      stage.classList.add('tx-zoomed');
      dots.forEach(function (n, k) { n.classList.toggle('on', k === i); });
      chips.forEach(function (n) { n.classList.toggle('on', +n.getAttribute('data-i') === i); });
      var m = info[i] || meta(i);
      if (callout) {
        callout.querySelector('b').textContent = m.title;
        callout.querySelector('p').textContent = m.desc;
        callout.classList.add('show');
      }
      st.focus = i;
    };

    st.reset = function () {
      if (!zoomer) return;
      zoomer.style.setProperty('--s', 1);
      zoomer.style.transform = 'translate3d(0,0,0) scale(1)';
      stage.classList.remove('tx-zoomed');
      dots.forEach(function (n) { n.classList.remove('on'); });
      chips.forEach(function (n) { n.classList.remove('on'); });
      if (callout) callout.classList.remove('show');
      st.focus = -1;
    };
    zoomer && (zoomer.style.setProperty('--s', 1));

    dots.forEach(function (d, i) {
      d.addEventListener('click', function (e) {
        e.preventDefault();
        stopTour(panel);
        if (d.getAttribute('data-act') === 'pano' && panel.getAttribute('data-pano')) { openPano(panel); return; }
        if (st.focus === i) st.reset(); else st.focusAt(i);
      });
    });
    chips.forEach(function (b) {
      b.addEventListener('click', function () {
        stopTour(panel);
        var i = +b.getAttribute('data-i');
        if (dots[i] && dots[i].getAttribute('data-act') === 'pano' && panel.getAttribute('data-pano')) { openPano(panel); return; }
        if (st.focus === i) st.reset(); else st.focusAt(i);
        if (stage && window.innerWidth < 860) stage.scrollIntoView({ block: 'center', behavior: 'smooth' });
      });
    });
    var back = panel.querySelector('.tx-back');
    if (back) back.addEventListener('click', function () { stopTour(panel); st.reset(); });

    /* خروج تصویر از صفحه → بازگشت به نمای کامل (کارت توضیح روی موبایل ثابت است) */
    if (stage && 'IntersectionObserver' in window) {
      new IntersectionObserver(function (en) {
        if (!en[0].isIntersecting && st.focus >= 0 && !st.playing) st.reset();
      }, { threshold: 0 }).observe(stage);
    }

    /* ---------- استعلام قیمت ---------- */
    var stops = panel.querySelector('.tx-stops'), cap = panel.querySelector('.tx-cap'), est = panel.querySelector('.tx-est');
    var base = +panel.getAttribute('data-base') || 0, per = +panel.getAttribute('data-per') || 0;
    function estimate() {
      if (!est) return '';
      if (base <= 0) { est.textContent = ''; return ''; }
      var n = clamp(parseInt(stops.value, 10) || 2, 2, 60), c = +cap.value || 6;
      var total = (base + per * Math.max(0, n - 2)) * (1 + Math.max(0, c - 6) * 0.04);
      var lo = Math.round(total * 0.92 / 1e5) * 1e5, hi = Math.round(total * 1.15 / 1e5) * 1e5;
      var txt = 'برآورد اولیه: ' + fa(lo) + ' تا ' + fa(hi) + ' تومان';
      est.innerHTML = '';
      est.appendChild(document.createTextNode(txt + ' '));
      var sm = document.createElement('small'); sm.textContent = '(غیرقطعی؛ قیمت نهایی پس از بازدید)'; est.appendChild(sm);
      return txt;
    }
    if (stops) stops.addEventListener('input', estimate);
    if (cap) cap.addEventListener('change', estimate);
    estimate();

    var ask = panel.querySelector('.tx-ask');
    if (ask) ask.addEventListener('click', function () {
      var title = ask.getAttribute('data-type-title');
      var n = clamp(parseInt(stops.value, 10) || 2, 2, 60), c = +cap.value || 6;
      prefill(title, n, c, estimate());
    });

    panel.querySelectorAll('[data-pano-open]').forEach(function (btn) { btn.addEventListener('click', function () { openPano(panel); }); });

    /* ---------- دکمه‌ی شنیدن ---------- */
    var btn = panel.querySelector('[data-listen]');
    st.btn = btn;
    if (btn) btn.addEventListener('click', function () { st.playing ? stopPlay(panel) : startPlay(panel); });
  }

  function prefill(title, stops, cap, estTxt) {
    var f = document.getElementById('request-form');
    if (!f) return;
    var set = function (name, v) { var el = f.elements[name]; if (el) { el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); } };
    var radio = f.querySelector('input[name="request_type"][value="install"]');
    if (radio) { radio.checked = true; radio.dispatchEvent(new Event('change', { bubbles: true })); }
    set('subject', 'استعلام قیمت ' + title);
    var sel = f.elements.elevator_type;
    if (sel) {
      var has = [].some.call(sel.options, function (o) { return o.value === title; });
      if (!has) { var o = document.createElement('option'); o.value = o.textContent = title; sel.appendChild(o); }
      sel.value = title;
    }
    set('floors', stops);
    set('passengers', cap);
    set('message', 'سلام، قیمت ' + title + ' با ' + fa(stops) + ' توقف و ظرفیت ' + fa(cap) + ' نفر را می‌خواهم.' + (estTxt ? '\n(' + estTxt + ')' : ''));
    setTimeout(function () { var n = f.elements.customer_name; if (n) n.focus({ preventScroll: true }); }, 700);
  }

  /* ---------- توضیح صوتی + تور خودکار قطعات ---------- */
  function pickVoice() {
    if (!synth) return;
    var v = synth.getVoices() || [];
    voice = null;
    for (var i = 0; i < v.length; i++) if (/^fa/i.test(v[i].lang)) { voice = v[i]; break; }
    if (!voice) {
      for (var j = 0; j < v.length; j++) if (/persian|farsi|iran/i.test(v[j].name || '')) { voice = v[j]; break; }
    }
    panels.forEach(updateListenBtn);
  }
  function updateListenBtn(panel) {
    var btn = panel._st && panel._st.btn;
    if (!btn) return;
    var hasAudio = !!(panel.getAttribute('data-audio') || '').trim();
    var hasSpeech = !!(panel.getAttribute('data-speech') || '').trim();
    var canTts = !!synth && typeof SpeechSynthesisUtterance !== 'undefined';
    btn.hidden = !(hasAudio || (hasSpeech && canTts && !!voice));
  }

  function stopTour(panel) { var st = panel._st; if (st && st.tour) { clearTimeout(st.tour); st.tour = 0; } }
  function startTour(panel, totalMs) {
    var st = panel._st, n = st.count || 0;
    if (!st.zoomer || !n) return;
    var each = clamp(totalMs / (n + 1), 3200, 8500), i = 0;
    stopTour(panel);
    (function next() {
      if (!st.playing) return;
      if (i >= n) { st.reset(); return; }
      st.focusAt(i++);
      st.tour = setTimeout(next, each);
    })();
  }

  function setBtn(panel, playing) {
    var st = panel._st; if (!st.btn) return;
    st.btn.classList.toggle('playing', playing);
    st.btn.querySelector('.tx-listen-label').textContent = playing ? 'توقف' : 'شنیدن توضیحات';
  }

  function stopPlay(panel) {
    var st = panel && panel._st; if (!st) return;
    st.playing = false;
    stopTour(panel);
    if (st.audio) { try { st.audio.pause(); } catch (e) { /* ignore */ } }
    if (synth) { try { synth.cancel(); } catch (e) { /* ignore */ } }
    setBtn(panel, false);
    st.reset();
  }

  function speak(panel) {
    var st = panel._st, text = panel.getAttribute('data-speech') || '';
    var chunks = text.replace(/([.!؟?۔])\s+/g, '$1|').split('|').filter(Boolean);   // بدون lookbehind (سازگار با iOS قدیمی)
    if (!chunks.length) { stopPlay(panel); return; }
    /* cancel بلافاصله speak بعدی را هم می‌کشد — کمی صبر لازم است */
    try { synth.cancel(); } catch (e) { /* ignore */ }
    var left = chunks.length;
    var useVoice = voice;
    var useLang = (voice && voice.lang) || 'fa-IR';
    if (!useVoice) {
      var all = (synth.getVoices && synth.getVoices()) || [];
      if (all.length) { useVoice = all[0]; useLang = useVoice.lang || 'en-US'; }
    }
    startTour(panel, Math.max(text.length / 12 * 1000, chunks.length * 2800));
    setTimeout(function () {
      if (!st.playing) return;
      chunks.forEach(function (c) {
        var u = new SpeechSynthesisUtterance(c);
        u.lang = useLang;
        if (useVoice) u.voice = useVoice;
        u.rate = 0.95;
        u.onend = function () { if (--left <= 0 && st.playing) stopPlay(panel); };
        u.onerror = function () {
          left -= 1;
          if (left <= 0 && st.playing) stopPlay(panel);
        };
        try { synth.speak(u); } catch (err) { left -= 1; }
      });
      if (left <= 0) stopPlay(panel);
    }, 60);
  }

  /* مسیر مطمئن: اول فایل مستقیم، اگر هاست مسدود کرد از api/audio.php (با Range) */
  function audioUrls(src) {
    var f = src.split('/').pop();
    return ['api/audio.php?f=' + encodeURIComponent(f), src];
  }
  function note(panel, msg) {
    var n = panel.querySelector('.tx-audio-note');
    if (!n) { n = document.createElement('p'); n.className = 'tx-audio-note'; var a = panel.querySelector('.tx-actions'); if (a) a.appendChild(n); }
    n.textContent = msg || ''; n.hidden = !msg;
  }
  function buildPlayer(panel) {
    var st = panel._st;
    if (st.bar) return st.bar;
    var bar = document.createElement('div'); bar.className = 'tx-player'; bar.hidden = true;
    bar.innerHTML = '<input type="range" min="0" max="1000" value="0" aria-label="جابجایی در صوت"><span class="tx-time" dir="ltr">0:00</span>';
    var a = panel.querySelector('.tx-actions'); if (a) a.appendChild(bar);
    st.bar = bar; st.range = bar.querySelector('input'); st.time = bar.querySelector('.tx-time');
    st.range.addEventListener('input', function () {
      if (st.audio && st.audio.duration) st.audio.currentTime = st.audio.duration * st.range.value / 1000;
    });
    return bar;
  }
  function fmt(t) { t = Math.max(0, Math.floor(t || 0)); return Math.floor(t / 60) + ':' + ('0' + (t % 60)).slice(-2); }
  function makeAudio(panel, src) {
    var st = panel._st, urls = audioUrls(src), idx = 0;
    var au = new Audio(); au.preload = 'auto'; au.setAttribute('playsinline', '');
    au.addEventListener('ended', function () { if (st.playing) stopPlay(panel); });
    au.addEventListener('timeupdate', function () {
      if (st.range && au.duration) { st.range.value = Math.round(au.currentTime / au.duration * 1000); st.time.textContent = fmt(au.currentTime) + ' / ' + fmt(au.duration); }
    });
    au.addEventListener('error', function () {
      if (idx < urls.length - 1) { idx++; au.src = urls[idx]; au.load(); if (st.playing) { var q = au.play(); if (q && q.catch) q.catch(function () {}); } return; }
      st.audio = null; st.playing = false; setBtn(panel, false); stopTour(panel);
      note(panel, 'فایل صوتی روی سرور پیدا یا بارگذاری نشد؛ آن را از پنل ادمین دوباره آپلود و ذخیره کنید.');
    });
    au.src = urls[0];
    return au;
  }

  function startPlay(panel) {
    panels.forEach(function (p) { if (p !== panel && p._st && p._st.playing) stopPlay(p); });
    var st = panel._st, src = (panel.getAttribute('data-audio') || '').trim();
    var canTts = !!synth && typeof SpeechSynthesisUtterance !== 'undefined' && !!voice;
    note(panel, '');
    st.playing = true; setBtn(panel, true); st.reset();
    if (src) {
      if (!st.audio) st.audio = makeAudio(panel, src);
      var bar = buildPlayer(panel); bar.hidden = false;
      var au = st.audio;
      try { au.currentTime = 0; } catch (e) { /* ignore */ }
      var p = au.play();   /* داخل همان کلیک کاربر صدا زده می‌شود تا موبایل اجازه دهد */
      var begin = function () { startTour(panel, (au.duration || 40) * 1000); };
      if (au.readyState >= 1) begin(); else au.addEventListener('loadedmetadata', begin, { once: true });
      if (p && p.catch) p.catch(function (err) {
        if (err && err.name === 'NotAllowedError') { st.playing = false; setBtn(panel, false); note(panel, 'مرورگر پخش را مسدود کرد؛ یک بار دیگر دکمه را بزنید.'); }
        else if (err && err.name !== 'AbortError') { note(panel, 'فایل صوتی بارگذاری نشد؛ فایل و فرمت آن را در پنل مدیریت بررسی کنید.'); }
      });
    } else if (canTts) {
      speak(panel);
    } else {
      st.playing = false; setBtn(panel, false);
      note(panel, 'برای این مدل هنوز فایل صوتی آپلود نشده است.');
    }
  }

  /* ---------- نمای ۳۶۰° (WebGL؛ تصویر equirectangular) ---------- */
  var panoEl = null, panoState = null;
  function closePano() {
    if (!panoEl) return;
    if (panoState && panoState.stop) panoState.stop();
    panoEl.hidden = true; panoEl.innerHTML = '';
    var sy = (panoState && typeof panoState.scrollY === 'number') ? panoState.scrollY : 0;
    document.body.classList.remove('no-scroll');
    document.body.style.position = '';
    document.body.style.top = '';
    document.body.style.width = '';
    window.scrollTo(0, sy);
    document.removeEventListener('keydown', panoKey);
    if (panoState && panoState.opener) { try { panoState.opener.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }
    panoState = null;
  }
  function panoKey(e) { if (e.key === 'Escape') closePano(); }

  function openPano(panel) {
    var src = panel.getAttribute('data-pano'); if (!src) return;
    if (current) stopPlay(current);
    if (!panoEl) {
      panoEl = document.createElement('div');
      panoEl.className = 'pano';
      panoEl.setAttribute('role', 'dialog');
      panoEl.setAttribute('aria-modal', 'true');
      panoEl.setAttribute('aria-label', 'نمای ۳۶۰ درجه داخل کابین');
      document.body.appendChild(panoEl);
    }
    panoEl.innerHTML = '';
    var box = document.createElement('div'); box.className = 'pano-box';
    var close = document.createElement('button'); close.type = 'button'; close.className = 'pano-close'; close.textContent = '✕ بستن';
    var title = document.createElement('div'); title.className = 'pano-title'; title.textContent = 'نمای نمونه داخل کابین — ' + (panel.getAttribute('data-title') || '');
    var hint = document.createElement('div'); hint.className = 'pano-hint'; hint.textContent = 'بکشید تا بچرخد · چرخ ماوس / دو انگشت برای زوم · کلیدهای جهت برای چرخش';
    box.appendChild(title); box.appendChild(close); box.appendChild(hint);
    panoEl.appendChild(box); panoEl.hidden = false;
    /* قفل اسکرول و جلوگیری از پرش به انتهای صفحه */
    var sy = window.scrollY || document.documentElement.scrollTop || 0;
    document.body.classList.add('no-scroll');
    document.body.style.top = '-' + sy + 'px';
    document.body.style.position = 'fixed';
    document.body.style.width = '100%';
    panoState = { opener: document.activeElement, scrollY: sy };
    document.addEventListener('keydown', panoKey);
    close.addEventListener('click', closePano);
    panoEl.onclick = function (e) { if (e.target === panoEl) closePano(); };
    close.focus({ preventScroll: true });

    var img = new Image(), activeState = panoState;
    img.onload = function () { if (!panoEl || panoEl.hidden || panoState !== activeState) return; panoState.stop = startViewer(box, img, hint); };
    img.onerror = function () { if (panoState === activeState) hint.textContent = 'بارگذاری تصویر ۳۶۰° ممکن نشد'; };
    img.src = src;
  }

  function startViewer(box, img, hint) {
    var yaw = 0, pitch = 0, fov = 75 * Math.PI / 180, auto = !reduce, dirty = true, raf = 0, dead = false;
    var canvas = document.createElement('canvas');
    var gl = null;
    try { gl = canvas.getContext('webgl', { antialias: false }) || canvas.getContext('experimental-webgl'); } catch (e) { gl = null; }
    var MIN_FOV = 30 * Math.PI / 180, MAX_FOV = 100 * Math.PI / 180;

    var drawFn;
    if (gl) {
      var vs = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}';
      var fs = '#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\nuniform sampler2D t;uniform vec2 r;uniform float y,pt,f;' +
        'void main(){vec2 q=(gl_FragCoord.xy-.5*r)/r.y;vec3 d=normalize(vec3(q.x,q.y,.5/tan(f*.5)));' +
        'float cp=cos(pt),sp=sin(pt);d=vec3(d.x,d.y*cp-d.z*sp,d.y*sp+d.z*cp);' +
        'float cy=cos(y),sy=sin(y);d=vec3(d.x*cy+d.z*sy,d.y,-d.x*sy+d.z*cy);' +
        'float lon=atan(d.x,d.z),lat=asin(clamp(d.y,-1.,1.));' +
        'gl_FragColor=texture2D(t,vec2(fract(lon/6.2831853+.5),1.-(lat/3.1415926+.5)));}';
      var mk = function (type, src) { var sh = gl.createShader(type); gl.shaderSource(sh, src); gl.compileShader(sh); return sh; };
      var prog = gl.createProgram();
      gl.attachShader(prog, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(prog, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) gl = null;
    }
    if (gl) {
      gl.useProgram(prog);
      var buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
      var loc = gl.getAttribLocation(prog, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
      // اگر تصویر از حد بافت دستگاه بزرگ‌تر بود، کوچک می‌شود
      var maxT = Math.min(gl.getParameter(gl.MAX_TEXTURE_SIZE) || 2048, 4096), tex = img;
      if (img.naturalWidth > maxT) {
        var c2 = document.createElement('canvas'); c2.width = maxT; c2.height = Math.round(img.naturalHeight * maxT / img.naturalWidth);
        c2.getContext('2d').drawImage(img, 0, 0, c2.width, c2.height); tex = c2;
      }
      var t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      var uR = gl.getUniformLocation(prog, 'r'), uY = gl.getUniformLocation(prog, 'y'), uP = gl.getUniformLocation(prog, 'pt'), uF = gl.getUniformLocation(prog, 'f');
      box.insertBefore(canvas, box.firstChild);
      drawFn = function () {
        var dpr = Math.min(window.devicePixelRatio || 1, 2), w = Math.round(box.clientWidth * dpr), h = Math.round(box.clientHeight * dpr);
        if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
        gl.viewport(0, 0, w, h);
        gl.uniform2f(uR, w, h); gl.uniform1f(uY, yaw); gl.uniform1f(uP, pitch); gl.uniform1f(uF, fov);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      };
    } else {
      /* جایگزین بدون WebGL: تصویر پیوسته‌ی قابل‌کشیدن (چرخش افقی) */
      var fb = document.createElement('div'); fb.className = 'pano-fallback';
      fb.style.backgroundImage = 'url("' + img.src + '")';
      box.insertBefore(fb, box.firstChild); canvas = fb;
      drawFn = function () {
        var h = Math.round(box.clientHeight * 2 * (75 * Math.PI / 180) / fov), w = Math.round(h * img.naturalWidth / img.naturalHeight);
        fb.style.backgroundSize = w + 'px ' + h + 'px';
        fb.style.backgroundPosition = (-(yaw / (2 * Math.PI)) * w) + 'px ' + (-(h - box.clientHeight) * (0.5 - pitch / Math.PI)) + 'px';
      };
    }

    canvas.setAttribute('tabindex', '0');
    canvas.setAttribute('aria-label', 'نمای ۳۶۰ درجه؛ برای حرکت از کلیدهای جهت و برای زوم از مثبت و منفی استفاده کنید');
    canvas.addEventListener('keydown', function(e) {
      if (e.key === 'ArrowLeft') yaw -= .18; else if (e.key === 'ArrowRight') yaw += .18;
      else if (e.key === 'ArrowUp') pitch = clamp(pitch + .15, -1.45, 1.45); else if (e.key === 'ArrowDown') pitch = clamp(pitch - .15, -1.45, 1.45);
      else if (e.key === '+' || e.key === '=') fov = clamp(fov * .9, MIN_FOV, MAX_FOV); else if (e.key === '-') fov = clamp(fov * 1.1, MIN_FOV, MAX_FOV); else return;
      e.preventDefault(); auto = false; dirty = true;
    });

    function frame() {
      raf = 0; if (dead) return;
      if (auto) { yaw += 0.0028; dirty = true; }
      if (dirty) { dirty = false; drawFn(); }
      raf = requestAnimationFrame(frame);
    }
    raf = requestAnimationFrame(frame);

    /* کشیدن و زوم */
    var ptrs = {}, lastDist = 0;
    canvas.addEventListener('pointerdown', function (e) { canvas.setPointerCapture(e.pointerId); ptrs[e.pointerId] = [e.clientX, e.clientY]; auto = false; hint.style.opacity = '0'; });
    canvas.addEventListener('pointermove', function (e) {
      var p = ptrs[e.pointerId]; if (!p) return;
      var ids = Object.keys(ptrs);
      if (ids.length === 2) {
        var o = ptrs[ids[0] === String(e.pointerId) ? ids[1] : ids[0]];
        ptrs[e.pointerId] = [e.clientX, e.clientY];
        var d = Math.hypot(e.clientX - o[0], e.clientY - o[1]);
        if (lastDist) { fov = clamp(fov * (lastDist / d), MIN_FOV, MAX_FOV); dirty = true; }
        lastDist = d; return;
      }
      var k = fov / (box.clientHeight || 600);
      yaw -= (e.clientX - p[0]) * k; pitch = clamp(pitch + (e.clientY - p[1]) * k, -1.45, 1.45);
      ptrs[e.pointerId] = [e.clientX, e.clientY]; dirty = true;
    });
    var up = function (e) { delete ptrs[e.pointerId]; lastDist = 0; };
    canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
    canvas.addEventListener('wheel', function (e) { e.preventDefault(); fov = clamp(fov * (e.deltaY > 0 ? 1.08 : 0.92), MIN_FOV, MAX_FOV); dirty = true; }, { passive: false });
    var onResize = function () { dirty = true; };
    window.addEventListener('resize', onResize);

    return function stop() { dead = true; window.removeEventListener('resize', onResize); cancelAnimationFrame(raf); if (gl) { var ext = gl.getExtension('WEBGL_lose_context'); if (ext) ext.loseContext(); } };
  }

  /* ---------- تب‌ها ---------- */
  function activate(id, focus) {
    var next = null;
    panels.forEach(function (p) { if (p.id === 'tx-' + id) next = p; });
    if (!next || next === current) return;
    if (current) stopPlay(current);
    panels.forEach(function (p) { p.hidden = p !== next; });
    tabs.forEach(function (t) {
      var on = t.getAttribute('data-tab') === id;
      t.setAttribute('aria-selected', on ? 'true' : 'false');
      t.tabIndex = on ? 0 : -1;
      if (on && focus) t.focus();
    });
    current = next;
  }
  tabs.forEach(function (t, i) {
    t.tabIndex = i === 0 ? 0 : -1;
    t.addEventListener('click', function () { activate(t.getAttribute('data-tab')); });
    t.addEventListener('keydown', function (e) {
      var d = e.key === 'ArrowLeft' ? 1 : e.key === 'ArrowRight' ? -1 : 0;   // RTL
      if (!d) return;
      e.preventDefault();
      var n = tabs[(i + d + tabs.length) % tabs.length];
      activate(n.getAttribute('data-tab'), true);
    });
  });

  panels.forEach(initPanel);
  if (synth) {
    pickVoice();
    if (synth.addEventListener) synth.addEventListener('voiceschanged', pickVoice); else synth.onvoiceschanged = pickVoice;
  }
  panels.forEach(updateListenBtn);
  document.addEventListener('visibilitychange', function () { if (document.hidden && current) stopPlay(current); });
  addEventListener('pagehide', function () { if (current) stopPlay(current); });
})();

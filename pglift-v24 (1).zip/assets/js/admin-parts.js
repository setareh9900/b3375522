/* =========================================================================
   پنل مدیریت — ویرایشگر «قطعات و متعلقات» (دسته‌ها/قفسه‌ها + کالاها)
   ========================================================================= */
(function () {
  'use strict';
  var mount = document.getElementById('parts-editor');
  if (!mount) return;

  var data = JSON.parse(document.getElementById('parts-json').textContent);
  var csrf = document.getElementById('parts-csrf').value;
  var toastEl = document.getElementById('toast'), toastT = 0;

  function toast(t, kind) {
    if (!toastEl) { alert(t); return; }
    clearTimeout(toastT); toastEl.textContent = t; toastEl.className = 'toast ' + (kind || ''); toastEl.hidden = false;
    requestAnimationFrame(function () { toastEl.classList.add('show'); });
    toastT = setTimeout(function () { toastEl.classList.remove('show'); setTimeout(function () { toastEl.hidden = true; }, 350); }, 3600);
  }
  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') n.textContent = attrs[k]; else if (k === 'class') n.className = attrs[k];
      else if (k === 'value') n.value = attrs[k]; else n.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  function field(label, input, hint) { return el('div', { class: 'field' }, [el('label', { text: label }), input, hint ? el('small', { class: 'muted', text: hint }) : null]); }
  function post(payload) {
    var fd = new FormData(); fd.append('csrf', csrf);
    Object.keys(payload).forEach(function (k) { fd.append(k, payload[k]); });
    return fetch('action.php', { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'پاسخ نامعتبر از سرور' }; }); });
  }
  function webPath(p) { return /^https?:/.test(p) ? p : '../' + p; }
  function uid(p) { return p + Math.random().toString(36).slice(2, 8); }

  /* حالت کاری: داده را در حافظه نگه می‌داریم و فرم‌ها را از روی آن می‌سازیم */
  var cardsReaders = [];

  function build() {
    mount.innerHTML = ''; cardsReaders = [];
    data.cats.forEach(function (cat, ci) { mount.appendChild(buildCat(cat, ci)); });
  }

  function buildCat(cat, ci) {
    var inTitle = el('input', { class: 'input', value: cat.title });
    var items = data.items.filter(function (it) { return it.cat === cat.id; });
    var list = el('div', { class: 'parts-adm-list' });

    var upC = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: '↑' });
    var dnC = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: '↓' });
    var delC = el('button', { type: 'button', class: 'btn btn-danger btn-sm', text: 'حذف دسته' });
    var addI = el('button', { type: 'button', class: 'btn btn-primary btn-sm', text: '+ قطعه‌ی جدید' });
    inTitle.addEventListener('input', function () { cat.title = inTitle.value; });
    upC.addEventListener('click', function () { moveCat(ci, -1); });
    dnC.addEventListener('click', function () { moveCat(ci, 1); });
    delC.addEventListener('click', function () {
      if (!confirm('این دسته و همه‌ی قطعه‌های آن حذف شود؟')) return;
      data.items = data.items.filter(function (it) { return it.cat !== cat.id; });
      data.cats.splice(ci, 1); build();
    });
    addI.addEventListener('click', function () {
      data.items.push({ id: uid('p'), cat: cat.id, title: 'قطعه‌ی جدید', tag: '', desc: '', specs: [], image: '', model: '', active: 1 }); build();
      var cards = mount.querySelectorAll('.parts-adm-item'); cards.length && cards[cards.length - 1].scrollIntoView({ block: 'center' });
    });

    items.forEach(function (it) { list.appendChild(buildItem(it)); });
    if (!items.length) list.appendChild(el('p', { class: 'muted small', text: 'این دسته قطعه‌ای ندارد.' }));

    var head = el('div', { class: 'tx-adm-head' }, [el('b', { text: (ci + 1) + '.' }), inTitle, upC, dnC, addI, delC]);
    return el('section', { class: 'card tx-adm-card' }, [head, list]);
  }

  function buildItem(it) {
    var inTitle = el('input', { class: 'input', value: it.title });
    var inTag = el('input', { class: 'input', value: it.tag || '' });
    var inDesc = el('textarea', { class: 'input', rows: '4' }); inDesc.value = it.desc || '';
    var inSpecs = el('textarea', { class: 'input', rows: '5' }); inSpecs.value = (it.specs || []).map(function (s) { return s[0] + ': ' + s[1]; }).join('\n');
    var inActive = el('input', { type: 'checkbox' }); inActive.checked = !!it.active;
    var selCat = el('select', { class: 'input' });
    data.cats.forEach(function (c) { var o = el('option', { value: c.id, text: c.title }); if (c.id === it.cat) o.selected = true; selCat.appendChild(o); });

    inTitle.addEventListener('input', function () { it.title = inTitle.value; });
    inTag.addEventListener('input', function () { it.tag = inTag.value; });
    inDesc.addEventListener('input', function () { it.desc = inDesc.value; });
    inSpecs.addEventListener('input', function () {
      it.specs = inSpecs.value.split('\n').map(function (l) { var i = l.indexOf(':'); if (i < 0) i = l.indexOf('：'); return i > 0 ? [l.slice(0, i).trim(), l.slice(i + 1).trim()] : null; }).filter(Boolean);
    });
    inActive.addEventListener('change', function () { it.active = inActive.checked ? 1 : 0; });
    selCat.addEventListener('change', function () { it.cat = selCat.value; build(); });

    /* عکس */
    var imgBox = el('div', { class: 'parts-adm-img' });
    function renderImg() {
      imgBox.innerHTML = '';
      if (it.image) imgBox.appendChild(el('img', { src: webPath(it.image), alt: '' }));
      var file = el('input', { type: 'file', accept: 'image/png,image/webp,image/jpeg' });
      var up = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: it.image ? 'جایگزینی عکس' : 'آپلود عکس' });
      up.addEventListener('click', function () {
        if (!file.files || !file.files[0]) { toast('ابتدا عکس را انتخاب کنید', 'err'); return; }
        var fd = new FormData(); fd.append('csrf', csrf); fd.append('kind', 'parts'); fd.append('file', file.files[0]);
        up.disabled = true; up.textContent = 'در حال آپلود...';
        fetch('upload-type-image.php', { method: 'POST', body: fd, credentials: 'same-origin' })
          .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'پاسخ نامعتبر از سرور' }; }); })
          .then(function (j) { if (j.ok) { it.image = j.path; toast('عکس آپلود شد؛ «ذخیره‌ی همه» را بزنید', 'ok'); renderImg(); } else { toast(j.error || 'خطا', 'err'); up.disabled = false; up.textContent = 'آپلود عکس'; } })
          .catch(function () { toast('خطا در ارتباط با سرور', 'err'); up.disabled = false; up.textContent = 'آپلود عکس'; });
      });
      imgBox.appendChild(el('div', { class: 'tx-adm-up' }, [file, up]));
    }
    renderImg();

    /* مدل سه‌بعدی اختصاصی GLB */
    var modelBox = el('div', { class: 'parts-adm-model' });
    function renderModel() {
      modelBox.innerHTML = '';
      var title = el('div', { class: 'model-adm-title' }, [el('b', { text: '◈ مدل سه‌بعدی GLB' }), el('span', { class: it.model ? 'model-state ready' : 'model-state', text: it.model ? 'مدل اختصاصی متصل است' : 'از مدل پیش‌فرض استفاده می‌شود' })]);
      var file = el('input', { type: 'file', accept: '.glb,model/gltf-binary' });
      var up = el('button', { type: 'button', class: 'btn btn-primary btn-sm', text: it.model ? 'جایگزینی GLB' : 'آپلود GLB' });
      var remove = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: 'حذف مدل' });
      remove.disabled = !it.model;
      up.addEventListener('click', function () {
        if (!file.files || !file.files[0]) { toast('ابتدا فایل .glb را انتخاب کنید', 'err'); return; }
        var selected = file.files[0];
        if (!/\.glb$/i.test(selected.name)) { toast('فرمت فایل باید GLB باشد', 'err'); return; }
        if (selected.size > 100 * 1024 * 1024) { toast('حجم مدل حداکثر ۱۰۰ مگابایت باشد', 'err'); return; }
        var fd = new FormData(); fd.append('csrf', csrf); fd.append('file', selected);
        up.disabled = true; up.textContent = 'در حال آپلود مدل…';
        fetch('upload-part-model.php', { method: 'POST', body: fd, credentials: 'same-origin' })
          .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'پاسخ نامعتبر سرور؛ احتمالاً حجم آپلود بیشتر از تنظیم PHP است' }; }); })
          .then(function (j) { if (j.ok) { it.model = j.path; toast('GLB آپلود شد؛ برای انتشار «ذخیره‌ی همه» را بزنید', 'ok'); renderModel(); } else { toast(j.error || 'آپلود ناموفق بود', 'err'); up.disabled = false; up.textContent = 'آپلود GLB'; } })
          .catch(function () { toast('ارتباط هنگام آپلود قطع شد', 'err'); up.disabled = false; up.textContent = 'آپلود GLB'; });
      });
      remove.addEventListener('click', function () { if (!it.model || !confirm('مدل اختصاصی قطعه حذف و مدل پیش‌فرض نمایش داده شود؟')) return; it.model = ''; toast('مدل حذف شد؛ «ذخیره‌ی همه» را بزنید', 'ok'); renderModel(); });
      modelBox.appendChild(title);
      if (it.model) modelBox.appendChild(el('code', { class: 'model-adm-path', text: it.model }));
      modelBox.appendChild(el('div', { class: 'tx-adm-up' }, [file, up, remove]));
      modelBox.appendChild(el('small', { class: 'muted', text: 'خروجی glTF Binary 2.0 با پسوند .glb تا ۱۰۰MB؛ بافت‌ها داخل فایل embed شوند. Draco نیز پشتیبانی می‌شود.' }));
    }
    renderModel();

    var del = el('button', { type: 'button', class: 'btn btn-danger btn-sm', text: 'حذف' });
    del.addEventListener('click', function () { if (confirm('این قطعه حذف شود؟')) { data.items = data.items.filter(function (x) { return x !== it; }); build(); } });

    return el('div', { class: 'parts-adm-item' }, [
      el('div', { class: 'parts-adm-top' }, [inTitle, el('label', { class: 'bg-opt' }, [inActive, el('span', { text: 'نمایش' })]), del]),
      el('div', { class: 'parts-adm-grid' }, [
        imgBox,
        el('div', { class: 'parts-adm-f' }, [
          field('دسته', selCat), field('شعار کوتاه', inTag), field('توضیح', inDesc),
          field('مشخصات (هر خط: عنوان: مقدار) — مثل نوع ریل، جنس، اندازه', inSpecs)
        ])
      ])
    ]);
  }

  function moveCat(i, d) {
    var j = i + d; if (j < 0 || j >= data.cats.length) return;
    var t = data.cats[i]; data.cats[i] = data.cats[j]; data.cats[j] = t; build();
  }

  document.getElementById('parts-add-cat').addEventListener('click', function () {
    if (data.cats.length >= 12) { toast('حداکثر ۱۲ دسته مجاز است', 'err'); return; }
    data.cats.push({ id: uid('c'), title: 'دسته‌ی جدید' }); build();
    mount.lastChild.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  document.getElementById('parts-save').addEventListener('click', function () {
    post({ do: 'parts.save', data: JSON.stringify(data) }).then(function (j) {
      if (j.ok) toast('ذخیره شد (' + j.count + ' قطعه)', 'ok'); else toast(j.error || 'خطا در ذخیره', 'err');
    }).catch(function () { toast('خطا در ارتباط با سرور', 'err'); });
  });
  document.getElementById('parts-reset').addEventListener('click', function () {
    if (!confirm('قطعات و دسته‌ها به حالت پیش‌فرض برگردد؟')) return;
    post({ do: 'parts.reset' }).then(function (j) { if (j.ok) location.reload(); else toast(j.error || 'خطا', 'err'); });
  });
  build();
})();

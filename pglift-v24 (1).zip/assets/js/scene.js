/* =========================================================================
   تعاملات اسکرول (سبک) — آسانسور خلیج فارس صادقی
   - فقط یک حلقه‌ی rAF، فقط وقتی اسکرول تغییر کرده
   - هیچ خواندن layout (getBoundingClientRect) در حلقه‌ی اسکرول نیست؛ اندازه‌ها کش می‌شوند
   - هیرو با اسکرول عقب می‌رود و محو می‌شود، خط مراحل مثل چراغ طبقات روشن می‌شود
   - تشخیص خودکار دستگاه ضعیف → data-perf="lite"
   - حذف دِر ورودی بعد از پایان انیمیشن
   ========================================================================= */
(function () {
  'use strict';

  var html = document.documentElement;
  var $ = function (id) { return document.getElementById(id); };
  var clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  var hero = $('hero'), heroIn = $('hero-inner');
  var hint = document.querySelector('.scroll-hint');
  var stepsRow = document.querySelector('.steps-row');
  var steps = [].slice.call(document.querySelectorAll('.pstep'));

  /* ---------- اندازه‌ها: فقط هنگام load / resize ---------- */
  var vh = innerHeight, heroRange = 1, stepsTop = 0, stepsH = 1;
  function measure() {
    vh = innerHeight;
    if (hero) heroRange = Math.max(hero.offsetHeight - vh, 1);
    if (stepsRow) {
      var r = stepsRow.getBoundingClientRect();
      stepsTop = r.top + (window.scrollY || 0);
      stepsH = r.height;
    }
    lastY = -1;
  }

  /* ---------- تشخیص دستگاه ضعیف از روی فریم‌ریت واقعی ---------- */
  var probing = html.getAttribute('data-perf') !== 'lite' && !reduce;
  var samples = [], lastT = 0, lastProbeY = -1;
  function probe(t, y) {
    if (!probing) return;
    if (y === lastProbeY) { lastT = t; return; }
    lastProbeY = y;
    if (lastT && t - lastT < 100) samples.push(t - lastT);
    lastT = t;
    if (samples.length >= 40) {
      probing = false;
      samples.sort(function (a, b) { return a - b; });
      if (samples[samples.length >> 1] > 26) {          // کمتر از ~۳۸ فریم بر ثانیه
        html.setAttribute('data-perf', 'lite');
        try { localStorage.setItem('gfPerf', 'lite'); } catch (e) { /* ignore */ }
      }
    }
  }

  /* ---------- حلقه‌ی اصلی ---------- */
  var raf = 0, lastY = -1, heroGone = false;

  function frame(t) {
    raf = 0;
    var y = window.scrollY || 0;
    probe(t, y);
    if (y === lastY) return;
    lastY = y;
    if (reduce) return;

    /* هیرو: عقب می‌رود، کوچک می‌شود و محو می‌شود */
    if (heroIn) {
      var hp = clamp(y / heroRange, 0, 1);
      if (hp < 1 || !heroGone) {
        heroIn.style.transform = 'translate3d(0,' + (-hp * 7).toFixed(2) + 'vh,0) scale(' + (1 - hp * 0.1).toFixed(3) + ')';
        heroIn.style.opacity = clamp(1.15 - hp * 1.35, 0, 1).toFixed(3);
        if (hint) hint.style.opacity = clamp(1 - hp * 6, 0, 1).toFixed(2);
        heroGone = hp >= 1;
      }
    }

    /* خط فرآیند + چراغ مراحل (با موقعیت کش‌شده) */
    if (stepsRow) {
      var top = stepsTop - y;
      if (top + stepsH > -50 && top < vh + 50) {
        var lp = clamp((vh * 0.82 - top) / (stepsH + vh * 0.2), 0, 1);
        stepsRow.style.setProperty('--lp', lp.toFixed(3));
        for (var s = 0; s < steps.length; s++) {
          var on = lp > (s + 0.3) / steps.length * 0.92;
          if (on !== steps[s].classList.contains('lit')) steps[s].classList.toggle('lit', on);
        }
      }
    }
  }

  function schedule() { if (!raf) raf = requestAnimationFrame(frame); }

  addEventListener('scroll', schedule, { passive: true });
  addEventListener('resize', function () { measure(); schedule(); });
  addEventListener('load', function () { measure(); schedule(); });
  if (typeof ResizeObserver !== 'undefined') {
    var ro = 0;
    new ResizeObserver(function () {
      cancelAnimationFrame(ro);
      ro = requestAnimationFrame(function () { measure(); schedule(); });
    }).observe(document.body);
  }
  measure();
  schedule();

  /* ---------- دِر ورودی: بعد از پایان انیمیشن از DOM حذف می‌شود ---------- */
  var intro = $('intro');
  if (intro) {
    var done = false;
    var finish = function () {
      if (done) return; done = true;
      html.classList.remove('intro-on');
      if (intro.parentNode) intro.parentNode.removeChild(intro);
      try { sessionStorage.setItem('gfIntro', '1'); } catch (e) { /* ignore */ }
    };
    intro.addEventListener('animationend', function (e) { if (e.target === intro) finish(); });
    setTimeout(finish, 2400);                 // اطمینان: حتی اگر animationend نیامد
  }
})();

/* =========================================================================
   CoverflowCarousel — پورت دقیق از کامپوننت React ارسالی
   نقاشی مستقیم روی DOM؛ فقط transform / opacity / z-index
   ========================================================================= */
(function () {
  'use strict';
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  function el(tag, cls, html) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  function mount(frame, o) {
    o = o || {};
    var rotate = o.rotate != null ? o.rotate : 44;
    var depth = o.depth != null ? o.depth : 0.6;
    var persp = o.perspective != null ? o.perspective : 3;
    var falloff = o.falloff != null ? o.falloff : 0.56;
    var fade = o.fade != null ? o.fade : 0.1;
    var gap = o.gap != null ? o.gap : 0.05;
    var showNav = o.showNavigation !== false;
    var showDots = o.showPagination !== false;
    var showCap = o.showCaption !== false;
    var root = frame.parentNode;

    var wrap = el('div', 'cf-wrap');
    root.insertBefore(wrap, frame);
    wrap.appendChild(frame);

    var stage = el('div', 'cf-stage');
    [].slice.call(frame.children).forEach(function (c) {
      if (c.hasAttribute('data-cf-skip')) return;
      stage.appendChild(c);
    });
    frame.appendChild(stage);
    frame.classList.add('cf-frame');
    frame.setAttribute('tabindex', '0');
    frame.setAttribute('role', 'region');
    frame.setAttribute('aria-roledescription', 'carousel');
    frame.setAttribute('aria-label', o.label || 'کاورفلو');
    frame.style.perspective = 'calc(var(--cf-card) * ' + persp + ')';
    frame.style.touchAction = 'pan-y';
    stage.style.transformStyle = 'preserve-3d';

    var prev = el('button', 'cf-nav cf-prev', '←');
    var next = el('button', 'cf-nav cf-next', '→');
    prev.type = next.type = 'button';
    prev.setAttribute('aria-label', 'قبلی');
    next.setAttribute('aria-label', 'بعدی');
    if (showNav) { wrap.appendChild(prev); wrap.appendChild(next); }

    var cap = el('div', 'cf-caption');
    cap.setAttribute('aria-live', 'polite');
    var dots = el('div', 'cf-dots');
    if (showCap) root.insertBefore(cap, wrap.nextSibling);
    if (showDots) root.insertBefore(dots, (showCap ? cap : wrap).nextSibling);

    var items = [], count = 0, loop = false;
    var pos = 0, target = 0, width = 0, raf = null, drag = null, selected = -1, moved = false;

    function collect() {
      items = [].slice.call(stage.children).filter(function (c) { return !c.hidden; });
      [].slice.call(stage.children).forEach(function (c) {
        c.style.display = c.hidden ? 'none' : '';
      });
      count = items.length;
      loop = o.loop !== false && count >= 3;
      items.forEach(function (c, i) {
        c.setAttribute('role', 'group');
        c.setAttribute('aria-roledescription', 'slide');
        c.setAttribute('aria-label', (i + 1) + ' از ' + count);
        /* مثل React: بدون transition روی transform */
        c.style.transition = 'border-color .3s, box-shadow .3s, filter .3s';
      });
    }
    function idxAt(p) { return count ? ((Math.round(p) % count) + count) % count : 0; }
    function clampPos(p) { return loop ? p : clamp(p, 0, Math.max(0, count - 1)); }

    /* دقیقاً همان paint کامپوننت React */
    function paint() {
      if (!width) return;
      var pitch = width * (1 + gap);
      for (var i = 0; i < count; i++) {
        var card = items[i];
        var offset = i - pos;
        if (loop) {
          offset = ((offset % count) + count) % count;
          if (offset > count / 2) offset -= count;
        }
        var distance = Math.abs(offset);
        var ramp = Math.pow(distance, falloff);
        var tilt = Math.min(rotate * ramp, 82) * Math.sign(offset || 0);
        card.style.transform =
          'translateX(calc(-50% + ' + (offset * pitch) + 'px)) ' +
          'translateZ(' + (-depth * width * ramp) + 'px) rotateY(' + (-tilt) + 'deg)';
        var edge = loop ? Math.min(1, Math.max(0, count / 2 - distance)) : 1;
        card.style.opacity = String(Math.max(0, 1 - fade * distance) * edge);
        card.style.zIndex = String(100 - Math.round(distance));
      }
    }

    function mark() {
      var s = idxAt(target);
      if (s === selected) return;
      selected = s;
      items.forEach(function (c, i) { c.classList.toggle('is-center', i === s); });
      [].slice.call(dots.children).forEach(function (d, i) {
        d.setAttribute('aria-current', i === s ? 'true' : 'false');
        d.classList.toggle('on', i === s);
      });
      if (showCap && o.caption && items[s]) {
        cap.innerHTML = o.caption(items[s]);
        cap.classList.remove('in');
        void cap.offsetWidth;
        cap.classList.add('in');
      }
      if (o.onChange) o.onChange(items[s], s);
    }

    function settle(t) {
      if (raf !== null) cancelAnimationFrame(raf);
      target = t;
      mark();
      if (reduce) { pos = t; paint(); raf = null; return; }
      (function step() {
        var rem = target - pos;
        if (Math.abs(rem) < 0.0004) { pos = target; paint(); raf = null; return; }
        pos += rem * 0.16;
        paint();
        raf = requestAnimationFrame(step);
      })();
    }
    function nudge(by) { settle(clampPos(Math.round(target) + by)); }
    function goTo(i) {
      var t = loop ? i + Math.round((target - i) / count) * count : i;
      settle(clampPos(t));
    }

    function buildDots() {
      if (!showDots) return;
      dots.innerHTML = '';
      if (count < 2) { dots.hidden = true; if (showNav) { prev.hidden = next.hidden = true; } return; }
      dots.hidden = false;
      if (showNav) { prev.hidden = next.hidden = false; }
      for (var i = 0; i < count; i++) (function (k) {
        var b = el('button');
        b.type = 'button';
        b.setAttribute('aria-label', 'رفتن به ' + (k + 1));
        b.addEventListener('click', function () { goTo(k); });
        dots.appendChild(b);
      })(i);
    }
    function measure() {
      var c = items[0];
      if (!c) return;
      width = c.offsetWidth;
      paint();
    }

    /* pointer — همان منطق React */
    frame.addEventListener('pointerdown', function (e) {
      if (e.button) return;
      if (raf !== null) { cancelAnimationFrame(raf); raf = null; }
      try { frame.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ }
      target = pos;
      moved = false;
      drag = { id: e.pointerId, x: e.clientX, pos: pos, v: 0, t: performance.now() };
      frame.classList.add('drag');
    });
    frame.addEventListener('pointermove', function (e) {
      if (!drag || drag.id !== e.pointerId) return;
      var pitch = width * (1 + gap);
      if (!pitch) return;
      var now = performance.now();
      var previous = pos;
      pos = clampPos(drag.pos - (e.clientX - drag.x) / pitch);
      drag.v = ((pos - previous) / Math.max(now - drag.t, 1)) * 1000;
      drag.t = now;
      if (Math.abs(e.clientX - drag.x) > 4) moved = true;
      var index = idxAt(pos);
      if (index !== selected) { target = pos; mark(); }
      paint();
    });
    function endDrag(e) {
      if (!drag || drag.id !== e.pointerId) return;
      var d = drag;
      drag = null;
      frame.classList.remove('drag');
      var carried = clamp(d.v * 0.18, -2, 2);
      settle(clampPos(Math.round(pos + carried)));
    }
    frame.addEventListener('pointerup', endDrag);
    frame.addEventListener('pointercancel', endDrag);

    frame.addEventListener('click', function (e) {
      if (moved) { moved = false; e.preventDefault(); e.stopPropagation(); return; }
      var c = e.target.closest ? e.target.closest('.cf-stage > *') : null;
      if (!c) return;
      var i = items.indexOf(c);
      if (i < 0) return;
      if (i !== idxAt(target)) { e.preventDefault(); e.stopPropagation(); goTo(i); }
    }, true);

    frame.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft') { e.preventDefault(); nudge(-1); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); nudge(1); }
    });
    prev.addEventListener('click', function () { nudge(-1); });
    next.addEventListener('click', function () { nudge(1); });
    if (showCap) {
      cap.addEventListener('click', function (e) {
        var b = e.target.closest('[data-cf-open]');
        if (b && items[idxAt(target)]) {
          if (o.onOpen) o.onOpen(items[idxAt(target)], b);
          else items[idxAt(target)].click();
        }
      });
    }

    function refresh(keep) {
      var cur = keep && items[idxAt(target)];
      collect();
      buildDots();
      selected = -1;
      var i = cur ? Math.max(0, items.indexOf(cur)) : 0;
      pos = target = i;
      measure();
      mark();
      paint();
    }

    collect();
    buildDots();
    measure();
    mark();
    paint();
    if (window.ResizeObserver) new ResizeObserver(measure).observe(frame);
    else addEventListener('resize', measure);
    return { refresh: refresh, goTo: goTo, nudge: nudge, el: frame, stage: stage, get index() { return idxAt(target); } };
  }

  window.GFCoverflow = { mount: mount };
})();

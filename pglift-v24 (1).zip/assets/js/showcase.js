/* =========================================================================
   Showcase v12 — جایگزین سبک و بدون وابستگی برای باندل React گالری‌ها
   ۱) پنل شاسی‌های طبقات + شفت متحرک (انواع آسانسور)
   ۲) قفسه‌های قطعات: کادر طراحی‌شده، برگشت قطعه به کادر با اسکرول، پیمایش چپ/راست
   ۳) دسته‌بندی: نشانگر لغزنده، تشخیص خودکار دسته‌ی فعال و حرکت جهت‌دار چپ/راست
   فقط transform و opacity؛ روی گوشی ضعیف هم روان.
   ========================================================================= */
(function () {
  'use strict';
  var doc = document, root = doc.documentElement;
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var lite = root.getAttribute('data-perf') === 'lite';
  var raf = window.requestAnimationFrame.bind(window);

  function $(s, c) { return (c || doc).querySelector(s); }
  function $$(s, c) { return [].slice.call((c || doc).querySelectorAll(s)); }
  function el(tag, cls, html) { var n = doc.createElement(tag); if (cls) n.className = cls; if (html != null) n.innerHTML = html; return n; }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function json(id) { try { var a = JSON.parse((doc.getElementById(id) || {}).textContent || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  /* ======================================================================
     ۱) پنل شاسی‌ها + شفت
     ====================================================================== */
  function initLift() {
    var host = doc.getElementById('floor-gallery');
    var items = json('floor-gallery-data');
    if (!host || !items.length) return;
    var N = items.length, cur = 0, timers = [], busy = false;

    host.innerHTML = '';
    var lg = el('div', 'lg'); lg.setAttribute('data-phase', 'idle');
    lg.setAttribute('role', 'region'); lg.setAttribute('aria-label', 'انتخاب طبقه و نوع آسانسور');

    /* --- پنل شاسی --- */
    var panel = el('div', 'lg-panel');
    var disp = el('div', 'lg-display', '<span class="lg-arrow" aria-hidden="true">▲</span><b class="lg-num">' + pad(items[0].floor || 1) + '</b>');
    disp.setAttribute('aria-live', 'polite');
    var btnWrap = el('div', 'lg-btns'); btnWrap.setAttribute('role', 'group'); btnWrap.setAttribute('aria-label', 'انتخاب طبقه');
    var btns = [];
    /* مثل پنل واقعی: بالاترین طبقه بالا */
    for (var k = N - 1; k >= 0; k--) {
      (function (i) {
        var b = el('button', 'lg-btn', '<span class="lg-led" aria-hidden="true"></span><span class="lg-lbl">' + pad(items[i].floor || i + 1) + '</span>');
        b.type = 'button'; b.setAttribute('data-i', i);
        b.setAttribute('aria-label', 'طبقه ' + (items[i].floor || i + 1) + ': ' + items[i].title);
        b.setAttribute('aria-pressed', i === 0 ? 'true' : 'false');
        b.addEventListener('click', function () { press(b); go(i, true); });
        btns[i] = b; btnWrap.appendChild(b);
      })(k);
    }
    var name = el('p', 'lg-name', esc(items[0].title));
    var tip = el('p', 'lg-tip', 'شاسی طبقه را بزنید؛ کابین می‌رسد و مشخصات همان مدل باز می‌شود');
    panel.appendChild(disp); panel.appendChild(btnWrap); panel.appendChild(name); panel.appendChild(tip);

    /* --- شفت --- */
    var shaft = el('div', 'lg-shaft');
    var win = el('div', 'lg-window');
    var strip = el('div', 'lg-strip');
    strip.style.height = (N * 100) + '%';
    items.forEach(function (it, i) {
      var s = el('button', 'lg-slide');
      s.type = 'button'; s.style.height = (100 / N) + '%'; s.setAttribute('data-i', i);
      s.setAttribute('aria-label', 'مشاهده مشخصات ' + it.title);
      s.setAttribute('tabindex', i === 0 ? '0' : '-1');
      var img = it.src ? '<img src="' + esc(it.src) + '" alt="" decoding="async" draggable="false"' + (i === 0 ? '' : ' loading="eager" fetchpriority="low"') + '>' : '<span class="lg-missing">تصویر در دسترس نیست</span>';
      s.innerHTML = img + '<span class="lg-cap"><small>طبقه ' + (it.floor || i + 1) + '</small><strong>' + esc(it.title) + '</strong>' +
        (it.caption ? '<span>' + esc(it.caption) + '</span>' : '') + '<em>مشاهده مشخصات ↗</em></span>';
      s.addEventListener('click', function () { if (i === cur && !busy) open(it); });
      strip.appendChild(s);
    });
    var dl = el('i', 'lg-door lg-door-l'), dr = el('i', 'lg-door lg-door-r'), streak = el('i', 'lg-streak');
    streak.setAttribute('aria-hidden', 'true'); dl.setAttribute('aria-hidden', 'true'); dr.setAttribute('aria-hidden', 'true');
    win.appendChild(strip); win.appendChild(streak); win.appendChild(dl); win.appendChild(dr);

    /* خط‌کش طبقات کنار شفت */
    var ruler = el('div', 'lg-ruler'); ruler.setAttribute('aria-hidden', 'true');
    var car = el('i', 'lg-car'); ruler.appendChild(car);
    for (var r = 0; r < N; r++) ruler.appendChild(el('span', 'lg-tick', '<b>' + pad(items[r].floor || r + 1) + '</b>'));
    shaft.appendChild(win); shaft.appendChild(ruler);

    lg.appendChild(shaft); lg.appendChild(panel); host.appendChild(lg);
    setCar(0); car.textContent = pad(items[0].floor || 1);

    function setCar(i) {
      /* جای کابین روی خط‌کش (۰ پایین، N-1 بالا)، بر حسب پیکسل */
      var h = Math.max(0, ruler.clientHeight - car.offsetHeight);
      var y = N === 1 ? 0 : (i / (N - 1)) * h;
      car.style.transform = 'translate3d(0,' + (-y).toFixed(1) + 'px,0)';
    }
    addEventListener('resize', function () { var d = car.style.transitionDuration; car.style.transitionDuration = '0s'; setCar(cur); void car.offsetWidth; car.style.transitionDuration = d; });
    function press(b) {
      b.classList.remove('pressed'); void b.offsetWidth; b.classList.add('pressed');
      if (navigator.vibrate) { try { navigator.vibrate(12); } catch (e) { } }
    }
    function clear() { timers.forEach(clearTimeout); timers = []; }
    function setDisplay(i, dir) {
      disp.querySelector('.lg-arrow').textContent = dir === 0 ? '■' : dir > 0 ? '▲' : '▼';
      disp.querySelector('.lg-num').textContent = pad(items[i].floor || i + 1);
      car.textContent = pad(items[i].floor || i + 1);
    }
    function mark(i, called) {
      btns.forEach(function (b, j) {
        b.classList.toggle('is-here', j === i && !called);
        b.classList.toggle('is-called', j === i && !!called);
        b.setAttribute('aria-pressed', j === i ? 'true' : 'false');
      });
    }

    function go(i, fromUser) {
      i = clamp(i, 0, N - 1);
      var from = cur, dist = Math.abs(i - from);
      if (i === from && !busy) { return; }
      clear();
      if (fromUser) {
        var tab = doc.getElementById('txt-' + items[i].id);
        if (tab && tab.getAttribute('aria-selected') !== 'true') { tab.click(); }
      }
      var dir = i > from ? 1 : -1;
      cur = i;
      name.textContent = items[i].title;
      $$('.lg-slide', strip).forEach(function (s, j) { s.setAttribute('tabindex', j === i ? '0' : '-1'); });
      if (reduce) {
        strip.style.transition = 'none'; strip.style.transform = 'translate3d(0,' + (-i * 100 / N) + '%,0)';
        setDisplay(i, 0); mark(i, false); setCar(i); lg.setAttribute('data-phase', 'idle'); busy = false; return;
      }
      busy = true; mark(i, true);
      lg.setAttribute('data-phase', 'closing');
      var travel = clamp(360 + dist * 200, 520, 1200);
      /* ۱) درها بسته می‌شوند ← ۲) طبقات حرکت می‌کنند ← ۳) درها باز می‌شوند */
      timers.push(setTimeout(function () {
        lg.setAttribute('data-phase', 'travelling');
        lg.style.setProperty('--dir', dir);
        strip.style.transitionDuration = travel + 'ms';
        strip.style.transform = 'translate3d(0,' + (-i * 100 / N) + '%,0)';
        car.style.transitionDuration = travel + 'ms'; setCar(i);
        /* شمارنده‌ی طبقه در مسیر */
        for (var s = 1; s <= dist; s++) {
          (function (step) {
            timers.push(setTimeout(function () { setDisplay(from + dir * step, dir); }, (travel / dist) * step - 30));
          })(s);
        }
      }, 290));
      timers.push(setTimeout(function () {
        lg.setAttribute('data-phase', 'opening'); setDisplay(i, 0); mark(i, false);
      }, 290 + travel));
      timers.push(setTimeout(function () { lg.setAttribute('data-phase', 'idle'); busy = false; }, 290 + travel + 460));
    }

    function open(it) {
      var tab = doc.getElementById('txt-' + it.id), panelEl = doc.getElementById('tx-' + it.id);
      if (tab) tab.click();
      if (panelEl) panelEl.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    }

    /* هماهنگی با تب‌های پایین */
    items.forEach(function (it, i) {
      var t = doc.getElementById('txt-' + it.id);
      if (t) t.addEventListener('click', function () { if (i !== cur) go(i, false); });
    });
    /* کیبورد */
    panel.addEventListener('keydown', function (e) {
      var n = cur;
      if (e.key === 'ArrowUp') n = Math.min(N - 1, cur + 1);
      else if (e.key === 'ArrowDown') n = Math.max(0, cur - 1);
      else if (e.key === 'Home') n = 0; else if (e.key === 'End') n = N - 1; else return;
      e.preventDefault(); press(btns[n]); btns[n].focus(); go(n, true);
    });
    mark(0, false);
  }

  /* ======================================================================
     ۲) قفسه‌ها + ۳) دسته‌بندی
     ====================================================================== */
  function initShelves() {
    var catalog = doc.getElementById('catalog');
    if (!catalog) return;
    var shelves = $$('.shelf', catalog);
    if (!shelves.length) return;
    /* هر قفسه = یک Coverflow سه‌بعدی؛ کارت مرکزی با کلیک باز می‌شود، کارت کناری به مرکز می‌آید */
    shelves.forEach(function (shelf) {
      var mount = $('[data-panoramic-shelf]', shelf); if (mount) mount.hidden = true;
      var row = $('.shelf-row', shelf); if (!row) return;
      shelf.classList.add('shelf-v12');
      if (!window.GFCoverflow) return;
      shelf._cf = GFCoverflow.mount(row, {
        caption: function (card) {
          var t = $('b', card), g = $('small', card);
          return '<strong>' + esc(t ? t.textContent : '') + '</strong>' + (g ? '<span>' + esc(g.textContent) + '</span>' : '') +
            '<button type="button" class="cf-open" data-cf-open>مشاهده جزئیات ↗</button>';
        },
        onOpen: function (card) { card.click(); }
      });
    });
    /* ---------- نوار دسته‌بندی: نشانگر لغزنده + دسته‌ی فعال + حرکت جهت‌دار ---------- */
    var rail = $('.cat-rail', catalog);
    if (rail) {
      var chips = $$('.cat-chip', rail);
      var track = el('div', 'cat-track'); var ind = el('i', 'cat-ind'); ind.setAttribute('aria-hidden', 'true');
      chips.forEach(function (c) { track.appendChild(c); });
      track.insertBefore(ind, track.firstChild); rail.appendChild(track);
      var shelfChips = chips.filter(function (c) { return !c.classList.contains('cat-chip-main'); });
      var activeIdx = -1;

      function place(c, instant) {
        if (!c) { ind.style.opacity = 0; return; }
        ind.style.opacity = 1;
        if (instant) ind.style.transition = 'none';
        ind.style.width = c.offsetWidth + 'px';
        ind.style.transform = 'translate3d(' + c.offsetLeft + 'px,0,0)';
        if (instant) { void ind.offsetWidth; ind.style.transition = ''; }
        /* دسته‌ی فعال را در وسط نوار بیاور (بدون اسکرول صفحه) */
        var rr = rail.getBoundingClientRect(), cr = c.getBoundingClientRect();
        var delta = (cr.left + cr.width / 2) - (rr.left + rr.width / 2);
        if (Math.abs(delta) > 12) rail.scrollBy({ left: delta, behavior: reduce ? 'auto' : 'smooth' });
      }
      function activate(i, instant) {
        if (i === activeIdx) return;
        activeIdx = i;
        shelfChips.forEach(function (c, j) { c.classList.toggle('on', j === i); if (j === i) c.setAttribute('aria-current', 'true'); else c.removeAttribute('aria-current'); });
        place(shelfChips[i] || null, instant);
      }
      shelfChips.forEach(function (c, i) {
        c.addEventListener('click', function (e) {
          var target = doc.querySelector(c.getAttribute('href')); if (!target) return;
          e.preventDefault();
          var dir = i > activeIdx ? 1 : -1;
          swoosh(target, activeIdx < 0 ? 1 : dir);
          activate(i);
          var y = target.getBoundingClientRect().top + scrollY - 138;
          scrollTo({ top: y, behavior: reduce ? 'auto' : 'smooth' });
          history.replaceState(null, '', c.getAttribute('href'));
        });
      });
      function swoosh(sh, dir) {
        if (reduce) return;
        sh.classList.remove('sw-l', 'sw-r'); void sh.offsetWidth;
        sh.classList.add(dir > 0 ? 'sw-l' : 'sw-r'); /* ورود از سمت مخالف جهت حرکت */
        setTimeout(function () { sh.classList.remove('sw-l', 'sw-r'); }, 900);
      }

      /* تشخیص قفسه‌ی فعال هنگام اسکرول */
      var sp = 0;
      function spy() {
        sp = 0;
        var line = innerHeight * .38, best = -1, cr = catalog.getBoundingClientRect();
        if (cr.top > line + 120 || cr.bottom < line - 80) { rail.classList.remove('is-live'); return; }
        rail.classList.add('is-live');
        for (var i = 0; i < shelfChips.length; i++) {
          var t = doc.querySelector(shelfChips[i].getAttribute('href')); if (!t) continue;
          var r = t.getBoundingClientRect();
          if (r.top <= line) best = i;
        }
        if (best < 0) best = 0;
        activate(best);
      }
      addEventListener('scroll', function () { if (!sp) sp = raf(spy); }, { passive: true });
      addEventListener('resize', function () { place(shelfChips[activeIdx], true); });
      /* بازچینش پس از لود فونت */
      if (doc.fonts && doc.fonts.ready) doc.fonts.ready.then(function () { place(shelfChips[activeIdx], true); });
      activate(0, true); spy();
    }
  }

  /* بک‌گراند شفت + گالری تصاویر باکیفیت */
  function initShaftBg() {
    var host = doc.getElementById('lift-bg');
    var track = doc.getElementById('lift-bg-track');
    if (!host || !track) return;
    var floors = $$('.lift-floor', track);
    var hqSlides = $$('.lift-hq-slide', host);
    var N = Math.max(floors.length, hqSlides.length, 1);
    var lastFloor = -1, t = 0, hqIdx = -1;

    function ease(x) { return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; }

    function showHq(i) {
      if (!hqSlides.length) return;
      var next = ((i % hqSlides.length) + hqSlides.length) % hqSlides.length;
      if (next === hqIdx) return;
      hqIdx = next;
      hqSlides.forEach(function (s, k) { s.classList.toggle('is-on', k === hqIdx); });
    }

    function upd() {
      t = 0;
      var max = Math.max(doc.documentElement.scrollHeight - innerHeight, 1);
      var y = scrollY || 0;
      var p = clamp(y / max, 0, 1);
      var travel = ease(p) * Math.max(N - 1, 1);
      var idx = clamp(Math.round(travel), 0, Math.max(N - 1, 0));
      var offset = -(travel * innerHeight);
      track.style.transform = 'translate3d(0,' + offset.toFixed(2) + 'px,0)';

      /* هیرو: کابین اصلی؛ بعد از کمی اسکرول HQ کامل دیده و عوض می‌شود */
      host.classList.toggle('is-top', y < innerHeight * 0.45);
      host.classList.remove('is-hero');

      /* تعویض تصویر بک‌گراند بر اساس پیشرفت اسکرول (هر بخش یک اسلاید) */
      if (hqSlides.length) {
        var hqStart = innerHeight * 0.35;
        var hqProgress = clamp((y - hqStart) / Math.max(max - hqStart, 1), 0, 1);
        var hqTarget = Math.min(hqSlides.length - 1, Math.floor(hqProgress * hqSlides.length));
        showHq(hqTarget);
      }

      if (idx !== lastFloor) {
        lastFloor = idx;
        floors.forEach(function (f, i) { f.classList.toggle('is-on', i === idx); });
        host.setAttribute('data-floor', String(idx + 1));
      }
    }

    function schedule() { if (!t) t = raf(upd); }
    addEventListener('scroll', schedule, { passive: true });
    addEventListener('resize', schedule);
    upd();
  }

  function boot() { initLift(); initShelves(); initShaftBg(); }
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', boot); else boot();
})();

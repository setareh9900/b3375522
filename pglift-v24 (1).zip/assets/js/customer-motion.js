(function () {
  'use strict';
  var root = document.documentElement, body = document.body;
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || !body.classList.contains('customer-page')) return;
  var scene = document.querySelector('.customer-scene-img');
  var cards = [].slice.call(document.querySelectorAll('.product-card'));
  cards.forEach(function(card, i) { card.style.setProperty('--i', Math.min(i, 6)); });
  body.classList.add('motion-ready');
  var ticking = false;
  function update() { ticking = false; if (scene) scene.style.setProperty('--scene-y', Math.min(28, scrollY * .035).toFixed(1) + 'px'); }
  addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, {passive:true});
  update();
  if (matchMedia('(hover: hover) and (pointer: fine)').matches) {
    cards.forEach(function (card) {
      card.addEventListener('pointermove', function(e) {
        var r = card.getBoundingClientRect();
        card.style.setProperty('--ry', (((e.clientX-r.left)/r.width-.5)*6).toFixed(2)+'deg');
        card.style.setProperty('--rx', ((.5-(e.clientY-r.top)/r.height)*6).toFixed(2)+'deg');
      }, {passive:true});
      card.addEventListener('pointerleave', function() { card.style.setProperty('--rx','0deg'); card.style.setProperty('--ry','0deg'); });
    });
  }
})();

/* =========================================================================
   راهنمای طبقات سایت — آسانسور سه‌بعدی با مقصد واقعی
   هر طبقه به یک بخش سایت وصل است؛ با رسیدن، CTA فعال می‌شود.
   ========================================================================= */
(function () {
  'use strict';
  var host = document.getElementById('e3');
  if (!host || host.getAttribute('data-three') === '1') return;
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var lite = document.documentElement.getAttribute('data-perf') === 'lite';
  var FH = 110, N = 4, H = FH * N, W = 400, D = 200, CAR_H = 92;
  /* مقصد هر طبقه — لینک بخش واقعی سایت */
  var FLOORS = [
    { n: '۱', t: 'پذیرش و مشاوره', d: 'نیاز ساختمان را بگویید؛ مسیر مناسب نصب یا سرویس پیشنهاد می‌شود.', href: '#request', cta: 'ثبت درخواست', type: 'service' },
    { n: '۲', t: 'قطعات اصل', d: 'موتور، ریل، تابلو و درب را ببینید و جزئیات هر قطعه را باز کنید.', href: '#catalog', cta: 'رفتن به قطعات', type: '' },
    { n: '۳', t: 'سرویس فنی', d: 'تعمیر، نگهداری دوره‌ای و پاسخ اضطراری تیم فنی.', href: '#request', cta: 'درخواست سرویس', type: 'maintenance' },
    { n: '۴', t: 'انواع آسانسور', d: 'مدل‌ها، توضیح صوتی و جزئیات هر کابین.', href: '#types', cta: 'مشاهده انواع', type: '' }
  ];
  function el(tag, cls, html) { var n = document.createElement(tag); if (cls) n.className = cls; if (html != null) n.innerHTML = html; return n; }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function st(n, css) { n.style.cssText = css; return n; }

  /* ---------- ساخت صحنه ---------- */
  var stage = el('div', 'e3-stage'); stage.setAttribute('tabindex', '0'); stage.setAttribute('role', 'img');
  stage.setAttribute('aria-label', 'آسانسور راهنما. ارتفاع اشاره‌گر یا شاسی، طبقه را انتخاب می‌کند.');
  var fit = el('div', 'e3-fit'), world = el('div', 'e3-world');
  fit.appendChild(world); stage.appendChild(fit);

  function plane(cls, css) { var p = el('i', 'e3-p ' + cls); p.style.cssText = css; world.appendChild(p); return p; }
  plane('e3-back', 'left:0;top:0;width:' + W + 'px;height:' + H + 'px;transform:translateZ(-' + D / 2 + 'px)');
  plane('e3-wall', 'left:0;top:0;width:' + D + 'px;height:' + H + 'px;transform-origin:left center;transform:translateZ(' + D / 2 + 'px) rotateY(90deg)');
  plane('e3-wall', 'left:' + W + 'px;top:0;width:' + D + 'px;height:' + H + 'px;transform-origin:left center;transform:translateZ(' + D / 2 + 'px) rotateY(90deg)');
  for (var k = 0; k <= N; k++) plane('e3-slab', 'left:0;top:' + k * FH + 'px;width:300px;height:' + D + 'px;transform-origin:top center;transform:translateZ(-' + D / 2 + 'px) rotateX(90deg)');
  var rooms = [], doors = [];
  for (var i = 0; i < N; i++) {
    var f = N - 1 - i;
    var r = plane('e3-room', 'left:14px;top:' + (i * FH + 14) + 'px;width:272px;height:' + (FH - 28) + 'px;transform:translateZ(-' + (D / 2 - 1) + 'px)');
    r.innerHTML = '<em>طبقه</em><b>' + FLOORS[f].n + '</b><span>' + FLOORS[f].t + '</span>';
    rooms[f] = r;
    var dr = plane('e3-landing', 'left:318px;top:' + (i * FH + 10) + 'px;width:64px;height:' + (FH - 16) + 'px;transform:translateZ(-' + (D / 2 - 1) + 'px)');
    dr.innerHTML = '<i></i>';
    doors[f] = dr;
  }
  plane('e3-rail', 'left:310px;top:0;width:4px;height:' + H + 'px;transform:translateZ(-80px)');
  plane('e3-rail', 'left:386px;top:0;width:4px;height:' + H + 'px;transform:translateZ(-80px)');
  var cable = plane('e3-cable', 'left:349px;top:0;width:2px;height:' + H + 'px;transform-origin:top center;transform:scaleY(.1)');
  var cw = plane('e3-cw', 'left:372px;top:0;width:14px;height:56px;transform:translate3d(0,300px,-64px)');

  var car = el('div', 'e3-car'); car.style.cssText = 'left:315px;top:0;width:70px;height:' + CAR_H + 'px';
  function face(cls, css) { var p = el('i', 'e3-f ' + cls); p.style.cssText = css; car.appendChild(p); return p; }
  face('e3-cb', 'left:0;top:0;width:70px;height:' + CAR_H + 'px;transform:translateZ(-55px)');
  face('e3-cs', 'left:0;top:0;width:110px;height:' + CAR_H + 'px;transform-origin:left center;transform:translateZ(55px) rotateY(90deg)');
  face('e3-cs', 'left:70px;top:0;width:110px;height:' + CAR_H + 'px;transform-origin:left center;transform:translateZ(55px) rotateY(90deg)');
  face('e3-ct', 'left:0;top:0;width:70px;height:110px;transform-origin:top center;transform:translateZ(-55px) rotateX(90deg)');
  face('e3-cs', 'left:0;top:' + CAR_H + 'px;width:70px;height:110px;transform-origin:top center;transform:translateZ(-55px) rotateX(90deg)');
  var dl = face('e3-door', 'left:0;top:0;width:35px;height:' + CAR_H + 'px;transform-origin:left center;transform:translateZ(55px)');
  var drr = face('e3-door', 'left:35px;top:0;width:35px;height:' + CAR_H + 'px;transform-origin:right center;transform:translateZ(55px)');
  face('e3-jamb', 'left:-3px;top:-3px;width:76px;height:5px;transform:translateZ(56px)');
  face('e3-sign', 'left:22px;top:6px;width:26px;height:10px;transform:translateZ(57px)').innerHTML = '<s></s>';
  world.appendChild(car);
  world.appendChild(el('i', 'e3-shadow'));
  host.appendChild(stage);

  /* ---------- پنل کنار صحنه + CTA مقصد ---------- */
  var panel = el('div', 'e3-panel');
  panel.innerHTML =
    '<span class="e3-tag"><i></i>طبقه فعلی</span>' +
    '<h3 class="e3-title" id="e3-title"></h3>' +
    '<p class="e3-desc" id="e3-desc"></p>' +
    '<div class="e3-ui"><div class="e3-lcd" aria-live="polite"><span id="e3-arrow">■</span><b id="e3-num">1</b></div><div class="e3-btns" id="e3-btns"></div></div>' +
    '<a class="e3-go" id="e3-go" href="#request"><span id="e3-go-label">ورود به این بخش</span><em aria-hidden="true">←</em></a>' +
    '<p class="e3-hint">اشاره‌گر را بالا و پایین ببرید یا شاسی بزنید؛ بعد از باز شدن در، دکمه فعال می‌شود</p>';
  host.appendChild(panel);
  var btnWrap = panel.querySelector('#e3-btns'), btns = [];
  for (var b = N - 1; b >= 0; b--) (function (f) {
    var x = el('button', 'e3-btn', '<span>' + (f + 1) + '</span>'); x.type = 'button';
    x.setAttribute('aria-label', 'طبقه ' + FLOORS[f].n + ': ' + FLOORS[f].t);
    x.addEventListener('click', function () { setTarget(f); x.classList.remove('pr'); void x.offsetWidth; x.classList.add('pr'); });
    btns[f] = x; btnWrap.appendChild(x);
  })(b);
  var tTitle = panel.querySelector('#e3-title');
  var tDesc = panel.querySelector('#e3-desc');
  var tNum = panel.querySelector('#e3-num');
  var tArrow = panel.querySelector('#e3-arrow');
  var goBtn = panel.querySelector('#e3-go');
  var goLabel = panel.querySelector('#e3-go-label');

  function goToFloor(f) {
    var info = FLOORS[f];
    if (!info) return;
    if (info.type) {
      var radio = document.querySelector('input[name="request_type"][value="' + info.type + '"]');
      if (radio) { radio.checked = true; radio.dispatchEvent(new Event('change', { bubbles: true })); }
    }
    var target = document.querySelector(info.href);
    if (target) target.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    else location.hash = info.href;
  }
  goBtn.addEventListener('click', function (e) {
    e.preventDefault();
    goToFloor(shownFloor >= 0 ? shownFloor : Math.round(target));
  });

  function fitScale() { var s = stage.clientWidth / 520; fit.style.setProperty('--s', s.toFixed(4)); }
  fitScale(); if (window.ResizeObserver) new ResizeObserver(fitScale).observe(stage); else addEventListener('resize', fitScale);

  var pos = 0, vel = 0, target = 0, door = 1, wait = 0, ry = -18, rx = 8, ryT = -18, px = .5, shownFloor = -1, moving = false, arrived = false;
  var speed = Number(host.getAttribute('data-intensity')) || 1;
  function setTarget(f) { target = clamp(f, 0, N - 1); arrived = false; goBtn.classList.remove('ready'); }
  function show(f) {
    if (f === shownFloor) return; shownFloor = f;
    var info = FLOORS[f];
    tTitle.textContent = info.t;
    tDesc.textContent = info.d;
    goLabel.textContent = info.cta;
    goBtn.setAttribute('href', info.href);
    tTitle.classList.remove('in'); void tTitle.offsetWidth; tTitle.classList.add('in');
  }
  show(0);

  function render(t) {
    var y = (N - 1 - pos) * FH + (FH - 6 - CAR_H);
    car.style.transform = 'translate3d(0,' + y.toFixed(2) + 'px,0)';
    cable.style.transform = 'scaleY(' + (Math.max(0, y) / H).toFixed(4) + ')';
    cw.style.transform = 'translate3d(0,' + (354 - y).toFixed(2) + 'px,-64px)';
    var s = 1 - .9 * door;
    dl.style.transform = 'translateZ(55px) scaleX(' + s.toFixed(3) + ')';
    drr.style.transform = 'translateZ(55px) scaleX(' + s.toFixed(3) + ')';
    var near = Math.round(pos);
    for (var f = 0; f < N; f++) {
      var lit = Math.abs(pos - f) < .45;
      if (rooms[f]._l !== lit) { rooms[f]._l = lit; rooms[f].classList.toggle('on', lit); doors[f].classList.toggle('on', lit); btns[f].classList.toggle('here', lit && !moving); }
    }
    tNum.textContent = near + 1;
    tArrow.textContent = moving ? (vel > 0 ? '▲' : '▼') : '■';
    for (var q = 0; q < N; q++) btns[q].classList.toggle('call', moving && q === target);
    if (!moving) {
      show(near);
      if (door > 0.85 && !arrived) { arrived = true; goBtn.classList.add('ready'); }
    } else {
      goBtn.classList.remove('ready');
      arrived = false;
    }
    ry += (ryT - ry) * .06;
    var sway = reduce || lite ? 0 : Math.sin(t / 2400) * 1.1;
    world.style.transform = 'rotateX(' + rx + 'deg) rotateY(' + (ry + sway).toFixed(2) + 'deg)';
  }

  var last = 0, running = false, raf = 0;
  function frame(t) {
    var dt = Math.min(.05, (t - last) / 1000 || .016); last = t;
    var d = target - pos;
    if (reduce) { pos = target; vel = 0; door = 1; moving = false; }
    else {
      var settled = Math.abs(d) < .004 && Math.abs(vel) < .03;
      if (settled) { pos = target; vel = 0; moving = false; wait += dt; if (wait > .22) door = Math.min(1, door + dt * 2.2); }
      else {
        wait = 0;
        if (door > .02) { door = Math.max(0, door - dt * 3.4); moving = false; }
        else {
          moving = true;
          var smax = 2.5 * speed, want = clamp(d * 2.4, -smax, smax);
          vel += (want - vel) * Math.min(1, dt * 4.2); pos += vel * dt;
        }
      }
    }
    render(t);
    if (running) raf = requestAnimationFrame(frame);
  }
  function start() { if (running) return; running = true; last = performance.now(); raf = requestAnimationFrame(frame); }
  function stop() { running = false; cancelAnimationFrame(raf); }
  if ('IntersectionObserver' in window) new IntersectionObserver(function (en) { en[0].isIntersecting ? start() : stop(); }, { rootMargin: '80px' }).observe(stage); else start();
  render(0);
  goBtn.classList.add('ready');

  function pick(e) {
    var r = stage.getBoundingClientRect(), fy = clamp((e.clientY - r.top) / r.height, 0, .9999);
    setTarget(N - 1 - Math.floor(fy * N));
  }
  stage.addEventListener('pointermove', function (e) {
    var r = stage.getBoundingClientRect(); px = clamp((e.clientX - r.left) / r.width, 0, 1); ryT = -6 - (1 - px) * 24;
    if (e.pointerType === 'mouse') pick(e);
  });
  stage.addEventListener('pointerleave', function () { ryT = -18; });
  stage.addEventListener('pointerdown', function (e) { pick(e); });
  stage.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowUp') { e.preventDefault(); setTarget(Math.round(target) + 1); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); setTarget(Math.round(target) - 1); }
    else if (e.key === 'Enter') { e.preventDefault(); goToFloor(shownFloor >= 0 ? shownFloor : Math.round(target)); }
  });
})();

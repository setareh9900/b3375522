/* =========================================================================
   اسکرول روان و جذاب — فقط transform/opacity، بدون خواندن layout در حلقه‌ی اسکرول
   ۱) اسکرول نرم چرخ موس (فقط دسکتاپ؛ موبایل و lite همان اسکرول بومی روان)
   ۲) ریل طبقات سمت صفحه: کابین کوچک با اسکرول بالا و پایین می‌رود و طبقه‌ی فعلی را نشان می‌دهد
   ۳) کارت‌ها و عنوان‌ها هنگام ورود با عمق و مقیاس هم‌پای اسکرول جابه‌جا می‌شوند
   ========================================================================= */
(function () {
  'use strict';
  var html = document.documentElement;
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
  var clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
  var lite = function () { return html.getAttribute('data-perf') === 'lite'; };

  /* ---------- ۱) اسکرول نرم چرخ موس ---------- */
  if (fine && !reduce && !lite()) {
    var cur = scrollY, tgt = scrollY, raf = 0, selfY = -1, maxY = 1;
    var calcMax = function () { maxY = Math.max(0, html.scrollHeight - innerHeight); };
    calcMax(); addEventListener('resize', calcMax); addEventListener('load', calcMax);
    var skip = function (t) { return t && t.closest && t.closest('textarea,select,input[type="number"],.pano,.pm,.cp-dlg,[data-no-smooth],.drawer'); };
    addEventListener('wheel', function (e) {
      if (e.ctrlKey || e.defaultPrevented || Math.abs(e.deltaX) > Math.abs(e.deltaY) || skip(e.target)) return;
      if (document.body.style.overflow === 'hidden' || html.style.overflow === 'hidden') return;
      e.preventDefault();
      var d = e.deltaMode === 1 ? e.deltaY * 34 : e.deltaMode === 2 ? e.deltaY * innerHeight : e.deltaY;
      if (!raf) { cur = scrollY; tgt = scrollY; calcMax(); }
      tgt = clamp(tgt + d * 1.05, 0, maxY);
      if (!raf) raf = requestAnimationFrame(tick);
    }, { passive: false });
    var tick = function () {
      cur += (tgt - cur) * 0.115;
      if (Math.abs(tgt - cur) < 0.35) { cur = tgt; raf = 0; }
      selfY = cur; scrollTo({ top: cur, left: 0, behavior: 'instant' });
      if (raf) raf = requestAnimationFrame(tick);
    };
    /* اسکرول از منبع دیگر (کیبورد، لینک، اسکرول‌بار): همگام شو */
    addEventListener('scroll', function () {
      if (raf && Math.abs(scrollY - selfY) < 2) return;
      if (raf) { cancelAnimationFrame(raf); raf = 0; }
      cur = tgt = scrollY;
    }, { passive: true });
  }

  /* ---------- ۲) ریل طبقات ---------- */
  var defs = [['#hero', 'همکف'], ['#features', 'مزایا'], ['#shaft3d', 'راهنمای طبقات'], ['#catalog', 'قطعات'], ['#services', 'خدمات'], ['#types', 'انواع آسانسور'], ['#request', 'درخواست']];
  var secs = defs.map(function (d) { return { el: document.querySelector(d[0]), id: d[0], label: d[1], top: 0 }; }).filter(function (s) { return s.el; });
  var rail = null, car = null, dots = [], docH = 1, vh = innerHeight;
  if (secs.length > 2) {
    rail = document.createElement('nav'); rail.className = 'floor-rail'; rail.setAttribute('aria-label', 'طبقه‌های صفحه');
    rail.innerHTML = '<i class="fr-line"></i><i class="fr-fill"></i><b class="fr-car"></b>';
    car = rail.querySelector('.fr-car'); var fill = rail.querySelector('.fr-fill');
    secs.forEach(function (s, i) {
      var a = document.createElement('a'); a.className = 'fr-dot'; a.href = s.id; a.innerHTML = '<span>' + s.label + '</span>';
      a.setAttribute('aria-label', 'رفتن به ' + s.label); rail.appendChild(a); dots.push(a); s.a = a;
    });
    document.body.appendChild(rail);
  }
  function measure() {
    vh = innerHeight; docH = Math.max(1, html.scrollHeight - vh);
    secs.forEach(function (s) { s.top = s.el.getBoundingClientRect().top + scrollY; if (s.a) s.a.style.top = clamp(s.top / docH, 0, 1) * 100 + '%'; });
    items.forEach(function (it) { var r = it.el.getBoundingClientRect(); it.top = r.top + scrollY; it.h = r.height; });
    last = -1; schedule();
  }

  /* ---------- ۳) چینش هم‌پا با اسکرول ---------- */
  var items = [], sel = '.section-head, .grid-3 > *, .shelf, .panel, .cta-banner, .tx-panel .tx-fig';
  if (!reduce && !lite()) {
    [].forEach.call(document.querySelectorAll(sel), function (el, i) {
      var lag = el.matches('.section-head') ? 0 : ((i % 3) - 1) * 16;
      items.push({ el: el, top: 0, h: 1, lag: lag, head: el.matches('.section-head'), e: -1 });
      el.classList.add('flow-i'); if (items[items.length - 1].head) el.classList.add('flow-head');
    });
  }

  var raf2 = 0, last = -1;
  function frame() {
    raf2 = 0; var y = scrollY; if (y === last) return; last = y;
    if (rail) {
      var p = clamp(y / docH, 0, 1); car.style.top = (p * 100).toFixed(2) + '%';
      fill.style.transform = 'scaleY(' + p.toFixed(4) + ')';
      var act = 0; for (var i = 0; i < secs.length; i++) if (secs[i].top <= y + vh * 0.42) act = i;
      for (i = 0; i < dots.length; i++) { var on = i === act, past = secs[i].top <= y + vh * 0.42; if (on !== dots[i].classList.contains('on')) dots[i].classList.toggle('on', on); if (past !== dots[i].classList.contains('past')) dots[i].classList.toggle('past', past); }
      rail.classList.toggle('show', y > vh * 0.25);
    }
    for (var k = 0; k < items.length; k++) {
      var it = items[k], rel = it.top - y;
      if (rel > vh + 80 || rel + it.h < -80) continue;
      var e = clamp((vh * 0.98 - rel) / (vh * 0.55), 0, 1); e = e * e * (3 - 2 * e);
      if (Math.abs(e - it.e) < 0.004) continue; it.e = e;
      var st = it.el.style;
      if (it.head) { st.setProperty('--fy', ((1 - e) * 26).toFixed(1) + 'px'); }
      else { st.setProperty('--fy', ((1 - e) * (34 + it.lag)).toFixed(1) + 'px'); st.setProperty('--fs', (0.955 + 0.045 * e).toFixed(4)); }
    }
  }
  function schedule() { if (!raf2) raf2 = requestAnimationFrame(frame); }
  addEventListener('scroll', schedule, { passive: true });
  addEventListener('resize', measure);
  addEventListener('load', measure);
  if (window.ResizeObserver) { var t0 = 0; new ResizeObserver(function () { clearTimeout(t0); t0 = setTimeout(measure, 120); }).observe(document.body); }
  measure();
})();

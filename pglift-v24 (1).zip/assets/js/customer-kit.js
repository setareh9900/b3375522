(function(){
  var links=Array.from(document.querySelectorAll('.kit-nav a'));
  if(links.length&&'IntersectionObserver'in window){var observer=new IntersectionObserver(function(entries){entries.forEach(function(e){if(!e.isIntersecting)return;links.forEach(function(a){a.classList.toggle('active',a.getAttribute('href')==='#'+e.target.id);});});},{rootMargin:'-20% 0px -65%'});['overview','products','services','contracts','stories'].forEach(function(id){var el=document.getElementById(id);if(el)observer.observe(el);});links.forEach(function(a){a.addEventListener('click',function(){links.forEach(function(x){x.classList.remove('active');});a.classList.add('active');});});}
  var card=document.getElementById('kit-lift-card'),scene=document.getElementById('kit-lift-scene');
  if(!card||!scene||window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  var scheduled=false,current=0,target=0;
  function calculate(){var rect=card.getBoundingClientRect(),travel=window.innerHeight+rect.height;target=Math.max(0,Math.min(1,(window.innerHeight-rect.top)/travel));}
  function render(){current+=(target-current)*.16;var p=current;scene.style.setProperty('--lift-y',((.5-p)*62).toFixed(2)+'px');scene.style.setProperty('--lift-ry',(-18+p*36).toFixed(2)+'deg');scene.style.setProperty('--lift-rx',(10-p*20).toFixed(2)+'deg');scene.style.setProperty('--lift-scale',(.88+p*.2).toFixed(3));scene.style.setProperty('--shadow-scale',(1.22-p*.4).toFixed(3));scene.style.setProperty('--shadow-opacity',(.35+p*.35).toFixed(3));if(Math.abs(target-current)>.001)requestAnimationFrame(render);else scheduled=false;}
  function update(){calculate();if(!scheduled){scheduled=true;requestAnimationFrame(render);}}
  window.addEventListener('scroll',update,{passive:true});window.addEventListener('resize',update,{passive:true});update();
})();

(function(){
  var root=document.querySelector('.cabin-cinema');if(!root)return;
  var product=document.getElementById('cinema-product'),bar=document.getElementById('cinema-progress'),index=document.getElementById('cinema-index');
  var copies=[root.querySelector('.cinema-copy-a'),root.querySelector('.cinema-copy-b'),root.querySelector('.cinema-copy-c')];
  if(matchMedia('(prefers-reduced-motion: reduce)').matches){copies[0].style.opacity=1;return;}
  var queued=false,target=0,current=-1;
  function measure(){var r=root.getBoundingClientRect(),travel=Math.max(1,root.offsetHeight-innerHeight);target=Math.max(0,Math.min(1,-r.top/travel));}
  function clamp(v){return Math.max(0,Math.min(1,v));}
  function draw(){
    current+=(target-current)*.2;var p=current;
    product.style.setProperty('--cr',(-38+p*76).toFixed(2)+'deg');product.style.setProperty('--cx',(7-p*14).toFixed(2)+'deg');product.style.setProperty('--cy',((.5-p)*55).toFixed(1)+'px');product.style.setProperty('--cs',(.88+Math.sin(p*Math.PI)*.18).toFixed(3));bar.style.setProperty('--progress',p.toFixed(4));
    var centers=[.16,.52,.87];
    copies.forEach(function(el,i){var d=Math.abs(p-centers[i]),visible=clamp(1-d/.19),direction=p<centers[i]?1:-1;el.style.opacity=visible.toFixed(3);el.style.transform='translate3d(0,'+(direction*(1-visible)*45).toFixed(1)+'px,0)';});
    index.textContent='0'+(p<.34?1:p<.69?2:3)+' / 03';
    if(Math.abs(target-current)>.0005)requestAnimationFrame(draw);else queued=false;
  }
  function update(){measure();if(!queued){queued=true;requestAnimationFrame(draw);}}
  addEventListener('scroll',update,{passive:true});addEventListener('resize',update,{passive:true});update();
})();

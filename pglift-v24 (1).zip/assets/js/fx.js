(function(){'use strict';
var reduce=matchMedia('(prefers-reduced-motion: reduce)').matches,fine=matchMedia('(hover:hover) and (pointer:fine)').matches;
var weak=(navigator.hardwareConcurrency||8)<=4||(navigator.deviceMemory||8)<=3;
/* ۱) ظاهر شدن نرم عناوین و کارت‌ها هنگام اسکرول (Motion: whileInView) */
if(!reduce&&'IntersectionObserver' in window){
 var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('fx-on');io.unobserve(e.target)}})},{rootMargin:'0px 0px -8% 0px',threshold:.12});
 var sel='.section-head,.section .grid-3>*,.shelf .section-head,.panel';
 [].forEach.call(document.querySelectorAll(sel),function(el,i){
  if(el.closest('.gfx'))return;
  el.classList.add('fx-in');if(!weak&&!el.matches('.panel'))el.classList.add('fx-blur');
  el.style.setProperty('--d',(Math.min(i%4,3)*.08)+'s');io.observe(el)});
}
/* ۲) Spotlight دنبال‌کننده‌ی ماوس روی کارت‌ها (Aceternity: Card Spotlight) */
if(fine&&!reduce){
 [].forEach.call(document.querySelectorAll('.tilt,.panel,.gfx-card'),function(el){
  if(getComputedStyle(el).position==='static')return;
  el.classList.add('fx-spot');
  el.addEventListener('pointermove',function(e){var r=el.getBoundingClientRect();el.style.setProperty('--mx',(e.clientX-r.left)+'px');el.style.setProperty('--my',(e.clientY-r.top)+'px')},{passive:true});
 });
 /* ۳) دکمه‌ی مغناطیسی */
 [].forEach.call(document.querySelectorAll('.btn,.cta,[class*="btn-"]'),function(b){
  if(b.closest('.dock,.admin'))return;b.classList.add('fx-mag');
  b.addEventListener('pointermove',function(e){var r=b.getBoundingClientRect();b.style.transform='translate('+((e.clientX-r.left-r.width/2)*.12).toFixed(1)+'px,'+((e.clientY-r.top-r.height/2)*.18).toFixed(1)+'px)'},{passive:true});
  b.addEventListener('pointerleave',function(){b.style.transform=''});
 });
}
/* ۴) Border Beam فقط وقتی کارت معرفی روی صفحه است */
if(!reduce&&'IntersectionObserver' in window){
 var io2=new IntersectionObserver(function(es){es.forEach(function(e){e.target.classList.toggle('fx-live',e.isIntersecting)})});
 [].forEach.call(document.querySelectorAll('.gfx-card'),function(c){io2.observe(c)});
}
})();

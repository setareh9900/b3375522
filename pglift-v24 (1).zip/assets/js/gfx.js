/* بخش اول: کابین با اسکرول — چرخش، نشستن در ریل، صعود (فقط transform/opacity) */
(function(){'use strict';
var root=document.getElementById('hero');if(!root||!root.classList.contains('gfx'))return;
var html=document.documentElement,$=function(s){return root.querySelector(s)},all=function(s){return[].slice.call(root.querySelectorAll(s))};
var reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
if(reduce){root.classList.add('is-static');return;}
var pin=$('.gfx-pin'),cab=$('.gfx-cab'),cv=$('.gfx-cv'),ring=$('.gfx-ring'),ring2=$('.gfx-ring.r2'),rl=$('.gfx-rail.l'),rr=$('.gfx-rail.r'),bl=rl.firstElementChild,br=rr.firstElementChild,
 shadow=$('.gfx-shadow'),streaks=$('.gfx-streaks'),dark=$('.gfx-dark'),
 floor=$('.gfx-floor'),fnum=$('.gfx-floor b'),cards=all('.gfx-card'),bar=$('.gfx-bar i');
var clamp=function(v,a,b){return v<a?a:v>b?b:v},seg=function(v,a,b){return clamp((v-a)/(b-a),0,1)},sm=function(a,b,v){var t=seg(v,a,b);return t*t*(3-2*t)},lerp=function(a,b,t){return a+(b-a)*t};
var NF=89,imgs=[],ready=0,ctx=cv.getContext('2d'),dk='',lastT=0,top=0,range=1,W=1,H=1,cabH=1,P=160,tgt=0,cur=-1,raf=0,last={},prev=0,covered=null,lite=false;
var wins=[[-1,0,.24,.31],[.36,.43,.50,.56],[.58,.65,.77,.83],[.85,.91,2,3]];
var lockAt=.535,lockDone=false;
function fa(n){return String(n).replace(/\d/g,function(d){return'۰۱۲۳۴۵۶۷۸۹'[d]})}
function set(el,k,v){if(last[k]!==v){last[k]=v;el.style.cssText&&0;return true}return false}
for(var n=0;n<NF;n++){(function(i){var im=new Image();im.decoding='async';im.onload=function(){imgs[i]=im;if(++ready===NF){cab.classList.add('cv');last.dk='';render(cur)}};im.src='assets/img/gfx2/c'+(i<10?'00':i<100?'0':'')+i+'.webp'})(n)}
function draw(u){if(ready<NF)return;var x=u*(NF-1),i=Math.min(Math.floor(x),NF-2),f=Math.round((x-i)*16)/16,k=i+':'+f;if(k===last.dk)return;last.dk=k;
 /* یک چرخش پیوسته: فریم‌های ویدیو + ترکیب نرم دو فریم مجاور (بدون پرش بین فریم‌ها) */
 var w=cv.width,h=cv.height;ctx.globalCompositeOperation='source-over';ctx.clearRect(0,0,w,h);ctx.imageSmoothingQuality='high';
 ctx.globalAlpha=1;ctx.drawImage(imgs[f>=1?i+1:i],0,0,w,h);
 if(f>0&&f<1){ctx.globalAlpha=f;ctx.drawImage(imgs[i+1],0,0,w,h);ctx.globalAlpha=1}}
function measure(){var dpr=Math.min(devicePixelRatio||1,2);var cw=Math.min(Math.round(cab.offsetWidth*dpr),760),ch=Math.round(cw*1323/608);if(cw>0&&(cv.width!==cw||cv.height!==ch)){cv.width=cw;cv.height=ch;last.dk=''}var r=root.getBoundingClientRect();top=r.top+scrollY;range=Math.max(root.offsetHeight-innerHeight,1);W=pin.clientWidth;H=pin.clientHeight;cabH=cab.offsetHeight;P=Math.round(H*.17);root.style.setProperty('--P',P+'px');lite=html.getAttribute('data-perf')==='lite';target()}
function target(){tgt=clamp((scrollY-top)/range,0,1);var c=scrollY<=top+range+8;if(c!==covered){covered=c;html.classList.toggle('gfx-cover',c)}}
function render(p){
 /* چرخش فیلم‌گونه: شتاب نرم، کمی دولی و تاب */
 var ru=seg(p,.02,.40),u=ru*ru*ru*(ru*(ru*6-15)+10);draw(u);
 var sway=0,dolly=1;
 var rg=(1-sm(.37,.48,p))*sm(0,.05,p);ring.style.opacity=(rg*.9).toFixed(2);ring2.style.opacity=(rg*.7).toFixed(2);
 if(rg>0){var tr='translateX(-50%) perspective(900px) rotateX(74deg) rotate('+(u*360).toFixed(1)+'deg)';ring.style.transform=tr;ring2.style.transform='translateX(-50%) perspective(900px) rotateX(74deg) rotate('+(-u*240).toFixed(1)+'deg)'}
 /* کابین */
 var dock=sm(.41,.54,p),q=seg(p,.54,.92),ex=seg(p,.92,1),sp=sm(.54,.62,p)*(1-ex);
 var cy=H*.11*dock-H*.27*Math.pow(q,1.35)-(H*.62+cabH*.6)*ex*ex;
 var s=lerp(.93,1,sm(0,.06,p))*lerp(1,.9,dock)*dolly;
 var sh=sway+((!lite&&sp>0)?Math.sin(p*900)*1.6*sp:0);
 var tf='translate3d(-50%,-50%,0) translate3d('+sh.toFixed(1)+'px,'+cy.toFixed(1)+'px,0)  scale('+s.toFixed(3)+')';
 if(last.cab!==tf){last.cab=tf;cab.style.transform=tf}
 shadow.style.opacity=(1-sm(.38,.5,p)).toFixed(3);
 /* ریل‌ها */
 var rs=sm(.43,.54,p),off=((Math.pow(q,1.6)*14*P+ex*10*P)%P);
 var o=rs.toFixed(3);if(last.rs!==o){last.rs=o;rl.style.opacity=o;rr.style.opacity=o}
 var tl='translate3d('+(-(1-rs)*70).toFixed(1)+'px,0,0)',tr='translate3d('+((1-rs)*70).toFixed(1)+'px,0,0)';
 rl.style.transform=tl;rr.style.transform=tr;
 var by='translate3d(0,'+(off-P).toFixed(1)+'px,0)';bl.style.transform=by;br.style.transform=by;
 /* سرعت */
 var spd=ex>0||q>0?sm(.55,.7,p)*(.4+.6*q):0;spd=Math.max(spd,ex);
 streaks.style.opacity=(spd*.9).toFixed(2);pin.classList.toggle('fast',spd>.05);
 /* طبقه */
 var fo=sm(.52,.58,p)*(1-sm(.9,.95,p));floor.style.opacity=fo.toFixed(2);
 var n=fa(1+Math.floor(q*23+ex*6));if(last.fn!==n){last.fn=n;fnum.textContent=n}
 dark.style.opacity=sm(.86,.99,p).toFixed(3);
 bar.style.transform='scaleX('+p.toFixed(4)+')';
 /* متن‌ها */
 for(var c=0;c<4;c++){var W4=wins[c],vin=sm(W4[0],W4[1],p),vout=sm(W4[2],W4[3],p),v=vin*(1-vout),el=cards[c];
  var ov=v.toFixed(3);if(last['c'+c]!==ov){last['c'+c]=ov;el.style.opacity=ov;el.style.visibility=v<.01?'hidden':'visible';el.style.transform='translate3d(0,'+((1-vin)*40-vout*30).toFixed(1)+'px,0)';el.classList.toggle('on',v>.5)}}
 /* قفل در ریل */
 if(p>=lockAt&&!lockDone){lockDone=true;cab.classList.remove('lock');void cab.offsetWidth;cab.classList.add('lock')}else if(p<lockAt-.02)lockDone=false;
 prev=p}
function loop(t){raf=0;var dt=lastT?Math.min((t-lastT)/1000,.05):.016;lastT=t;cur+=(tgt-cur)*(1-Math.exp(-dt*9));if(Math.abs(tgt-cur)<.0004)cur=tgt;render(cur);if(cur!==tgt)raf=requestAnimationFrame(loop);else lastT=0}
function kick(){target();if(!raf)raf=requestAnimationFrame(loop)}
addEventListener('scroll',kick,{passive:true});
addEventListener('resize',function(){measure();kick()});
addEventListener('load',function(){measure();kick()});
if(window.ResizeObserver)new ResizeObserver(function(){measure();kick()}).observe(document.body);
measure();cur=tgt;prev=tgt;render(cur);
})();

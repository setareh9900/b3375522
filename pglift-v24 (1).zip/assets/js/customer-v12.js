/* پنل مشتریان v12: جستجوی فارسی‌فهم، فیلتر، مرتب‌سازی، وضعیت هوشمند ضمانت، پنجره‌ی جزئیات، قفسه‌ی متحرک */
(function () {
  'use strict';
  var d = document, reduce = matchMedia('(prefers-reduced-motion: reduce)').matches, lite = d.documentElement.getAttribute('data-perf') === 'lite';
  var $ = function (s, c) { return (c || d).querySelector(s); }, $$ = function (s, c) { return [].slice.call((c || d).querySelectorAll(s)); };
  var raf = requestAnimationFrame.bind(window);
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function norm(s) {
    return String(s || '').replace(/[۰-۹]/g, function (c) { return c.charCodeAt(0) - 1776; }).replace(/[٠-٩]/g, function (c) { return c.charCodeAt(0) - 1632; })
      .replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/[\u200c\u200f\u200e]/g, ' ').replace(/\s+/g, ' ').toLowerCase().trim();
  }
  function fa(n) { return String(n).replace(/\d/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'[c]; }); }
  var toastT;
  function toast(t) { var e = $('#toast'); if (!e) return; e.textContent = t; e.hidden = false; clearTimeout(toastT); toastT = setTimeout(function () { e.hidden = true; }, 2200); }

  /* ----- شنیدن مشخصات آسانسور (فایل ادمین یا گفتار مرورگر) ----- */
  (function initElevatorListen() {
    var host = $('#cp-listen-host');
    var btn = $('#cp-listen');
    if (!host || !btn) return;
    var synth = window.speechSynthesis || null;
    var voice = null;
    var playing = false;
    var audio = null;
    var label = btn.querySelector('.cp-listen-label');
    var canTts = !!synth && typeof SpeechSynthesisUtterance !== 'undefined';

    function pickVoice() {
      if (!synth) return;
      var v = synth.getVoices() || [];
      voice = null;
      for (var i = 0; i < v.length; i++) if (/^fa/i.test(v[i].lang)) { voice = v[i]; break; }
      if (!voice) {
        for (var j = 0; j < v.length; j++) if (/persian|farsi|iran/i.test(v[j].name || '')) { voice = v[j]; break; }
      }
    }
    function updateBtn() {
      var hasAudio = !!(host.getAttribute('data-audio') || '').trim();
      var hasSpeech = !!(host.getAttribute('data-speech') || '').trim();
      /* دکمه همیشه دیده شود اگر صوت یا متن مشخصات باشد */
      btn.hidden = !(hasAudio || (hasSpeech && canTts));
    }
    function setPlaying(on) {
      playing = on;
      btn.classList.toggle('playing', on);
      if (label) label.textContent = on ? 'توقف' : 'شنیدن مشخصات';
    }
    function stop() {
      playing = false;
      if (audio) { try { audio.pause(); audio.currentTime = 0; } catch (e) { /* ignore */ } }
      if (synth) { try { synth.cancel(); } catch (e) { /* ignore */ } }
      setPlaying(false);
    }
    function speak() {
      var text = (host.getAttribute('data-speech') || '').trim();
      if (!text || !canTts) { stop(); toast('متنی برای خواندن ثبت نشده است'); return; }
      var chunks = text.replace(/([.!؟?۔])\s+/g, '$1|').split('|').filter(Boolean);
      if (!chunks.length) chunks = [text];
      synth.cancel();
      var left = chunks.length;
      chunks.forEach(function (c) {
        var u = new SpeechSynthesisUtterance(c);
        u.lang = (voice && voice.lang) || 'fa-IR';
        if (voice) u.voice = voice;
        u.rate = 0.95;
        u.onend = function () { if (--left <= 0 && playing) stop(); };
        u.onerror = function () { if (playing) stop(); };
        synth.speak(u);
      });
    }
    function start() {
      var src = (host.getAttribute('data-audio') || '').trim();
      setPlaying(true);
      if (src) {
        if (!audio || audio.src.indexOf(src) < 0) {
          audio = new Audio(src);
          audio.preload = 'auto';
          audio.addEventListener('ended', function () { if (playing) stop(); });
          audio.addEventListener('error', function () {
            if (!playing) return;
            audio = null;
            stop(); toast('پخش فایل صوتی ممکن نیست؛ از مدیر بخواهید فایل را بررسی کند');
          });
        }
        audio.currentTime = 0;
        var p = audio.play();
        if (p && p.catch) p.catch(function () { if (playing) { stop(); toast('پخش صوت ممکن نیست؛ دوباره تلاش کنید'); } });
      } else if (canTts) {
        speak();
      } else {
        stop();
        toast('مرورگر از خواندن پشتیبانی نمی‌کند');
      }
    }
    btn.addEventListener('click', function () { playing ? stop() : start(); });
    pickVoice();
    updateBtn();
    if (synth) {
      if (typeof synth.addEventListener === 'function') synth.addEventListener('voiceschanged', function () { pickVoice(); updateBtn(); });
      else synth.onvoiceschanged = function () { pickVoice(); updateBtn(); };
    }
    /* اگر voices دیر لود شوند، یک بار دیگر بعد از کوتاهی چک کن */
    setTimeout(function () { pickVoice(); updateBtn(); }, 400);
  })();

  /* ----- ورود ----- */
  var pw = $('#pw');
  if (pw) {
    var eye = $('#pw-eye'), caps = $('#caps');
    eye.addEventListener('click', function () { var s = pw.type === 'password'; pw.type = s ? 'text' : 'password'; eye.textContent = s ? 'پنهان' : 'نمایش'; eye.setAttribute('aria-pressed', s); });
    pw.addEventListener('keyup', function (e) { if (e.getModifierState) caps.hidden = !e.getModifierState('CapsLock'); });
    pw.addEventListener('blur', function () { caps.hidden = true; });
    $('#login-form').addEventListener('submit', function () { var b = $('#login-btn'); b.classList.add('busy'); b.firstElementChild.textContent = 'در حال ورود…'; });
  }

  /* ----- حرکت با موس: شفت کابین + کارت‌ها ----- */
  (function initMouseMotion() {
    if (reduce || lite) return;
    if (!matchMedia('(hover: hover) and (pointer: fine)').matches) return;
    var cab = $('.cp-shaft-cab');
    var tilts = $$('[data-tilt]');
    var cx = 0, cy = 0, tx = 0, ty = 0, ticking = false;
    function frame() {
      ticking = false;
      cx += (tx - cx) * 0.1; cy += (ty - cy) * 0.1;
      if (cab) cab.style.transform = 'translate(-50%,-48%) translate3d(' + (cx * 18).toFixed(1) + 'px,' + (cy * 12).toFixed(1) + 'px,0) rotateY(' + (cx * -6).toFixed(2) + 'deg) rotateX(' + (cy * 5).toFixed(2) + 'deg)';
      if (Math.abs(tx - cx) > 0.002 || Math.abs(ty - cy) > 0.002) { ticking = true; raf(frame); }
    }
    addEventListener('pointermove', function (e) {
      tx = (e.clientX / Math.max(innerWidth, 1) - 0.5) * 2;
      ty = (e.clientY / Math.max(innerHeight, 1) - 0.5) * 2;
      if (!ticking) { ticking = true; raf(frame); }
    }, { passive: true });
    tilts.forEach(function (el) {
      el.addEventListener('pointermove', function (e) {
        var r = el.getBoundingClientRect();
        var rx = ((0.5 - (e.clientY - r.top) / r.height) * 8).toFixed(2);
        var ry = ((((e.clientX - r.left) / r.width) - 0.5) * 10).toFixed(2);
        el.style.transform = 'perspective(900px) rotateX(' + rx + 'deg) rotateY(' + ry + 'deg)';
      }, { passive: true });
      el.addEventListener('pointerleave', function () { el.style.transform = ''; });
    });
  })();

  var list = $('#part-list'); if (!list) return;

  /* ----- سلام بر اساس ساعت ----- */
  var g = $('#greet'); if (g) { var h = new Date().getHours(); g.textContent = h < 5 ? 'شب بخیر' : h < 12 ? 'صبح بخیر' : h < 17 ? 'ظهر بخیر' : h < 20 ? 'عصر بخیر' : 'شب بخیر'; }

  /* ----- شمارش آمار ----- */
  if (!reduce) $$('[data-count]').forEach(function (n) {
    var to = Number(n.getAttribute('data-count')) || 0; if (!to) return; var t0 = performance.now();
    (function step(t) { var p = clamp((t - t0) / 900, 0, 1); n.textContent = Math.round(to * (1 - Math.pow(1 - p, 3))); if (p < 1) raf(step); })(t0);
  });

  /* ----- داده‌ها ----- */
  var data = {}; try { JSON.parse($('#parts-json').textContent).forEach(function (p) { data[p.id] = p; }); } catch (e) { }
  var cards = $$('.pc', list), order = cards.slice();

  /* ----- وضعیت هوشمند ضمانت (شمسی/میلادی) ----- */
  function j2g(jy, jm, jd) {
    jy += 1595; var days = -355668 + 365 * jy + Math.floor(jy / 33) * 8 + Math.floor((jy % 33 + 3) / 4) + jd + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
    var gy = 400 * Math.floor(days / 146097); days %= 146097;
    if (days > 36524) { gy += 100 * Math.floor(--days / 36524); days %= 36524; if (days >= 365) days++; }
    gy += 4 * Math.floor(days / 1461); days %= 1461;
    if (days > 365) { gy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    var gd = days + 1, sal = [0, 31, (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], gm;
    for (gm = 0; gm < 13 && gd > sal[gm]; gm++) gd -= sal[gm];
    return [gy, gm, gd];
  }
  function warranty(p) {
    var i = norm(p.installed).match(/(\d{4})\s*[\/\-.]\s*(\d{1,2})\s*[\/\-.]\s*(\d{1,2})/), w = norm(p.warranty).match(/(\d+)\s*(ماه|سال|month|year)/);
    if (!i || !w) return null;
    var y = +i[1], m = +i[2], dd = +i[3]; if (m < 1 || m > 12 || dd < 1 || dd > 31) return null;
    var s = y < 1700 ? j2g(y, m, dd) : [y, m, dd], start = new Date(s[0], s[1] - 1, s[2]);
    var months = +w[1] * (w[2] === 'سال' || w[2] === 'year' ? 12 : 1), end = new Date(start); end.setMonth(end.getMonth() + months);
    var left = Math.round((end - new Date()) / 864e5);
    if (left < 0) return { c: 'end', t: 'ضمانت پایان یافته', long: 'ضمانت این قطعه به پایان رسیده است' };
    if (left <= 90) return { c: 'soon', t: 'ضمانت: ' + fa(left) + ' روز مانده', long: 'ضمانت تا حدود ' + fa(left) + ' روز دیگر معتبر است' };
    var mo = Math.round(left / 30); return { c: 'ok', t: 'ضمانت: ' + fa(mo) + ' ماه مانده', long: 'ضمانت تا حدود ' + fa(mo) + ' ماه دیگر معتبر است' };
  }
  cards.forEach(function (c) {
    var p = data[c.getAttribute('data-id')], st = p && warranty(p), el = $('[data-status]', c);
    if (st && el) { el.textContent = st.t; el.className = 'pc-status ' + st.c; el.hidden = false; p.st = st; }
    c._idx = norm(c.getAttribute('data-search'));
  });

  /* ----- جستجو / فیلتر / مرتب‌سازی ----- */
  var q = $('#part-search'), f = 'all', sortEl = $('#sort'), count = $('#count'), none = $('#no-results');
  function apply() {
    var terms = norm(q.value).split(' ').filter(Boolean), shown = 0;
    cards.forEach(function (c) {
      var ok = terms.every(function (t) { return c._idx.indexOf(t) > -1; });
      if (ok && f === 'image') ok = c.getAttribute('data-image') === '1';
      else if (ok && f === 'warranty') ok = c.getAttribute('data-warranty') === '1';
      else if (ok && f.indexOf('brand:') === 0) ok = c.getAttribute('data-brand') === f.slice(6);
      c.hidden = !ok; if (ok) shown++;
    });
    count.textContent = shown === cards.length ? fa(cards.length) + ' قطعه' : fa(shown) + ' مورد از ' + fa(cards.length) + ' قطعه';
    none.hidden = shown > 0; if (cf) cf.refresh();
  }
  function sort() {
    var v = sortEl.value, arr = order.slice();
    if (v === 'name') arr.sort(function (a, b) { return $('.pc-name', a).textContent.localeCompare($('.pc-name', b).textContent, 'fa'); });
    if (v === 'brand') arr.sort(function (a, b) { return (a.getAttribute('data-brand') || '\uffff').localeCompare(b.getAttribute('data-brand') || '\uffff', 'fa'); });
    var host = (viewMode === 'cover' && $('.cf-stage', list)) ? $('.cf-stage', list) : list;
    arr.forEach(function (c) { host.appendChild(c); }); cards = $$('.pc', list); apply();
  }
  q.addEventListener('input', apply); sortEl.addEventListener('change', sort);
  $('#chips').addEventListener('click', function (e) {
    var b = e.target.closest('.chip'); if (!b) return;
    $$('.chip').forEach(function (x) { x.classList.toggle('on', x === b); x.setAttribute('aria-pressed', x === b); });
    f = b.getAttribute('data-f'); apply();
  });
  d.addEventListener('keydown', function (e) { if (e.key === '/' && !/INPUT|SELECT|TEXTAREA/.test(d.activeElement.tagName) && $('#dlg').hidden) { e.preventDefault(); q.focus(); } });

  /* ----- نمای کاتالوگ: شبکه / لیست / سه‌بعدی ----- */
  function capHtml(c) {
    var n = $('.pc-name', c), b = $('.pc-brand', c), m = $$('.pc-meta b', c), st = $('[data-status]', c);
    return '<strong>' + esc(n ? n.textContent : '') + '</strong><span>' + esc(b ? b.textContent : '') + '</span>' +
      '<dl><div><dt>تعداد</dt><dd>' + esc(m[0] ? m[0].textContent : '—') + '</dd></div><div><dt>تاریخ نصب</dt><dd>' + esc(m[1] ? m[1].textContent : '—') + '</dd></div></dl>' +
      (st && !st.hidden ? '<span class="cf-st ' + st.className.replace('pc-status ', '') + '">' + esc(st.textContent) + '</span>' : '') +
      '<button type="button" class="cf-open" data-cf-open>مشاهده جزئیات ↗</button>';
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var shelf = $('#catalog-shelf') || list.parentElement;
  var cf = null, stage = list, viewMode = 'grid';
  function setView(mode) {
    viewMode = mode;
    ['grid', 'list', 'cover'].forEach(function (m) {
      var btn = $('#view-' + m); if (btn) { btn.classList.toggle('on', m === mode); btn.setAttribute('aria-pressed', m === mode); }
      if (shelf) shelf.classList.toggle('is-' + m, m === mode);
    });
    if (mode === 'cover' && !cf && window.GFCoverflow) {
      cf = GFCoverflow.mount(list, { caption: capHtml, onOpen: function (c) { var b = $('.pc-open', c); if (b) b.click(); } });
      stage = $('.cf-stage', list) || list;
    }
    if (cf && cf.refresh) cf.refresh();
    apply();
  }
  var vg = $('#view-grid'), vl = $('#view-list'), vc = $('#view-cover');
  if (vg) vg.addEventListener('click', function () { setView('grid'); });
  if (vl) vl.addEventListener('click', function () { setView('list'); });
  if (vc) vc.addEventListener('click', function () { setView('cover'); });
  /* پیش‌فرض: شبکه (بدون coverflow تا چاپ خراب نشود) */
  if (shelf) shelf.classList.add('is-grid');

  /* ----- پنجره‌ی جزئیات ----- */
  var dlg = $('#dlg'), cur = null, lastBtn = null;
  function visible() { return cards.filter(function (c) { return !c.hidden; }); }
  function show(id) {
    var p = data[id]; if (!p) return; cur = id;
    $('#dlg-title').textContent = p.name;
    $('#dlg-brand').textContent = [p.brand, p.model].filter(Boolean).join(' · ') || 'برند ثبت نشده';
    $('#dlg-spec').textContent = p.spec || 'مشخصاتی ثبت نشده است.';
    var im = $('#dlg-img'); im.innerHTML = ''; if (p.img) { var x = new Image(); x.src = p.img; x.alt = p.name; im.appendChild(x); } else im.textContent = 'تصویر ثبت نشده';
    var rows = [['تعداد', p.qty], ['شماره سریال', p.serial], ['تاریخ نصب', p.installed], ['گارانتی', p.warranty]];
    $('#dlg-dl').innerHTML = rows.map(function (r) { return '<div><dt>' + r[0] + '</dt><dd></dd></div>'; }).join('');
    $$('#dlg-dl dd').forEach(function (n, i) { n.textContent = rows[i][1] || 'ثبت نشده'; });
    var st = $('#dlg-status'); st.hidden = !p.st; if (p.st) st.textContent = p.st.long;
    $('#dlg-copy').hidden = !p.serial;
    var v = visible(), i = v.findIndex(function (c) { return c.getAttribute('data-id') == id; });
    $('#dlg-pos').textContent = fa(i + 1) + ' از ' + fa(v.length);
    history.replaceState(null, '', '#part-' + id);
  }
  function open(id, btn) { lastBtn = btn; show(id); dlg.hidden = false; d.body.classList.add('no-scroll'); $('#dlg-x').focus(); }
  function close() { dlg.hidden = true; d.body.classList.remove('no-scroll'); history.replaceState(null, '', location.pathname + location.search); if (lastBtn) lastBtn.focus(); }
  function step(n) { var v = visible(), i = v.findIndex(function (c) { return c.getAttribute('data-id') == cur; }); if (!v.length) return; show(v[(i + n + v.length) % v.length].getAttribute('data-id')); }
  list.addEventListener('click', function (e) { var b = e.target.closest('[data-open]'); if (b) open(b.getAttribute('data-open'), b); });
  $('#dlg-x').addEventListener('click', close);
  dlg.addEventListener('click', function (e) { if (e.target === dlg) close(); });
  $('#dlg-prev').addEventListener('click', function () { step(-1); }); $('#dlg-next').addEventListener('click', function () { step(1); });
  d.addEventListener('keydown', function (e) {
    if (dlg.hidden) return;
    if (e.key === 'Escape') close(); else if (e.key === 'ArrowLeft') step(1); else if (e.key === 'ArrowRight') step(-1);
  });
  function text(p) {
    return [p.name, [p.brand, p.model].filter(Boolean).join(' - '), p.serial && 'سریال: ' + p.serial, p.installed && 'تاریخ نصب: ' + p.installed, p.warranty && 'گارانتی: ' + p.warranty].filter(Boolean).join('\n');
  }
  function copy(t, ok) { (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(function () { toast(ok); }, function () { var a = d.createElement('textarea'); a.value = t; d.body.appendChild(a); a.select(); try { d.execCommand('copy'); toast(ok); } catch (e) { } a.remove(); }); }
  $('#dlg-copy').addEventListener('click', function () { copy(data[cur].serial, 'شماره سریال کپی شد'); });
  $('#dlg-share').addEventListener('click', function () {
    var p = data[cur], t = text(p);
    if (navigator.share) navigator.share({ title: p.name, text: t }).catch(function () { }); else copy(t, 'مشخصات کپی شد؛ هر جا بخواهید بفرستید');
  });
  var call = $('#dlg-call'); if (call) call.addEventListener('click', function () { copy(text(data[cur]), 'مشخصات قطعه کپی شد تا هنگام تماس بگویید'); });

  /* لینک مستقیم به یک قطعه */
  var m = location.hash.match(/^#part-(\d+)$/); if (m && data[m[1]]) open(m[1]);

  /* ----- چاپ کاتالوگ / فاکتور ----- */
  function printCatalog() { window.location.href = 'catalog-print.php'; }
  function printInvoice() {
    var sheet = $('#invoice-sheet');
    if (sheet) { sheet.hidden = false; sheet.setAttribute('aria-hidden', 'false'); }
    d.body.classList.remove('print-catalog');
    d.body.classList.add('print-invoice');
    setTimeout(function () { window.print(); }, 80);
  }
  function afterPrint() {
    d.body.classList.remove('print-catalog', 'print-invoice');
    var sheet = $('#invoice-sheet');
    if (sheet) { sheet.hidden = true; sheet.setAttribute('aria-hidden', 'true'); }
  }
  addEventListener('afterprint', afterPrint);
  var b1 = $('#btn-print-cat'); if (b1) b1.addEventListener('click', printCatalog);
  var b2 = $('#btn-invoice'); if (b2) b2.addEventListener('click', printInvoice);
  var b3 = $('#btn-invoice-2'); if (b3) b3.addEventListener('click', printInvoice);
  apply();
})();

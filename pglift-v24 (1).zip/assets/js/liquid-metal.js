/* Liquid Metal Button — پورت پایدار از کامپوننت React (بدون WebGL)
   در هر عرضی درست کار می‌کند؛ شیدر با گرادیان CSS متحرک شبیه‌سازی می‌شود. */
(function () {
  'use strict';
  if (document.documentElement.getAttribute('data-perf') === 'lite') return;

  var STYLE_ID = 'lm-v2-style';
  if (!document.getElementById(STYLE_ID)) {
    var st = document.createElement('style');
    st.id = STYLE_ID;
    st.textContent =
      '@keyframes lmRipple{0%{transform:translate(-50%,-50%) scale(0);opacity:.55}100%{transform:translate(-50%,-50%) scale(4);opacity:0}}' +
      '@keyframes lmFlow{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}' +
      '.lm-v2{position:relative;display:inline-block;vertical-align:middle;perspective:1000px;perspective-origin:50% 50%;flex:0 0 auto;max-width:100%}' +
      '.lm-v2-scene{position:relative;height:46px;width:var(--lm-w,142px);max-width:100%;transform-style:preserve-3d}' +
      '.lm-v2-label{position:absolute;inset:0;z-index:30;display:flex;align-items:center;justify-content:center;gap:6px;' +
      'transform:translateZ(20px);pointer-events:none;padding:0 14px;box-sizing:border-box}' +
      '.lm-v2-label span{font-size:14px;font-weight:700;color:#cfcfcf;text-shadow:0 1px 2px rgba(0,0,0,.55);white-space:nowrap;' +
      'overflow:hidden;text-overflow:ellipsis;max-width:100%;font-family:inherit}' +
      '.lm-v2-inner,.lm-v2-shell{position:absolute;inset:0;transform-style:preserve-3d;transition:transform .15s cubic-bezier(.4,0,.2,1),box-shadow .15s}' +
      '.lm-v2-inner{z-index:20;transform:translateZ(10px)}.lm-v2-shell{z-index:10;transform:translateZ(0)}' +
      '.lm-v2-inner>i{display:block;position:absolute;inset:2px;border-radius:100px;background:linear-gradient(180deg,#202020,#000);pointer-events:none}' +
      '.lm-v2-metal{position:absolute;inset:0;border-radius:100px;overflow:hidden;' +
      'background:linear-gradient(120deg,#3a3a3a 0%,#9a9a9a 18%,#efefef 34%,#6e6e6e 48%,#cfcfcf 62%,#4a4a4a 78%,#b8b8b8 100%);' +
      'background-size:280% 280%;animation:lmFlow 7s ease-in-out infinite;box-shadow:0 0 0 1px rgba(0,0,0,.35),0 18px 28px -14px rgba(0,0,0,.55)}' +
      '.lm-v2-metal::after{content:"";position:absolute;inset:0;border-radius:inherit;' +
      'background:linear-gradient(180deg,rgba(255,255,255,.28),transparent 42%,rgba(0,0,0,.35));pointer-events:none}' +
      '.lm-v2.is-hover .lm-v2-metal{animation-duration:3.2s;box-shadow:0 0 0 1px rgba(0,0,0,.4),0 12px 18px -10px rgba(0,0,0,.45)}' +
      '.lm-v2.is-press .lm-v2-inner,.lm-v2.is-press .lm-v2-shell{transform:translateZ(10px) translateY(1px) scale(.98)}' +
      '.lm-v2.is-press .lm-v2-shell{transform:translateZ(0) translateY(1px) scale(.98)}' +
      '.lm-v2.is-press .lm-v2-inner>i{box-shadow:inset 0 2px 4px rgba(0,0,0,.4)}' +
      '.lm-v2-hit{position:absolute;inset:0;z-index:40;border:0;border-radius:100px;background:transparent;cursor:pointer;padding:0;' +
      'transform:translateZ(25px);overflow:hidden;font:inherit;color:inherit}' +
      '.lm-v2-hit:focus-visible{outline:2px solid rgba(224,138,79,.85);outline-offset:3px}' +
      '.lm-v2-ripple{position:absolute;width:20px;height:20px;border-radius:50%;pointer-events:none;' +
      'background:radial-gradient(circle,rgba(255,255,255,.4) 0%,rgba(255,255,255,0) 70%);animation:lmRipple .6s ease-out forwards}' +
      '.liquid-metal-mount.lm-ready{display:inline-flex;max-width:100%}' +
      '.liquid-metal-form .lm-v2,.liquid-metal-wide .lm-v2{width:100%;max-width:min(100%,var(--lm-w,300px))}' +
      '.liquid-metal-form .lm-v2-scene,.liquid-metal-wide .lm-v2-scene{width:100%}' +
      '@media (prefers-reduced-motion:reduce){.lm-v2-metal{animation:none}}';
    document.head.appendChild(st);
  }

  function measureLabel(label, minW) {
    var probe = document.createElement('span');
    probe.style.cssText = 'position:absolute;visibility:hidden;white-space:nowrap;font:700 14px Vazirmatn,Tahoma,sans-serif;padding:0 28px';
    probe.textContent = label;
    document.body.appendChild(probe);
    var w = Math.ceil(probe.getBoundingClientRect().width);
    probe.remove();
    return Math.max(minW || 142, Math.min(420, w));
  }

  function mount(host) {
    if (!host || host.getAttribute('data-static') === '1' || host._lm) return;
    var label = host.getAttribute('data-label') || 'ادامه';
    var href = host.getAttribute('data-href');
    var target = host.getAttribute('data-target');
    var btnId = host.getAttribute('data-button-id');
    var type = host.getAttribute('data-type') === 'submit' ? 'submit' : 'button';
    var forced = parseInt(host.getAttribute('data-width') || '0', 10);
    var width = forced > 0 ? Math.min(420, Math.max(142, forced)) : measureLabel(label, 142);
    /* فرم‌های پهن: عرض کامل کانتینر تا سقف data-width — بدون کش آمدن شیدر */
    var fluid = host.classList.contains('liquid-metal-form') || host.classList.contains('liquid-metal-wide');

    var root = document.createElement('div');
    root.className = 'lm-v2';
    root.style.setProperty('--lm-w', width + 'px');
    root.innerHTML =
      '<div class="lm-v2-scene">' +
        '<div class="lm-v2-label"><span></span></div>' +
        '<div class="lm-v2-inner"><i></i></div>' +
        '<div class="lm-v2-shell"><div class="lm-v2-metal" aria-hidden="true"></div></div>' +
      '</div>';
    var labelEl = root.querySelector('.lm-v2-label span');
    labelEl.textContent = label;

    var hit;
    if (href) {
      hit = document.createElement('a');
      hit.href = href;
      if (target === '_blank') { hit.target = '_blank'; hit.rel = 'noopener noreferrer'; }
    } else {
      hit = document.createElement('button');
      hit.type = type;
    }
    hit.className = 'lm-v2-hit';
    hit.setAttribute('aria-label', label);
    if (btnId) hit.id = btnId;
    root.querySelector('.lm-v2-scene').appendChild(hit);

    hit.addEventListener('mouseenter', function () { root.classList.add('is-hover'); });
    hit.addEventListener('mouseleave', function () { root.classList.remove('is-hover', 'is-press'); });
    hit.addEventListener('mousedown', function () { root.classList.add('is-press'); });
    hit.addEventListener('mouseup', function () { root.classList.remove('is-press'); });
    hit.addEventListener('click', function (e) {
      var r = hit.getBoundingClientRect();
      var ripple = document.createElement('span');
      ripple.className = 'lm-v2-ripple';
      ripple.style.left = (e.clientX - r.left) + 'px';
      ripple.style.top = (e.clientY - r.top) + 'px';
      hit.appendChild(ripple);
      setTimeout(function () { ripple.remove(); }, 650);
    });

    /* همگام‌سازی لیبل از فرم (مثل باندل قبلی) */
    if (btnId) {
      hit.addEventListener('liquid-label', function (ev) {
        if (typeof ev.detail === 'string') {
          labelEl.textContent = ev.detail;
          hit.setAttribute('aria-label', ev.detail);
        }
      });
    }

    host.innerHTML = '';
    host.appendChild(root);
    host.classList.add('lm-ready');
    host._lm = root;

    if (fluid && window.ResizeObserver) {
      var ro = new ResizeObserver(function () {
        var avail = host.clientWidth || width;
        root.style.setProperty('--lm-w', Math.min(width, avail) + 'px');
      });
      ro.observe(host);
    }
  }

  function boot() {
    document.querySelectorAll('[data-liquid-metal]').forEach(mount);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
  window.GFLiquidMetal = { mount: mount, boot: boot };
})();

/* =========================================================================
   تعاملات صفحه اصلی — آسانسور خلیج فارس صادقی
   ========================================================================= */
(function () {
  'use strict';

  var html = document.documentElement;
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var introOn = html.classList.contains('intro-on');

  /* ---------- عنوان هیرو: کلمه‌به‌کلمه با چرخش سه‌بعدی ---------- */
  var title = document.querySelector('.hero-title');
  if (title && !reduce) {
    var words = title.textContent.trim().split(/\s+/);
    title.textContent = '';
    title.classList.remove('grad');
    title.classList.add('split');
    words.forEach(function (w, i) {
      var sp = document.createElement('span');
      sp.className = 'w grad';
      sp.style.setProperty('--i', i);
      sp.textContent = w;
      title.appendChild(sp);
      if (i < words.length - 1) title.appendChild(document.createTextNode(' '));
    });
  }

  /* ---------- ظاهر شدن تدریجی با اسکرول ---------- */
  var reveals = document.querySelectorAll('[data-reveal],[data-rd],.section-head');
  function showEl(el) {
    var d = parseInt(el.getAttribute('data-rd') || '0', 10);
    // عناصر هیرو بعد از باز شدن درهای ورودی شروع می‌شوند
    if (introOn && el.closest && el.closest('#hero')) d += 950;
    el.style.setProperty('--d', d + 'ms');
    el.classList.add('in');
  }
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        showEl(en.target);
        io.unobserve(en.target);
      });
    }, { threshold: .15, rootMargin: '0px 0px -8% 0px' });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add('in'); });
  }

  /* ---------- شمارنده‌ی اعداد هیرو ---------- */
  var FA = '۰۱۲۳۴۵۶۷۸۹';
  function toEn(str) { return str.replace(/[۰-۹]/g, function (d) { return FA.indexOf(d); }); }
  function toFa(str) { return String(str).replace(/\d/g, function (d) { return FA[+d]; }); }
  if (!reduce) {
    document.querySelectorAll('.hstat b').forEach(function (el) {
      var m = el.textContent.trim().match(/^([^\d۰-۹]*)([\d۰-۹]+)(.*)$/);
      if (!m) return;
      var pre = m[1], num = parseInt(toEn(m[2]), 10), suf = m[3];
      if (!num || num > 1000000) return;
      var started = false;
      function run() {
        if (started) return; started = true;
        var t0 = null, dur = 1500;
        function step(t) {
          if (t0 === null) t0 = t;
          var k = Math.min((t - t0) / dur, 1);
          var eased = 1 - Math.pow(1 - k, 3);
          el.textContent = pre + toFa(Math.round(num * eased)) + suf;
          if (k < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
      }
      el.textContent = pre + toFa(0) + suf;
      setTimeout(run, introOn ? 1400 : 600);
    });
  }

  /* ---------- هدر چسبان + نوار پیشرفت + دکمه‌های شناور + ناوبری پایین ----------
     هیچ خواندن layout در حلقه‌ی اسکرول نیست: موقعیت بخش‌ها کش می‌شود و فقط هنگام resize بروز می‌شود. */
  var nav  = document.getElementById('site-nav');
  var bar  = document.getElementById('scroll-progress');
  var fabs = document.getElementById('fabs');
  var dockLinks = Array.prototype.slice.call(document.querySelectorAll('[data-dock-link]'));
  var dockTops = [], docMax = 1, vhNow = innerHeight;
  var raf = 0, sNav = null, sFab = null, sBar = -1, sDock = '';

  function measureDock() {
    vhNow = innerHeight;
    docMax = Math.max(document.documentElement.scrollHeight - vhNow, 1);
    var y = window.scrollY || 0;
    dockTops = dockLinks.map(function (a) {
      var t = document.querySelector(a.getAttribute('href'));
      return t ? t.getBoundingClientRect().top + y : Infinity;
    });
  }

  var pill = document.getElementById('dock-pill'), pillReady = false, dockHost = document.getElementById('bottom-dock');
  function movePill() {
    if (!pill || !dockHost) return;
    var a = dockHost.querySelector('.dock-link.is-active');
    if (!a) return;
    /* getBoundingClientRect نسبت به داک — پایدار در RTL و fixed */
    var dr = dockHost.getBoundingClientRect();
    var ar = a.getBoundingClientRect();
    pill.style.width = Math.round(ar.width) + 'px';
    pill.style.height = Math.round(ar.height) + 'px';
    pill.style.transform = 'translate3d(' + Math.round(ar.left - dr.left) + 'px,' + Math.round(ar.top - dr.top) + 'px,0)';
    if (!pillReady) { pillReady = true; requestAnimationFrame(function () { pill.classList.add('ready'); }); }
  }

  function onScroll() {
    if (raf) return;
    raf = requestAnimationFrame(function () {
      raf = 0;
      var y = window.scrollY || 0;

      var scrolled = y > 40;
      if (scrolled !== sNav && nav) { sNav = scrolled; nav.classList.toggle('scrolled', scrolled); }
      var showFab = y > 500;
      if (showFab !== sFab && fabs) { sFab = showFab; fabs.classList.toggle('show', showFab); }
      if (bar) {
        var k = Math.round((y / docMax) * 1000) / 1000;
        if (k !== sBar) { sBar = k; bar.style.transform = 'scaleX(' + Math.min(k, 1) + ')'; }
      }

      var cur = '#hero', best = -1, line = y + vhNow * 0.45;
      for (var i = 0; i < dockLinks.length; i++) if (dockTops[i] <= line && dockTops[i] > best) { best = dockTops[i]; cur = dockLinks[i].getAttribute('href'); }
      if (cur !== sDock) {
        sDock = cur;
        dockLinks.forEach(function (a) { a.classList.toggle('is-active', a.getAttribute('href') === cur); });
        movePill();
      }
    });
  }
  addEventListener('scroll', onScroll, { passive: true });
  addEventListener('resize', function () { measureDock(); movePill(); onScroll(); });
  addEventListener('load', function () { measureDock(); movePill(); onScroll(); });
  if (typeof ResizeObserver !== 'undefined') {
    var roT = 0;
    new ResizeObserver(function () {
      cancelAnimationFrame(roT);
      roT = requestAnimationFrame(function () { measureDock(); onScroll(); });
    }).observe(document.body);
  }
  measureDock();
  movePill();
  onScroll();

  /* ---------- ناوبری پایین: active state و موج لمس/کلیک ---------- */
  dockLinks.forEach(function (link) {
    link.addEventListener('click', function (event) {
      var rect = link.getBoundingClientRect();
      var ripple = document.createElement('span');
      var size = Math.max(rect.width, rect.height) * 1.7;
      ripple.className = 'dock-ripple';
      ripple.style.width = size + 'px';
      ripple.style.height = size + 'px';
      ripple.style.left = ((event.clientX || rect.left + rect.width / 2) - rect.left - size / 2) + 'px';
      ripple.style.top = ((event.clientY || rect.top + rect.height / 2) - rect.top - size / 2) + 'px';
      link.appendChild(ripple);
      window.setTimeout(function () { if (ripple.parentNode) ripple.parentNode.removeChild(ripple); }, 650);
    });
  });

  /* ---------- افکت سه‌بعدی روی کارت‌ها ---------- */
  if (!matchMedia('(hover: none)').matches) {
    document.querySelectorAll('.tilt').forEach(function (card) {
      var rx = 0, ry = 0, tx = 0, ty = 0, loop = 0;
      card.addEventListener('pointermove', function (e) {
        var r = card.getBoundingClientRect();
        tx = ((e.clientY - r.top) / r.height - .5) * -9;
        ty = ((e.clientX - r.left) / r.width  - .5) *  9;
        card.style.setProperty('--mx', (e.clientX - r.left).toFixed(0) + 'px');
        card.style.setProperty('--my', (e.clientY - r.top).toFixed(0) + 'px');
        if (!loop) run();
      });
      card.addEventListener('pointerleave', function () { tx = 0; ty = 0; });
      function run() {
        rx += (tx - rx) * .1; ry += (ty - ry) * .1;
        card.style.transform = 'perspective(900px) rotateX(' + rx.toFixed(2) + 'deg) rotateY(' + ry.toFixed(2) + 'deg) translateY(-4px)';
        if (Math.abs(rx - tx) > .05 || Math.abs(ry - ty) > .05) {
          loop = requestAnimationFrame(run);
        } else {
          loop = 0;
          if (tx === 0 && ty === 0) card.style.transform = '';
        }
      }
    });
  }

  /* ---------- ارسال فرم‌ها با AJAX ---------- */
  function wireForm(formId, url, btnId, msgId, okId, ticketId, againId) {
    var form = document.getElementById(formId);
    if (!form) return;
    var btn = document.getElementById(btnId);
    var msg = document.getElementById(msgId);
    var ok  = document.getElementById(okId);
    var tk  = document.getElementById(ticketId);
    var ag  = document.getElementById(againId);
    var original = btn ? (btn.dataset.liquidOriginalLabel || btn.innerHTML) : '';
    function setButtonLabel(value) {
      if (!btn) return;
      if (btn.dataset.liquidControl === '1') {
        btn.dispatchEvent(new CustomEvent('liquid-label', { detail: value }));
        btn.setAttribute('aria-label', value);
      } else {
        btn.innerHTML = value;
      }
    }

    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      if (msg) { msg.hidden = true; msg.className = 'form-msg'; }

      // اعتبارسنجی مرورگر
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      if (btn) { btn.disabled = true; setButtonLabel('در حال ارسال...'); }

      fetch(url, { method: 'POST', body: new FormData(form), credentials: 'same-origin' })
        .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'پاسخ نامعتبر از سرور' }; }); })
        .then(function (d) {
          if (d && d.ok) {
            if (tk) tk.textContent = d.ticket || '';
            form.reset();
            form.hidden = true;
            if (ok) ok.hidden = false;
          } else {
            if (msg) {
              msg.textContent = (d && d.error) || 'ارسال ناموفق بود.';
              msg.className = 'form-msg error';
              msg.hidden = false;
            }
          }
        })
        .catch(function () {
          if (msg) {
            msg.textContent = 'ارتباط با سرور برقرار نشد. دوباره تلاش کنید.';
            msg.className = 'form-msg error';
            msg.hidden = false;
          }
        })
        .finally(function () {
          if (btn) { btn.disabled = false; setButtonLabel(original); }
        });
    });

    if (ag) ag.addEventListener('click', function () {
      if (ok) ok.hidden = true;
      form.hidden = false;
      form.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  }

  wireForm('request-form', 'api/request.php', 'request-btn', 'request-msg',
           'request-success', 'request-ticket', 'request-again');
  wireForm('support-form', 'api/support.php', 'support-btn', 'support-msg',
           'support-success', 'support-ticket', 'support-again');
})();

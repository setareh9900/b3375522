/* =========================================================================
   ساختمان واقعی با کابین متحرک — تصویر فتوریالیستیک ساختمان + کابین زنده داخل شفت
   • کابین، طناب، نور و مسافر با transform حرکت می‌کنند (سبک، بدون WebGL، مناسب گوشی ضعیف)
   • لبه‌ی دال‌ها از خود تصویر روی کابین کشیده شده تا کابین «پشت» دال‌ها رد شود (اکلوژن واقعی)
   • شتاب/ترمز واقعی، زنگ رسیدن، کلیک روی هر طبقه
   ========================================================================= */
(function () {
  'use strict';
  var host = document.getElementById('e3');
  if (!host || host.getAttribute('data-three') === '1') return;
  host.setAttribute('data-three', '1');
  var html = document.documentElement;
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var lite = html.getAttribute('data-perf') === 'lite';

  var FLOORS = [
    { n: 'همکف', t: 'پذیرش و مشاوره', d: 'نیاز ساختمان را بگویید؛ مسیر مناسب نصب یا سرویس پیشنهاد می‌شود.', href: '#request', cta: 'ثبت درخواست', type: 'service' },
    { n: '۱', t: 'کارگاه فنی', d: 'بازدید، تعمیر و نگهداری آسانسور توسط تیم فنی.', href: '#services', cta: 'مشاهده خدمات', type: '' },
    { n: '۲', t: 'قطعات و تجهیزات', d: 'موتور، ریل، تابلو و درب را در کاتالوگ ببینید.', href: '#catalog', cta: 'مشاهده قطعات', type: '' },
    { n: '۳', t: 'انواع آسانسور', d: 'مدل‌ها، توضیح صوتی و جزئیات هر کابین.', href: '#types', cta: 'مشاهده انواع', type: '' }
  ];
  var N = FLOORS.length;
  var clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
  function el(tag, cls, h) { var n = document.createElement(tag); if (cls) n.className = cls; if (h != null) n.innerHTML = h; return n; }

  /* ---------- هندسه‌ی تصویر ساختمان (پیکسل‌های خود تصویر 1244×1450) ---------- */
  var IW = 880, IH = 1184, CARW = 74, CARH = 127, CARX = 410;
  var FLOOR_Y = [1015, 837, 662, 487];
  var BANDS = [[485, 511], [661, 686], [835, 866]];
  var ROOMS = [[866, 1015], [686, 835], [511, 661], [329, 485]];
  var PICK = [850, 674, 499];
  var ROPE_TOP = 330, SHAFT = [400, 494, 329, 1015];

  var stage = el('div', 'e3-stage e3-gl'); stage.setAttribute('tabindex', '0'); stage.setAttribute('role', 'img');
  stage.setAttribute('aria-label', 'ساختمان چندطبقه با آسانسور. روی هر طبقه بزنید یا شاسی را انتخاب کنید.');
  var scene = el('div', 'bd-scene');
  var img = new Image(); img.className = 'bd-img'; img.alt = ''; img.decoding = 'async'; img.draggable = false;
  img.src = 'assets/img/building/cutaway-v21.webp';
  scene.appendChild(img);

  var pc = function (v, t) { return (v / t * 100).toFixed(4) + '%'; };
  function box(cls, x, y, w, h, par) { var d = el('div', cls); d.style.cssText = 'left:' + pc(x, IW) + ';top:' + pc(y, IH) + ';width:' + pc(w, IW) + ';height:' + pc(h, IH); (par || scene).appendChild(d); return d; }

  var hl = box('bd-hl', 95, ROOMS[0][0], 705, ROOMS[0][1] - ROOMS[0][0]);          /* نور نشان‌دهنده‌ی طبقه‌ی انتخاب‌شده */
  var clip = box('bd-clip', SHAFT[0], SHAFT[2], SHAFT[1] - SHAFT[0], SHAFT[3] - SHAFT[2]);
  var inner = el('div', 'bd-clip-in'); inner.style.cssText = 'left:' + pc(-SHAFT[0], SHAFT[1] - SHAFT[0]) + ';top:' + pc(-SHAFT[2], SHAFT[3] - SHAFT[2]) + ';width:' + pc(IW, SHAFT[1] - SHAFT[0]) + ';height:' + pc(IH, SHAFT[3] - SHAFT[2]);
  clip.appendChild(inner);
  /* طناب‌ها */
  var ropes = [432, 462].map(function (x) { var r = box('bd-rope', x, ROPE_TOP, 2.2, 1, inner); r.style.height = '1px'; return r; });
  /* کابین */
  var car = box('bd-car', CARX, 0, CARW, CARH, inner);
  car.innerHTML = '<img class="c-sprite" src="assets/img/building/cabin-v21.webp" alt="" draggable="false"><i class="c-shade"></i><i class="c-frame"></i>';
  var glow = box('bd-glow', CARX - 70, 0, CARW + 140, CARH + 120, inner);
  /* نور خروجی کابین روی راهرو وقتی در باز است */
  var spill = box('bd-spill', 484, 0, 70, 127);
  /* لبه‌ی دال‌ها: همان تصویر، بالای کابین */
  BANDS.forEach(function (b) {
    var w = SHAFT[1] - SHAFT[0], h = b[1] - b[0], d = box('bd-band', SHAFT[0], b[0], w, h);
    var im = new Image(); im.alt = ''; im.draggable = false; im.className = 'bd-band-img';
    im.src = img.src; im.style.cssText = 'width:' + pc(IW, w) + ';left:' + pc(-SHAFT[0], w) + ';top:' + pc(-b[0], h);
    d.appendChild(im);
  });
  var vig = el('i', 'bd-vig'); scene.appendChild(vig);
  stage.appendChild(scene);
  host.appendChild(stage);

  var panel = el('div', 'e3-panel');
  panel.innerHTML =
    '<span class="e3-tag"><i></i>طبقه فعلی</span>' +
    '<h3 class="e3-title" id="e3-title"></h3>' +
    '<p class="e3-desc" id="e3-desc"></p>' +
    '<div class="e3-ui"><div class="e3-lcd" aria-live="polite"><span id="e3-arrow">■</span><b id="e3-num">1</b></div><div class="e3-btns" id="e3-btns"></div>' +
    '<button type="button" class="e3-snd" id="e3-snd" aria-pressed="true" title="صدای آسانسور">🔊</button></div>' +
    '<a class="e3-go" id="e3-go" href="#request"><span id="e3-go-label">ورود به این بخش</span><em aria-hidden="true">←</em></a>' +
    '<p class="e3-hint">روی هر طبقه‌ی ساختمان بزنید یا شاسی را انتخاب کنید؛ کابین با شتاب واقعی می‌رسد</p>';
  host.appendChild(panel);
  var btnWrap = panel.querySelector('#e3-btns'), btns = [];
  var tTitle = panel.querySelector('#e3-title'), tDesc = panel.querySelector('#e3-desc'), tNum = panel.querySelector('#e3-num'),
      tArrow = panel.querySelector('#e3-arrow'), goBtn = panel.querySelector('#e3-go'), goLabel = panel.querySelector('#e3-go-label'),
      sndBtn = panel.querySelector('#e3-snd');
  for (var b = N - 1; b >= 0; b--) (function (f) {
    var x = el('button', 'e3-btn', '<span>' + (f === 0 ? 'G' : f) + '</span>'); x.type = 'button';
    x.setAttribute('aria-label', 'طبقه ' + FLOORS[f].n + ': ' + FLOORS[f].t);
    x.addEventListener('click', function () { scrollGuard = window.scrollY; setTarget(f); x.classList.remove('pr'); void x.offsetWidth; x.classList.add('pr'); });
    btns[f] = x; btnWrap.appendChild(x);
  })(b);

  /* ---------- صدا: زنگ رسیدن و صدای باز/بسته شدن در (WebAudio، بدون فایل) ---------- */
  var actx = null, soundOn = true;
  function audio() { if (!actx) { try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { actx = false; } } if (actx && actx.state === 'suspended') actx.resume(); return actx; }
  function tone(freq, t0, dur, vol, type) {
    var a = audio(); if (!a || !soundOn) return;
    var o = a.createOscillator(), g = a.createGain(); o.type = type || 'sine'; o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, a.currentTime + t0); g.gain.exponentialRampToValueAtTime(vol, a.currentTime + t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, a.currentTime + t0 + dur);
    o.connect(g); g.connect(a.destination); o.start(a.currentTime + t0); o.stop(a.currentTime + t0 + dur + 0.05);
  }
  function ding() { tone(988, 0, 0.9, 0.12); tone(784, 0.28, 1.1, 0.1); }
  function whoosh() {
    var a = audio(); if (!a || !soundOn) return;
    var len = a.sampleRate * 0.9, buf = a.createBuffer(1, len, a.sampleRate), d = buf.getChannelData(0);
    for (var i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.sin(Math.PI * i / len) * 0.5;
    var s = a.createBufferSource(), f = a.createBiquadFilter(), g = a.createGain(); f.type = 'lowpass'; f.frequency.value = 600; g.gain.value = 0.05;
    s.buffer = buf; s.connect(f); f.connect(g); g.connect(a.destination); s.start();
  }
  sndBtn.addEventListener('click', function () { soundOn = !soundOn; sndBtn.textContent = soundOn ? '🔊' : '🔇'; sndBtn.setAttribute('aria-pressed', soundOn ? 'true' : 'false'); if (soundOn) { audio(); ding(); } });

  function goToFloor(f) {
    var info = FLOORS[f]; if (!info) return;
    if (info.type) {
      var radio = document.querySelector('input[name="request_type"][value="' + info.type + '"]');
      if (radio) { radio.checked = true; radio.dispatchEvent(new Event('change', { bubbles: true })); }
    }
    var t = document.querySelector(info.href);
    if (t) t.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' }); else location.hash = info.href;
  }
  goBtn.addEventListener('click', function (e) { e.preventDefault(); goToFloor(shown >= 0 ? shown : cur); });

  /* ---------- حالت منطقی آسانسور ---------- */
  var FH = 3.4, cy = 0, vel = 0, target = 0, door = 1, phase = 'open', dwell = 9, cur = 0, shown = -1, active = true, dirtyUI = true;
  function setTarget(f) {
    f = clamp(f, 0, N - 1); if (phase === 'scrolling') { phase = 'moving'; }
    if (f === target && phase !== 'open') return;
    target = f; goBtn.classList.remove('ready'); wake();
    audio();
  }
  function show(f) {
    if (f === shown) return; shown = f;
    var i = FLOORS[f]; tTitle.textContent = i.t; tDesc.textContent = i.d; goLabel.textContent = i.cta; goBtn.setAttribute('href', i.href);
    tTitle.classList.remove('in'); void tTitle.offsetWidth; tTitle.classList.add('in');
  }
  show(0); goBtn.classList.add('ready');


  /* ---------- حالت منطقی آسانسور ---------- */
  var FH = 3.4, cy = 0, vel = 0, target = 0, door = 1, phase = 'open', dwell = 9, cur = 0, shown = -1, running = false, raf = 0, last = 0, idle = 0, lastLed = '';
  var A = 1.15, VMAX = 2.9, scale = 1, spos = 0, lastScrollT = 0, inView = false, lastP = null, scrollGuard = 0;
  function setTarget(f) {
    f = clamp(f, 0, N - 1);
    if (phase === 'scrolling') { phase = 'moving'; }
    if (f === target && phase !== 'open') return;
    target = f; goBtn.classList.remove('ready'); audio(); wake();
  }
  function show(f) {
    if (f === shown) return; shown = f;
    var i = FLOORS[f]; tTitle.textContent = i.t; tDesc.textContent = i.d; goLabel.textContent = i.cta; goBtn.setAttribute('href', i.href);
    tTitle.classList.remove('in'); void tTitle.offsetWidth; tTitle.classList.add('in');
    var r = ROOMS[f]; hl.style.top = pc(r[0], IH); hl.style.height = pc(r[1] - r[0], IH);
  }
  show(0); goBtn.classList.add('ready');

  function ypx(m) {                                     /* متر → پیکسل تصویر (بالای کابین) */
    var t = clamp(m / FH, 0, N - 1), i = Math.min(N - 2, Math.floor(t)), u = t - i;
    return FLOOR_Y[i] + (FLOOR_Y[i + 1] - FLOOR_Y[i]) * u - CARH;
  }

  function step(dt) {
    if (reduce) { cy = target * FH; vel = 0; door = 1; phase = 'open'; cur = target; return false; }
    if (phase === 'scrolling') {                          /* کابین هم‌پا با اسکرول صفحه */
      door = Math.max(0, door - dt / .5);
      var dd = clamp(spos, 0, (N - 1) * FH) - cy; vel = clamp(dd * 7, -4.2, 4.2); cy = clamp(cy + vel * dt, 0, (N - 1) * FH);
      if (Math.abs(dd) < .004) { vel = 0; }
      if (performance.now() - lastScrollT > 650) { target = clamp(Math.round(cy / FH), 0, N - 1); vel = clamp(vel, -.6, .6); phase = 'moving'; }
      return true;
    }
    if (phase === 'open') {
      dwell += dt;
      if (target !== cur && dwell > .9) { phase = 'closing'; whoosh(); }
    } else if (phase === 'closing') { door = Math.max(0, door - dt / .9); if (door <= 0) { phase = 'moving'; } }
    else if (phase === 'moving') {
      var ty = target * FH, d = ty - cy, ad = Math.abs(d);
      var vd = Math.sign(d) * Math.min(VMAX, Math.sqrt(2 * A * Math.max(ad - .01, 0)));
      vel += clamp(vd - vel, -A * dt, A * dt); cy = clamp(cy + vel * dt, 0, (N - 1) * FH);
      if (ad < .012 && Math.abs(vel) < .08) { cy = ty; vel = 0; cur = target; phase = 'opening'; ding(); whoosh(); }
    } else if (phase === 'opening') { door = Math.min(1, door + dt / 1.1); if (door >= 1) { phase = 'open'; dwell = 0; } }
    return phase !== 'open';
  }

  function render(t) {
    var y = ypx(cy) * scale;
    /* حرکت کاملاً روان روی ریل: لرزش مصنوعی و نوسان افقی حذف شده است. */
    car.style.transform = 'translate3d(0,' + y.toFixed(3) + 'px,0)';
    glow.style.transform = 'translate3d(0,' + (y - 60 * scale).toFixed(2) + 'px,0)';
    var rl = Math.max(1, y - ROPE_TOP * scale);
    for (var i = 0; i < ropes.length; i++) ropes[i].style.transform = 'translate3d(0,0,0) scale(1,' + rl.toFixed(2) + ')';
    var near = clamp(Math.round(cy / FH), 0, N - 1);
    var fy = (cy / FH - near);                          /* فاصله تا نزدیک‌ترین طبقه */
    spill.style.transform = 'translate3d(0,' + ((FLOOR_Y[near] - 188) * scale).toFixed(2) + 'px,0)';
    spill.style.opacity = (Math.abs(fy) < .08 ? door * .85 : 0).toFixed(2);
    car.style.setProperty('--lit', (.9 + .1 * door).toFixed(2));
    var mv = phase === 'moving' || phase === 'scrolling';
    tNum.textContent = near === 0 ? 'G' : near; tArrow.textContent = mv ? (vel > 0 ? '▲' : '▼') : '■';
    for (var q = 0; q < N; q++) { btns[q].classList.toggle('call', mv && q === target); btns[q].classList.toggle('here', !mv && q === near && phase === 'open'); }
    if (phase === 'scrolling') { show(near); goBtn.classList.remove('ready'); }
    else if (phase === 'open') { show(near); if (target === cur && !goBtn.classList.contains('ready')) goBtn.classList.add('ready'); }
    else goBtn.classList.remove('ready');
  }
  function frame(t) {
    var dt = Math.min(.05, (t - last) / 1000 || .016); last = t;
    var mv = step(dt); render(t);
    if (mv || phase !== 'open') idle = 0; else idle++;
    if (idle > 20 && !mv) { running = false; return; }
    if (running) raf = requestAnimationFrame(frame);
  }
  function start() { if (running) return; running = true; last = performance.now(); raf = requestAnimationFrame(frame); }
  function stop() { running = false; cancelAnimationFrame(raf); }
  function wake() { idle = 0; start(); }

  function size() { scale = (scene.clientWidth || IW) / IW; render(performance.now()); }
  if (window.ResizeObserver) new ResizeObserver(size).observe(scene); else addEventListener('resize', size);
  size();
  if ('IntersectionObserver' in window) new IntersectionObserver(function (en) { if (!en[0].isIntersecting) stop(); else if (phase !== 'open' || target !== cur) start(); }, { rootMargin: '80px' }).observe(stage);
  document.addEventListener('visibilitychange', function () { if (document.hidden) stop(); else if (phase !== 'open' || target !== cur) start(); });

  /* ---------- هم‌پایی با اسکرول: پایین رفتن صفحه = پایین آمدن کابین در ساختمان ---------- */
  function onScroll() {
    if (reduce || !inView) return;
    var r = stage.getBoundingClientRect(), vh = innerHeight || 800;
    var p;
    p = clamp((vh * .85 - r.top) / (r.height + vh * .55), 0, 1);
    if (lastP === null) { lastP = p; return; }
    if (Math.abs(p - lastP) < .0015) return;
    lastP = p;
    if (phase !== 'scrolling' && Math.abs(window.scrollY - scrollGuard) < 50) return;   /* اسکرول خودکار بعد از کلیک را نادیده بگیر */
    spos = p * (N - 1) * FH; lastScrollT = performance.now();
    if (phase !== 'scrolling') phase = 'scrolling';
    wake();
  }
  addEventListener('scroll', onScroll, { passive: true });
  if ('IntersectionObserver' in window) new IntersectionObserver(function (en) { inView = en[0].isIntersecting; lastP = null; scrollGuard = window.scrollY; }, { threshold: 0 }).observe(stage);
  else inView = true;

  /* ---------- تعامل ---------- */
  function floorAt(e) {
    var r = scene.getBoundingClientRect(), yy = (e.clientY - r.top) / r.height * IH;
    return yy < PICK[2] ? 3 : yy < PICK[1] ? 2 : yy < PICK[0] ? 1 : 0;
  }
  stage.addEventListener('click', function (e) { scrollGuard = window.scrollY; setTarget(floorAt(e)); });
  if (!lite && !reduce && matchMedia('(hover: hover)').matches) {
    stage.addEventListener('pointermove', function (e) {
      var r = stage.getBoundingClientRect(), px = ((e.clientX - r.left) / r.width - .5), py = ((e.clientY - r.top) / r.height - .5);
      scene.style.transform = 'translate3d(' + (px * -10).toFixed(1) + 'px,' + (py * -10).toFixed(1) + 'px,0) scale(1.03)';
    });
    stage.addEventListener('pointerleave', function () { scene.style.transform = ''; });
  }
  stage.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowUp') { e.preventDefault(); setTarget(target + 1); } else if (e.key === 'ArrowDown') { e.preventDefault(); setTarget(target - 1); } else if (e.key === 'Enter') { e.preventDefault(); goToFloor(shown >= 0 ? shown : cur); }
  });
  img.addEventListener('error', function () {
    if (stage.parentNode) stage.parentNode.removeChild(stage); if (panel.parentNode) panel.parentNode.removeChild(panel);
    host.removeAttribute('data-three'); var s = document.createElement('script'); s.src = 'assets/js/elevator3d.js'; document.body.appendChild(s);
  });
  window.GFE3 = { step: step, render: render, setTarget: setTarget, state: function () { return { cy: cy, phase: phase, cur: cur }; } };
})();

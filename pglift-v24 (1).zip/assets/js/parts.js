/* =========================================================================
   قفسه‌ی قطعات و متعلقات — دسته‌بندی، پنجره‌ی جزئیات، استعلام قیمت
   ========================================================================= */
(function () {
  'use strict';
  var dataEl = document.getElementById('parts-data');
  var root = document.getElementById('catalog');
  if (!dataEl || !root) return;

  var items = {};
  try { JSON.parse(dataEl.textContent).forEach(function (it) { items[it.id] = it; }); } catch (e) { return; }

  var modal = null, opener = null;
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }

  function close() {
    if (!modal) return;
    modal.hidden = true; modal.innerHTML = '';
    document.body.classList.remove('no-scroll');
    document.removeEventListener('keydown', onKey);
    if (opener) { try { opener.focus(); } catch (e) { /* ignore */ } }
  }
  function onKey(e) { if (e.key === 'Escape') close(); }

  function open(id, from) {
    var it = items[id]; if (!it) return;
    opener = from || null;
    if (!modal) { modal = el('div', 'pm'); modal.setAttribute('role', 'dialog'); modal.setAttribute('aria-modal', 'true'); document.body.appendChild(modal); }
    modal.innerHTML = '';
    var box = el('div', 'pm-box');
    var x = el('button', 'pm-x', '✕'); x.type = 'button'; x.setAttribute('aria-label', 'بستن'); x.addEventListener('click', close);
    var imgWrap = el('div', 'pm-img');
    if (it.image) { var im = el('img'); im.src = it.image; im.alt = it.title; imgWrap.appendChild(im); }
    var info = el('div', 'pm-info');
    info.appendChild(el('h3', '', it.title));
    if (it.tag) info.appendChild(el('p', 'pm-tag', it.tag));
    if (it.desc) info.appendChild(el('p', 'pm-desc', it.desc));
    if (it.specs && it.specs.length) {
      var ul = el('ul', 'tx-specs');
      it.specs.forEach(function (s) { var li = el('li'); li.appendChild(el('b', '', s[0])); li.appendChild(el('span', '', s[1])); ul.appendChild(li); });
      info.appendChild(ul);
    }
    var quoteLinks = el('div', 'part-quote-actions');
    var full = el('a', 'btn btn-primary', 'فرم استعلام این قطعه'); full.href = 'inquiry/?source=catalog&id=' + encodeURIComponent(it.id) + '&mode=full';
    var phoneEl = document.querySelector('a.nav-phone[href^="tel:"], a[href^="tel:"]');
    var tel = phoneEl ? phoneEl.getAttribute('href') : '';
    var quick = el('a', 'btn btn-ghost', tel ? 'تماس تلفنی' : 'ثبت درخواست تماس');
    quick.href = tel || '#request';
    if (tel) quick.setAttribute('dir', 'ltr');
    else quick.addEventListener('click', function () { prefill(it); });
    quoteLinks.appendChild(full); quoteLinks.appendChild(quick); info.appendChild(quoteLinks);
    box.appendChild(x); box.appendChild(imgWrap); box.appendChild(info);
    modal.appendChild(box); modal.hidden = false;
    document.body.classList.add('no-scroll');
    document.addEventListener('keydown', onKey);
    modal.onclick = function (e) { if (e.target === modal) close(); };
    x.focus();
  }

  function prefill(it) {
    var f = document.getElementById('request-form'); if (!f) return;
    var set = function (n, v) { var e = f.elements[n]; if (e) { e.value = v; e.dispatchEvent(new Event('input', { bubbles: true })); } };
    var r = f.querySelector('input[name="request_type"][value="service"]');
    if (r) { r.checked = true; r.dispatchEvent(new Event('change', { bubbles: true })); }
    set('subject', 'استعلام قیمت: ' + it.title);
    set('message', 'سلام، قیمت و موجودی «' + it.title + '» را می‌خواهم.');
    setTimeout(function () { var n = f.elements.customer_name; if (n) n.focus({ preventScroll: true }); }, 700);
  }

  root.addEventListener('open-shelf-part', function (e) { if (e.detail && items[e.detail.id]) open(e.detail.id, e.detail.opener); });

  root.addEventListener('click', function (e) {
    var c = e.target.closest ? e.target.closest('.pcard') : null;
    if (c) open(c.getAttribute('data-part'), c);
  });

  if ('IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches && document.documentElement.getAttribute('data-perf') !== 'lite') {
    var shelfMotion = new IntersectionObserver(function(entries) { entries.forEach(function(entry) { if (entry.isIntersecting) { entry.target.classList.add('is-in'); shelfMotion.unobserve(entry.target); } }); }, {threshold: .15});
    root.querySelectorAll('.shelf').forEach(function(shelf) { shelfMotion.observe(shelf); });
  }

  /* دسته‌بندی (نشانگر لغزنده، دسته‌ی فعال و حرکت چپ/راست) در showcase.js مدیریت می‌شود */
})();

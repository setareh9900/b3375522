/* =========================================================================
   پنل مدیریت — ارسال فرم‌ها با AJAX
   ========================================================================= */
(function () {
  'use strict';

  var toastEl = document.getElementById('toast');
  var toastT = 0;

  function toast(text, kind) {
    if (!toastEl) return;
    clearTimeout(toastT);
    toastEl.textContent = text;
    toastEl.className = 'toast ' + (kind || '');
    toastEl.hidden = false;
    requestAnimationFrame(function () { toastEl.classList.add('show'); });
    toastT = setTimeout(function () {
      toastEl.classList.remove('show');
      setTimeout(function () { toastEl.hidden = true; }, 350);
    }, 3200);
  }

  function post(payload) {
    return fetch('action.php', {
      method: 'POST',
      body: payload,
      credentials: 'same-origin',
    }).then(function (r) {
      if (r.status === 401) {
        toast('نشست شما منقضی شده. در حال انتقال به صفحه ورود...', 'err');
        setTimeout(function () { location.href = 'login.php'; }, 1400);
        throw new Error('unauthorized');
      }
      return r.json().catch(function () { return { ok: false, error: 'پاسخ نامعتبر از سرور' }; });
    });
  }

  /* ---------- اندازه‌ی قابل تنظیم هیرو ---------- */
  document.querySelectorAll('.hero-height-range').forEach(function (range) {
    var output = range.closest('.hero-size-field')?.querySelector('[data-hero-height-output]');
    range.addEventListener('input', function () {
      if (output) output.textContent = Number(range.value).toLocaleString('fa-IR') + '٪ ارتفاع صفحه';
    });
  });

  /* ---------- فرم‌های AJAX ---------- */
  document.querySelectorAll('form.js-ajax').forEach(function (form) {
    var action = form.getAttribute('data-do');
    var reset  = form.getAttribute('data-reset') === '1';

    form.addEventListener('submit', function (ev) {
      ev.preventDefault();

      // بررسی یکسان بودن رمز جدید
      if (action === 'password.change') {
        var n1 = form.querySelector('[name="new"]');
        var n2 = form.querySelector('[name="new2"]');
        if (n1 && n2 && n1.value !== n2.value) {
          toast('رمز جدید و تکرار آن یکسان نیستند', 'err');
          return;
        }
      }

      if (!form.checkValidity()) { form.reportValidity(); return; }

      var fd = new FormData(form);
      fd.append('do', action);

      // چک‌باکس‌های تیک‌نخورده را صریحاً صفر بفرست
      form.querySelectorAll('input[type="checkbox"]').forEach(function (cb) {
        if (!cb.checked && cb.name) fd.append(cb.name, '0');
      });

      var btn = form.querySelector('button[type="submit"]');
      var html = btn ? btn.innerHTML : '';
      if (btn) { btn.disabled = true; btn.innerHTML = 'در حال ذخیره...'; }

      post(fd)
        .then(function (d) {
          if (d && d.ok) {
            toast((d && d.message) || 'با موفقیت ذخیره شد', 'ok');
            if (reset) form.reset();
          } else {
            toast((d && d.error) || 'ذخیره ناموفق بود', 'err');
          }
        })
        .catch(function (e) { if (e.message !== 'unauthorized') toast('خطا در ارتباط با سرور', 'err'); })
        .finally(function () { if (btn) { btn.disabled = false; btn.innerHTML = html; } });
    });
  });

  /* ---------- دکمه‌های حذف ---------- */
  document.querySelectorAll('.js-delete').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var msg = btn.getAttribute('data-confirm') || 'حذف شود؟';
      if (!confirm(msg)) return;

      var fd = new FormData();
      fd.append('do', btn.getAttribute('data-do'));
      fd.append('id', btn.getAttribute('data-id'));
      var tokenEl = document.querySelector('input[name="csrf"]');
      fd.append('csrf', tokenEl ? tokenEl.value : '');

      btn.disabled = true;
      post(fd)
        .then(function (d) {
          if (d && d.ok) {
            toast('با موفقیت حذف شد', 'ok');
            setTimeout(function () { location.reload(); }, 700);
          } else {
            toast((d && d.error) || 'حذف ناموفق بود', 'err');
            btn.disabled = false;
          }
        })
        .catch(function (e) {
          if (e.message !== 'unauthorized') toast('خطا در ارتباط با سرور', 'err');
          btn.disabled = false;
        });
    });
  });

  /* ---------- اندازه‌ی لوگو (پیش‌نمایش زنده) ---------- */
  var SIZE_DEF = { nav: [48, 0], ft: [64, 0] };
  document.querySelectorAll('.logo-size-box').forEach(function (box) {
    var img = box.querySelector('.size-prev img');
    var rh = box.querySelector('.js-lh'), rw = box.querySelector('.js-lw');
    var oh = box.querySelector('[data-out="h"]'), ow = box.querySelector('[data-out="w"]');
    function apply() {
      var h = +rh.value, w = +rw.value;
      oh.textContent = h;
      ow.textContent = w ? w + ' پیکسل' : 'خودکار';
      if (img) { img.style.height = h + 'px'; img.style.width = w ? w + 'px' : 'auto'; }
    }
    rh.addEventListener('input', apply); rw.addEventListener('input', apply);
    box._apply = apply; apply();
  });
  var resetBtn = document.querySelector('.js-logo-reset');
  if (resetBtn) resetBtn.addEventListener('click', function () {
    document.querySelectorAll('.logo-size-box').forEach(function (box) {
      var d = SIZE_DEF[box.getAttribute('data-zone')] || [48, 0];
      box.querySelector('.js-lh').value = d[0]; box.querySelector('.js-lw').value = d[1];
      box._apply();
    });
    toast('مقادیر پیش‌فرض اعمال شد؛ برای ثبت، «ذخیره‌ی اندازه‌ها» را بزنید', 'ok');
  });

  /* ---------- حذف پس‌زمینه‌ی تک‌رنگ (سمت مرورگر، قبل از آپلود) ---------- */
  function removeBackground(img, tol) {
    var MAX = 1200, sc = Math.min(1, MAX / Math.max(img.naturalWidth, img.naturalHeight));
    var w = Math.max(1, Math.round(img.naturalWidth * sc)), h = Math.max(1, Math.round(img.naturalHeight * sc));
    var cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    var cx = cv.getContext('2d', { willReadFrequently: true });
    cx.drawImage(img, 0, 0, w, h);
    var im = cx.getImageData(0, 0, w, h), d = im.data;

    /* رنگ پس‌زمینه = میانگین چهار گوشه (اگر شبیه هم نبودند، پس‌زمینه تک‌رنگ نیست) */
    var pts = [[0, 0], [w - 1, 0], [0, h - 1], [w - 1, h - 1]], bg = [0, 0, 0], cols = [];
    pts.forEach(function (p) {
      var i = (p[1] * w + p[0]) * 4; cols.push([d[i], d[i + 1], d[i + 2], d[i + 3]]);
      bg[0] += d[i]; bg[1] += d[i + 1]; bg[2] += d[i + 2];
    });
    bg = bg.map(function (v) { return v / 4; });
    var dist = function (i) { var dr = d[i] - bg[0], dg = d[i + 1] - bg[1], db = d[i + 2] - bg[2]; return Math.sqrt(dr * dr + dg * dg + db * db); };
    var alreadyClear = cols.every(function (c) { return c[3] < 10; });
    if (alreadyClear) return { canvas: cv, note: 'این تصویر از قبل شفاف است' };
    var spread = cols.some(function (c) { return Math.abs(c[0] - bg[0]) + Math.abs(c[1] - bg[1]) + Math.abs(c[2] - bg[2]) > tol * 2.2; });
    if (spread) return { canvas: cv, note: 'پس‌زمینه تک‌رنگ نیست؛ حذف انجام نشد' };

    /* پر کردن سیل‌وار از لبه‌ها (فقط پیکسل‌های متصل به بیرون حذف می‌شوند، نه داخل لوگو) */
    var seen = new Uint8Array(w * h), stack = [];
    function push(x, y) { var k = y * w + x; if (!seen[k] && dist(k * 4) <= tol) { seen[k] = 1; stack.push(k); } }
    for (var x = 0; x < w; x++) { push(x, 0); push(x, h - 1); }
    for (var y = 0; y < h; y++) { push(0, y); push(w - 1, y); }
    while (stack.length) {
      var k = stack.pop(), px = k % w, py = (k / w) | 0;
      if (px > 0) push(px - 1, py); if (px < w - 1) push(px + 1, py);
      if (py > 0) push(px, py - 1); if (py < h - 1) push(px, py + 1);
    }
    var minX = w, minY = h, maxX = -1, maxY = -1;
    for (var yy = 0; yy < h; yy++) for (var xx = 0; xx < w; xx++) {
      var kk = yy * w + xx, i4 = kk * 4;
      if (seen[kk]) { d[i4 + 3] = 0; continue; }
      /* لبه‌ی نرم: پیکسل‌های مجاور حذف‌شده‌ها کمی شفاف می‌شوند تا هاله‌ی رنگی نماند */
      var near = (xx > 0 && seen[kk - 1]) || (xx < w - 1 && seen[kk + 1]) || (yy > 0 && seen[kk - w]) || (yy < h - 1 && seen[kk + w]);
      if (near) { var dd = dist(i4), f = Math.min(1, Math.max(0, (dd - tol) / (tol * 0.8))); d[i4 + 3] = Math.round(d[i4 + 3] * f); }
      if (d[i4 + 3] > 8) { if (xx < minX) minX = xx; if (xx > maxX) maxX = xx; if (yy < minY) minY = yy; if (yy > maxY) maxY = yy; }
    }
    cx.putImageData(im, 0, 0);
    if (maxX < 0) return { canvas: cv, note: 'چیزی باقی نماند؛ حساسیت را کمتر کنید' };
    /* برش دور لوگو تا دقیقاً همان تصویر بدون حاشیه‌ی اضافی باشد */
    var out = document.createElement('canvas'); out.width = maxX - minX + 1; out.height = maxY - minY + 1;
    out.getContext('2d').drawImage(cv, minX, minY, out.width, out.height, 0, 0, out.width, out.height);
    return { canvas: out, note: '' };
  }

  document.querySelectorAll('form.js-upload').forEach(function (form) {
    var fileIn = form.querySelector('input[type="file"]');
    var chk = form.querySelector('.js-bgremove'), tolWrap = form.querySelector('.bg-tol');
    var tol = form.querySelector('.js-tol'), tolOut = form.querySelector('.js-tol-out');
    var prevBox = form.querySelector('.bg-prev'), prevCv = prevBox && prevBox.querySelector('canvas');
    if (!chk || !fileIn) return;
    form._processed = null;

    function refresh() {
      form._processed = null;
      var f = fileIn.files && fileIn.files[0];
      tolWrap.hidden = prevBox.hidden = !chk.checked;
      if (!chk.checked || !f) return;
      if (f.type === 'image/svg+xml' || /\.svg$/i.test(f.name)) { toast('SVG از قبل بدون پس‌زمینه است', 'ok'); return; }
      var url = URL.createObjectURL(f), im = new Image();
      im.onload = function () {
        var r = removeBackground(im, +tol.value);
        prevCv.width = r.canvas.width; prevCv.height = r.canvas.height;
        prevCv.getContext('2d').drawImage(r.canvas, 0, 0);
        if (r.note) toast(r.note, 'err');
        r.canvas.toBlob(function (b) { form._processed = b; }, 'image/png');
        URL.revokeObjectURL(url);
      };
      im.onerror = function () { toast('خواندن تصویر ممکن نشد', 'err'); URL.revokeObjectURL(url); };
      im.src = url;
    }
    chk.addEventListener('change', refresh);
    fileIn.addEventListener('change', refresh);
    tol.addEventListener('input', function () { tolOut.textContent = tol.value; clearTimeout(form._t); form._t = setTimeout(refresh, 120); });
  });

  /* ---------- آپلود لوگو ---------- */
  document.querySelectorAll('form.js-upload').forEach(function (form) {
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var file = form.querySelector('input[type="file"]');
      if (!file || !file.files.length) { toast('ابتدا فایلی انتخاب کنید', 'err'); return; }

      var btn = form.querySelector('button[type="submit"]');
      var html = btn ? btn.innerHTML : '';
      if (btn) { btn.disabled = true; btn.innerHTML = 'در حال آپلود...'; }

      var body = new FormData(form);
      if (form._processed) body.set('file', form._processed, 'logo.png');
      fetch('upload-logo.php', {
        method: 'POST', body: body, credentials: 'same-origin',
      })
        .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'پاسخ نامعتبر' }; }); })
        .then(function (d) {
          if (d && d.ok) {
            toast('تصویر با موفقیت ذخیره شد', 'ok');
            var prev = form.parentElement.querySelector('.logo-prev');
            if (prev && d.dataUrl) prev.innerHTML = '<img src="' + d.dataUrl + '" alt="">';
            setTimeout(function () { location.reload(); }, 900);
          } else {
            toast((d && d.error) || 'آپلود ناموفق بود', 'err');
          }
        })
        .catch(function () { toast('خطا در آپلود فایل', 'err'); })
        .finally(function () { if (btn) { btn.disabled = false; btn.innerHTML = html; } });
    });
  });
})();

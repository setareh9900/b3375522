(function () {
  'use strict';
  var key = 'gf-admin-theme', allowed = ['copper', 'ocean', 'forest'], value = 'copper';
  try { var saved = localStorage.getItem(key); if (allowed.indexOf(saved) !== -1) value = saved; } catch (e) {}
  document.documentElement.setAttribute('data-admin-theme', value);
  document.addEventListener('DOMContentLoaded', function () {
    var select = document.getElementById('admin-theme-select');
    if (!select) return;
    select.value = value;
    select.addEventListener('change', function () {
      if (allowed.indexOf(select.value) === -1) return;
      document.documentElement.setAttribute('data-admin-theme', select.value);
      try { localStorage.setItem(key, select.value); } catch (e) {}
    });
  });
})();
